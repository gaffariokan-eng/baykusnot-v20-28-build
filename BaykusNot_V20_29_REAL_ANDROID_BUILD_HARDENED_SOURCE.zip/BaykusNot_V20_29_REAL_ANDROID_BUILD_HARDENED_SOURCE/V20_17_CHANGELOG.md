# BaykuşNot V20.17 Changelog

## P0/P1 — Öğrenci kâğıdı mutasyon/ilerleme yarış durumu
- Geçerli öğrenci kâğıtları varken yeni PDF/fotoğraf/kamera aktarımı başlatıldığında eski `canProceed=true` durumuyla sonraki aşamaya geçilebilmesi kapatıldı.
- Sayfa silme, öğrenci kimliği kaydetme, manuel sayfa eşleştirme, öğrenci seti silme ve tümünü temizleme işlemleri de tek `isProcessing` kapısına alındı.
- Bu mutasyonlardan biri tamamlanmadan `Devam Et` fail-closed kalır.
- Beklenmeyen repository istisnasında import/mutasyon ekranının sonsuza kadar `isProcessing=true` kalmaması için tüm asenkron kâğıt işlemlerine `try/finally` temizliği eklendi.

## UX doğruluğu
- Öğrenci kâğıdı ekranındaki “Sonraki adım” metni artık sınav türüne göre doğru yolu gösterir: Ödev -> Değerlendirme, Test -> Yerel Optik Okuma, diğerleri -> Değerlendirme Tercihleri.

## Denetim genişletmesi
- V20.17 full-flow audit öğrenci kâğıdı mutation gate için yeni kaynak kontrolleri içerir.
- `UploadPapersUiStateMutationGateTest` eklendi.

## Sürüm
- `versionCode=18`
- `versionName=1.15-v20.17`
- Aktif marker: `BAYKUSNOT_SOURCE_V20_17_PAPER_MUTATION_HARDENED.marker`
