# BaykuşNot V20.2 Changelog

## V20.1 sonrası gerçek kaynak değişiklikleri
1. **Yıllık YAZEK/veri kullanım kapısı güçlendirildi.** V20.1 onayı politika v2 ile bir kez geçersizlenir; kurum bilgilendirme/onam süreci ile gerçek öğrenci verisine uygun faturalandırılmış/kurumsal Gemini projesi birlikte doğrulanır.
2. **Ekonomik dönüt katmanı izole edildi.** Dönüt modeli ham cevap, soru metni, görüntü, rubrik, interpretedMeaning veya gradingEvidence alamaz; yalnız öğretmen onaylı puan ve kompakt `strengths/missingElements/misconceptions/nextSteps` teşhisini alır.
3. **Ana model prose çıktısı kaldırıldı.** Pahalı model uzun öğrenci dönütü üretmez; yalnız transkripsiyon, puan/kanıt/güven ve yapılandırılmış pedagojik teşhis üretir.
4. **Öğretmen onayı ağ dönütünü beklemez.** Puanlar hemen onaylanır; ayrıntılı dönüt Raporlar aşamasında hazırlanır.
5. **Dönüt başarısızlığı görünür ve retry edilebilir.** Eksik dönütler rapor üretimini engeller; `Yalnız Dönütleri Yeniden Dene` yalnız prose katmanını tekrar çalıştırır.
6. **Basit cevaplarda ücretsiz yerel dönüt.** Boş ve tam-doğru/temiz cevaplarda uygun olduğunda API çıktısı kullanılmaz; her öğrencide yine bütün sınavı yorumlayan genel değerlendirme üretilir.
7. **Tüm öğrenci dönütleri tek PDF.** Tek dosya yazdırırken iki kopya seçilerek öğrenci dağıtımı ve öğretmen fiziksel dosyası desteklenir. Cevap görüntüsü dönüt PDF'sine tekrar basılmaz.
8. **Batch gerçek öğretmen yoluna bağlandı.** Standard hızlı yol varsayılandır; gelişmiş model profilindeki ekonomik toplu değerlendirme tercihi gerçek değerlendirme başlangıcında uygulanır.
9. **Model/fiyat profili runtime oldu.** Ana okuma, dönüt, yardımcı model ve fiyat/batch katsayıları APK yeniden derlenmeden değiştirilebilir; `*-latest` reddedilir.
10. **Model benchmark otomasyonu eklendi.** `run_candidate.py` anonim vakaları seçilen sabit Gemini modelinde çalıştırıp usageMetadata tokenlarını kaydeder; `score_results.py` doğruluk+maliyet eşiğine göre `ADOPT/KEEP_BASELINE` üretir.
11. **Serbest ödev gizlilik kapısı.** Üst bölüm yerel olarak kırpılır; sayfa gövdesindeki olası kişisel veri için AI öncesi batch başına tek gizlilik doğrulaması istenir. Standart BaykuşNot sınav kâğıdına ekstra öğretmen işlemi eklenmez.
12. **Öğrenci görüntülerinde AES-256-GCM at-rest koruma.** Yeni yüklemeler Keystore anahtarıyla şifreli saklanır; eski düz görüntüler ilk okunmalarında best-effort şifreliye yükseltilir. Kamera ham JPEG'i yalnız `cacheDir` içinde geçici tutulur, kalıcı şifreli dosya oluşturulunca silinir.
13. **Öğretmen sonradan puan değiştirirse eski final durum geçersizleşir.** Eski onay/dönüt yeniden kullanılmaz.
14. **Remote Batch temizliği korunur.** Uzak input resource adı upload tamamlanır tamamlanmaz kalıcı metadata'ya yazılır ve terminal başarı/hata yollarında best-effort silinir.
15. **Maliyet ekranı Batch profilini tutarlı hesaplar.** Gelişmiş profil Batch seçtiğinde giriş fiyatı, açıklama ve cache süre varsayımı aynı effective Batch durumunu kullanır.

## Korunan ürün kararları
- AI önerisi resmî/final not değildir; nihai akademik karar öğretmendedir ve e-Okul/öğretmen güncel kaydı esastır.
- Öğrenci itirazı sonrası öğretmenin BaykuşNot'a yeniden girmesi zorunlu değildir.
- Fiziksel cevap kâğıdı + iki basılı dönüt nüshası ana arşiv düzenidir; uzun dönem dijital görüntü arşivi zorunlu değildir.
- İki sayfa tek uzun JPEG yapılmaz.
- Uzun kişisel dönüt BaykuşNot'un temel farklılaştırıcı özelliği olarak korunur.
