# BaykuşNot V20.16 Changelog

## Uçtan uca bağımsız yeniden denetim
- V20.15'in aktif beş sınav türü ve tüm ana workflow aşamaları yeniden incelendi: Yazılı, Dinleme, Test/Optik, Ödev ve Hazırbulunuşluk.
- Taslak oluşturma, kaynak alma, soru/rubrik kilidi, cevap kâğıdı, öğrenci kâğıdı yükleme, değerlendirme, öğretmen inceleme, rapor, rewind ve tam silme akışları yeniden doğrulandı.
- V20.15'in mevcut full-flow kontrolleri korunup V20.16'da yarış durumlarına özel yeni kontroller eklendi.

## P0/P1 — Cevap kâğıdı ayar/PDF yarış durumu
- Öğrenci sayısı, yerleşim yoğunluğu veya satır ayarı değiştirildikten hemen sonra PDF üretme/Devam tetiklenirse eski persisted ayarın kullanılabilmesi kapatıldı.
- Ayar değişir değişmez mevcut PDF artık güncel sayılmıyor.
- Ayar kaydı tamamlanana kadar PDF üretme ve Devam eylemleri kapalı.
- Konfigürasyon ve satır ayarı asenkron kayıtlarında `latest write wins`; önceki iş iptal edilip join edilmeden yenisi yazılmıyor.
- Satır override JSON dosyası `AtomicFile` ile crash-safe yazılıyor.

## P0/P1 — Öğretmen düzeltmesi/final onay yarış durumu
- Öğretmen puan değişikliği, test cevabı çözümleme, “çözüldü” işareti ve öğrenci/veli yeniden inceleme talebi işlemleri tek bir tracked-mutation kapısına alındı.
- Bir öğretmen düzeltmesi DB'ye tamamlanmadan `Sonuçları Onayla` çalışmıyor.
- Final onay hem ViewModel hem UI seviyesinde `isSavingChanges` durumuna bağlı olarak fail-closed.
- Böylece öğretmen değişikliğinin veya açık yeniden inceleme talebinin final bütünlük kontrolünden önce atlanması engellendi.

## Küçük UX doğruluğu
- Şube doğrulama hata metnindeki yanıltıcı `A-Z` ifadesi kaldırıldı; desteklenen Türkçe şube harfleri açıkça belirtildi.

## Denetim genişletmesi
- V20.16 full-flow audit cevap-kâğıdı yarış durumları için 7 ve öğretmen inceleme/final onay yarışı için 4 yeni kontrol içeriyor.
- Full-flow toplamı `89/89 PASS`.

## Sürüm
- `versionCode=17`
- `versionName=1.14-v20.16`
- Aktif marker: `BAYKUSNOT_SOURCE_V20_16_FLOW_RACE_HARDENED.marker`
