# BaykuşNot V20.3 Changelog

## V20.2 sonrası kapatılan son denetim maddeleri
1. **Yeni formlarda fail-closed anonimleştirme.** QR artık `V:3` taşır. V3/kimliği belirsiz formda dört referans işaretiyle güvenli hizalama sağlanamazsa AI'a görüntü gönderilmez; legacy yüzdelik crop yalnız açıkça eski BaykuşNot formu olduğu bilinen kayıtların geriye dönük yolu olarak kalır.
2. **Öğretmen puanı eski AI teşhisinden üstün.** Final dönüt isteğine `originalAiScore` da eklenir. Öğretmen puanı maddi biçimde yükselttiğinde eski deficit/misconception iddiaları; maddi biçimde düşürdüğünde eski aşırı praise iddiaları final prose öncesi bastırılır.
3. **Yazım/noktalama prose pahalı modelden çıkarıldı.** Ana model yalnız `writingStrengths`, `writingIssues`, `writingNextSteps` üretir. Öğrenciye yönelik yazım/anlatım metni onay sonrası ekonomik final katmanında yazılır.
4. **DB 23.** Yapılandırılmış yazım/anlatım teşhisleri `exam_student_evaluation` içinde üç ayrı liste alanında saklanır; `22→23` migration ve instrumentation testi eklendi.
5. **Toplu PDF rasterizasyonu kaldırıldı.** Bütün öğrenci raporları tek `PdfDocument` içine aynı doğrudan metin/vektör çizim fonksiyonuyla eklenir; 595×842 bitmap/PdfRenderer birleştirmesi kullanılmaz.
6. **EXIF yön normalizasyonu.** Kamera ve galeri görüntüleri şifreli kalıcı depoya geçmeden önce EXIF orientation'a göre döndürülür/çevrilir.
7. **Öğretmen ve AI aynı sayfa geometrisini görür.** Teacher Review ve AI Review önizlemeleri `ExamImagePrivacyProcessor` perspektif-düzeltilmiş preview yardımcılarını kullanır.
8. **El yazısı kaynak kalitesi yükseltildi.** PDF render genişliği 1240→2000 px, `RENDER_MODE_FOR_PRINT`; kalıcı şifreli JPEG üretim kalitesi 88→94.
9. **Cache fiyatları runtime profile taşındı.** `evaluationCachedInputPerMillionUsd` ve `cacheStoragePerMillionTokenHourUsd` gelişmiş model profilinden değiştirilebilir; 2027 fiyat değişimleri APK güncellemesi gerektirmez.
10. **Maliyet tahmini güncellendi.** Yapılandırılmış yazım teşhisi/ekonomik final prose ayrımı ve seçili Batch profili cache süresi/fiyatına yansıtıldı.
11. **Benchmark maliyet hesabı doğrulaştırıldı.** REST image alanı `inlineData` olarak düzeltildi, benchmark görüntüsü `MEDIA_RESOLUTION_HIGH` kullanır ve `thoughtsTokenCount` output maliyetine eklenir. Gerçek koşuda anonim `image_path + prompt_path` zorunludur.
12. **Uzun dönüt maliyet emniyet tavanı eklendi.** Dönüt seviyesi ve AI gerektiren soru sayısına göre dinamik `maxOutputTokens` kullanılır; ayrıntılı mod öğretmen gibi uzun dönüt için geniş kalırken kontrolsüz prose büyümesi engellenir.
13. **Statik QA genişletildi.** V20.3 fail-closed, EXIF, vektör PDF, öğretmen-score sanitization, yapılandırılmış yazım teşhisi, DB23 ve runtime cache fiyatlarını doğrudan kaynak davranışıyla denetler.

## V20.2'den korunan ana kararlar
- İki sayfa tek uzun JPEG yapılmaz; iki ayrı HIGH image part aynı öğrenci isteğinde kalır.
- Kimlik başlığı dış AI'a gönderilmez.
- Şüpheli soru yalnız kendi cevap alanıyla ikinci okunur.
- Öğretmen nihai puanı onaylamadan uzun dönüt üretilmez.
- Ekonomik dönüt modeli ham öğrenci cevabı/rubrik/görüntü görmez.
- Eksik dönüt görünür; yalnız dönüt yeniden denenebilir.
- Tüm bireysel dönütler tek PDF ve iki fiziksel nüsha kullanımını destekler.
- Yıllık YAZEK + uygun provider doğrulaması korunur.
- Öğrenci görüntüleri Keystore AES-256-GCM ile saklanır.
- Standard varsayılandır; ekonomik Batch gelişmiş profilden seçilebilir.
- İtiraz sonrası öğretmenin BaykuşNot'a dönmesi zorunlu değildir; e-Okul/öğretmen güncel kaydı nihai kayıttır.

## Sürüm
- `versionCode=5`
- `versionName=1.3-v20.3`
- Room schema `23`
