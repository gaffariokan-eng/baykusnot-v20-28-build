# BaykuşNot V20.7 — YAZEK Compliance Hardening Changelog

V20.7, V20.6 üzerindeki YAZEK/mahremiyet/üretim güvenliği denetiminde kalan P0/P1 açıklarını kaynak seviyesinde kapatır. Temel öğretmen akışı değiştirilmemiştir.

## 1. YAZEK beyanı artık kapsam-bağlı ve fail-closed
- Eğitim yılına bağlı tek checkbox kaldırıldı.
- `YazekDeclarationScope`: kurum, ders, sınıf, sınav türü/uygulama kapsamı, hedef şubeler, eğitsel amaç ve AI aracını fingerprint içine alır.
- Kapsam/eğitsel amaç/AI aracı/hedef kitle değişirse önceki doğrulama geçerli sayılmaz.
- Eksik kurum/ders/sınıf/hedef şube/kapsam/amaç/AI aracı varsa kapsam doğrulanamaz ve öğrenci verisi AI'a gönderilemez.
- Resmî YAZEK işleminin yerine geçmediği UI'da açıkça yazılır; opsiyonel resmî beyan/kurum takip referansı kaydedilebilir.
- Gerçek AI kullanımı başladığında sınava `exam_yazek_declaration` audit snapshot'ı bağlanır.

## 2. Tam sınav silme
- Eski yalnız-DB silme yolu `ExamDeletionRepository.deleteExamCompletely()` orkestrasyonuna bağlandı.
- Yönetilen öğrenci görüntüleri, sınav kaynak/dinleme alanı, teacher-rubric meta, satır override'ları, gizlilik maskeleri ve Batch yerel kayıtları temizlenir.
- Uygun credential varsa uzak Batch/file cleanup best-effort denenir; credential yoksa yerel Batch kaydı yine silinir.
- Öğretmenin bilinçli olarak dışarı aktardığı rapor/PDF dosyaları uygulama özel alanı dışında bırakılır.

## 3. Öğrenci/veli yeniden inceleme kaydı
- `exam_review_request` tablosu eklendi.
- Talep eden, gerekçe, talep öncesi/sonrası puan, durum, tarih ve öğretmen sonuç notu audit edilir.
- Teacher Review ekranına talep açma ve kapatma akışı eklendi.
- Bu yerel yeniden inceleme kaydı resmî YAZEK etik ihlal başvuru sürecinin yerine geçmez.

## 4. Açıklanabilirlik
- Teacher Review ekranında `interpretedMeaning` ve `gradingEvidence` görünür hale getirildi.
- Öğretmen modelin cevaptan ne çıkardığını ve puanlama/rubrik kanıtını inceleyebilir.

## 5. AI arızasında manuel B planı
- Yazılı/dinleme/ödev değerlendirmesinde `AI Olmadan Manuel Değerlendirmeye Geç` yolu eklendi.
- Manuel yol `MANUAL` cevap türüyle açıkça işaretlenir; AI teşhisi varmış gibi gösterilmez.
- Çoktan seçmeli sınavlar mevcut yerel optik/deterministik akışta kalır.

## 6. Production Gemini secret güvenliği
- Release build `ALLOW_DIRECT_GEMINI=false`.
- `BAYKUS_AI_GATEWAY_URL` yoksa release AI çağrıları fail-closed durur.
- Gateway modunda cihazda upstream Gemini secret saklanmaz; legacy `apiKey` parametresi yalnız non-secret placeholder alır ve interceptor tarafından upstream isteğinden çıkarılır.
- Tüm doğrudan Gemini çağrılarındaki `?key=...` URL kullanımı kaldırıldı; debug/test yolunda `x-goog-api-key` header kullanılır.
- `docs/SECURE_AI_GATEWAY_REQUIREMENTS.md` production gateway/auth sözleşmesini tanımlar.
- Gerçek authenticated gateway deploy'u bu Android kaynak paketinin dışında olduğu için production AI kabulü `BLOCKED_EXTERNAL_INFRA` olarak kalır.

## 7. SQLCipher Room şifreleme
- `net.zetetic:sqlcipher-android:4.18.0` + AndroidX SQLite 2.7.0 eklendi.
- 32-byte rastgele DB passphrase Android Keystore AES-256-GCM ile korunur.
- Mevcut plaintext Room DB açılmadan önce `sqlcipher_export()` ile şifreli kopyaya dönüştürülür.
- Şifreli kopya `sqlite_master` ve `user_version` ile doğrulanmadan orijinal DB değiştirilmez; dönüşüm başarısızsa plaintext ile devam edilmez.
- Room `SupportOpenHelperFactory` üzerinden SQLCipher ile açılır.
- `DatabaseEncryptionManagerTest` instrumented migration testi eklendi.
- Fiziksel cihazda V20.6→V20.7 gerçek veri migrationı çalıştırılmadan bu madde production PASS değildir (`DEVICE_TEST_REQUIRED`).

## 8. YAZEK içerik politikası
- Evaluation ve feedback promptlarına ortak `YazekContentPolicy` eklendi.
- Kimlik/korunan özellik/sosyoekonomik çıkarım, aşağılayıcı-ötekileştirici dil, ideolojik yönlendirme ve rubrik dışı değer yargısı puan kriteri yasaklanır.
- Millî Eğitimin genel amaç ve temel ilkelerine, millî/manevi/kültürel değerlere saygı üretim talimatına bağlanır.
- Yerel çıktı doğrulaması açık kimlik-temelli saldırı kalıplarını reddeder.

## 9. Benchmark kapsayıcılık/fairness sertleştirmesi
- Evaluation production approval artık en az 20 benzersiz `REAL_ANONYMIZED` vaka + kategori/sınıf kapsamı ister.
- Zor el yazısı/düşük görüntü kalitesi, silinti-düzeltme ve Türkçe karakter kapsaması evaluation coverage gate'e girdi.
- Feedback benchmarkı farklı feedback kategorileri, en az iki grade band, misconception ve teacher-modified vakalarını ister.
- Authoring benchmarkı extraction/rubric/objective görevlerinin tamamı + en az iki grade band ister.
- Approval record `coverage=PASS` olmadan üretim onayı vermez.
- Paketteki tek örnek `SYNTHETIC_EXAMPLE`; hiçbir production approval veremez.

## 10. Gizlilik ve erişilebilirlik sertleştirmesi
- `FLAG_SECURE` ile ekran görüntüsü/screen capture hassas öğrenci ekranlarında uygulama çapında engellenir.
- Batch File API payload'ı plaintext JSONL temp dosyasına yazılmadan streaming RequestBody ile gönderilir.
- TalkBack/200% font/focus/semantics için `docs/ACCESSIBILITY_ACCEPTANCE_TEST.md` eklendi. Gerçek cihaz kabulü yine gereklidir.

## 11. Room schema
- DB version: 27.
- 25→26: authoring fiyat snapshot kolonları.
- 26→27: `exam_review_request` + `exam_yazek_declaration`.
- Exported schema 26/27 ancak başarılı Room/KSP build'den sonra üretilebilir; bu ortamda Gradle dağıtımı indirilemediği için `BLOCKED_ENV`.

## Sürüm
- `versionCode=9`
- `versionName=1.6-v20.7`
