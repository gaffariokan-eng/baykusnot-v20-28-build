# V20.16 Requirements Matrix

| Gereksinim | V20.16 karşılığı | Durum |
|---|---|---|
| Ana sayfadan gerçek akışa devam | `Screen.Workflow(draftId)` | PASS |
| Geri dönüş DB'de persist edilsin | `WorkflowViewModel.selectStage()` persisted rewind | PASS |
| Rewind sırasında stale AI/Batch sonucu yazılmasın | `stopEvaluationAndAwait` + reset + stage guards | PASS |
| Yerel optik rewind sonrası stale yazmasın | persisted `AI_EVALUATION` write guards | PASS |
| Kaynak değişince eski soru seti kullanılmasın | `invalidateUnlockedQuestionSet` + fail-closed extraction | PASS |
| Yeni extraction staging seti öncelikli olsun | unlocked staging-first review | PASS |
| Mapping onayı cross-ref ile atomik geçersizleşsin | Room transaction | PASS |
| Soru toplamı/rubrik revision yeniden doğrulansın | Workflow contract guards | PASS |
| Dinleme kaynağı değişince downstream soru yapısı invalid olsun | `ListeningMaterialViewModel` invalidation | PASS |
| Ödev yarım kilitle ilerlemesin | question + rubric + preferences triple lock | PASS |
| Test akışı AI yerine yerel optik politikayı uygulasın | Test answer-key + optical workflow | PASS |
| Eski basılı cevap formu reddedilsin | QR V4 + SHA-256 form token + `STALE_FORM` | PASS |
| Manuel eşleştirme stale formu aşamasın | repository + UI status guard | PASS |
| QR üretimi hata verirse form üretilmesin | fail-closed `QrCodeGenerator` | PASS |
| Cevap kâğıdı ayarı değişince eski PDF güncel kalmasın | synchronous `isPdfUpToDate=false` | PASS |
| Cevap kâğıdı ayarı kaydolmadan PDF üretilmesin | `isSavingSettings` gate | PASS |
| Cevap kâğıdı ayarı kaydolmadan Devam edilemesin | ViewModel/UI/Route gate | PASS |
| Hızlı cevap-kâğıdı ayar değişimlerinde son değişiklik kazansın | cancel+join revisioned jobs | PASS |
| Satır override dosyası crash-safe olsun | `AtomicFile` | PASS |
| Öğrenci kâğıdı importu process-death güvenli olsun | durable import journal + recovery | PASS |
| Import eşzamanlı mutasyonlara kapalı olsun | single-operation guards | PASS |
| Çoklu görsel OOM/zip-bomb riski sınırlansın | streaming ZIP + 100 item / 50 MB | PASS |
| Test öğretmen anahtarı yanlış/eski formu reddetsin | versioned teacher-key QR token | PASS |
| Öğretmen puan düzeltmesi tamamlanmadan final onay yapılmasın | tracked mutation + `isSavingChanges` | PASS |
| Öğrenci/veli yeniden inceleme talebi yazılmadan final onay yapılmasın | tracked mutation + final gate | PASS |
| Açık yeniden inceleme varken final onay olmasın | final integrity review-request gate | PASS |
| Raporlar nihai bütünlüğü tekrar kontrol etsin | `checkFinalResultsIntegrity` | PASS |
| YAZEK beyan + veri bilgilendirme/onam kapısı | iki ayrı fail-closed doğrulama | PASS_SOURCE |
| Öğretmen nihai karar verici olsun | teacher review + correction + final confirm gates | PASS_SOURCE |
| Crash-safe tam silme | PREPARED/COMMITTED deletion journal | PASS |
| Şifreli öğrenci görüntüsü | AES-256-GCM / Android Keystore | PASS_SOURCE |
| DB şifreleme/migration fail-closed | SQLCipher conversion/recovery path | PASS_SOURCE |
| Android backup öğrenci verisini dışarı taşımamalı | `allowBackup=false` + extraction/backup rules | PASS_SOURCE |
| Release telefonda kalıcı Gemini key istememeli | authenticated HTTPS gateway policy | PASS_SOURCE |
| Statik audit | 150/150 | PASS |
| Semantik audit | 9/9 | PASS |
| Transactional audit | 23/23 | PASS |
| Runtime/lifecycle audit | 21/21 | PASS |
| Process-death audit | 18/18 | PASS |
| Deletion journal audit | 15/15 | PASS |
| YAZEK/onam audit | 16/16 | PASS |
| Compile-risk audit | 14/14 | PASS |
| V20.16 full-flow audit | 89/89 | PASS |
| Kotlin PSI syntax | 311/311 | PASS |
| Constructor/Factory call-shape | 1539/1539 | PASS |
| Android XML parse | 14/14 | PASS |
| Secret/private-key scan | 0 findings | PASS |
| Room migration validator | exported 21→25 + 25→28 SQL validation | PASS_STATIC |
| Gerçek Gradle/Android compile | `services.gradle.org` DNS çözülemiyor | BLOCKED_ENV |
| Room final schema 28 KSP export | gerçek Android/KSP build gerekli | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | kurum/backend altyapısı gerekli | BLOCKED_EXTERNAL_INFRA |
| TalkBack / %200 font / kamera / picker smoke | gerçek Android cihaz gerekli | DEVICE_TEST_REQUIRED |
| 20+ gerçek anonim öğretmen benchmarkı | gerçek veri + öğretmen ground-truth gerekli | BLOCKED_REAL_DATA |
