# BaykuşNot V20.16 release output

Bu kaynak teslimi APK içermez. `BAYKUSNOT_BUILD_V20_16_RELEASE_APK.bat`, gerçek Windows/Android build ortamında HTTPS authenticated gateway, provider-policy ve release signing değişkenleri sağlandığında release APK üretmeyi dener.

Yerel compile/smoke için `BAYKUSNOT_BUILD_V20_16_LOCAL_TEST_ONLY.bat` kullanılabilir. Bu debug APK yalnız sentetik/demo veri içindir; gerçek öğrenci verisiyle kullanılmamalıdır.

Release AI trafiği telefonda kalıcı Gemini anahtarı kullanmaz ve geçerli gateway oturumu/veri koruma profili olmadan fail-closed davranır.
