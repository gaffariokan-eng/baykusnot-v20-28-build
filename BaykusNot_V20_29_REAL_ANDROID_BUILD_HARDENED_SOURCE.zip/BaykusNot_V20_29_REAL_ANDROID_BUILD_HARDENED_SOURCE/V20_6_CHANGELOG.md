# BaykuşNot V20.6 Changelog

## Amaç
V20.5 sonrası bağımsız çapraz denetimde bulunan gizlilik, Android device-transfer, maliyet, audit, öğretmen puan değişikliği ve benchmark yönetişimi açıklarını kapatmak.

## P0 — Gizlilik / veri aktarımı
1. **Legacy form privacy fail-closed**
   - Privacy sayfası ancak preview başarıyla üretildikten sonra “görüldü” sayılır.
   - N/N sayfa görülmeden UI onayı aktif olmaz.
   - Repository, UI'dan bağımsız olarak tüm sayfaların görüldüğünü ve her preview'ın yeniden üretilebildiğini doğrular.
2. **Homework privacy fail-closed**
   - Her şifreli sayfa decode edilebilmeden ve öğretmen tarafından görülmeden onay yazılamaz.
3. **Android 12+ device-transfer**
   - `data_extraction_rules.xml` içinde root/file/database/sharedpref/external açıkça exclude edilir.
4. **FileProvider daraltma**
   - Genel cache/files/external kök paylaşımı kaldırıldı; yalnız kullanılan çıktı/geçici klasörleri tanımlı.

## P1 — Maliyet ve AI audit
1. **Batch + cached-input matematiği düzeltildi**
   - Uncached input ve output/thinking Batch faktörü alır.
   - Cached input standart cached-input tarifesinde kalır.
2. **Authoring pricing profile**
   - input/output/cached-input fiyatları modele ve sınav run profile snapshot'ına eklendi.
3. **Ortak authoring usage ledger**
   - Question extraction, scenario extraction, objective matching, rubric generation/source extraction/audit çağrıları token/model/response/status/maliyet kayıtlarına girer.
4. **Call-time requested model snapshot**
   - Authoring çağrısında kullanılan istenen model çağrı başlamadan yakalanır; provider gerçek model bilgisi ayrı tutulur.

## P1 — Öğretmen nihai otoritesi
- Manuel soru puanı değişikliği tek Room transaction'a alındı.
- Aynı transaction içinde soru puanı, toplam, teacher approval ve final feedback invalidasyonu birlikte commit edilir.
- Büyük değişiklikte (>= max(1 puan, soru max puanının %20'si)) eski AI teşhis alanları stale kabul edilip temizlenir.

## P1 — Benchmark yönetişimi
- BN-BENCH-2 production onayı yerine role-bound BNBENCH3:
  - `BN-EVAL-B`
  - `BN-FEEDBACK-B`
  - `BN-AUTHOR-B`
- Evaluation capability profile binding korunur.
- Eski V2 kayıtları production approval sağlamaz.
- Minimum 20 `REAL_ANONYMIZED` vaka olmadan ADOPT üretilemez.
- Paket örneği `SYNTHETIC_EXAMPLE` olarak etiketlidir.
- Feedback ve authoring scorer'ları kalite metriklerine ek olarak token/kestirilen maliyet raporlar.

## P1/P2 — Rapor ve beyan
- Çoktan seçmeli local-optical sınavda AI değerlendirme kullanılmadıysa PDF bunu açıkça belirtir.
- AI yalnız authoring'de kullanıldıysa öğrenci puanlamasının yerel olduğu ayrıştırılır.
- YAZEK beyanı authoring/evaluation/feedback rollerinin tamamını kapsar.
- Provider model retirement zamanı/status mesajı görünür uyarıya dönüşür.

## Room
- DB version 25→26.
- `exam_ai_run_profiles` için authoring input/output/cached-input fiyat snapshot sütunları eklendi.
- Migration SQL kaynak doğrulaması PASS; Room/KSP tarafından üretilecek schema 26 dosyası gerçek Gradle build bekliyor.

## Bilinçli olarak tamamlanmamış işler
- **SQLCipher:** DEFERRED; gerçek Android upgrade/migration testi yapılmadan açılmadı.
- **20+ gerçek anonim benchmark dataset:** BLOCKED_REAL_DATA; sentetik veri gerçekmiş gibi üretilmedi.
- **Gerçek Gradle/KSP/APK build:** BLOCKED_ENV; Gradle 9.3.1 dağıtımı dış ağ/DNS engeli nedeniyle indirilemedi.
