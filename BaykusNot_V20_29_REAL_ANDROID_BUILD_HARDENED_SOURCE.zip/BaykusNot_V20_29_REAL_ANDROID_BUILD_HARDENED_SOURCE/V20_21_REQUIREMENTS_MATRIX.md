# BaykuşNot V20.21 Requirements Matrix

| Requirement | Implementation | Status |
|---|---|---|
| Benchmark approval cannot be forged with a public checksum | ECDSA P-256 BNBENCH4 signature verification | PASS_SOURCE |
| Private approval key must not ship in source/APK | external `--private-key`; source secret scan | PASS_SOURCE/SCAN |
| Clean production build contains verified role approvals | BuildConfig signed manifest + `verifyReleaseModelApprovals` | PASS_SOURCE; REAL_DATA_REQUIRED |
| Approval must be role-bound | EVALUATION / FEEDBACK / AUTHORING | PASS_SOURCE |
| Approval must require real anonymous data | `REAL_ANONYMIZED` + >=20 + coverage | PASS_SOURCE |
| Approval must enforce role quality thresholds | build-time + runtime threshold validation | PASS_SOURCE |
| Evaluation approval must bind media/Batch/cache/thinking capability | highTokens/highMedia/batch/cache/thinking binding | PASS_SOURCE |
| Expired approval must stop new network use | expiry-bearing registry snapshot + runtime revalidation | PASS_SOURCE |
| Locked exam profile must not outlive approval | `ensureAiRunProfile` revalidates all roles + capability | PASS_SOURCE |
| Production teacher should not manage benchmark hashes/codes | signed release manifest; manual entry DEBUG-only | PASS_SOURCE |
| Legacy hidden evaluation controls must not contradict Teacher Mode | Room 29->30 canonical migration + runtime normalization | PASS_STATIC |
| Teacher-owned writing/punctuation/feedback choices preserved | migration excludes those fields | PASS_STATIC |
| Long evaluation intent must survive process death | durable run-state table | PASS_SOURCE |
| User pause must stay paused | PAUSED state excluded from auto-resume | PASS_SOURCE |
| Large classes should avoid hundreds of fragile sequential requests | 50+ auto recoverable Batch where supported | PASS_SOURCE |
| Completed student results must not be duplicated after recovery | transactional result reuse / Batch ledger recovery | PASS_SOURCE |
| Five active exam types remain routed | Written/Listening/MC/Homework/Readiness | 25/25 PASS |
| YAZEK declaration/consent remains fail-closed | existing per-exam scope/fingerprint dual gate | 16/16 + 47/47 PASS |
| Teacher remains final decision maker | review/correction/final approval gates | PASS_SOURCE |
| Static audit | active V20.21 audit | 191/191 PASS |
| Full-flow | active V20.21 flow audit | 98/98 PASS |
| Governance negative audit | tamper/wrong-key/expiry/durable controls | 24/24 PASS |
| Transactional audit | active general audit | 23/23 PASS |
| Runtime/lifecycle | active general audit | 21/21 PASS |
| Process-death | active V20.21 audit | 18/18 PASS |
| Deletion journal | active V20.21 audit | 15/15 PASS |
| Kotlin PSI | all Kotlin sources | 320/320 PASS |
| Constructor/factory call-shape | all Kotlin sources | 1544/1544 PASS |
| Android XML | parse validation | 14/14 PASS |
| Secret/private key scan | main source | 0 findings |
| Room migration | exported 20->25 + SQL 25->30 | PASS_STATIC |
| Real Gradle/Kotlin/KSP build | Gradle distribution fetch | BLOCKED_ENV |
| Final Room 30 KSP schema export | real build required | BUILD_REQUIRED |
| Real device SQLCipher/accessibility/500-student smoke | physical Android device | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway/backend | external institution infrastructure | BLOCKED_EXTERNAL_INFRA |
| Real role benchmark + release signing | 20+ anonymized teacher ground truth per role | BLOCKED_REAL_DATA |
