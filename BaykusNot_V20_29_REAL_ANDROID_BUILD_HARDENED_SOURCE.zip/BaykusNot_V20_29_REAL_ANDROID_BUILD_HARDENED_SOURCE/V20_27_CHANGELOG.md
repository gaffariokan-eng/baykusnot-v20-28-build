# BaykuşNot V20.27 — Compile / Authoring / Feedback / Memory Hardened

V20.26 bağımsız kaynak denetiminde bulunan ve önceki PASS testlerinin yakalamadığı açıkları kapatır.

## Kaynak düzeltmeleri

1. **Gerçek Kotlin compile riski kapatıldı.** `RubricViewModel.processUploadedDocument()` block-body/implicit-Unit fonksiyonundaki `return Result.failure(...)` kaldırıldı; legacy `.doc` kolu mesaj yayımlayıp yalnız `return` ile çıkıyor.
2. **Evaluation dışındaki AI HTTP çağrıları coroutine-cancellable oldu.** Soru çıkarma, senaryo çıkarma, hedef eşleme, rubrik üretme, final feedback ve bağlantı testi yolları `OkHttpClient.executeCancellable()` kullanıyor; parent coroutine iptali gerçek `Call.cancel()` çağrısına bağlı.
3. **Batch remote helper cancellation yutması kapatıldı.** `remoteCancel`, `remoteGetBatchSnapshot`, `remoteDeleteBatch`, `remoteDeleteFileConfirmed` ve remote-operation listing `CancellationException`'ı `false/null`a çevirmiyor.
4. **Authoring lifecycle stage-bound hale getirildi.** Upload Source, Question Points ve Rubric AI Job'ları stage değişiminde ve Compose ekran dispose olduğunda iptal ediliyor. Provider dönüşünden sonra stage yeniden doğrulanmadan staging/persistence yapılmıyor.
5. **Question/Rubric coordinator stage validator eklendi.** AppContainer production wiring sırasıyla `UPLOAD_SOURCE` ve `RUBRIC` stage'lerine bağlı.
6. **Final feedback stale-write yarışı transaction içinde kapatıldı.** Commit yalnız `REPORTS` stage, öğretmen-onaylı öğrenci snapshot'ı ve soru-evaluation snapshot'ı değişmemişse gerçekleşiyor; tüm soru feedback anahtarlarının da birebir eşleşmesi gerekiyor.
7. **Final feedback provider işi aktif lifecycle'a bağlandı.** Reports stage'inden çıkış veya ekran dispose aktif feedback Job'ını iptal ediyor; repository her öğrenci öncesi cancellation ve REPORTS stage'i tekrar kontrol ediyor.
8. **Test cevap anahtarı metin içe aktarımı bounded streaming'e geçirildi.** `readText().take(...)` ile önce tüm dosyayı RAM'e alma kaldırıldı.
9. **Öğretmen cevap anahtarı PDF bellek modeli düzeltildi.** Önce yalnız sayfa sayısı doğrulanıyor; sonra her sayfa tek tek render/read/recycle ediliyor. Sayfa boyutu, oranı ve render yüksekliği sınırlandırılıyor.
10. **Batch/cache dahili audit ledger okumaları bounded fail-closed oldu.** Bozulmuş/aşırı büyümüş app-private JSON kayıtları sınırsız `readText()` ile RAM’e alınmıyor; yazma boyutu da sınırlandırılıyor.
11. **V20.27 benchmark governance fingerprint'leri yenilendi.** EVALUATION/FEEDBACK/AUTHORING engine revision'ları V20.27'ye bağlı.

## Sürüm

- versionCode: 28
- versionName: 1.25-v20.27
- targetSdk: 36
- Room schema: 30 (değişmedi; yeni migration gerekmedi)

## Build durumu

`./gradlew :app:assembleDebug --stacktrace` gerçek build denemesi `services.gradle.org` DNS çözümleme hatası nedeniyle Gradle dağıtımı indirilmeden duruyor. Kotlin/KSP/Compose/Room compiler aşamasına ulaşılamadığı için bu kapı `BLOCKED_ENV` olarak kalır; PASS değildir.
