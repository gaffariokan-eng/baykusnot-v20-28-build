package com.example.core.data

import android.content.Context

/**
 * Synchronous process-death guard for explicit teacher pause requests.
 *
 * Room remains the canonical run-state ledger. This committed marker closes the narrow crash
 * window between the UI pause tap and the coroutine/Room cancellation path.
 * It contains only an exam id marker, never student content.
 */
class EvaluationPauseGuard(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "evaluation_pause_guard_v1",
        Context.MODE_PRIVATE
    )

    fun markPaused(examDraftId: Long): Boolean {
        require(examDraftId > 0L)
        return prefs.edit().putBoolean(key(examDraftId), true).commit()
    }

    fun clearPause(examDraftId: Long): Boolean {
        require(examDraftId > 0L)
        return prefs.edit().remove(key(examDraftId)).commit()
    }

    fun isPaused(examDraftId: Long): Boolean =
        examDraftId > 0L && prefs.getBoolean(key(examDraftId), false)

    private fun key(examDraftId: Long) = "exam_$examDraftId"
}
