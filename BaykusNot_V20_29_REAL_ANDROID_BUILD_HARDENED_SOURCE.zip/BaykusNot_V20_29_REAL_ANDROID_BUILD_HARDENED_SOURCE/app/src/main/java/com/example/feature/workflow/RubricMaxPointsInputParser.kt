package com.example.feature.workflow

sealed interface RubricMaxPointsParseResult {

    data class Parsed(
        val maxPoints: Int
    ) : RubricMaxPointsParseResult

    data class Rejected(
        val code: RubricInputIssueCode
    ) : RubricMaxPointsParseResult
}

object RubricMaxPointsInputParser {

    private val MAX_POINTS_REGEX = Regex("^[+-]?[0-9]+$")

    fun parse(value: String): RubricMaxPointsParseResult {
        val normalized = value.trim()
        if (normalized.isEmpty()) {
            return RubricMaxPointsParseResult.Rejected(RubricInputIssueCode.BLANK_MAX_POINTS)
        }
        if (!MAX_POINTS_REGEX.matches(normalized)) {
            return RubricMaxPointsParseResult.Rejected(RubricInputIssueCode.INVALID_MAX_POINTS_FORMAT)
        }
        val parsedLong = normalized.toLongOrNull()
            ?: return RubricMaxPointsParseResult.Rejected(RubricInputIssueCode.MAX_POINTS_OUT_OF_RANGE)

        if (parsedLong < Int.MIN_VALUE.toLong() || parsedLong > Int.MAX_VALUE.toLong()) {
            return RubricMaxPointsParseResult.Rejected(RubricInputIssueCode.MAX_POINTS_OUT_OF_RANGE)
        }
        return RubricMaxPointsParseResult.Parsed(maxPoints = parsedLong.toInt())
    }
}
