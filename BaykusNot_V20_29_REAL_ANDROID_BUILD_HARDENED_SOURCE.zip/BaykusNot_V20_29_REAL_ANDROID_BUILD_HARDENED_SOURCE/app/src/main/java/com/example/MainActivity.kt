package com.example
import androidx.compose.ui.graphics.drawscope.scale
import com.example.core.ui.drawCanonicalOwl

import android.os.Bundle
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.core.model.ExamType
import com.example.core.navigation.Screen
import com.example.core.ui.WiseOwlLogo
import com.example.feature.examtype.ExamTypeSelectionScreen
import com.example.feature.home.HomeScreen
import com.example.feature.home.HomeViewModel
import com.example.feature.profile.ProfileScreen
import com.example.feature.profile.ProfileViewModel
import com.example.feature.settings.ApiKeySettingsScreen
import com.example.feature.settings.ApiKeySettingsViewModel
import com.example.feature.workflow.NewDraftScreen
import com.example.feature.workflow.NewDraftViewModel
import com.example.feature.workflow.WorkflowScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.WiseAmberSecondary
import com.example.ui.theme.WiseNavyPrimary
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        enableEdgeToEdge()
        val evaluatorApplication = applicationContext as EvaluatorApplication
        setContent {
            MyApplicationTheme {
                var recoveryMessage by remember { mutableStateOf(evaluatorApplication.currentStartupBlockingMessage()) }
                if (recoveryMessage != null) {
                    StartupSafetyRequiredScreen(
                        message = recoveryMessage!!,
                        canResetLocalData = evaluatorApplication.destructiveLocalResetAllowed(),
                        onRetry = { recoveryMessage = evaluatorApplication.retryStartupChecks() },
                        onCopyDiagnostic = {
                            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("BaykuşNot tanı", evaluatorApplication.safeStartupDiagnostic()))
                            Toast.makeText(this@MainActivity, "Güvenli tanı bilgisi kopyalandı.", Toast.LENGTH_SHORT).show()
                        },
                        onResetLocalData = {
                            val manager = getSystemService(ActivityManager::class.java)
                            if (!manager.clearApplicationUserData()) {
                                Toast.makeText(this@MainActivity, "Yerel veriler sıfırlanamadı. Android Ayarları > Uygulamalar > BaykuşNot > Depolama bölümünü kullanın.", Toast.LENGTH_LONG).show()
                            }
                        },
                        onCloseApp = { finishAffinity() }
                    )
                    return@MyApplicationTheme
                }
                val appContainer = evaluatorApplication.container
                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = Screen.Splash) {
                    composable<Screen.Splash> {
                        SplashScreen(onTimeout = {
                            navController.navigate(Screen.Home) {
                                popUpTo(Screen.Splash) { inclusive = true }
                            }
                        })
                    }
                    composable<Screen.Home> {
                        val viewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(appContainer.teacherProfileRepository, appContainer.examDraftRepository))
                        HomeScreen(
                            viewModel = viewModel,
                            onNavigateToNewExam = { examType -> navController.navigate(Screen.NewDraft(examTypeId = examType.name)) },
                            onNavigateToProfile = { navController.navigate(Screen.Profile) },
                            onNavigateToDraft = { draftId -> navController.navigate(Screen.Workflow(draftId)) }
                        )
                    }
                    composable<Screen.ExamTypeSelection> {
                        ExamTypeSelectionScreen(
                            onExamTypeSelected = { typeId -> navController.navigate(Screen.NewDraft(examTypeId = typeId)) },
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    composable<Screen.Profile> {
                        val viewModel: ProfileViewModel = viewModel(factory = ProfileViewModel.Factory(appContainer.teacherProfileRepository))
                        ProfileScreen(
                            viewModel = viewModel,
                            onNavigateBack = { navController.popBackStack() },
                            onNavigateToApiKeySettings = { navController.navigate(Screen.ApiKeySettings) }
                        )
                    }
                    composable<Screen.ApiKeySettings> {
                        val viewModel: ApiKeySettingsViewModel = viewModel(
                            factory = ApiKeySettingsViewModel.Factory(
                                secureApiKeyStore = appContainer.secureApiKeyStore,
                                storedApiKeyConnectionChecker = appContainer.storedApiKeyConnectionChecker,
                                modelQualityPreferenceStore = appContainer.modelQualityPreferenceStore,
                                geminiModelProfileStore = appContainer.geminiModelProfileStore,
                                yazekComplianceStore = appContainer.yazekComplianceStore,
                                gatewaySessionManager = appContainer.gatewaySessionManager,
                                geminiBatchJobManager = appContainer.geminiBatchJobManager,
                                geminiCacheManager = appContainer.geminiCacheManager
                            )
                        )
                        ApiKeySettingsScreen(
                            viewModel = viewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    composable<Screen.NewDraft> { backStackEntry ->
                        val args = backStackEntry.toRoute<Screen.NewDraft>()
                        val viewModel: NewDraftViewModel = viewModel(
                            factory = NewDraftViewModel.Factory(
                                appContainer.examDraftRepository, 
                                appContainer.teacherProfileRepository,
                                appContainer.examDeletionRepository,
                                appContainer.examObjectiveRepository,
                                args.examTypeId, 
                                args.draftId
                            )
                        )
                        NewDraftScreen(
                            viewModel = viewModel,
                            isEditMode = args.draftId != 0L,
                            onNavigateBack = { navController.popBackStack() },
                            onNavigateToWorkflow = { draftId -> 
                                navController.navigate(Screen.Workflow(draftId)) {
                                    popUpTo(Screen.Home)
                                }
                            }
                        )
                    }
                    composable<Screen.Workflow> { backStackEntry ->
                        val args = backStackEntry.toRoute<Screen.Workflow>()
                        WorkflowScreen(
                            draftId = args.draftId,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StartupSafetyRequiredScreen(
    message: String,
    canResetLocalData: Boolean,
    onRetry: () -> Unit,
    onCopyDiagnostic: () -> Unit,
    onResetLocalData: () -> Unit,
    onCloseApp: () -> Unit
) {
    var showResetConfirmation by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Güvenli başlatma durduruldu",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = message + "\n\nMevcut veriler otomatik olarak silinmedi, sıfırlanmadı veya yeniden anahtarlanmadı.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                Text("Tekrar dene")
            }
            androidx.compose.material3.OutlinedButton(onClick = onCopyDiagnostic, modifier = Modifier.fillMaxWidth()) {
                Text("Güvenli tanı bilgisini kopyala")
            }
            if (canResetLocalData) {
                androidx.compose.material3.OutlinedButton(
                    onClick = { showResetConfirmation = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Yeni kurulum için yerel verileri sıfırla")
                }
            }
            androidx.compose.material3.TextButton(onClick = onCloseApp) {
                Text("Uygulamayı kapat")
            }
        }
    }

    if (showResetConfirmation) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showResetConfirmation = false },
            title = { Text("Tüm yerel veriler silinecek") },
            text = {
                Text(
                    "Bu işlem mevcut şifreli veritabanını, öğrenci görüntülerini, yerel ayarları ve diğer BaykuşNot uygulama verilerini geri döndürülemez biçimde siler. " +
                        "Kurtarma anahtarınız yoksa eski veriler sonradan geri getirilemez. Yalnız yeni ve boş bir kurulumla devam etmek istediğinizden eminseniz onaylayın."
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    showResetConfirmation = false
                    onResetLocalData()
                }) { Text("Tüm yerel verileri kalıcı olarak sil") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showResetConfirmation = false }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    var animTimeMs by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val startTime = System.currentTimeMillis()
        while (animTimeMs < 2500f) {
            val elapsed = System.currentTimeMillis() - startTime
            animTimeMs = elapsed.coerceAtMost(2500).toFloat()
            if (animTimeMs >= 2500f) break
            kotlinx.coroutines.delay(16)
        }
        onTimeout()
    }

    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.background,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
            MaterialTheme.colorScheme.background
        )
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        val owlSize = minOf(
            maxWidth - 20.dp,
            maxHeight * 0.48f,
            340.dp
        ).coerceAtLeast(190.dp)
        val haloSize = (owlSize + 36.dp).coerceAtMost(maxWidth)

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                androidx.compose.foundation.Canvas(modifier = Modifier.size(haloSize)) {
                    drawCircle(
                        color = WiseNavyPrimary.copy(alpha = 0.08f),
                        radius = size.minDimension * 0.46f,
                        center = center
                    )
                    drawCircle(
                        color = WiseAmberSecondary.copy(alpha = 0.10f),
                        radius = size.minDimension * 0.34f,
                        center = center
                    )
                }
                AnimatedWiseOwlCanvas(
                    timeMs = animTimeMs,
                    modifier = Modifier.size(owlSize)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            val textAlpha = ((animTimeMs - 1450f) / 320f).coerceIn(0f, 1f)
            val textOffsetY = (22f * (1f - textAlpha)).dp

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = textAlpha
                        translationY = textOffsetY.toPx()
                    }
            ) {
                Text(
                    text = "BaykuşNot",
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Siz yorulmayın,\nBaykuş yorulsun.",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 40.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.86f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AnimatedWiseOwlCanvas(
    timeMs: Float,
    modifier: Modifier = Modifier
) {
    val primaryColor = WiseNavyPrimary
    val secondaryColor = WiseAmberSecondary

    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val centerX = w / 2f
        val centerY = h * 0.55f
        
        // 1. Owl Appears (0 - 300ms)
        val phase1Progress = (timeMs / 300f).coerceIn(0f, 1f)
        val owlScale = phase1Progress
        
        // 2. Puts on Glasses (300 - 800ms)
        val phase2Progress = ((timeMs - 300f) / 500f).coerceIn(0f, 1f)
        val glassesYOffset = (1f - phase2Progress) * -80f
        val glassesAlpha = phase2Progress
        
        // 3. Rolls up Sleeves (800 - 1300ms)
        val phase3Progress = ((timeMs - 800f) / 500f).coerceIn(0f, 1f)
        val wingsFlex = phase3Progress
        val sleeveRoll = phase3Progress
        
        // 4. Sips Coffee (1300 - 1800ms)
        val phase4Progress = ((timeMs - 1300f) / 500f).coerceIn(0f, 1f)
        val cupYLift = if (phase4Progress in 0.1f..0.9f) {
            kotlin.math.sin(phase4Progress * Math.PI.toFloat()) * (w * 0.105f)
        } else 0f
        val beakSipTilt = if (phase4Progress in 0.3f..0.7f) 6f else 0f
        
        // 5. Starts Working (1800 - 2500ms)
        val phase5Progress = ((timeMs - 1800f) / 700f).coerceIn(0f, 1f)
        val isWinking = timeMs >= 2300f

        if (owlScale > 0f) {
            scale(scale = owlScale, pivot = androidx.compose.ui.geometry.Offset(centerX, centerY)) {
                drawCanonicalOwl(
                    primaryColor = primaryColor,
                    accentColor = secondaryColor,
                    glassesYOffset = glassesYOffset,
                    glassesAlpha = glassesAlpha,
                    beakTilt = beakSipTilt,
                    wingsFlex = wingsFlex,
                    sleeveRoll = sleeveRoll,
                    isWinking = isWinking
                )
                
                val owlRadius = w * 0.38f
                
                // Coffee Cup - proportional to the canonical owl so it stays visible on high-density phones.
                if (timeMs >= 1300f) {
                    val cupX = centerX + owlRadius * 0.92f
                    val cupY = centerY + owlRadius * 0.34f - cupYLift
                    val cupW = w * 0.115f
                    val cupH = w * 0.13f
                    val stroke = (w * 0.012f).coerceAtLeast(3f)
                    drawRoundRect(
                        color = secondaryColor,
                        topLeft = androidx.compose.ui.geometry.Offset(cupX - cupW / 2f, cupY - cupH / 2f),
                        size = androidx.compose.ui.geometry.Size(cupW, cupH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(cupW * 0.18f, cupW * 0.18f)
                    )
                    // Coffee surface and handle make the prop read clearly as a cup, not a rectangle.
                    drawOval(
                        color = androidx.compose.ui.graphics.Color(0xFF6B3E26),
                        topLeft = androidx.compose.ui.geometry.Offset(cupX - cupW * 0.38f, cupY - cupH * 0.42f),
                        size = androidx.compose.ui.geometry.Size(cupW * 0.76f, cupH * 0.20f)
                    )
                    drawCircle(
                        color = secondaryColor,
                        radius = cupH * 0.26f,
                        center = androidx.compose.ui.geometry.Offset(cupX + cupW * 0.55f, cupY),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                    )
                    if (cupYLift > w * 0.02f) {
                        val steamAlpha = (cupYLift / (w * 0.105f)).coerceIn(0f, 1f)
                        drawCircle(
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = steamAlpha * 0.72f),
                            radius = w * 0.014f,
                            center = androidx.compose.ui.geometry.Offset(cupX - cupW * 0.15f, cupY - cupH * 0.78f)
                        )
                        drawCircle(
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = steamAlpha * 0.58f),
                            radius = w * 0.017f,
                            center = androidx.compose.ui.geometry.Offset(cupX + cupW * 0.10f, cupY - cupH * 1.02f)
                        )
                    }
                }
                
                // Exam Papers & Light Scanning
                if (timeMs >= 1800f) {
                    val paperW = w * 0.30f
                    val paperH = w * 0.20f
                    val paperY = kotlin.math.min(
                        h - paperH / 2f - w * 0.02f,
                        centerY + owlRadius * 0.98f
                    )
                    if (timeMs < 2300f) {
                        val cycle = (phase5Progress * 4f) % 1f
                        val flyingX = centerX - w * 0.4f + cycle * w * 0.8f
                        drawRoundRect(
                            color = androidx.compose.ui.graphics.Color.White,
                            topLeft = androidx.compose.ui.geometry.Offset(flyingX - paperW / 2f, paperY - paperH / 2f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f)
                        )
                        drawRoundRect(
                            color = primaryColor.copy(alpha = 0.3f),
                            topLeft = androidx.compose.ui.geometry.Offset(flyingX - paperW / 2f, paperY - paperH / 2f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = (w * 0.008f).coerceAtLeast(2f))
                        )
                        val scanLineY = paperY - paperH / 2f + (cycle * paperH)
                        drawLine(
                            color = androidx.compose.ui.graphics.Color(0xFF38BDF8),
                            start = androidx.compose.ui.geometry.Offset(flyingX - paperW / 2f - w * 0.025f, scanLineY),
                            end = androidx.compose.ui.geometry.Offset(flyingX + paperW / 2f + w * 0.025f, scanLineY),
                            strokeWidth = (w * 0.018f).coerceAtLeast(4f)
                        )
                    } else {
                        val stackX = centerX
                        drawRoundRect(
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.6f),
                            topLeft = androidx.compose.ui.geometry.Offset(stackX - paperW / 2f - w * 0.018f, paperY - paperH / 2f + w * 0.018f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f)
                        )
                        drawRoundRect(
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f),
                            topLeft = androidx.compose.ui.geometry.Offset(stackX - paperW / 2f - w * 0.009f, paperY - paperH / 2f + w * 0.009f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f)
                        )
                        drawRoundRect(
                            color = androidx.compose.ui.graphics.Color.White,
                            topLeft = androidx.compose.ui.geometry.Offset(stackX - paperW / 2f, paperY - paperH / 2f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f)
                        )
                        drawRoundRect(
                            color = androidx.compose.ui.graphics.Color(0xFF16A34A),
                            topLeft = androidx.compose.ui.geometry.Offset(stackX - paperW / 2f, paperY - paperH / 2f),
                            size = androidx.compose.ui.geometry.Size(paperW, paperH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.012f, w * 0.012f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = (w * 0.008f).coerceAtLeast(2f))
                        )
                        drawCircle(color = androidx.compose.ui.graphics.Color(0xFF16A34A), radius = w * 0.055f, center = androidx.compose.ui.geometry.Offset(stackX + paperW / 2f, paperY - paperH / 2f))
                        val doneCheck = androidx.compose.ui.graphics.Path().apply {
                            moveTo(stackX + paperW / 2f - w * 0.024f, paperY - paperH / 2f)
                            lineTo(stackX + paperW / 2f - 2f, paperY - paperH / 2f + w * 0.018f)
                            lineTo(stackX + paperW / 2f + w * 0.024f, paperY - paperH / 2f - w * 0.018f)
                        }
                        drawPath(doneCheck, color = androidx.compose.ui.graphics.Color.White, style = androidx.compose.ui.graphics.drawscope.Stroke(width = (w * 0.012f).coerceAtLeast(3f)))
                    }
                }
            }
        }
    }
}
