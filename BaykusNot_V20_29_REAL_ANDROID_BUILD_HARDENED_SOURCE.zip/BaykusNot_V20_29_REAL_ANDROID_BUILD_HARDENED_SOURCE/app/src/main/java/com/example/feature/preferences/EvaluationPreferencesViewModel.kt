package com.example.feature.preferences

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.CopyEvaluationPreferencesResult
import com.example.core.data.ExamAnswerSheetRepository
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.SaveEvaluationPreferencesResult
import com.example.core.data.LockEvaluationPreferencesResult
import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.model.EvaluationMode
import com.example.core.model.ExamType
import com.example.core.model.EvaluationPreferences
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel
import com.example.core.model.WritingAndPunctuationPreferences
import com.example.core.network.GeminiModelRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class EvaluationPreferencesCopySourceUiModel(
    val examDraftId: Long,
    val draftName: String,
    val courseName: String,
    val examDate: Long
)

data class EvaluationPreferencesUiState(
    val examDraftId: Long,
    val examType: ExamType = ExamType.WRITTEN,
    val isLoading: Boolean = true,
    val examExists: Boolean? = null,
    val preferencesExist: Boolean = false,

    val isLocked: Boolean = false,
    val lockedAt: Long? = null,
    val revision: Int? = null,

    val evaluationMode: EvaluationMode =
        EvaluationMode.PAPER_BY_PAPER,

    val rubricAdherenceLevel: RubricAdherenceLevel =
        RubricAdherenceLevel.BALANCED,

    val feedbackDetailLevel: FeedbackDetailLevel =
        FeedbackDetailLevel.BRIEF,

    val deductWritingAndPunctuationPoints: Boolean = false,
    val hasExplicitWritingPunctuationPreference: Boolean = false,
    val provideWritingAndPunctuationFeedback: Boolean = false,

    val modelQualityTier: ModelQualityTier =
        ModelQualityTier.STANDARD,

    val reportClass: Boolean = true,
    val reportIndividual: Boolean = true,
    val reportQuestion: Boolean = true,
    val useBatchApi: Boolean = false,
    val usePromptCaching: Boolean = true,
    val estimatedCostText: String? = null,
    val showConfirmationDialog: Boolean = false,

    val isDirty: Boolean = false,
    val isSaving: Boolean = false,
    val isLocking: Boolean = false,
    val isCopying: Boolean = false,

    val copySources:
        List<EvaluationPreferencesCopySourceUiModel> =
        emptyList(),

    val selectedCopySourceExamDraftId: Long? = null,
    val message: String? = null
)

class EvaluationPreferencesViewModel(
    private val preferencesRepository: ExamEvaluationPreferencesRepository,
    private val examDraftRepository: ExamDraftRepository,
    private val paperUploadRepository: ExamPaperUploadRepository? = null,
    private val questionRepository: ExamQuestionRepository? = null,
    private val rubricRepository: ExamRubricRepository? = null,
    private val answerSheetRepository: ExamAnswerSheetRepository? = null,
    private val examDraftId: Long
) : ViewModel() {

    constructor(
        preferencesRepository: ExamEvaluationPreferencesRepository,
        examDraftRepository: ExamDraftRepository,
        examDraftId: Long
    ) : this(
        preferencesRepository = preferencesRepository,
        examDraftRepository = examDraftRepository,
        paperUploadRepository = null,
        questionRepository = null,
        rubricRepository = null,
        answerSheetRepository = null,
        examDraftId = examDraftId
    )

    private val _uiState =
        MutableStateFlow(
            EvaluationPreferencesUiState(
                examDraftId = examDraftId
            )
        )

    val uiState:
        StateFlow<EvaluationPreferencesUiState> =
        _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val exam = examDraftRepository.getDraftByIdOnce(examDraftId)
            if (exam == null) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    examExists = false,
                    preferencesExist = false,
                    revision = null
                )
                return@launch
            }

            preferencesRepository.observePreferences(examDraftId).collectLatest { entity ->
                if (entity == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        examExists = true,
                        examType = exam.examType,
                        preferencesExist = false,
                        isLocked = false,
                        lockedAt = null,
                        revision = null,
                        evaluationMode = EvaluationMode.PAPER_BY_PAPER,
                        rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
                        feedbackDetailLevel = FeedbackDetailLevel.BRIEF,
                        deductWritingAndPunctuationPoints = false,
                        hasExplicitWritingPunctuationPreference = true,
                        provideWritingAndPunctuationFeedback = true,
                        modelQualityTier = ModelQualityTier.STANDARD,
                        isDirty = false
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        examExists = true,
                        examType = exam.examType,
                        preferencesExist = true,
                        isLocked = entity.isLocked,
                        lockedAt = entity.lockedAt,
                        revision = entity.revision,
                        evaluationMode = EvaluationMode.PAPER_BY_PAPER,
                        rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
                        feedbackDetailLevel = entity.feedbackDetailLevel,
                        deductWritingAndPunctuationPoints = false,
                        hasExplicitWritingPunctuationPreference = true,
                        provideWritingAndPunctuationFeedback = entity.feedbackDetailLevel != FeedbackDetailLevel.SCORE_ONLY,
                        modelQualityTier = ModelQualityTier.STANDARD,
                        reportClass = entity.reportClass,
                        reportIndividual = entity.reportIndividual,
                        reportQuestion = entity.reportQuestion,
                        useBatchApi = false,
                        usePromptCaching = true,
                        isDirty = false,
                        copySources = emptyList(),
                        selectedCopySourceExamDraftId = null
                    )
                }
            }
        }
    }

    private fun canEditPreferences(state: EvaluationPreferencesUiState): Boolean {
        return !state.isLoading &&
                state.examExists == true &&
                !state.isLocked &&
                !state.isSaving &&
                !state.isLocking &&
                !state.isCopying
    }

    fun updateEvaluationMode(
        evaluationMode: EvaluationMode
    ) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.evaluationMode == evaluationMode) {
            return
        }
        _uiState.value = current.copy(
            evaluationMode = evaluationMode,
            useBatchApi = if (evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) false else current.useBatchApi,
            estimatedCostText = null,
            message = if (evaluationMode == EvaluationMode.QUESTION_BY_QUESTION && current.useBatchApi) {
                when (current.examType) {
                    ExamType.HOMEWORK -> "Görev görev değerlendirmede Batch kullanılamadığı için Batch kapatıldı."
                    ExamType.READINESS -> "Hazırbulunuşlukta soru soru değerlendirme ile Batch birlikte kullanılamadığı için Batch kapatıldı."
                    else -> "Soru soru değerlendirmede Batch kullanılamadığı için Batch kapatıldı."
                }
            } else null,
            isDirty = true
        )
    }

    fun updateRubricAdherenceLevel(
        rubricAdherenceLevel: RubricAdherenceLevel
    ) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.rubricAdherenceLevel == rubricAdherenceLevel) {
            return
        }
        _uiState.value = current.copy(
            rubricAdherenceLevel = rubricAdherenceLevel,
            isDirty = true
        )
    }

    fun updateFeedbackDetailLevel(
        feedbackDetailLevel: FeedbackDetailLevel
    ) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.feedbackDetailLevel == feedbackDetailLevel) {
            return
        }
        _uiState.value = current.copy(
            feedbackDetailLevel = feedbackDetailLevel,
            isDirty = true
        )
    }

    fun updateDeductWritingAndPunctuationPoints(
        deductPoints: Boolean
    ) {
        val current = _uiState.value
        if (current.examType == ExamType.MULTIPLE_CHOICE) return
        if (!canEditPreferences(current) || current.deductWritingAndPunctuationPoints == deductPoints) {
            return
        }
        _uiState.value = current.copy(
            deductWritingAndPunctuationPoints = deductPoints,
            hasExplicitWritingPunctuationPreference = true,
            isDirty = true
        )
    }

    fun updateProvideWritingAndPunctuationFeedback(
        provideFeedback: Boolean
    ) {
        val current = _uiState.value
        if (current.examType == ExamType.MULTIPLE_CHOICE) return
        if (!canEditPreferences(current) || current.provideWritingAndPunctuationFeedback == provideFeedback) {
            return
        }
        _uiState.value = current.copy(
            provideWritingAndPunctuationFeedback = provideFeedback,
            isDirty = true
        )
    }

    fun updateModelQualityTier(
        modelQualityTier: ModelQualityTier
    ) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.modelQualityTier == modelQualityTier) {
            return
        }
        _uiState.value = current.copy(
            modelQualityTier = modelQualityTier,
            isDirty = true
        )
    }

    fun updateReportClass(value: Boolean) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.reportClass == value) return
        _uiState.value = current.copy(reportClass = value, isDirty = true)
    }

    fun updateReportIndividual(value: Boolean) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.reportIndividual == value) return
        _uiState.value = current.copy(reportIndividual = value, isDirty = true)
    }

    fun updateReportQuestion(value: Boolean) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.reportQuestion == value) return
        _uiState.value = current.copy(reportQuestion = value, isDirty = true)
    }

    fun updateUseBatchApi(value: Boolean) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.useBatchApi == value) return
        if (value && current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
            _uiState.value = current.copy(
                message = when (current.examType) {
                    ExamType.HOMEWORK -> "Görev görev değerlendirme ile Batch birlikte kullanılamaz. Önce Teslim Teslim değerlendirmeyi seçin."
                    ExamType.READINESS -> "Hazırbulunuşlukta soru soru değerlendirme ile Batch birlikte kullanılamaz. Önce Kâğıt Kâğıt değerlendirmeyi seçin."
                    else -> "Soru soru değerlendirme ile Batch birlikte kullanılamaz. Önce Kâğıt Kâğıt değerlendirmeyi seçin."
                }
            )
            return
        }
        _uiState.value = current.copy(useBatchApi = value, estimatedCostText = null, message = null, isDirty = true)
    }

    fun updateUsePromptCaching(value: Boolean) {
        val current = _uiState.value
        if (!canEditPreferences(current) || current.usePromptCaching == value) return
        _uiState.value = current.copy(usePromptCaching = value, isDirty = true)
    }

    fun calculateCost() {
        viewModelScope.launch {
            val current = _uiState.value
            try {
                if (paperUploadRepository == null || answerSheetRepository == null || questionRepository == null || rubricRepository == null) {
                    _uiState.value = _uiState.value.copy(
                        estimatedCostText = null,
                        message = null
                    )
                    return@launch
                }
                // 1. Student Count (from real uploaded papers or configured count)
                val uploadedPapers = paperUploadRepository.getStudentPapers(examDraftId).first()
                val answerSheetConfig = if (current.examType == ExamType.HOMEWORK) null else answerSheetRepository.getConfig(examDraftId)
                val studentCount = if (uploadedPapers.isNotEmpty()) {
                    uploadedPapers.size
                } else {
                    answerSheetConfig?.studentCount ?: 0
                }

                // 2. Actual Total Pages per paper
                val totalPages = paperUploadRepository.getActualTotalPages(examDraftId)

                // 3. Exam questions & rubrics for shared prompt token calculation
                val questions = questionRepository.getQuestionsOnce(examDraftId)
                val rubrics = rubricRepository.getCriteriaOnce(examDraftId)

                val questionTokens = questions.sumOf { (it.questionText.length + 40) / 4 }
                val rubricTokens = rubrics.sumOf { (it.title.length + it.description.length + (it.expectedAnswer?.length ?: 0) + 40) / 4 }
                val baseSystemPromptTokens = 800
                val sharedContextTokens = baseSystemPromptTokens + questionTokens + rubricTokens

                // 4. Main evaluation cost. HIGH image-token budget comes from the active benchmarked model profile.
                // Paper-by-paper keeps all anonymous pages in one request. Question-by-question sends
                // one targeted answer crop per question. A small reserve covers uncertainty rechecks.
                val evaluationPassesPerStudent = if (current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
                    questions.size.coerceAtLeast(1)
                } else 1
                val mainVisionTokensPerStudent = if (current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
                    questions.size.coerceAtLeast(1) * GeminiModelRegistry.currentProfile().highImageTokens
                } else {
                    totalPages.coerceAtLeast(1) * GeminiModelRegistry.currentProfile().highImageTokens
                }
                val secondCheckReserveTokensPerStudent = (questions.size.coerceAtLeast(1) * GeminiModelRegistry.currentProfile().highImageTokens * 0.15).toInt()
                val studentPaperInputTokens = mainVisionTokensPerStudent + secondCheckReserveTokensPerStudent

                // Main model produces compact grading evidence/diagnosis, not long student prose.
                val mainThinkingTokensPerStudent = if (current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
                    questions.size.coerceAtLeast(1) * 300
                } else {
                    550 + questions.size * 45
                }
                val mainVisibleOutputTokensPerStudent = 180 + questions.size * 115 +
                    (if (current.provideWritingAndPunctuationFeedback) 55 else 0)
                val mainOutputAndThinkingTokensPerStudent =
                    mainThinkingTokensPerStudent + mainVisibleOutputTokensPerStudent

                // 5. Low-cost feedback writer. It receives only structured grading evidence; no images.
                val feedbackInputTokensPerStudent = when (current.feedbackDetailLevel) {
                    FeedbackDetailLevel.SCORE_ONLY -> 0
                    else -> if (current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
                        questions.size.coerceAtLeast(1) * (190 + 125)
                    } else {
                        190 + questions.size * 125
                    }
                }
                val feedbackOutputTokensPerStudent = when (current.feedbackDetailLevel) {
                    FeedbackDetailLevel.SCORE_ONLY -> 0
                    FeedbackDetailLevel.BRIEF -> questions.size * 35 + 120 + (if (current.provideWritingAndPunctuationFeedback) 55 else 0)
                    FeedbackDetailLevel.INSTRUCTIONAL -> questions.size * 90 + 260 + (if (current.provideWritingAndPunctuationFeedback) 90 else 0)
                    FeedbackDetailLevel.DETAILED -> questions.size * 155 + 500 + (if (current.provideWritingAndPunctuationFeedback) 140 else 0)
                }

                // 6. Pricing is centralized beside model ids so model/price switches require one edit.
                val effectiveBatchPricing = current.useBatchApi || GeminiModelRegistry.currentProfile().preferBatchEvaluation
                val evalPricing = GeminiModelRegistry.evaluationPricing(effectiveBatchPricing)
                val feedbackPricing = GeminiModelRegistry.feedbackPricing()

                val totalMainInputCostUsd: Double
                val cacheStorageFee: Double
                val cacheStorageFeeHourly: Double

                if (current.usePromptCaching) {
                    val sharedCost =
                        (sharedContextTokens * evaluationPassesPerStudent * evalPricing.cachedInputPerMillionUsd * studentCount) / 1_000_000.0
                    val studentPagesCost = (studentCount * studentPaperInputTokens * evalPricing.inputPerMillionUsd) / 1_000_000.0

                    cacheStorageFeeHourly =
                        (sharedContextTokens * evalPricing.cacheStoragePerMillionTokenHourUsd) / 1_000_000.0
                    val cacheStorageDurationHours = if (effectiveBatchPricing) 24.0 else (5.0 / 60.0)
                    cacheStorageFee = cacheStorageFeeHourly * cacheStorageDurationHours
                    totalMainInputCostUsd = sharedCost + studentPagesCost + cacheStorageFee
                } else {
                    val totalInputTokens = (sharedContextTokens * evaluationPassesPerStudent + studentPaperInputTokens) * studentCount
                    totalMainInputCostUsd = (totalInputTokens * evalPricing.inputPerMillionUsd) / 1_000_000.0
                    cacheStorageFee = 0.0
                    cacheStorageFeeHourly = 0.0
                }

                val totalMainOutputTokens = mainOutputAndThinkingTokensPerStudent * studentCount
                val totalMainOutputCostUsd =
                    (totalMainOutputTokens * evalPricing.outputPerMillionUsd) / 1_000_000.0

                val totalFeedbackInputTokens = feedbackInputTokensPerStudent * studentCount
                val totalFeedbackOutputTokens = feedbackOutputTokensPerStudent * studentCount
                val feedbackCostUsd =
                    (totalFeedbackInputTokens * feedbackPricing.inputPerMillionUsd +
                        totalFeedbackOutputTokens * feedbackPricing.outputPerMillionUsd) / 1_000_000.0

                val totalCostUsd = totalMainInputCostUsd + totalMainOutputCostUsd + feedbackCostUsd
                val formattedUsd = String.format(java.util.Locale.US, "%.4f", totalCostUsd)
                val baseProcessingCost = totalMainInputCostUsd - cacheStorageFee + totalMainOutputCostUsd + feedbackCostUsd
                val formattedBaseCost = String.format(java.util.Locale.US, "%.4f", baseProcessingCost)
                val formattedHourlyStorage = String.format(java.util.Locale.US, "%.6f", cacheStorageFeeHourly)
                val formattedFeedbackCost = String.format(java.util.Locale.US, "%.4f", feedbackCostUsd)

                val batchText = if (effectiveBatchPricing) "Batch API (İndirimli)" else "Standart API"
                val cacheText = if (current.usePromptCaching) {
                    "Prompt Caching Etkin ($${evalPricing.cachedInputPerMillionUsd}/1M)"
                } else {
                    "Prompt Caching Pasif"
                }

                val detailSummary = StringBuilder()
                if (effectiveBatchPricing && current.usePromptCaching) {
                    detailSummary.append("Tahmini AI Maliyeti: Temel İşlem ~$${formattedBaseCost} USD + Depolama ~$${formattedHourlyStorage} USD/saat\n")
                } else {
                    detailSummary.append("Tahmini AI Maliyeti: ~$${formattedUsd} USD\n")
                }
                detailSummary.append(
                    "Ana okuma: ${GeminiModelRegistry.evaluationModel} • Dönüt: ${GeminiModelRegistry.feedbackModel} " +
                        "(dönüt payı ~$${formattedFeedbackCost} USD)\n\n"
                )

                val documentLabel = when (current.examType) {
                    ExamType.HOMEWORK -> "Ödev Verileri"
                    ExamType.READINESS -> "Hazırbulunuşluk Verileri"
                    else -> "Sınav Verileri"
                }
                val itemLabel = if (current.examType == ExamType.HOMEWORK) "Görev/Maddeler" else "Sorular"
                val pageLabel = when (current.examType) {
                    ExamType.HOMEWORK -> "sayfa/teslim"
                    ExamType.READINESS -> "sayfa/hazırbulunuşluk kâğıdı"
                    else -> "sayfa/kâğıt"
                }
                val modeLabel = if (current.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
                    if (current.examType == ExamType.HOMEWORK) "Görev görev" else "Soru soru"
                } else {
                    if (current.examType == ExamType.HOMEWORK) "Teslim teslim" else "Kâğıt kâğıt"
                }
                detailSummary.append("• $documentLabel: $studentCount öğrenci, $totalPages $pageLabel\n")
                    .append("• $itemLabel ve Rubrik: ${questions.size} madde, ~$sharedContextTokens jeton ortak bağlam\n")
                    .append("• Değerlendirme Sırası: $modeLabel ($evaluationPassesPerStudent AI geçişi/öğrenci)\n")
                    .append("• Ana Okuma: ~$studentPaperInputTokens görsel+yeniden kontrol rezervi jetonu/öğrenci, ~$mainOutputAndThinkingTokensPerStudent çıktı+düşünme jetonu/öğrenci\n")
                    .append("• Kişisel Dönüt: ~$feedbackInputTokensPerStudent girdi, ~$feedbackOutputTokensPerStudent çıktı jetonu/öğrenci (görsel gönderilmez)\n")
                    .append("• Model Yapılandırması: $batchText, $cacheText\n")
                    .append("• Prompt Caching: ${if (effectiveBatchPricing) "Batch işinin ne zaman sonuçlanacağı belirsiz olduğundan depolama maliyeti saatlik ek ücret olarak sunulmuştur." else "Standart önbellek süresi (5 dk) üzerinden hesaplanmıştır."}\n")
                    .append("*Hesaplama gerçek ${when (current.examType) { ExamType.HOMEWORK -> "ödev"; ExamType.READINESS -> "hazırbulunuşluk"; else -> "sınav" }} parametreleriyle yerel olarak yapılmıştır, canlı AI isteği gönderilmemiştir.")

                _uiState.value = _uiState.value.copy(
                    estimatedCostText = detailSummary.toString(),
                    message = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    estimatedCostText = "Maliyet hesaplanırken bir hata oluştu: ${e.message}",
                    message = null
                )
            }
        }
    }

    fun showConfirmationDialog() {
        _uiState.value = _uiState.value.copy(showConfirmationDialog = true)
    }

    fun dismissConfirmationDialog() {
        _uiState.value = _uiState.value.copy(showConfirmationDialog = false)
    }

    private fun canSavePreferences(state: EvaluationPreferencesUiState): Boolean {
        return !state.isLoading &&
                state.examExists == true &&
                !state.isLocked &&
                !state.isSaving &&
                !state.isLocking &&
                !state.isCopying &&
                (!state.preferencesExist || state.isDirty)
    }

    private fun applyStoredPreferences(
        current: EvaluationPreferencesUiState,
        entity: ExamEvaluationPreferencesEntity,
        message: String? = current.message
    ): EvaluationPreferencesUiState {
        return current.copy(
            isLoading = false,
            examExists = true,
            preferencesExist = true,
            isLocked = entity.isLocked,
            lockedAt = entity.lockedAt,
            revision = entity.revision,
            evaluationMode = EvaluationMode.PAPER_BY_PAPER,
            rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
            feedbackDetailLevel = entity.feedbackDetailLevel,
            deductWritingAndPunctuationPoints = false,
            hasExplicitWritingPunctuationPreference = true,
            provideWritingAndPunctuationFeedback = entity.feedbackDetailLevel != FeedbackDetailLevel.SCORE_ONLY,
            modelQualityTier = ModelQualityTier.STANDARD,
            reportClass = entity.reportClass,
            reportIndividual = entity.reportIndividual,
            reportQuestion = entity.reportQuestion,
            useBatchApi = false,
            usePromptCaching = true,
            isDirty = false,
            message = message,
            copySources = emptyList(),
            selectedCopySourceExamDraftId = null
        )
    }

    fun savePreferences() {
        val current = _uiState.value
        if (!canSavePreferences(current)) {
            return
        }

        _uiState.value = current.copy(
            isSaving = true,
            message = null
        )

        val preferences = EvaluationPreferences(
            // Teacher Mode keeps scoring behavior consistent and hides technical choices.
            evaluationMode = EvaluationMode.PAPER_BY_PAPER,
            rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
            feedbackDetailLevel = current.feedbackDetailLevel,
            writingAndPunctuation = WritingAndPunctuationPreferences(
                deductPoints = false,
                hasExplicitPreference = true,
                provideFeedback = current.feedbackDetailLevel != FeedbackDetailLevel.SCORE_ONLY
            ),
            modelQualityTier = ModelQualityTier.STANDARD,
            reportClass = true,
            reportIndividual = true,
            reportQuestion = true,
            // Automatic second-check evaluation is synchronous; Batch would bypass it.
            useBatchApi = false,
            usePromptCaching = true
        )

        viewModelScope.launch {
            try {
                val result = preferencesRepository.savePreferences(
                    examDraftId = examDraftId,
                    preferences = preferences
                )
                when (result) {
                    is SaveEvaluationPreferencesResult.Created -> {
                        _uiState.value = applyStoredPreferences(
                            current = _uiState.value,
                            entity = result.preferences,
                            message = "Değerlendirme tercihleri kaydedildi."
                        ).copy(isSaving = false)
                    }
                    is SaveEvaluationPreferencesResult.Updated -> {
                        _uiState.value = applyStoredPreferences(
                            current = _uiState.value,
                            entity = result.preferences,
                            message = "Değerlendirme tercihleri kaydedildi."
                        ).copy(isSaving = false)
                    }
                    SaveEvaluationPreferencesResult.Locked -> {
                        _uiState.value = _uiState.value.copy(
                            isSaving = false,
                            message = "Değerlendirme tercihleri kilitli olduğu için kaydedilemedi."
                        )
                    }
                    SaveEvaluationPreferencesResult.ExamNotFound -> {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            examExists = false,
                            preferencesExist = false,
                            isSaving = false,
                            revision = null,
                            message = when (_uiState.value.examType) {
                                    ExamType.HOMEWORK -> "Ödev kontrolü kaydı bulunamadı."
                                    ExamType.READINESS -> "Hazırbulunuşluk sınavı kaydı bulunamadı."
                                    else -> "Sınav kaydı bulunamadı."
                                }
                        )
                    }
                    SaveEvaluationPreferencesResult.ConcurrentModification -> {
                        _uiState.value = _uiState.value.copy(
                            isSaving = false,
                            message = "Değerlendirme tercihleri başka bir işlem tarafından değiştirildi. Lütfen yeniden deneyin."
                        )
                    }
                }
            } catch (exception: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    message = "Değerlendirme tercihleri kaydedilemedi."
                )
            }
        }
    }

    private fun canStartLock(state: EvaluationPreferencesUiState): Boolean {
        return !state.isLoading &&
                state.examExists == true &&
                state.preferencesExist &&
                !state.isLocked &&
                !state.isDirty &&
                !state.isSaving &&
                !state.isLocking &&
                !state.isCopying
    }

    fun lockPreferences() {
        val current = _uiState.value

        if (current.isLoading || current.examExists != true || current.isSaving || current.isLocking || current.isCopying) {
            return
        }

        if (current.isLocked) {
            return
        }

        if (!current.preferencesExist) {
            _uiState.value = current.copy(
                message = "Kilitlemeden önce değerlendirme tercihlerini kaydedin."
            )
            return
        }

        if (current.isDirty) {
            _uiState.value = current.copy(
                message = "Kilitlemeden önce değişiklikleri kaydedin."
            )
            return
        }

        _uiState.value = current.copy(
            isLocking = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val result = preferencesRepository.lockPreferences(examDraftId)
                when (result) {
                    is LockEvaluationPreferencesResult.Success -> {
                        _uiState.value = applyStoredPreferences(
                            current = _uiState.value,
                            entity = result.preferences,
                            message = "Değerlendirme tercihleri kilitlendi."
                        ).copy(isLocking = false)
                    }
                    LockEvaluationPreferencesResult.PreferencesNotFound -> {
                        _uiState.value = _uiState.value.copy(
                            preferencesExist = false,
                            isLocked = false,
                            lockedAt = null,
                            revision = null,
                            isLocking = false,
                            message = "Kilitlemeden önce değerlendirme tercihlerini kaydedin."
                        )
                    }
                    LockEvaluationPreferencesResult.AlreadyLocked -> {
                        _uiState.value = _uiState.value.copy(
                            isLocking = false,
                            isLocked = true,
                            message = "Değerlendirme tercihleri zaten kilitli."
                        )
                    }
                    LockEvaluationPreferencesResult.ConcurrentModification -> {
                        _uiState.value = _uiState.value.copy(
                            isLocking = false,
                            message = "Değerlendirme tercihleri başka bir işlem tarafından değiştirildi. Lütfen yeniden deneyin."
                        )
                    }
                }
            } catch (exception: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLocking = false,
                    message = "Değerlendirme tercihleri kilitlenemedi."
                )
            }
        }
    }

    fun unlockPreferences() {
        val current = _uiState.value
        if (current.isLoading || current.examExists != true || current.isSaving || current.isLocking || current.isCopying) {
            return
        }
        if (!current.isLocked) {
            return
        }
        viewModelScope.launch {
            try {
                val success = preferencesRepository.unlockPreferences(examDraftId)
                if (success) {
                    val entity = preferencesRepository.observePreferences(examDraftId).first()
                    if (entity != null) {
                        _uiState.value = applyStoredPreferences(
                            current = _uiState.value,
                            entity = entity,
                            message = "Tercihlerin kilidi açıldı."
                        ).copy(isLocked = false)
                    }
                } else {
                    _uiState.value = _uiState.value.copy(
                        message = "Tercihlerin kilidi açılması başarısız oldu."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    message = "Tercihlerin kilidi açılırken hata oluştu."
                )
            }
        }
    }

    private fun canLoadCopySources(state: EvaluationPreferencesUiState): Boolean {
        return !state.isLoading &&
                state.examExists == true &&
                !state.preferencesExist &&
                !state.isLocked &&
                !state.isSaving &&
                !state.isLocking &&
                !state.isCopying
    }

    fun loadCopySources() {
        val current = _uiState.value
        if (!canLoadCopySources(current)) {
            return
        }

        _uiState.value = current.copy(
            isCopying = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val drafts = examDraftRepository.getEvaluationPreferencesCopySourceDrafts(
                    targetExamDraftId = examDraftId
                )
                val mappedSources = drafts
                    .filter { it.examType == _uiState.value.examType }
                    .map { draft ->
                    EvaluationPreferencesCopySourceUiModel(
                        examDraftId = draft.id,
                        draftName = draft.draftName,
                        courseName = draft.courseName,
                        examDate = draft.examDate
                    )
                }
                val currentSelection = _uiState.value.selectedCopySourceExamDraftId
                val stillExists = mappedSources.any { it.examDraftId == currentSelection }

                _uiState.value = _uiState.value.copy(
                    isCopying = false,
                    copySources = mappedSources,
                    selectedCopySourceExamDraftId = if (stillExists) currentSelection else null,
                    message = null
                )
            } catch (exception: Exception) {
                _uiState.value = _uiState.value.copy(
                    isCopying = false,
                    message = when (_uiState.value.examType) {
                        ExamType.HOMEWORK -> "Kopyalanabilir ödev kontrolü listesi yüklenemedi."
                        ExamType.READINESS -> "Kopyalanabilir hazırbulunuşluk sınavı listesi yüklenemedi."
                        else -> "Kopyalanabilir sınav listesi yüklenemedi."
                    }
                )
            }
        }
    }

    fun selectCopySource(examDraftId: Long?) {
        val current = _uiState.value
        if (!canLoadCopySources(current)) {
            return
        }
        if (examDraftId == null) {
            if (current.selectedCopySourceExamDraftId == null) {
                return
            }
            _uiState.value = current.copy(selectedCopySourceExamDraftId = null)
            return
        }
        if (examDraftId == this.examDraftId) {
            return
        }
        val isValid = current.copySources.any { it.examDraftId == examDraftId }
        if (!isValid) {
            return
        }
        if (current.selectedCopySourceExamDraftId == examDraftId) {
            return
        }
        _uiState.value = current.copy(
            selectedCopySourceExamDraftId = examDraftId,
            message = null
        )
    }

    private fun canCopyPreferences(state: EvaluationPreferencesUiState): Boolean {
        val selectedId = state.selectedCopySourceExamDraftId
        return !state.isLoading &&
                state.examExists == true &&
                !state.preferencesExist &&
                !state.isLocked &&
                !state.isDirty &&
                !state.isSaving &&
                !state.isLocking &&
                !state.isCopying &&
                selectedId != null &&
                selectedId != examDraftId &&
                state.copySources.any { it.examDraftId == selectedId }
    }

    fun copyPreferences() {
        val current = _uiState.value
        if (current.preferencesExist) {
            return
        }
        
        if (!current.isLoading && current.examExists == true && !current.isLocked && !current.isDirty && !current.isSaving && !current.isLocking && !current.isCopying) {
            val sourceExamDraftId = current.selectedCopySourceExamDraftId
            if (sourceExamDraftId == null) {
                _uiState.value = current.copy(message = when (current.examType) {
                    ExamType.HOMEWORK -> "Kopyalanacak ödev kontrolünü seçin."
                    ExamType.READINESS -> "Kopyalanacak hazırbulunuşluk sınavını seçin."
                    else -> "Kopyalanacak sınavı seçin."
                })
                return
            }
            
            val isValid = current.copySources.any { it.examDraftId == sourceExamDraftId }
            if (!isValid || sourceExamDraftId == examDraftId) {
                _uiState.value = current.copy(
                    selectedCopySourceExamDraftId = null,
                    message = when (current.examType) {
                    ExamType.HOMEWORK -> "Kopyalanacak ödev kontrolünü seçin."
                    ExamType.READINESS -> "Kopyalanacak hazırbulunuşluk sınavını seçin."
                    else -> "Kopyalanacak sınavı seçin."
                }
                )
                return
            }

            _uiState.value = current.copy(
                isCopying = true,
                message = null
            )

            viewModelScope.launch {
                try {
                    val result = preferencesRepository.copyPreferences(
                        sourceExamDraftId = sourceExamDraftId,
                        targetExamDraftId = examDraftId
                    )
                    when (result) {
                        is CopyEvaluationPreferencesResult.Success -> {
                            val entity = result.preferences
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                examExists = true,
                                preferencesExist = true,
                                evaluationMode = entity.evaluationMode,
                                rubricAdherenceLevel = entity.rubricAdherenceLevel,
                                feedbackDetailLevel = entity.feedbackDetailLevel,
                                deductWritingAndPunctuationPoints = entity.deductWritingAndPunctuationPoints,
                        hasExplicitWritingPunctuationPreference = entity.hasExplicitWritingPunctuationPreference,
                                provideWritingAndPunctuationFeedback = entity.provideWritingAndPunctuationFeedback,
                                modelQualityTier = entity.modelQualityTier,
                                isLocked = false,
                                lockedAt = null,
                                revision = 1,
                                isDirty = false,
                                isCopying = false,
                                copySources = emptyList(),
                                selectedCopySourceExamDraftId = null,
                                message = "Değerlendirme tercihleri kopyalandı."
                            )
                        }
                        is CopyEvaluationPreferencesResult.SourcePreferencesNotFound -> {
                            val updatedSources = _uiState.value.copySources.filterNot {
                                it.examDraftId == sourceExamDraftId
                            }
                            _uiState.value = _uiState.value.copy(
                                isCopying = false,
                                copySources = updatedSources,
                                selectedCopySourceExamDraftId = null,
                                message = when (_uiState.value.examType) {
                                    ExamType.HOMEWORK -> "Kaynak ödev kontrolünün değerlendirme tercihleri bulunamadı."
                                    ExamType.READINESS -> "Kaynak hazırbulunuşluk sınavının değerlendirme tercihleri bulunamadı."
                                    else -> "Kaynak sınavın değerlendirme tercihleri bulunamadı."
                                }
                            )
                        }
                        is CopyEvaluationPreferencesResult.TargetExamNotFound -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                examExists = false,
                                preferencesExist = false,
                                isLocked = false,
                                lockedAt = null,
                                revision = null,
                                isDirty = false,
                                isCopying = false,
                                copySources = emptyList(),
                                selectedCopySourceExamDraftId = null,
                                message = when (_uiState.value.examType) {
                                    ExamType.HOMEWORK -> "Ödev kontrolü kaydı bulunamadı."
                                    ExamType.READINESS -> "Hazırbulunuşluk sınavı kaydı bulunamadı."
                                    else -> "Sınav kaydı bulunamadı."
                                }
                            )
                        }
                        is CopyEvaluationPreferencesResult.TargetAlreadyHasPreferences -> {
                            _uiState.value = _uiState.value.copy(
                                isCopying = false,
                                copySources = emptyList(),
                                selectedCopySourceExamDraftId = null,
                                message = when (_uiState.value.examType) {
                                    ExamType.HOMEWORK -> "Bu ödev kontrolü için değerlendirme tercihleri zaten mevcut."
                                    ExamType.READINESS -> "Bu hazırbulunuşluk sınavı için değerlendirme tercihleri zaten mevcut."
                                    else -> "Bu sınav için değerlendirme tercihleri zaten mevcut."
                                }
                            )
                        }
                        is CopyEvaluationPreferencesResult.ConcurrentModification -> {
                            _uiState.value = _uiState.value.copy(
                                isCopying = false,
                                message = "Değerlendirme tercihleri başka bir işlem tarafından değiştirildi. Lütfen yeniden deneyin."
                            )
                        }
                    }
                } catch (exception: Exception) {
                    _uiState.value = _uiState.value.copy(
                        isCopying = false,
                        message = "Değerlendirme tercihleri kopyalanamadı."
                    )
                }
            }
        }
    }

    class Factory(
        private val preferencesRepository: ExamEvaluationPreferencesRepository,
        private val examDraftRepository: ExamDraftRepository,
        private val paperUploadRepository: ExamPaperUploadRepository,
        private val questionRepository: ExamQuestionRepository,
        private val rubricRepository: ExamRubricRepository,
        private val answerSheetRepository: ExamAnswerSheetRepository,
        private val examDraftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EvaluationPreferencesViewModel(
                preferencesRepository,
                examDraftRepository,
                paperUploadRepository,
                questionRepository,
                rubricRepository,
                answerSheetRepository,
                examDraftId
            ) as T
        }
    }
}
