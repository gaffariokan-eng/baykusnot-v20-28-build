package com.example.feature.workflow

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.ExamType
import com.example.core.model.documentExamName
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

data class UploadSourceCopy(
    val title: String = "Boş Sınav Dosyası",
    val description: String = "Soruların ve puan dağılımının çıkarılması için boş sınav dosyasını yükleyin.",
    val emptyTitle: String = "Henüz sınav kaynağı yüklenmedi",
    val emptyDescription: String = "PDF, Word ve Görsel dosyaları desteklenir. (Maks. 50 MB)",
    val documentTypeLabel: String = "Sınav Dosyası",
    val readyLabel: String = "Sınav dosyası hazır",
    val unusableLabel: String = "Sınav dosyası kullanılamıyor",
    val replaceLabel: String = "Sınavı Değiştir",
    val continueLabel: String = "Devam Et"
)

internal object UploadSourceTestTags {
    const val CONTENT = "upload_source_content"
    const val LOADING = "upload_source_loading"
    const val NOT_FOUND = "upload_source_not_found"
    const val EMPTY_STATE = "upload_source_empty_state"
    const val DOCUMENT_CARD = "upload_source_document_card"
    const val DOCUMENT_NAME = "upload_source_document_name"
    const val DOCUMENT_SIZE = "upload_source_document_size"
    const val DOCUMENT_PAGE_COUNT = "upload_source_document_page_count"
    const val DOCUMENT_TYPE = "upload_source_document_type"
    const val DOCUMENT_STATUS = "upload_source_document_status"
    const val MESSAGE = "upload_source_message"
    const val SELECT_BUTTON = "upload_source_select_button"
    const val REPLACE_BUTTON = "upload_source_replace_button"
    const val REMOVE_BUTTON = "upload_source_remove_button"
    const val CONTINUE_BUTTON = "upload_source_continue_button"
}

internal fun formatSourceFileSize(sizeBytes: Long): String {
    if (sizeBytes < 0) return "0 B"
    if (sizeBytes < 1024) return "$sizeBytes B"
    
    val symbols = DecimalFormatSymbols(Locale.US)
    val df = DecimalFormat("#.##", symbols)
    
    if (sizeBytes < 1048576) {
        return "${df.format(sizeBytes / 1024.0)} KB"
    }
    return "${df.format(sizeBytes / 1048576.0)} MB"
}

@Composable
internal fun UploadSourceContent(
    uiState: UploadSourceUiState,
    onPasteText: () -> Unit,
    onSelectPdf: () -> Unit,
    onReplacePdf: () -> Unit,
    onRemovePdf: () -> Unit,
    onContinue: () -> Unit,
    onClearMessage: () -> Unit,
    onSelectScenarioPdf: () -> Unit,
    onConfirmScenario: () -> Unit,
    onUpdateStagingObjective: (com.example.core.database.ExamObjectiveEntity) -> Unit = {},
    onAddStagingObjective: (com.example.core.database.ExamObjectiveEntity) -> Unit = {},
    onDeleteStagingObjective: (Long) -> Unit = {},
    onClearScenarioPreview: () -> Unit,
    onRemoveScenario: () -> Unit,
    copy: UploadSourceCopy = UploadSourceCopy(),
    showScenarioSection: Boolean = true,
    modifier: Modifier = Modifier
) {
    val isReadiness = uiState.draft?.examType == ExamType.READINESS
    val scenarioTitle = if (isReadiness)
        "Hazırbulunuşluk Senaryosu / Ön Koşul-Soru Dağılımı (İsteğe Bağlı)"
    else
        "Sınav Senaryosu / Konu-Soru Dağılım Tablosu (İsteğe Bağlı)"
    val scenarioDescription = if (isReadiness)
        "Ön koşul bilgi/beceri bazlı tanılayıcı raporlama için hazırbulunuşluk senaryosunu yükleyebilirsiniz. Yüklemezseniz raporlarda ön koşul bilgi/beceri analizleri yer almaz."
    else
        "Kazanım bazlı raporlama yapabilmek için sınav senaryosunu yükleyebilirsiniz. Yüklemezseniz raporlarda kazanım analizleri yer almaz."

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag(UploadSourceTestTags.CONTENT)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = copy.title,
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = copy.description,
            style = MaterialTheme.typography.bodyLarge
        )

        if (uiState.message != null && !(uiState.draftExists == false && uiState.message == "Sınav taslağı bulunamadı.")) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.MESSAGE),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uiState.message,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClearMessage) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Mesajı kapat"
                        )
                    }
                }
            }
        }

        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.LOADING)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Kaynak dosyası yükleniyor…")
                }
            }
        } else if (uiState.draftExists == false) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.NOT_FOUND)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Sınav taslağı bulunamadı.")
            }
        } else if (uiState.document == null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.EMPTY_STATE),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudUpload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = copy.emptyTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = copy.emptyDescription,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onSelectPdf,
                            enabled = !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting && uiState.draftExists == true,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag(UploadSourceTestTags.SELECT_BUTTON),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (uiState.isImporting) "Yükleniyor…" else "Dosya Seç")
                        }

                        OutlinedButton(
                            onClick = onPasteText,
                            enabled = !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting && uiState.draftExists == true,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("upload_source_paste_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Metin Yapıştır")
                        }
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.DOCUMENT_CARD)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = uiState.document.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.testTag(UploadSourceTestTags.DOCUMENT_NAME)
                    )
                    Text(
                        text = formatSourceFileSize(uiState.document.sizeBytes),
                        modifier = Modifier.testTag(UploadSourceTestTags.DOCUMENT_SIZE)
                    )
                    Text(
                        text = "${uiState.document.pageCount} parça",
                        modifier = Modifier.testTag(UploadSourceTestTags.DOCUMENT_PAGE_COUNT)
                    )
                    Text(
                        text = copy.documentTypeLabel,
                        modifier = Modifier.testTag(UploadSourceTestTags.DOCUMENT_TYPE)
                    )
                    Text(
                        text = if (uiState.isDocumentUsable) copy.readyLabel else copy.unusableLabel,
                        color = if (uiState.isDocumentUsable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.testTag(UploadSourceTestTags.DOCUMENT_STATUS)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedButton(
                    onClick = onReplacePdf,
                    enabled = !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting,
                    modifier = Modifier
                        .weight(1f)
                        .testTag(UploadSourceTestTags.REPLACE_BUTTON)
                ) {
                    Text(if (uiState.isImporting) "Yükleniyor…" else copy.replaceLabel)
                }
                OutlinedButton(
                    onClick = onRemovePdf,
                    enabled = !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting,
                    modifier = Modifier
                        .weight(1f)
                        .testTag(UploadSourceTestTags.REMOVE_BUTTON)
                ) {
                    Text(if (uiState.isRemoving) "Kaldırılıyor…" else "Dosyayı Kaldır")
                }
            }
            if (showScenarioSection) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = scenarioTitle,
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = scenarioDescription,
                    style = MaterialTheme.typography.bodyMedium
                )
                if (uiState.scenarioObjectives?.isNotEmpty() == true) {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                if (isReadiness)
                                    "Senaryo Yüklendi (${uiState.scenarioObjectives.size} Ön Koşul/Beceri Hedefi)"
                                else
                                    "Senaryo Yüklendi (${uiState.scenarioObjectives.size} Kazanım)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = onRemoveScenario, modifier = Modifier.fillMaxWidth()) {
                                Text("Senaryoyu Kaldır")
                            }
                        }
                    }
                } else if (uiState.extractedScenarioPreview?.isNotEmpty() == true) {
                    Button(onClick = { /* Will open dialog that is declared below */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("Senaryo Önizlemesini Düzenle ve Onayla")
                    }
                } else {
                    OutlinedButton(
                        onClick = onSelectScenarioPdf,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !uiState.isExtractingScenario
                    ) {
                        Text(if (uiState.isExtractingScenario) "Çıkarılıyor..." else "Senaryo Belgesi Yükle (PDF/Görsel)")
                    }
                }
            }

            
            if (uiState.isExtracting) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp
                        )
                        Column {
                            Text(
                                text = "Sorular çıkarılıyor…",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Yapay zeka sınav belgesini analiz edip soruları çıkarıyor, lütfen bekleyin.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onContinue,
                enabled = !uiState.isLoading && uiState.draftExists == true && uiState.isDocumentUsable && !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(UploadSourceTestTags.CONTINUE_BUTTON)
            ) {
                Text(copy.continueLabel)
            }
        }
    }

        if (showScenarioSection && uiState.extractedScenarioPreview?.isNotEmpty() == true) {
            ScenarioPreviewDialog(
                objectives = uiState.extractedScenarioPreview,
                draft = uiState.draft,
                examType = uiState.draft?.examType ?: ExamType.WRITTEN,
                onDismiss = onClearScenarioPreview,
                onConfirm = onConfirmScenario,
                onUpdateObjective = onUpdateStagingObjective,
                onAddObjective = onAddStagingObjective,
                onDeleteObjective = onDeleteStagingObjective
            )
        }
}


@Composable
fun ScenarioPreviewDialog(
    objectives: List<com.example.core.database.ExamObjectiveEntity>,
    draft: com.example.core.database.ExamDraftEntity?,
    examType: ExamType = ExamType.WRITTEN,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    onUpdateObjective: (com.example.core.database.ExamObjectiveEntity) -> Unit,
    onAddObjective: (com.example.core.database.ExamObjectiveEntity) -> Unit,
    onDeleteObjective: (Long) -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    if (examType == ExamType.READINESS) "Hazırbulunuşluk Senaryosunu Düzenle ve Onayla" else "Senaryoyu Düzenle ve Onayla",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                if (draft != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Senaryo Üst Bilgileri", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                            
                            MetadataRow(label = "Senaryodaki Ders", stagingValue = draft.stagingCourseName, draftValue = draft.courseName)
                            MetadataRow(label = "Senaryodaki Sınıf", stagingValue = draft.stagingGradeLevel, draftValue = draft.gradeLevel)
                            MetadataRow(label = "Senaryodaki Dönem", stagingValue = draft.stagingTerm, draftValue = draft.term)
                            MetadataRow(label = "Senaryodaki ${draft.examType.documentExamName()}", stagingValue = draft.stagingExamSequenceNumber, draftValue = draft.examSequenceNumber)
                        }
                    }
                }

                
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items = objectives ?: emptyList(), key = { it.id }) { obj ->
                        ObjectiveEditItem(
                            objective = obj,
                            examType = examType,
                            onUpdate = { onUpdateObjective(it) },
                            onDelete = { onDeleteObjective(obj.id) }
                        )
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                onAddObjective(
                                    com.example.core.database.ExamObjectiveEntity(
                                        examDraftId = 0L,
                                        learningArea = "",
                                        objectiveCode = "",
                                        objectiveText = "",
                                        notes = "",
                                        expectedQuestionCount = 1,
                                        isStaging = true
                                    )
                                )
                            },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text(if (examType == ExamType.READINESS) "Yeni Ön Koşul/Beceri Hedefi Ekle" else "Yeni Kazanım Ekle")
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Vazgeç")
                    }
                    Button(onClick = onConfirm, modifier = Modifier.weight(1f)) {
                        Text("Senaryoyu Onayla")
                    }
                }
            }
        }
    }
}

@Composable
fun MetadataRow(label: String, stagingValue: String?, draftValue: String) {
    val isMissing = stagingValue.isNullOrBlank()
    val isMatch = !isMissing && draftValue.trim().lowercase() == stagingValue!!.trim().lowercase()
    val displayValue = if (isMissing) "Belgede bulunamadı" else stagingValue!!

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            val textColor = when {
                isMissing -> MaterialTheme.colorScheme.onSurfaceVariant
                isMatch -> MaterialTheme.colorScheme.onSurface
                else -> MaterialTheme.colorScheme.error
            }
            Text(
                text = "$label: $displayValue",
                style = MaterialTheme.typography.bodyMedium,
                color = textColor
            )
            if (!isMissing && !isMatch) {
                Text(
                    text = "(Sınav Bilgisi: $draftValue)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
fun ObjectiveEditItem(
    objective: com.example.core.database.ExamObjectiveEntity,
    examType: ExamType = ExamType.WRITTEN,
    onUpdate: (com.example.core.database.ExamObjectiveEntity) -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(
                value = objective.learningArea ?: "",
                onValueChange = { onUpdate(objective.copy(learningArea = it)) },
                label = { Text("Öğrenme Alanı") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = objective.objectiveCode ?: "",
                onValueChange = { onUpdate(objective.copy(objectiveCode = it)) },
                label = { Text(if (examType == ExamType.READINESS) "Ön Koşul/Beceri Kodu" else "Kazanım Kodu") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = objective.objectiveText,
                onValueChange = { onUpdate(objective.copy(objectiveText = it)) },
                label = { Text(if (examType == ExamType.READINESS) "Ön Koşul Bilgi/Beceri Hedefi" else "Kazanım Metni") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = objective.notes ?: "",
                onValueChange = { onUpdate(objective.copy(notes = it)) },
                label = { Text("Açıklama / Notlar") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = objective.expectedQuestionCount?.toString() ?: "",
                onValueChange = { onUpdate(objective.copy(expectedQuestionCount = it.toIntOrNull())) },
                label = { Text("Beklenen Soru Sayısı") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = onDelete, modifier = Modifier.align(Alignment.End)) {
                Text("Sil", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
