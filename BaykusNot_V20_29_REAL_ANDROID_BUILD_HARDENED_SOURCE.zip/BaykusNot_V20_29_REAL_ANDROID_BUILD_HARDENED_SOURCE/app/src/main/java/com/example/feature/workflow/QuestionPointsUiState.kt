package com.example.feature.workflow

import com.example.core.model.ExamType
import com.example.core.model.QuestionPointsValidationIssue

data class QuestionPointsUiState(
    val draftId: Long,
    val draftExists: Boolean = false,
    val examType: ExamType = ExamType.WRITTEN,
    val listeningTranscript: String = "",
    val hasListeningAudio: Boolean = false,
    val listeningPlaybackCount: Int = 2,
    val listeningInstructions: String = "",
    val isListeningMaterialReady: Boolean = true,
    val editableQuestions: List<EditableExamQuestion> = emptyList(),
    val expectedTotalPoints: Int = 0,
    val calculatedTotalPoints: Long = 0L,
    val remainingPoints: Long = 0L,
    val validationIssues: List<QuestionPointsValidationIssue> = emptyList(),
    val inputIssues: List<QuestionPointsInputIssue> = emptyList(),
    val objectives: List<com.example.core.database.ExamObjectiveEntity>? = null,
    val isObjectivesMappingValid: Boolean = true,
    val isObjectiveMappingApproved: Boolean = false,
    val isMismatchAccepted: Boolean = false,
    val hasScenario: Boolean = false,
    val hasObjectiveMismatch: Boolean = false,
    val canSave: Boolean = false,
    val canLock: Boolean = false,
    val canContinue: Boolean = false,
    val isLocked: Boolean = false,
    val lockedAt: Long? = null,
    val revision: Int = 0,
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val isLocking: Boolean = false,
    val isUnlocking: Boolean = false,
    val isSuggestingObjectives: Boolean = false,
    val message: String? = null,
    val hasUnsavedChanges: Boolean = false
)
