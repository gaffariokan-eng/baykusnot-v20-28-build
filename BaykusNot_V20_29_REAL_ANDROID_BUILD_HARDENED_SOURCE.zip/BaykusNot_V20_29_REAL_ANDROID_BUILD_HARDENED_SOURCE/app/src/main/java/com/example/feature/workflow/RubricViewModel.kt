package com.example.feature.workflow

import android.content.Context
import android.net.Uri
import java.io.File
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.TeacherRubricPdfStatus
import com.example.core.data.PdfSafWriter
import com.example.core.model.EvaluationMode
import com.example.core.model.EvaluationPreferences
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel
import com.example.core.model.WritingAndPunctuationPreferences
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.model.WorkflowStage
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.ExamRubricSetMetadata
import com.example.core.data.LockExamRubricSetResult
import com.example.core.data.SaveExamRubricResult
import com.example.core.data.UnlockExamRubricSetResult
import com.example.core.data.ExamRubricGenerationCoordinator
import com.example.core.data.ExamRubricGenerationCoordinatorResult
import com.example.core.data.ExamRubricGenerationPreflightResult
import com.example.core.network.ExamRubricGenerationResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RubricViewModel(
    private val draftId: Long,
    private val examRubricRepository: ExamRubricRepository,
    private val examQuestionRepository: ExamQuestionRepository,
    private val examDraftRepository: ExamDraftRepository,
    private val preferencesRepository: ExamEvaluationPreferencesRepository,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val examListeningMaterialRepository: ExamListeningMaterialRepository? = null,
    private val rubricGenerationCoordinator: ExamRubricGenerationCoordinator? = null,
    private val examRubricGenerator: com.example.core.network.ExamRubricGenerator? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        RubricUiState(
            draftId = draftId,
            draftExists = false,
            questions = emptyList(),
            editableCriteria = emptyList(),
            calculatedPointsByQuestionOrder = emptyMap(),
            validationIssues = emptyList(),
            currentValidationIssues = emptyList(),
            inputIssues = emptyList(),
            canSave = false,
            canLock = false,
            canContinue = false,
            isLocked = false,
            lockedAt = null,
            revision = 0,
            questionSetRevision = null,
            rubricQuestionSetRevision = null,
            isLoading = true,
            isSaving = false,
            isLocking = false,
            isUnlocking = false,
            message = null,
            hasUnsavedChanges = false
        )
    )

    val uiState: StateFlow<RubricUiState> = _uiState.asStateFlow()

    private var draftExists: Boolean = false
    private var examType: ExamType? = null
    private var deductWritingPunctuationPoints: Boolean? = null
    private var questions: List<ExamQuestion> = emptyList()
    private var questionSetMetadata: ExamQuestionSetMetadata? = null
    private var persistedCriteria: List<ExamRubricCriterion> = emptyList()
    private var editableCriteria: List<EditableExamRubricCriterion> = emptyList()
    private var rubricMetadata: ExamRubricSetMetadata? = null
    private var isLoading: Boolean = true
    private var message: String? = null
    private var isSaving: Boolean = false
    private var isLocking: Boolean = false
    private var isUnlocking: Boolean = false
    private var isGenerating: Boolean = false
    private var rubricGenerationJob: Job? = null
    private var documentProcessingJob: Job? = null
    private var matchingJob: Job? = null
    private var evaluationSourceTypeOverride: String? = null
    private var originalTeacherAnswerKeyOverride: String? = null
    private var originalTeacherRubricOverride: String? = null
    private var elaboratedAnswerKeyOverride: String? = null
    private var elaboratedRubricOverride: String? = null
    private var isAsIsOverride: Boolean? = null
    private var isMatching: Boolean = false
    private var answerKeyDocument: UploadedDocumentInfo? = null
    private var rubricDocument: UploadedDocumentInfo? = null
    private var isProcessingDocument: Boolean = false
    private var documentProcessingProgress: String? = null
    private var generatedPdfFile: File? = null
    private var isPdfUpToDate: Boolean = false
    private var pdfStaleTitle: String? = null
    private var pdfStaleSubtitle: String? = null
    private var isGeneratingPdf: Boolean = false
    private var pdfGenerationProgress: String? = null
    private var saveSuccessMessage: String? = null
    private var pdfPageCount: Int = 1
    private var selectedPreviewPageIndex: Int = 1
    internal var nextLocalId: Long = 1L
    private var isFirstQuestionsEmission: Boolean = true
    private var isFirstQuestionMetadataEmission: Boolean = true
    private var isFirstCriteriaEmission: Boolean = true
    private var isFirstRubricMetadataEmission: Boolean = true

    fun cancelActiveAuthoringWork() {
        rubricGenerationJob?.cancel()
        documentProcessingJob?.cancel()
        matchingJob?.cancel()
    }

    init {
        viewModelScope.launch {
            val draft = withContext(ioDispatcher) {
                examDraftRepository.getDraftByIdOnce(draftId)
            }
            
            if (draft == null) {
                draftExists = false
                examType = null
                questions = emptyList()
                questionSetMetadata = null
                persistedCriteria = emptyList()
                editableCriteria = emptyList()
                rubricMetadata = null
                isLoading = false
                message = "Sınav taslağı bulunamadı."
                publishState()
            } else {
                draftExists = true
                examType = draft.examType

                launch {
                    examDraftRepository.getDraftById(draftId).collectLatest { liveDraft ->
                        if (liveDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) {
                            cancelActiveAuthoringWork()
                        }
                    }
                }
                
                // No automatic rubric generation.
                // We just observe questions and wait for user command.
                
                launch {
                    withContext(ioDispatcher) {
                        preferencesRepository.observePreferences(draftId)
                    }.collectLatest { incomingPrefs ->
                        if (draft.examType == ExamType.MULTIPLE_CHOICE) {
                            deductWritingPunctuationPoints = false
                            if (incomingPrefs?.hasExplicitWritingPunctuationPreference != true && incomingPrefs?.isLocked != true) {
                                saveWritingAndPunctuationPreference(false)
                            }
                        } else {
                            // Teacher Mode determines writing/punctuation relevance per question.
                            // Keep the legacy flag false so rubric generation never waits for a toggle.
                            deductWritingPunctuationPoints = false
                        }
                        publishState()
                    }
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examQuestionRepository.observeQuestions(draftId)
                    }.collectLatest { incomingQuestions ->
                        handleIncomingQuestions(incomingQuestions)
                    }
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examQuestionRepository.observeMetadata(draftId)
                    }.collectLatest { incomingMetadata ->
                        handleIncomingQuestionMetadata(incomingMetadata)
                    }
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examRubricRepository.observeCriteria(draftId)
                    }.collectLatest { incomingCriteria ->
                        handleIncomingCriteria(incomingCriteria)
                    }
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examRubricRepository.observeMetadata(draftId)
                    }.collectLatest { incomingMetadata ->
                        handleIncomingRubricMetadata(incomingMetadata)
                    }
                }
            }
        }
    }

    private fun handleGenerationResult(result: ExamRubricGenerationCoordinatorResult) {
        when (result) {
            is ExamRubricGenerationCoordinatorResult.PreflightBlocked -> {
                when (result.result) {
                    ExamRubricGenerationPreflightResult.InvalidTarget -> {
                        message = "Sınav bilgisi geçersiz olduğu için rubrik oluşturulamadı."
                    }
                    ExamRubricGenerationPreflightResult.QuestionMetadataMissing -> {
                        message = "Soru seti bilgisi bulunamadığı için rubrik oluşturulamadı."
                    }
                    ExamRubricGenerationPreflightResult.QuestionsMissing -> {
                        message = "Rubrik oluşturmak için soru bulunamadı."
                    }
                    ExamRubricGenerationPreflightResult.QuestionSetUnlocked -> {
                        message = "Rubrik oluşturmak için önce soru ve puanları kilitleyin."
                    }
                    ExamRubricGenerationPreflightResult.PreferencesMissing -> {
                        message = "Öğretmen Modu rubrik hazırlığı tamamlanamadı. Lütfen yeniden deneyin."
                    }
                    ExamRubricGenerationPreflightResult.PreferencesIncomplete -> {
                        message = "Öğretmen Modu rubrik hazırlığı tamamlanamadı. Lütfen yeniden deneyin."
                    }
                    ExamRubricGenerationPreflightResult.ListeningSourceMissing -> {
                        message = "Dinleme sınavı kaynağı bulunamadı. Dinleme Materyali aşamasında ses dosyası veya dinleme metni ekleyin."
                    }
                    ExamRubricGenerationPreflightResult.HomeworkSourceMissing -> {
                        message = "Ödev kaynağı bulunamadı. Ödev Kaynağı aşamasında ödev dosyası veya ödev metni ekleyin."
                    }
                    ExamRubricGenerationPreflightResult.ExistingRubric -> {
                        // ExistingRubric is NOT an error.
                    }
                    is ExamRubricGenerationPreflightResult.Ready -> {
                        // Will not occur in PreflightBlocked
                    }
                }
            }
            is ExamRubricGenerationCoordinatorResult.GenerationFailed -> {
                when (result.result) {
                    ExamRubricGenerationResult.MissingApiKey -> {
                        message = "Gemini API anahtarı bulunamadı."
                    }
                    ExamRubricGenerationResult.Unauthorized -> {
                        message = "Gemini API anahtarı geçersiz veya yetkisiz."
                    }
                    ExamRubricGenerationResult.RateLimited -> {
                        message = "Gemini kullanım sınırına ulaşıldı. Daha sonra tekrar deneyin."
                    }
                    ExamRubricGenerationResult.ServiceUnavailable -> {
                        message = "Gemini hizmetine şu anda ulaşılamıyor."
                    }
                    ExamRubricGenerationResult.NetworkFailure -> {
                        message = "İnternet bağlantısı nedeniyle rubrik oluşturulamadı."
                    }
                    ExamRubricGenerationResult.MalformedResponse -> {
                        message = "Gemini rubriği beklenen biçimde döndürmedi."
                    }
                    ExamRubricGenerationResult.InvalidInput -> {
                        message = "Rubrik oluşturma girdisi geçersiz."
                    }
                    ExamRubricGenerationResult.UnexpectedFailure -> {
                        message = "Rubrik oluşturulurken beklenmeyen bir hata oluştu."
                    }
                    is ExamRubricGenerationResult.Generated -> {
                        // Will not occur in GenerationFailed
                    }
                }
            }
            is ExamRubricGenerationCoordinatorResult.ValidationFailed -> {
                val issueCodes = result.result.issues
                    .map { it.code.name }
                    .distinct()
                    .joinToString(", ")
                message = if (issueCodes.isNotBlank()) {
                    "Üretilen rubrik doğrulamadan geçemedi: $issueCodes"
                } else {
                    "Üretilen rubrik doğrulamadan geçemedi."
                }
            }
            is ExamRubricGenerationCoordinatorResult.SaveResult -> {
                when (val saveRes = result.result) {
                    is SaveExamRubricResult.Success -> {
                        // Success -> no failure message
                    }
                    SaveExamRubricResult.DraftNotFound -> {
                        message = "Sınav kaydı bulunamadığı için rubrik kaydedilemedi."
                    }
                    SaveExamRubricResult.QuestionSetMetadataMissing -> {
                        message = "Soru seti bilgisi bulunamadığı için rubrik kaydedilemedi."
                    }
                    is SaveExamRubricResult.ValidationFailed -> {
                        message = "Otomatik üretilen rubrik doğrulanamadığı için kaydedilemedi."
                    }
                    is SaveExamRubricResult.Locked -> {
                        message = "Rubrik kilitli olduğu için otomatik rubrik kaydedilemedi."
                    }
                    is SaveExamRubricResult.RevisionConflict -> {
                        message = "Rubrik kaydedilirken sürüm çakışması oluştu."
                    }
                    SaveExamRubricResult.StateConflict -> {
                        message = "Soru veya rubrik durumu değiştiği için rubrik kaydedilemedi."
                    }
                    is SaveExamRubricResult.Failure -> {
                        message = "Otomatik rubrik kaydedilirken beklenmeyen bir hata oluştu."
                    }
                }
            }
        }
    }

    private fun handleIncomingQuestions(incomingQuestions: List<ExamQuestion>) {
        questions = incomingQuestions
        if (isFirstQuestionsEmission) {
            isFirstQuestionsEmission = false
            checkInitialLoadingComplete()
            publishState()
            return
        }
        checkInitialLoadingComplete()
        publishState()
    }

    private fun handleIncomingQuestionMetadata(incomingMetadata: ExamQuestionSetMetadata?) {
        questionSetMetadata = incomingMetadata
        if (isFirstQuestionMetadataEmission) {
            isFirstQuestionMetadataEmission = false
        }
        checkInitialLoadingComplete()
        publishState()
    }

    private fun handleIncomingCriteria(incomingCriteria: List<ExamRubricCriterion>) {
        if (isFirstCriteriaEmission) {
            val mapping = RubricEditableMapper.map(
                criteria = incomingCriteria,
                firstLocalId = nextLocalId
            )
            editableCriteria = mapping.editableCriteria
            nextLocalId = mapping.nextLocalId
            persistedCriteria = incomingCriteria
            isFirstCriteriaEmission = false
            checkInitialLoadingComplete()
            publishState()
            return
        }

        val wasDirty = RubricDirtyStateEvaluator.hasUnsavedChanges(
            editableCriteria = editableCriteria,
            persistedCriteria = persistedCriteria
        )
        val contentsChanged = persistedCriteria != incomingCriteria

        if (!wasDirty && contentsChanged) {
            val mapping = RubricEditableMapper.map(
                criteria = incomingCriteria,
                firstLocalId = nextLocalId
            )
            editableCriteria = mapping.editableCriteria
            nextLocalId = mapping.nextLocalId
        }

        persistedCriteria = incomingCriteria
        publishState()
    }

    private fun handleIncomingRubricMetadata(incomingMetadata: ExamRubricSetMetadata?) {
        rubricMetadata = incomingMetadata
        if (isFirstRubricMetadataEmission) {
            isFirstRubricMetadataEmission = false
        }
        checkInitialLoadingComplete()
        publishState()
    }

    private fun checkInitialLoadingComplete() {
        if (!isFirstQuestionsEmission &&
            !isFirstQuestionMetadataEmission &&
            !isFirstCriteriaEmission &&
            !isFirstRubricMetadataEmission &&
            !isGenerating
        ) {
            isLoading = false
        }
    }

    private fun publishState() {
        val hasUnsavedChanges = RubricDirtyStateEvaluator.hasUnsavedChanges(
            editableCriteria = editableCriteria,
            persistedCriteria = persistedCriteria
        )

        val resolvedType = evaluationSourceTypeOverride ?: rubricMetadata?.evaluationSourceType ?: "AI_GENERATED_RUBRIC"
        val resolvedAnswerKey = originalTeacherAnswerKeyOverride ?: rubricMetadata?.originalTeacherAnswerKey
        val resolvedRubric = originalTeacherRubricOverride ?: rubricMetadata?.originalTeacherRubric
        val resolvedIsAsIs = isAsIsOverride ?: rubricMetadata?.isAsIs ?: false
        val resolvedElaboratedAnswerKey = if (resolvedIsAsIs) null else (elaboratedAnswerKeyOverride ?: rubricMetadata?.elaboratedAnswerKey)
        val resolvedElaboratedRubric = if (resolvedIsAsIs) null else (elaboratedRubricOverride ?: rubricMetadata?.elaboratedRubric)

        val baseState = RubricUiStateFactory.create(
            draftId = draftId,
            draftExists = draftExists,
            examType = examType ?: ExamType.WRITTEN,
            questions = questions,
            questionSetMetadata = questionSetMetadata,
            rubricMetadata = rubricMetadata,
            editableCriteria = editableCriteria,
            deductWritingPunctuationPoints = deductWritingPunctuationPoints,
            isGenerating = isGenerating,
            hasUnsavedChanges = hasUnsavedChanges,
            isLoading = isLoading,
            isSaving = isSaving,
            isLocking = isLocking,
            isUnlocking = isUnlocking,
            message = message,
            evaluationSourceType = resolvedType,
            originalTeacherAnswerKey = resolvedAnswerKey,
            originalTeacherRubric = resolvedRubric,
            elaboratedAnswerKey = resolvedElaboratedAnswerKey,
            elaboratedRubric = resolvedElaboratedRubric,
            isAsIs = resolvedIsAsIs,
            isMatching = isMatching,
            answerKeyDocument = answerKeyDocument,
            rubricDocument = rubricDocument,
            isProcessingDocument = isProcessingDocument,
            documentProcessingProgress = documentProcessingProgress
        )

        _uiState.value = baseState.copy(
            generatedPdfFile = generatedPdfFile,
            isPdfUpToDate = isPdfUpToDate,
            pdfStaleTitle = pdfStaleTitle,
            pdfStaleSubtitle = pdfStaleSubtitle,
            isGeneratingPdf = isGeneratingPdf,
            pdfGenerationProgress = pdfGenerationProgress,
            saveSuccessMessage = saveSuccessMessage,
            pdfPageCount = pdfPageCount,
            selectedPreviewPageIndex = selectedPreviewPageIndex
        )
    }

    fun checkTeacherRubricPdfStatus(context: Context) {
        viewModelScope.launch(ioDispatcher) {
            val status = examRubricRepository.getTeacherRubricPdfStatus(context, draftId)
            when (status) {
                is TeacherRubricPdfStatus.UpToDate -> {
                    val count = getPdfPageCount(status.pdfFile)
                    generatedPdfFile = status.pdfFile
                    isPdfUpToDate = true
                    pdfStaleTitle = null
                    pdfStaleSubtitle = null
                    pdfPageCount = count
                    selectedPreviewPageIndex = selectedPreviewPageIndex.coerceIn(1, count)
                }
                is TeacherRubricPdfStatus.Stale -> {
                    val count = getPdfPageCount(status.pdfFile)
                    generatedPdfFile = status.pdfFile
                    isPdfUpToDate = false
                    pdfStaleTitle = status.title
                    pdfStaleSubtitle = status.subtitle
                    pdfPageCount = count
                    selectedPreviewPageIndex = selectedPreviewPageIndex.coerceIn(1, count)
                }
                is TeacherRubricPdfStatus.NotGenerated -> {
                    generatedPdfFile = null
                    isPdfUpToDate = false
                    pdfStaleTitle = null
                    pdfStaleSubtitle = null
                    pdfPageCount = 1
                    selectedPreviewPageIndex = 1
                }
            }
            publishState()
        }
    }

    fun generateTeacherRubricPdf(context: Context) {
        viewModelScope.launch(ioDispatcher) {
            isGeneratingPdf = true
            pdfGenerationProgress = "Öğretmen rubriği PDF belgesi hazırlanıyor..."
            publishState()
            try {
                val file = examRubricRepository.generateTeacherRubricPdf(context, draftId)
                val count = getPdfPageCount(file)
                isGeneratingPdf = false
                pdfGenerationProgress = null
                generatedPdfFile = file
                isPdfUpToDate = true
                pdfStaleTitle = null
                pdfStaleSubtitle = null
                pdfPageCount = count
                selectedPreviewPageIndex = 1
                saveSuccessMessage = "Öğretmen Rubriği PDF belgesi başarıyla oluşturuldu."
                publishState()
            } catch (e: Exception) {
                isGeneratingPdf = false
                pdfGenerationProgress = null
                message = "Rubrik PDF oluşturulamadı. Lütfen tekrar deneyin."
                publishState()
            }
        }
    }

    fun savePdfToUri(context: Context, destination: Uri) {
        val file = generatedPdfFile ?: return
        if (!file.exists()) return

        viewModelScope.launch(ioDispatcher) {
            PdfSafWriter.writeVerified(context, file, destination)
                .onSuccess {
                    saveSuccessMessage = "PDF seçtiğiniz konuma güvenli biçimde kaydedildi (${file.name})."
                    message = null
                    publishState()
                }
                .onFailure {
                    message = "PDF kaydedilemedi veya yazım doğrulanamadı. Lütfen başka bir konum seçip tekrar deneyin."
                    publishState()
                }
        }
    }

    fun selectPreviewPage(pageIndex: Int) {
        val max = pdfPageCount.coerceAtLeast(1)
        selectedPreviewPageIndex = pageIndex.coerceIn(1, max)
        publishState()
    }

    fun clearSaveSuccessMessage() {
        saveSuccessMessage = null
        publishState()
    }

    private fun getPdfPageCount(file: File): Int {
        return try {
            android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                android.graphics.pdf.PdfRenderer(pfd).use { renderer ->
                    renderer.pageCount.coerceAtLeast(1)
                }
            }
        } catch (e: Exception) {
            1
        }
    }

    fun addCriterion(questionOrderIndex: Int) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return

        val question = questions.firstOrNull {
            it.orderIndex == questionOrderIndex
        } ?: return

        if (nextLocalId == Long.MAX_VALUE) {
            message = "Yeni rubrik ölçütü eklenemedi."
            publishState()
            return
        }

        val updatedCriteria = EditableExamRubricCriterionListEditor.addCriterion(
            criteria = editableCriteria,
            localId = nextLocalId,
            questionOrderIndex = question.orderIndex,
            questionNumberSnapshot = question.questionNumber
        )

        if (updatedCriteria !== editableCriteria) {
            editableCriteria = updatedCriteria
            nextLocalId++
        }

        publishState()
    }

    fun removeCriterion(localId: Long) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.removeCriterion(
            criteria = editableCriteria,
            localId = localId
        )
        publishState()
    }

    fun updateCriterionTitle(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updateTitle(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun updateCriterionDescription(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updateDescription(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun updateCriterionMaxPoints(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updateMaxPoints(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun updateCriterionExpectedAnswer(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updateExpectedAnswer(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun updateCriterionPartialCreditGuidance(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updatePartialCreditGuidance(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun updateCriterionCommonMistakes(localId: Long, value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.updateCommonMistakes(
            criteria = editableCriteria,
            localId = localId,
            value = value
        )
        publishState()
    }

    fun moveCriterionUp(localId: Long) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.moveCriterionUp(
            criteria = editableCriteria,
            localId = localId
        )
        publishState()
    }

    fun moveCriterionDown(localId: Long) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true) return
        editableCriteria = EditableExamRubricCriterionListEditor.moveCriterionDown(
            criteria = editableCriteria,
            localId = localId
        )
        publishState()
    }

    fun dismissMessage() {
        message = null
        publishState()
    }

    fun reportDocumentSelectionError(error: String) {
        message = error.take(300)
        publishState()
    }

    fun saveRubric() {
        if (!_uiState.value.canSave) return

        val hasUnsavedChanges =
            RubricDirtyStateEvaluator.hasUnsavedChanges(
                editableCriteria = editableCriteria,
                persistedCriteria = persistedCriteria
            )

        val evaluation = RubricFormEvaluator.evaluate(
            examDraftId = draftId,
            questions = questions,
            questionSetMetadata = questionSetMetadata,
            rubricMetadata = rubricMetadata,
            editableCriteria = editableCriteria,
            hasUnsavedChanges = hasUnsavedChanges
        )

        val criteria = evaluation.domainCriteria ?: return

        if (evaluation.saveValidation?.isValid != true) return

        val expectedRevision = rubricMetadata?.revision ?: 0

        isSaving = true
        message = null
        publishState()

        val resolvedType = evaluationSourceTypeOverride ?: rubricMetadata?.evaluationSourceType ?: "AI_GENERATED_RUBRIC"
        val resolvedAnswerKey = originalTeacherAnswerKeyOverride ?: rubricMetadata?.originalTeacherAnswerKey
        val resolvedRubric = originalTeacherRubricOverride ?: rubricMetadata?.originalTeacherRubric
        val resolvedIsAsIs = isAsIsOverride ?: rubricMetadata?.isAsIs ?: false

        val resolvedElaboratedAnswerKey = if (resolvedIsAsIs) null else (elaboratedAnswerKeyOverride ?: rubricMetadata?.elaboratedAnswerKey)
        val resolvedElaboratedRubric = if (resolvedIsAsIs) null else (elaboratedRubricOverride ?: rubricMetadata?.elaboratedRubric)

        val metadataToMerge = ExamRubricSetMetadata(
            examDraftId = draftId,
            questionSetRevision = questionSetMetadata?.revision ?: 0,
            isLocked = false,
            lockedAt = null,
            revision = rubricMetadata?.revision ?: 0,
            createdAt = rubricMetadata?.createdAt ?: 0L,
            updatedAt = 0L,
            evaluationSourceType = resolvedType,
            originalTeacherAnswerKey = resolvedAnswerKey,
            originalTeacherRubric = resolvedRubric,
            elaboratedAnswerKey = resolvedElaboratedAnswerKey,
            elaboratedRubric = resolvedElaboratedRubric,
            isAsIs = resolvedIsAsIs
        )

        viewModelScope.launch {
            try {
                val result = withContext(ioDispatcher) {
                    examRubricRepository.saveRubric(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision,
                        criteria = criteria,
                        metadataToMerge = metadataToMerge
                    )
                }

                when (result) {
                    is SaveExamRubricResult.Success -> {
                        rubricMetadata = result.metadata
                        message = "Rubrik kaydedildi."
                    }
                    SaveExamRubricResult.DraftNotFound -> {
                        draftExists = false
                        message = "Sınav taslağı bulunamadı."
                    }
                    SaveExamRubricResult.QuestionSetMetadataMissing -> {
                        message = "Soru seti bilgisi bulunamadı."
                    }
                    is SaveExamRubricResult.ValidationFailed -> {
                        message = "Rubrik kaydedilemedi. Rubrik bilgilerini kontrol edin."
                    }
                    is SaveExamRubricResult.Locked -> {
                        message = "Kilitli rubrik kaydedilemez."
                    }
                    is SaveExamRubricResult.RevisionConflict -> {
                        message = "Rubrik başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    SaveExamRubricResult.StateConflict -> {
                        message = "Rubrik durumu değişti. Lütfen yeniden deneyin."
                    }
                    is SaveExamRubricResult.Failure -> {
                        message = "Rubrik kaydedilemedi."
                    }
                }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                message = "Rubrik kaydedilemedi."
            } finally {
                isSaving = false
                publishState()
            }
        }
    }

    fun unlockRubricSet() {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked != true) return

        val expectedRevision = rubricMetadata?.revision ?: return

        isUnlocking = true
        message = null
        publishState()

        viewModelScope.launch {
            try {
                val result = withContext(ioDispatcher) {
                    examRubricRepository.unlockRubricSet(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision
                    )
                }

                when (result) {
                    is UnlockExamRubricSetResult.Success -> {
                        rubricMetadata = result.metadata
                        message = "Rubrik kilidi açıldı."
                    }
                    UnlockExamRubricSetResult.MetadataMissing -> {
                        message = "Kaydedilmiş rubrik bulunamadı."
                    }
                    is UnlockExamRubricSetResult.AlreadyUnlocked -> {
                        message = "Rubriğin kilidi zaten açık."
                    }
                    is UnlockExamRubricSetResult.RevisionConflict -> {
                        message = "Rubrik başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    UnlockExamRubricSetResult.StateConflict -> {
                        message = "Rubrik durumu değişti. Lütfen yeniden deneyin."
                    }
                    is UnlockExamRubricSetResult.Failure -> {
                        message = "Rubrik kilidi açılamadı."
                    }
                }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                message = "Rubrik kilidi açılamadı."
            } finally {
                isUnlocking = false
                publishState()
            }
        }
    }

    fun saveWritingAndPunctuationPreference(deduct: Boolean) {
        viewModelScope.launch {
            try {
                val currentEntity = preferencesRepository.observePreferences(draftId).first()
                
                val currentPrefs = EvaluationPreferences(
                    evaluationMode = currentEntity?.evaluationMode ?: EvaluationMode.PAPER_BY_PAPER,
                    rubricAdherenceLevel = currentEntity?.rubricAdherenceLevel ?: RubricAdherenceLevel.BALANCED,
                    feedbackDetailLevel = currentEntity?.feedbackDetailLevel ?: FeedbackDetailLevel.BRIEF,
                    writingAndPunctuation = WritingAndPunctuationPreferences(
                        deductPoints = deduct,
                        hasExplicitPreference = true,
                        provideFeedback = currentEntity?.provideWritingAndPunctuationFeedback ?: false
                    ),
                    modelQualityTier = currentEntity?.modelQualityTier ?: ModelQualityTier.STANDARD
                )
                
                preferencesRepository.savePreferences(draftId, currentPrefs)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                message = "Tercih kaydedilemedi."
                publishState()
            }
        }
    }

    fun generateRubric() {
        if (_uiState.value.isGenerating || rubricGenerationCoordinator == null) return
        if (_uiState.value.examType == ExamType.MULTIPLE_CHOICE) {
            message = "Test Sınavında yapay zekâ rubriği kullanılmaz. Doğru seçenekleri Cevap Anahtarı ekranından girin."
            publishState()
            return
        }
        
        isGenerating = true
        message = null
        publishState()
        
        val job = viewModelScope.launch {
            try {
                val stageDraft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (stageDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) return@launch
                val result = rubricGenerationCoordinator.generate(draftId)
                handleGenerationResult(result)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                message = "Otomatik rubrik oluşturulamadı."
            } finally {
                isGenerating = false
                publishState()
            }
        }
        rubricGenerationJob = job
        job.invokeOnCompletion {
            if (rubricGenerationJob === job) rubricGenerationJob = null
            isGenerating = false
            publishState()
        }
    }

    fun lockRubricSet() {
        if (!_uiState.value.canLock) return

        val expectedRevision = rubricMetadata?.revision ?: return

        isLocking = true
        message = null
        publishState()

        viewModelScope.launch {
            try {
                val result = withContext(ioDispatcher) {
                    examRubricRepository.lockRubricSet(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision
                    )
                }

                when (result) {
                    is LockExamRubricSetResult.Success -> {
                        rubricMetadata = result.metadata
                        message = "Rubrik kilitlendi."
                    }
                    LockExamRubricSetResult.DraftNotFound -> {
                        draftExists = false
                        message = "Sınav taslağı bulunamadı."
                    }
                    LockExamRubricSetResult.MetadataMissing -> {
                        message = "Kaydedilmiş rubrik bulunamadı."
                    }
                    LockExamRubricSetResult.QuestionSetMetadataMissing -> {
                        message = "Soru seti bilgisi bulunamadı."
                    }
                    is LockExamRubricSetResult.ValidationFailed -> {
                        message = "Rubrik kilitlenemedi. Rubrik bilgilerini kontrol edin."
                    }
                    is LockExamRubricSetResult.AlreadyLocked -> {
                        message = "Rubrik zaten kilitli."
                    }
                    is LockExamRubricSetResult.RevisionConflict -> {
                        message = "Rubrik başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    LockExamRubricSetResult.StateConflict -> {
                        message = "Rubrik durumu değişti. Lütfen yeniden deneyin."
                    }
                    is LockExamRubricSetResult.Failure -> {
                        message = "Rubrik kilitlenemedi."
                    }
                }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                message = "Rubrik kilitlenemedi."
            } finally {
                isLocking = false
                publishState()
            }
        }
    }

    fun setEvaluationSourceType(type: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        evaluationSourceTypeOverride = type
        publishState()
    }

    fun updateOriginalTeacherAnswerKey(value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        originalTeacherAnswerKeyOverride = value
        publishState()
    }

    fun updateOriginalTeacherRubric(value: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        originalTeacherRubricOverride = value
        publishState()
    }

    fun setIsAsIs(value: Boolean) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        isAsIsOverride = value
        if (value) {
            elaboratedAnswerKeyOverride = null
            elaboratedRubricOverride = null
        }
        publishState()
    }

    fun processUploadedDocument(
        targetType: String, // "ANSWER_KEY" or "RUBRIC"
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching || isProcessingDocument) return

        val isPdf = mimeType.contains("pdf", ignoreCase = true) || fileName.endsWith(".pdf", ignoreCase = true)
        val isLegacyDoc = fileName.endsWith(".doc", ignoreCase = true) || mimeType.equals("application/msword", ignoreCase = true)
        if (isLegacyDoc) {
            message = "Eski .doc biçimi desteklenmiyor. Dosyayı .docx veya PDF olarak kaydedip yeniden seçin."
            publishState()
            return
        }
        val isDocx = mimeType.contains("officedocument", ignoreCase = true) || fileName.endsWith(".docx", ignoreCase = true)
        val isPng = mimeType.contains("png", ignoreCase = true) || fileName.endsWith(".png", ignoreCase = true)
        val isWebP = mimeType.contains("webp", ignoreCase = true) || fileName.endsWith(".webp", ignoreCase = true)
        val isJpeg = mimeType.contains("jpeg", ignoreCase = true) || mimeType.contains("jpg", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) || fileName.endsWith(".jpg", ignoreCase = true)
        val isTxt = mimeType.contains("text", ignoreCase = true) || fileName.endsWith(".txt", ignoreCase = true)

        val typeLabel = when {
            isPdf -> "PDF"
            isDocx -> "DOCX / Word"
            isPng -> "PNG Görseli"
            isWebP -> "WebP Görseli"
            isJpeg -> "JPEG Görseli"
            else -> "Metin Belgesi"
        }

        if (!isPdf && !isDocx && !isPng && !isWebP && !isJpeg && !isTxt) {
            val errDoc = UploadedDocumentInfo(
                fileName = fileName,
                fileType = typeLabel,
                pageCount = null,
                sizeBytes = bytes.size.toLong(),
                status = "ERROR",
                statusMessage = "Bu dosya türü desteklenmiyor. Yalnızca PDF, Word (DOCX), PNG, JPEG veya WebP yükleyebilirsiniz."
            )
            if (targetType == "ANSWER_KEY") answerKeyDocument = errDoc else rubricDocument = errDoc
            message = "Bu dosya türü desteklenmiyor."
            publishState()
            return
        }

        isProcessingDocument = true
        documentProcessingProgress = "Dosya hazırlanıyor..."

        val initialDocInfo = UploadedDocumentInfo(
            fileName = fileName,
            fileType = typeLabel,
            pageCount = null,
            sizeBytes = bytes.size.toLong(),
            status = "PREPARING",
            statusMessage = "Dosya hazırlanıyor..."
        )

        if (targetType == "ANSWER_KEY") {
            answerKeyDocument = initialDocInfo
        } else {
            rubricDocument = initialDocInfo
        }
        publishState()

        val job = viewModelScope.launch {
            try {
                val stageDraft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (stageDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) return@launch
                documentProcessingProgress = "İçerik okunuyor..."
                val readingDoc = initialDocInfo.copy(
                    status = "READING",
                    statusMessage = "İçerik okunuyor..."
                )
                if (targetType == "ANSWER_KEY") answerKeyDocument = readingDoc else rubricDocument = readingDoc
                publishState()

                var pageCount: Int? = null
                if (isPdf) {
                    val tempPdfFile = java.io.File.createTempFile("uploaded_", ".pdf")
                    try {
                        tempPdfFile.writeBytes(bytes)
                        pageCount = com.example.core.data.AndroidPdfPageInspector().readPageCount(tempPdfFile)
                    } catch (e: Exception) {
                        pageCount = 1
                    } finally {
                        tempPdfFile.delete()
                    }
                }

                val extractionResult = withContext(ioDispatcher) {
                    if (examRubricGenerator != null) {
                        examRubricGenerator.extractDocumentTextForExam(draftId, fileName, mimeType, bytes)
                    } else if (isDocx) {
                        try {
                            val parsed = com.example.core.data.DocxParser.parse(bytes)
                            val docxText = parsed.parts
                                .filterIsInstance<com.example.core.network.ExamExtractionInput.WordPart.TextPart>()
                                .joinToString("\n") { it.text }
                                .trim()
                            if (docxText.isNotBlank()) Result.success(docxText) else Result.failure(Exception("Word belgesi boş."))
                        } catch (e: Exception) {
                            Result.failure(e)
                        }
                    } else if (isTxt) {
                        Result.success(String(bytes, Charsets.UTF_8))
                    } else {
                        Result.failure(Exception("Rubrik oluşturucu servis bulunamadı."))
                    }
                }

                val latestDraft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (latestDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) return@launch
                val extractedText = extractionResult.getOrNull()

                if (extractedText.isNullOrBlank()) {
                    val errorMsg = extractionResult.exceptionOrNull()?.message ?: "Belgeden metin içerik okunamadı."
                    val errDoc = initialDocInfo.copy(
                        pageCount = pageCount,
                        status = "ERROR",
                        statusMessage = errorMsg
                    )
                    if (targetType == "ANSWER_KEY") answerKeyDocument = errDoc else rubricDocument = errDoc
                    message = errorMsg
                } else {
                    val successDoc = initialDocInfo.copy(
                        pageCount = pageCount,
                        status = "SUCCESS",
                        statusMessage = "Sorularla eşleştirmeye hazır"
                    )
                    if (targetType == "ANSWER_KEY") {
                        originalTeacherAnswerKeyOverride = extractedText
                        answerKeyDocument = successDoc
                    } else {
                        originalTeacherRubricOverride = extractedText
                        rubricDocument = successDoc
                    }
                    message = "$typeLabel belgesi başarıyla okundu."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val errDoc = initialDocInfo.copy(
                    status = "ERROR",
                    statusMessage = "Dosya işlenirken hata oluştu: ${e.localizedMessage ?: "Okuma hatası"}"
                )
                if (targetType == "ANSWER_KEY") answerKeyDocument = errDoc else rubricDocument = errDoc
                message = "Dosya okunamadı."
            } finally {
                isProcessingDocument = false
                documentProcessingProgress = null
                publishState()
            }
        }
        documentProcessingJob = job
        job.invokeOnCompletion {
            if (documentProcessingJob === job) documentProcessingJob = null
            isProcessingDocument = false
            documentProcessingProgress = null
            publishState()
        }
    }

    fun removeUploadedDocument(targetType: String) {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        if (targetType == "ANSWER_KEY") {
            answerKeyDocument = null
            originalTeacherAnswerKeyOverride = ""
        } else {
            rubricDocument = null
            originalTeacherRubricOverride = ""
        }
        message = "Yüklenen belge kaldırıldı."
        publishState()
    }

    fun matchWithQuestions() {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || rubricMetadata?.isLocked == true || isMatching) return
        val currentType = evaluationSourceTypeOverride ?: rubricMetadata?.evaluationSourceType ?: "AI_GENERATED_RUBRIC"
        val answerKey = originalTeacherAnswerKeyOverride ?: rubricMetadata?.originalTeacherAnswerKey ?: ""
        val rubric = originalTeacherRubricOverride ?: rubricMetadata?.originalTeacherRubric ?: ""
        val isAsIs = isAsIsOverride ?: rubricMetadata?.isAsIs ?: false

        if (currentType == "TEACHER_ANSWER_KEY" && answerKey.isBlank()) {
            message = "Cevap anahtarı içeriği boş olamaz."
            publishState()
            return
        }
        if (currentType == "TEACHER_RUBRIC" && rubric.isBlank()) {
            message = "Rubrik içeriği boş olamaz."
            publishState()
            return
        }
        if (currentType == "TEACHER_ANSWER_KEY_AND_RUBRIC" && (answerKey.isBlank() || rubric.isBlank())) {
            message = "Hem cevap anahtarı hem de rubrik içeriği doldurulmalıdır."
            publishState()
            return
        }

        if (examRubricGenerator == null) {
            message = "Rubrik oluşturucu bulunamadı."
            publishState()
            return
        }

        isMatching = true
        message = null
        publishState()

        val job = viewModelScope.launch {
            try {
                val stageDraft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (stageDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) return@launch
                val sourceContext = if (examType == ExamType.LISTENING) {
                    withContext(ioDispatcher) {
                        examListeningMaterialRepository?.getRubricSourceContext(draftId)
                    } ?: run {
                        message = "Dinleme sınavı kaynağı bulunamadı. Önce ses dosyası veya dinleme metni ekleyin."
                        return@launch
                    }
                } else {
                    null
                }

                val generationInput = com.example.core.network.ExamRubricGenerationInput(
                    examDraftId = draftId,
                    questions = questions.map {
                        com.example.core.network.RubricGenerationQuestion(
                            questionOrderIndex = it.orderIndex,
                            questionNumber = it.questionNumber,
                            questionText = it.questionText,
                            points = it.points.toInt()
                        )
                    },
                    deductWritingPunctuationPoints = false,
                    sourceContext = sourceContext,
                    examType = examType ?: ExamType.WRITTEN
                )

                val result = withContext(ioDispatcher) {
                    examRubricGenerator.generateWithSource(
                        input = generationInput,
                        evaluationSourceType = currentType,
                        originalTeacherAnswerKey = answerKey,
                        originalTeacherRubric = rubric,
                        isAsIs = isAsIs
                    )
                }
                val latestDraft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (latestDraft?.currentWorkflowStage != WorkflowStage.RUBRIC) return@launch

                when (result) {
                    is com.example.core.network.ExamRubricGenerationResult.Generated -> {
                        val mapped = result.criteria.map {
                            ExamRubricCriterion(
                                id = 0L,
                                examDraftId = draftId,
                                questionOrderIndex = it.questionOrderIndex,
                                questionNumberSnapshot = it.questionNumberSnapshot,
                                criterionOrderIndex = it.criterionOrderIndex,
                                title = it.title,
                                description = it.description,
                                maxPoints = it.maxPoints,
                                expectedAnswer = it.expectedAnswer,
                                partialCreditGuidance = it.partialCreditGuidance,
                                commonMistakes = it.commonMistakes,
                                originalAnswerKey = answerKey.takeIf { currentType != "TEACHER_RUBRIC" },
                                originalRubric = rubric.takeIf { currentType != "TEACHER_ANSWER_KEY" }
                            )
                        }

                        if (!isAsIs) {
                            elaboratedAnswerKeyOverride = mapped
                                .groupBy { it.questionOrderIndex }
                                .values
                                .mapNotNull { group ->
                                    val first = group.firstOrNull() ?: return@mapNotNull null
                                    "Soru ${first.questionNumberSnapshot}: ${first.expectedAnswer}"
                                }
                                .joinToString("\n\n")

                            elaboratedRubricOverride = mapped
                                .joinToString("\n\n") { c ->
                                    val partialStr = if (c.partialCreditGuidance.isNotBlank()) "\nKısmi Puan: ${c.partialCreditGuidance}" else ""
                                    val mistakesStr = if (c.commonMistakes.isNotBlank()) "\nYaygın Hatalar: ${c.commonMistakes}" else ""
                                    "Soru ${c.questionNumberSnapshot} - ${c.title} (${c.maxPoints} Puan):\n${c.description}$partialStr$mistakesStr"
                                }
                        } else {
                            elaboratedAnswerKeyOverride = null
                            elaboratedRubricOverride = null
                        }

                        // Re-initialize local editing variables
                        val mapping = RubricEditableMapper.map(
                            criteria = mapped,
                            firstLocalId = 1L
                        )
                        editableCriteria = mapping.editableCriteria
                        nextLocalId = mapping.nextLocalId
                        persistedCriteria = emptyList() // Needs to be dirty to trigger saving

                        message = "Eşleştirme başarılı şekilde tamamlandı. Sonuçları gözden geçirip kaydedebilirsiniz."
                    }
                    com.example.core.network.ExamRubricGenerationResult.MissingApiKey -> {
                        message = "Gemini API anahtarı bulunamadı."
                    }
                    com.example.core.network.ExamRubricGenerationResult.Unauthorized -> {
                        message = "Gemini API anahtarı geçersiz veya yetkisiz."
                    }
                    com.example.core.network.ExamRubricGenerationResult.RateLimited -> {
                        message = "İstek limiti aşıldı. Lütfen biraz bekleyip tekrar deneyin."
                    }
                    com.example.core.network.ExamRubricGenerationResult.ServiceUnavailable -> {
                        message = "Gemini servisi şu anda kullanılamıyor."
                    }
                    else -> {
                        message = "Sorularla eşleştirme yapılırken hata oluştu."
                    }
                }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                message = "Beklenmeyen bir hata oluştu: ${error.message}"
            } finally {
                isMatching = false
                publishState()
            }
        }
        matchingJob = job
        job.invokeOnCompletion {
            if (matchingJob === job) matchingJob = null
            isMatching = false
            publishState()
        }
    }

    class Factory(
        private val draftId: Long,
        private val examRubricRepository: ExamRubricRepository,
        private val examQuestionRepository: ExamQuestionRepository,
        private val examDraftRepository: ExamDraftRepository,
        private val preferencesRepository: ExamEvaluationPreferencesRepository,
        private val examListeningMaterialRepository: ExamListeningMaterialRepository? = null,
        private val rubricGenerationCoordinator: ExamRubricGenerationCoordinator? = null,
        private val examRubricGenerator: com.example.core.network.ExamRubricGenerator? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(RubricViewModel::class.java)) {
                return RubricViewModel(
                    draftId = draftId,
                    examRubricRepository = examRubricRepository,
                    examQuestionRepository = examQuestionRepository,
                    examDraftRepository = examDraftRepository,
                    preferencesRepository = preferencesRepository,
                    examListeningMaterialRepository = examListeningMaterialRepository,
                    rubricGenerationCoordinator = rubricGenerationCoordinator,
                    examRubricGenerator = examRubricGenerator
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
