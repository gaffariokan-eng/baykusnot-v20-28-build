package com.example.feature.settings

import com.example.BuildConfig
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.network.GeminiModelRegistry

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeySettingsScreen(
    viewModel: ApiKeySettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var apiKeyInput by remember { mutableStateOf("") }
    var gatewayEnrollmentInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var isEditing by remember { mutableStateOf(false) }
    var showAdvancedModels by remember { mutableStateOf(false) }
    var evalModel by remember { mutableStateOf("") }
    var feedbackModel by remember { mutableStateOf("") }
    var authoringModel by remember { mutableStateOf("") }
    var evalInputPrice by remember { mutableStateOf("") }
    var evalOutputPrice by remember { mutableStateOf("") }
    var evalCachedInputPrice by remember { mutableStateOf("") }
    var cacheStoragePrice by remember { mutableStateOf("") }
    var feedbackInputPrice by remember { mutableStateOf("") }
    var feedbackOutputPrice by remember { mutableStateOf("") }
    var authoringInputPrice by remember { mutableStateOf("") }
    var authoringOutputPrice by remember { mutableStateOf("") }
    var authoringCachedInputPrice by remember { mutableStateOf("") }
    var batchFactor by remember { mutableStateOf("") }
    var highImageTokens by remember { mutableStateOf("") }
    var supportsHighMedia by remember { mutableStateOf(true) }
    var supportsBatch by remember { mutableStateOf(true) }
    var supportsCache by remember { mutableStateOf(true) }
    var supportsThinking by remember { mutableStateOf(true) }
    var approvalModelId by remember { mutableStateOf("") }
    var approvalCode by remember { mutableStateOf("") }

    LaunchedEffect(uiState.modelProfile) {
        val p = uiState.modelProfile
        evalModel = p.evaluationModel
        feedbackModel = p.feedbackModel
        authoringModel = p.authoringModel
        evalInputPrice = p.evaluationInputPerMillionUsd.toString()
        evalOutputPrice = p.evaluationOutputPerMillionUsd.toString()
        evalCachedInputPrice = p.evaluationCachedInputPerMillionUsd.toString()
        cacheStoragePrice = p.cacheStoragePerMillionTokenHourUsd.toString()
        feedbackInputPrice = p.feedbackInputPerMillionUsd.toString()
        feedbackOutputPrice = p.feedbackOutputPerMillionUsd.toString()
        authoringInputPrice = p.authoringInputPerMillionUsd.toString()
        authoringOutputPrice = p.authoringOutputPerMillionUsd.toString()
        authoringCachedInputPrice = p.authoringCachedInputPerMillionUsd.toString()
        batchFactor = p.batchPriceFactor.toString()
        highImageTokens = p.highImageTokens.toString()
        supportsHighMedia = p.supportsHighMediaResolution
        supportsBatch = p.supportsBatch
        supportsCache = p.supportsPromptCaching
        supportsThinking = p.supportsThinkingLevel
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Bağlantısı / Geliştirici Ayarları") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (uiState.isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            } else {
                if (uiState.isGatewayManaged) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Durum: Güvenli AI Gateway etkin", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Gemini kimlik bilgisi mobil uygulamada tutulmuyor. Üretim çağrıları yapılandırılmış güvenli gateway üzerinden iletiliyor.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    if (!uiState.isGatewayEnrolled) {
                        OutlinedTextField(
                            value = gatewayEnrollmentInput,
                            onValueChange = { gatewayEnrollmentInput = it; viewModel.clearMessages() },
                            label = { Text("Kurumsal Gateway Eşleştirme Kodu") },
                            supportingText = { Text("Bu kod kurum gateway'i tarafından verilir; Gemini API anahtarı değildir.") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().testTag("gateway_enrollment_input")
                        )
                        Button(
                            onClick = {
                                viewModel.enrollGateway(gatewayEnrollmentInput)
                                gatewayEnrollmentInput = ""
                            },
                            enabled = !uiState.isTestingConnection,
                            modifier = Modifier.fillMaxWidth().testTag("gateway_enroll_button")
                        ) { Text("Kurumsal Gateway ile Eşleştir") }
                    } else {
                        Text(
                            "Kurumsal eşleştirme mevcut. AI çağrılarında kısa ömürlü oturum otomatik alınır/yenilenir.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(
                            onClick = viewModel::testConnection,
                            enabled = !uiState.isTestingConnection,
                            modifier = Modifier.fillMaxWidth().testTag("test_connection_button")
                        ) {
                            if (uiState.isTestingConnection) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Gateway test ediliyor…")
                            } else Text("Güvenli AI Bağlantısını Test Et")
                        }
                        OutlinedButton(
                            onClick = viewModel::clearGatewayEnrollment,
                            modifier = Modifier.fillMaxWidth().testTag("gateway_unenroll_button")
                        ) { Text("Gateway Eşleştirmesini Kaldır") }
                    }
                } else if (uiState.productionAiBlocked) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Üretim AI erişimi güvenlik nedeniyle kapalı", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Bu release paketinde güvenli AI gateway yapılandırılmamış. Mobil uygulamaya Gemini anahtarı girilerek doğrudan production çağrısı yapılmasına izin verilmez.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                } else if (uiState.hasApiKey && !isEditing) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Geliştirici modu: API anahtarı kayıtlı", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Doğrudan cihaz anahtarı yalnız debug/geliştirme sürümünde kullanılabilir. Production release güvenli gateway gerektirir.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { isEditing = true }, modifier = Modifier.weight(1f)) { Text("Değiştir") }
                        OutlinedButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) { Text("Sil") }
                    }
                    Button(
                        onClick = viewModel::testConnection,
                        enabled = !uiState.isTestingConnection,
                        modifier = Modifier.fillMaxWidth().testTag("test_connection_button")
                    ) {
                        if (uiState.isTestingConnection) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Bağlantı test ediliyor…")
                        } else Text("Bağlantıyı Test Et")
                    }
                } else {
                    Text("Gemini API Anahtarı — Geliştirici Modu", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Bu alan yalnız debug/geliştirme testi içindir; production release cihaz anahtarı kabul etmez.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it; viewModel.clearMessages() },
                        label = { Text("API Anahtarı") },
                        modifier = Modifier.fillMaxWidth().testTag("api_key_input"),
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(imageVector = image, contentDescription = if (passwordVisible) "Gizle" else "Göster")
                            }
                        }
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.saveApiKey(apiKeyInput)
                                if (apiKeyInput.trim().length >= 10) { apiKeyInput = ""; isEditing = false }
                            },
                            modifier = Modifier.weight(1f).testTag("save_api_key_button")
                        ) { Text("Kaydet") }
                        if (isEditing) {
                            OutlinedButton(
                                onClick = { isEditing = false; apiKeyInput = ""; viewModel.clearMessages() },
                                modifier = Modifier.weight(1f)
                            ) { Text("İptal") }
                        }
                    }
                }

                uiState.connectionTestMessage?.let { message ->
                    Text(
                        text = message,
                        color = when (uiState.isConnectionTestSuccessful) {
                            true -> MaterialTheme.colorScheme.primary
                            false -> MaterialTheme.colorScheme.error
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.testTag("connection_test_message")
                    )
                }
                
                uiState.errorMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.testTag("error_message")
                    )
                }
                
                uiState.successMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.testTag("success_message")
                    )
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("model_quality_section"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Akıllı Değerlendirme",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "BaykuşNot uygun Gemini ayarlarını otomatik kullanır. El yazısı yüksek görüntü ayrıntısıyla okunur; belirsiz veya çok düşük puanlı cevaplar gerektiğinde bağımsız ikinci kontrolden geçer. Model seçmeniz gerekmez.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Sınav içinde yalnızca dönüt ayrıntısını seçersiniz: Yok, Kısa, Standart veya Ayrıntılı.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Ana okuma: ${uiState.modelProfile.evaluationModel} • Dönüt: ${uiState.modelProfile.feedbackModel}. Model kimlikleri BaykuşNot içinde merkezi olarak yönetilir.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Gerçek öğrenci kâğıtlarında ücretli/kurumsal veri koşullarına uygun Gemini hesabı kullanılması önerilir. BaykuşNot'un kendi cevap kâğıtlarında ad-soyad, okul no, sınıf/şube ve QR başlığı AI'a gönderilmez.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("YAZEK / Veri Güvenliği", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "YAZEK doğrulaması artık eğitim yılına ait tek bir onay değildir. Gerçek öğrenci verisi AI'a gönderilmeden önce BaykuşNot; kurum, ders, sınıf/şube, uygulama kapsamı, eğitsel amaç ve kullanılan AI aracını o çalışmanın resmî YAZEK beyanıyla eşleştirmenizi ister. Kapsam değişirse önceki doğrulama geçerli sayılmaz. Sınava özel resmî form bilgileri Ayarlar'da değil, AI Değerlendirmesi ekranındaki YAZEK kapısında hazırlanır.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(viewModel.buildAiDeploymentTransparencyNote()))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("AI Dağıtım / Şeffaflık Notunu Kopyala")
                        }
                        Text(
                            "Bu düğme yalnız teknik AI dağıtım/şeffaflık notunu kopyalar; resmî YAZEK kısa özeti veya sınava özel beyan bilgisi değildir. Resmî beyan YAZEK sisteminde tamamlanmalıdır.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                TextButton(onClick = { showAdvancedModels = !showAdvancedModels }) {
                    Text(if (showAdvancedModels) "Gelişmiş model yönetimini kapat" else "Gelişmiş model yönetimi")
                }
                if (showAdvancedModels) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Teknik Model Profili", style = MaterialTheme.typography.titleMedium)
                            Text("Normal öğretmen kullanımında değiştirilmesi gerekmez. Yalnız BaykuşNot benchmarkından geçen sabit model kimliklerini ve sağlayıcının güncel milyon-token fiyatlarını girin; '*-latest' kullanmayın.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(evalModel, { evalModel = it }, label = { Text("Ana okuma modeli") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(feedbackModel, { feedbackModel = it }, label = { Text("Ekonomik dönüt modeli") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(authoringModel, { authoringModel = it }, label = { Text("Soru/rubrik modeli") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(evalInputPrice, { evalInputPrice = it }, label = { Text("Okuma giriş $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(evalOutputPrice, { evalOutputPrice = it }, label = { Text("Okuma çıkış $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(evalCachedInputPrice, { evalCachedInputPrice = it }, label = { Text("Cache giriş $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(cacheStoragePrice, { cacheStoragePrice = it }, label = { Text("Cache depolama $/1M-saat") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(feedbackInputPrice, { feedbackInputPrice = it }, label = { Text("Dönüt giriş $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(feedbackOutputPrice, { feedbackOutputPrice = it }, label = { Text("Dönüt çıkış $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(authoringInputPrice, { authoringInputPrice = it }, label = { Text("Hazırlık giriş $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(authoringOutputPrice, { authoringOutputPrice = it }, label = { Text("Hazırlık çıkış $/1M") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            OutlinedTextField(authoringCachedInputPrice, { authoringCachedInputPrice = it }, label = { Text("Hazırlık cache giriş $/1M") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(batchFactor, { batchFactor = it }, label = { Text("Batch fiyat katsayısı") }, supportingText = { Text("Örn. standart fiyatın yarısıysa 0.5") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(highImageTokens, { highImageTokens = it.filter(Char::isDigit) }, label = { Text("HIGH görsel token bütçesi") }, supportingText = { Text("Model dokümanındaki yaklaşık görüntü token bütçesi; örn. 1120") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = supportsHighMedia, onClick = { supportsHighMedia = !supportsHighMedia }, label = { Text("HIGH medya") })
                                FilterChip(selected = supportsBatch, onClick = { supportsBatch = !supportsBatch }, label = { Text("Batch") })
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = supportsCache, onClick = { supportsCache = !supportsCache }, label = { Text("Prompt cache") })
                                FilterChip(selected = supportsThinking, onClick = { supportsThinking = !supportsThinking }, label = { Text("Thinking") })
                            }
                            HorizontalDivider()
                            Text("İmzalı Model Onayı", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            Text("Üretim sürümünde model onayları geliştirici tarafından imzalanmış release manifestinden gelir; normal öğretmen benchmark kaydı girmez.", style = MaterialTheme.typography.labelSmall)
                            if (BuildConfig.DEBUG) {
                                OutlinedTextField(approvalModelId, { approvalModelId = it }, label = { Text("Geliştirici: sabit model kimliği") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(approvalCode, { approvalCode = it }, label = { Text("Geliştirici: BNBENCH4 imzalı kayıt") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedButton(onClick = { viewModel.approveBenchmarkedModel(approvalModelId, approvalCode) }, modifier = Modifier.fillMaxWidth()) { Text("İmzalı Kaydı Doğrula") }
                            }
                            Text(
                                "Değerlendirme onayı: ${uiState.approvedEvaluationModelIds.sorted().joinToString().ifBlank { "yok" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Dönüt onayı: ${uiState.approvedFeedbackModelIds.sorted().joinToString().ifBlank { "yok" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Hazırlık onayı: ${uiState.approvedAuthoringModelIds.sorted().joinToString().ifBlank { "yok" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("Ekonomik toplu değerlendirme")
                                    Text("Açılırsa kâğıt-kâğıt toplu AI okumasında Batch kullanılabilir; öğretmenin normal ekran akışı değişmez.", style = MaterialTheme.typography.labelSmall)
                                }
                                Switch(checked = uiState.modelProfile.preferBatchEvaluation, onCheckedChange = viewModel::setPreferBatchEvaluation)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    viewModel.saveModelProfile(evalModel, feedbackModel, authoringModel, evalInputPrice, evalOutputPrice, evalCachedInputPrice, cacheStoragePrice, feedbackInputPrice, feedbackOutputPrice, authoringInputPrice, authoringOutputPrice, authoringCachedInputPrice, batchFactor, highImageTokens, supportsHighMedia, supportsBatch, supportsCache, supportsThinking)
                                }, modifier = Modifier.weight(1f)) { Text("Profili Kaydet") }
                                OutlinedButton(onClick = viewModel::restoreDefaultModelProfile, modifier = Modifier.weight(1f)) { Text("Varsayılana Dön") }
                            }
                        }
                    }
                }
                }
            }
        }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            icon = { Icon(Icons.Filled.Warning, contentDescription = null) },
            title = { Text("Anahtarı Sil") },
            text = { Text("Kayıtlı API anahtarını silmek istediğinizden emin misiniz?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteApiKey()
                        showDeleteConfirmation = false
                    },
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Sil")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) {
                    Text("İptal")
                }
            }
        )
    }
}
