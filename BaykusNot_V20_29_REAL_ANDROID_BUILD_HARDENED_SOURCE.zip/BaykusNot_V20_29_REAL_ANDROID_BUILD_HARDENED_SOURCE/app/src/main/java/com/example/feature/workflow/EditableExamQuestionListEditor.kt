package com.example.feature.workflow

object EditableExamQuestionListEditor {

    fun addQuestion(
        questions: List<EditableExamQuestion>,
        localId: Long
    ): List<EditableExamQuestion> {
        if (questions.any { it.localId == localId }) {
            return questions
        }
        val newQuestion = EditableExamQuestion(
            localId = localId,
            persistedId = 0L,
            orderIndex = questions.size + 1,
            questionNumber = "",
            questionText = "",
            pointsText = ""
        )
        return reindex(questions + newQuestion)
    }

    fun removeQuestion(
        questions: List<EditableExamQuestion>,
        localId: Long
    ): List<EditableExamQuestion> {
        if (questions.none { it.localId == localId }) {
            return questions
        }
        val filtered = questions.filterNot { it.localId == localId }
        return reindex(filtered)
    }

    fun updateQuestionNumber(
        questions: List<EditableExamQuestion>,
        localId: Long,
        value: String
    ): List<EditableExamQuestion> {
        if (questions.none { it.localId == localId }) {
            return questions
        }
        return questions.map {
            if (it.localId == localId) {
                it.copy(questionNumber = value)
            } else {
                it
            }
        }
    }

    fun updateQuestionText(
        questions: List<EditableExamQuestion>,
        localId: Long,
        value: String
    ): List<EditableExamQuestion> {
        if (questions.none { it.localId == localId }) {
            return questions
        }
        return questions.map {
            if (it.localId == localId) {
                it.copy(questionText = value)
            } else {
                it
            }
        }
    }

    fun updateQuestionPoints(
        questions: List<EditableExamQuestion>,
        localId: Long,
        value: String
    ): List<EditableExamQuestion> {
        if (questions.none { it.localId == localId }) {
            return questions
        }
        return questions.map {
            if (it.localId == localId) {
                it.copy(pointsText = value)
            } else {
                it
            }
        }
    }

    fun moveQuestionUp(
        questions: List<EditableExamQuestion>,
        localId: Long
    ): List<EditableExamQuestion> {
        val index = questions.indexOfFirst { it.localId == localId }
        if (index <= 0) {
            return questions
        }
        val mutable = questions.toMutableList()
        val temp = mutable[index]
        mutable[index] = mutable[index - 1]
        mutable[index - 1] = temp
        return reindex(mutable)
    }

    fun moveQuestionDown(
        questions: List<EditableExamQuestion>,
        localId: Long
    ): List<EditableExamQuestion> {
        val index = questions.indexOfFirst { it.localId == localId }
        if (index < 0 || index >= questions.size - 1) {
            return questions
        }
        val mutable = questions.toMutableList()
        val temp = mutable[index]
        mutable[index] = mutable[index + 1]
        mutable[index + 1] = temp
        return reindex(mutable)
    }

    private fun reindex(
        questions: List<EditableExamQuestion>
    ): List<EditableExamQuestion> {
        return questions.mapIndexed { index, item ->
            item.copy(orderIndex = index + 1)
        }
    }
}
