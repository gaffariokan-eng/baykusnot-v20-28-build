package com.example.core.model

enum class EvaluationMode(
    val displayName: String,
    val description: String
) {
    PAPER_BY_PAPER(
        displayName = "Bütün kâğıtları sırayla değerlendir",
        description =
            "Her öğrencinin sınav kâğıdı bütün sorularıyla tamamlanır, ardından sonraki öğrenciye geçilir."
    ),

    QUESTION_BY_QUESTION(
        displayName = "Soru soru değerlendirme",
        description =
            "Aynı soru bütün öğrenciler için değerlendirildikten sonra sonraki soruya geçilir."
    )
}
