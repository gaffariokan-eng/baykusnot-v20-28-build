package com.example.feature.workflow

import com.example.core.model.ExamQuestion

object QuestionPointsDirtyStateEvaluator {

    fun hasUnsavedChanges(
        editableQuestions: List<EditableExamQuestion>,
        persistedQuestions: List<ExamQuestion>,
        persistedCrossRefMap: Map<Long, Set<Long>> = emptyMap()
    ): Boolean {
        if (editableQuestions.size != persistedQuestions.size) {
            return true
        }

        for (i in editableQuestions.indices) {
            val editable = editableQuestions[i]
            val persisted = persistedQuestions[i]

            if (editable.orderIndex != persisted.orderIndex) {
                return true
            }
            if (editable.questionNumber != persisted.questionNumber) {
                return true
            }
            if (editable.questionText != persisted.questionText) {
                return true
            }

            when (val parseResult = QuestionPointsInputParser.parse(editable.pointsText)) {
                is QuestionPointsParseResult.Rejected -> return true
                is QuestionPointsParseResult.Parsed -> {
                    if (parseResult.points != persisted.points) {
                        return true
                    }
                }
            }
            val originalIds = if (persisted.id != 0L) persistedCrossRefMap[persisted.id] ?: emptySet() else emptySet()
            if (editable.selectedObjectiveIds != originalIds) {
                return true
            }
        }

        return false
    }
}
