package com.example.core.data

object TestOpticalFormGeometry {
    const val pageWidthPt = 595f
    const val pageHeightPt = 842f
    const val answerBubbleRadiusPt = 10f
    const val firstOptionCenterXPt = 205f
    const val optionSpacingPt = 62f
    val registrationCentersPt: List<Pair<Float, Float>> = listOf(
        24f to 24f,
        571f to 54f,
        54f to 818f,
        571f to 788f
    )

    fun optionCenterX(index: Int): Float = firstOptionCenterXPt + optionSpacingPt * index
}
