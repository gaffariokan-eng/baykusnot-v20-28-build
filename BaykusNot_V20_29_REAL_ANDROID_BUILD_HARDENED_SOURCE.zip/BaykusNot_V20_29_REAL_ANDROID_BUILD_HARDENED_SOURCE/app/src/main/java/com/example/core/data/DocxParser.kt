package com.example.core.data

import com.example.core.network.ExamExtractionImage
import com.example.core.network.ExamExtractionInput
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.StringReader
import java.util.zip.ZipInputStream

object DocxParser {
    private const val MAX_DOCX_COMPRESSED_BYTES = 50 * 1024 * 1024
    private const val MAX_ZIP_ENTRIES = 1000
    private const val MAX_XML_ENTRY_BYTES = 12 * 1024 * 1024
    private const val MAX_MEDIA_ENTRY_BYTES = 12 * 1024 * 1024
    private const val MAX_RELEVANT_UNCOMPRESSED_BYTES = 60 * 1024 * 1024
    private const val MAX_MEDIA_FILES = 100

    data class LevelFormat(val numFmt: String, val lvlText: String)

    private fun readEntryLimited(zis: ZipInputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream(minOf(limit, 64 * 1024))
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = zis.read(buffer)
            if (read < 0) break
            total += read
            require(total <= limit) { "Word belgesindeki bir ZIP girdisi güvenli açılmış boyut sınırını aşıyor." }
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    private fun rejectUnsafeXml(xml: String) {
        require(!xml.contains("<!DOCTYPE", ignoreCase = true) && !xml.contains("<!ENTITY", ignoreCase = true)) {
            "Word belgesinde desteklenmeyen haricî XML tanımı bulundu."
        }
    }

    private fun getAttr(parser: XmlPullParser, name: String): String? {
        for (i in 0 until parser.attributeCount) {
            val attrName = parser.getAttributeName(i)
            if (attrName == name || attrName == "w:$name" || attrName.endsWith(":$name")) {
                return parser.getAttributeValue(i)
            }
        }
        return null
    }

    fun parse(bytes: ByteArray): ExamExtractionInput.WordExtracted {
        var documentXml = ""
        var relsXml = ""
        var numberingXml = ""
        val mediaFiles = mutableMapOf<String, ByteArray>()

        require(bytes.size <= MAX_DOCX_COMPRESSED_BYTES) { "Word dosyası 50 MB sınırını aşıyor." }
        var entryCount = 0
        var relevantUncompressed = 0L

        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val currentEntry = entry
                entryCount++
                require(entryCount <= MAX_ZIP_ENTRIES) { "Word belgesinde olağandışı sayıda ZIP girdisi var." }
                val name = currentEntry.name.replace('\\', '/')
                require(!name.startsWith("/") && name.split('/').none { it == ".." }) {
                    "Word belgesinde güvenli olmayan ZIP yolu bulundu."
                }

                fun readRelevant(limit: Int): ByteArray {
                    if (currentEntry.size >= 0) require(currentEntry.size <= limit.toLong()) {
                        "Word belgesindeki $name girdisi güvenli boyut sınırını aşıyor."
                    }
                    val data = readEntryLimited(zis, limit)
                    relevantUncompressed += data.size
                    require(relevantUncompressed <= MAX_RELEVANT_UNCOMPRESSED_BYTES) {
                        "Word belgesinin açılmış içeriği güvenli toplam boyut sınırını aşıyor."
                    }
                    return data
                }

                when {
                    name == "word/document.xml" -> {
                        documentXml = String(readRelevant(MAX_XML_ENTRY_BYTES), Charsets.UTF_8)
                        rejectUnsafeXml(documentXml)
                    }
                    name == "word/_rels/document.xml.rels" -> {
                        relsXml = String(readRelevant(MAX_XML_ENTRY_BYTES), Charsets.UTF_8)
                        rejectUnsafeXml(relsXml)
                    }
                    name == "word/numbering.xml" -> {
                        numberingXml = String(readRelevant(MAX_XML_ENTRY_BYTES), Charsets.UTF_8)
                        rejectUnsafeXml(numberingXml)
                    }
                    name.startsWith("word/media/") -> {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (ext in setOf("png", "jpg", "jpeg", "webp")) {
                            require(mediaFiles.size < MAX_MEDIA_FILES) { "Word belgesinde 100'den fazla görsel bulunuyor." }
                            mediaFiles[name] = readRelevant(MAX_MEDIA_ENTRY_BYTES)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        
        if (documentXml.isBlank()) {
            throw IllegalArgumentException("Geçersiz veya okunamayan Word belgesi.")
        }

        val relMap = mutableMapOf<String, String>()
        if (relsXml.isNotBlank()) {
            val relRegex = Regex("<Relationship[^>]*Id=\"([^\"]+)\"[^>]*Target=\"([^\"]+)\"")
            relRegex.findAll(relsXml).forEach { match ->
                relMap[match.groupValues[1]] = match.groupValues[2]
            }
        }
        
        val numberingMap = mutableMapOf<String, Map<String, LevelFormat>>()
        if (numberingXml.isNotBlank()) {
            try {
                val factory = XmlPullParserFactory.newInstance()
                factory.isNamespaceAware = true
                val parser = factory.newPullParser()
                parser.setInput(StringReader(numberingXml))

                val abstractNumMap = mutableMapOf<String, MutableMap<String, LevelFormat>>()
                val numToAbstract = mutableMapOf<String, String>()

                var eventType = parser.eventType
                var currentAbstractNumId: String? = null
                var currentLvl: String? = null
                var currentNumFmt: String? = null
                var currentLvlText: String? = null
                var currentNumId: String? = null

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        val name = parser.name
                        when (name) {
                            "abstractNum" -> currentAbstractNumId = getAttr(parser, "abstractNumId")
                            "lvl" -> {
                                currentLvl = getAttr(parser, "ilvl")
                                currentNumFmt = null
                                currentLvlText = null
                            }
                            "numFmt" -> currentNumFmt = getAttr(parser, "val")
                            "lvlText" -> currentLvlText = getAttr(parser, "val")
                            "num" -> currentNumId = getAttr(parser, "numId")
                            "abstractNumId" -> {
                                if (currentNumId != null) {
                                    val absVal = getAttr(parser, "val")
                                    if (absVal != null) {
                                        numToAbstract[currentNumId] = absVal
                                    }
                                }
                            }
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        when (parser.name) {
                            "lvl" -> {
                                if (currentAbstractNumId != null && currentLvl != null) {
                                    val map = abstractNumMap.getOrPut(currentAbstractNumId) { mutableMapOf() }
                                    map[currentLvl] = LevelFormat(currentNumFmt ?: "", currentLvlText ?: "")
                                }
                            }
                        }
                    }
                    eventType = parser.nextToken()
                }

                for ((numId, absId) in numToAbstract) {
                    val formats = abstractNumMap[absId]
                    if (formats != null) {
                        numberingMap[numId] = formats
                    }
                }
            } catch (e: Exception) {
                // Numbering parsing failed, but we can still parse text
            }
        }
        
        val listCounters = mutableMapOf<String, MutableMap<String, Int>>()

        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = true
        val parser = factory.newPullParser()
        parser.setInput(StringReader(documentXml))

        val partsList = mutableListOf<ExamExtractionInput.WordPart>()
        var currentText = StringBuilder()
        
        var eventType = parser.eventType
        var inText = false
        var isNumPr = false
        var ilvl = "0"
        var numId = "0"

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name
                    when (name) {
                        "t" -> inText = true
                        "p" -> {
                            if (currentText.isNotEmpty() && !currentText.endsWith("\n")) {
                                currentText.append("\n")
                            }
                            ilvl = "0"
                            numId = "0"
                        }
                        "br" -> currentText.append("\n")
                        "tab" -> currentText.append("\t")
                        "tc" -> {
                             if (currentText.isNotEmpty() && !currentText.endsWith("\t") && !currentText.endsWith("\n")) {
                                 currentText.append("\t")
                             }
                        }
                        "tr" -> {
                            if (currentText.isNotEmpty() && !currentText.endsWith("\n")) {
                                currentText.append("\n")
                            }
                        }
                        "numPr" -> isNumPr = true
                        "ilvl" -> {
                            if (isNumPr) {
                                ilvl = getAttr(parser, "val") ?: "0"
                            }
                        }
                        "numId" -> {
                            if (isNumPr) {
                                numId = getAttr(parser, "val") ?: "0"
                            }
                        }
                        "blip" -> {
                            val rId = getAttr(parser, "embed")
                            if (rId != null) {
                                val target = relMap[rId]
                                if (target != null) {
                                    val mediaPath = if (target.startsWith("/")) target.substring(1) else "word/$target"
                                    val imgBytes = mediaFiles[mediaPath]
                                    if (imgBytes != null) {
                                        val ext = mediaPath.substringAfterLast(".", "").lowercase()
                                        val mime = when(ext) {
                                            "png" -> "image/png"
                                            "jpg", "jpeg" -> "image/jpeg"
                                            "webp" -> "image/webp"
                                            else -> null
                                        }
                                        if (mime != null) {
                                            if (currentText.isNotEmpty()) {
                                                partsList.add(ExamExtractionInput.WordPart.TextPart(currentText.toString()))
                                                currentText.clear()
                                            }
                                            partsList.add(
                                                ExamExtractionInput.WordPart.ImagePart(
                                                    ExamExtractionImage(imgBytes, mime)
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inText) {
                        currentText.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name
                    when (name) {
                        "t" -> inText = false
                        "numPr" -> {
                            isNumPr = false
                            if (numId != "0") {
                                val format = numberingMap[numId]?.get(ilvl)
                                if (format != null) {
                                    val counters = listCounters.getOrPut(numId) { mutableMapOf() }
                                    val count = counters.getOrDefault(ilvl, 0) + 1
                                    counters[ilvl] = count
                                    
                                    if (format.numFmt == "bullet") {
                                        currentText.append("• ")
                                    } else {
                                        var textToAppend = format.lvlText
                                        val formattedValue = formatCounter(count, format.numFmt)
                                        val levelNum = (ilvl.toIntOrNull() ?: 0) + 1
                                        textToAppend = textToAppend.replace("%$levelNum", formattedValue)
                                        currentText.append(textToAppend).append(" ")
                                    }
                                } else {
                                    currentText.append("• ") // Fallback
                                }
                            }
                        }
                        "p", "tr" -> {
                            if (currentText.isNotEmpty() && !currentText.endsWith("\n")) {
                                currentText.append("\n")
                            }
                        }
                    }
                }
            }
            eventType = parser.nextToken()
        }
        
        if (currentText.isNotEmpty()) {
            partsList.add(ExamExtractionInput.WordPart.TextPart(currentText.toString()))
        }
        
        val filteredParts = partsList.filter { 
            it is ExamExtractionInput.WordPart.ImagePart || 
            (it as ExamExtractionInput.WordPart.TextPart).text.isNotBlank() 
        }

        return ExamExtractionInput.WordExtracted(filteredParts)
    }

    private fun formatCounter(value: Int, format: String): String {
        return when (format) {
            "decimal" -> value.toString()
            "lowerLetter" -> {
                var v = value
                var res = ""
                while (v > 0) {
                    val rem = (v - 1) % 26
                    res = ('a' + rem) + res
                    v = (v - 1) / 26
                }
                res
            }
            "upperLetter" -> {
                var v = value
                var res = ""
                while (v > 0) {
                    val rem = (v - 1) % 26
                    res = ('A' + rem) + res
                    v = (v - 1) / 26
                }
                res
            }
            "lowerRoman" -> toRoman(value).lowercase()
            "upperRoman" -> toRoman(value)
            else -> value.toString()
        }
    }

    private fun toRoman(num: Int): String {
        val map = linkedMapOf(1000 to "M", 900 to "CM", 500 to "D", 400 to "CD", 100 to "C", 90 to "XC", 50 to "L", 40 to "XL", 10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I")
        var n = num
        var res = ""
        for ((k, v) in map) {
            while (n >= k) {
                res += v
                n -= k
            }
        }
        return res
    }
}
