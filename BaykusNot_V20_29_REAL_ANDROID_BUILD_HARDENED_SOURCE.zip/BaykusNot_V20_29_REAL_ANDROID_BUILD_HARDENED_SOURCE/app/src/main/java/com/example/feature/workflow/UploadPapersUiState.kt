package com.example.feature.workflow

import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamStudentPaperEntity

enum class UploadPapersFilter {
    ALL,
    READY,
    ISSUES
}

data class UploadPapersUiState(
    val isLoading: Boolean = true,
    val isHomework: Boolean = false,
    val hasFixedExpectedStudentCount: Boolean = true,
    val expectedStudentCount: Int = 20,
    val studentAssignmentCapacity: Int = 20,
    val configuredTotalPages: Int = 1,
    val studentPapers: List<ExamStudentPaperEntity> = emptyList(),
    val pages: List<ExamPaperPageEntity> = emptyList(),
    val selectedFilter: UploadPapersFilter = UploadPapersFilter.ALL,
    val isProcessing: Boolean = false,
    val processingMessage: String? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val previewingPage: ExamPaperPageEntity? = null,
    val editingPaper: ExamStudentPaperEntity? = null,
    val reassigningPage: ExamPaperPageEntity? = null
) {
    val totalUploadedSets: Int get() = studentPapers.size
    val readySetsCount: Int get() = studentPapers.count { it.status == "READY" }
    val missingPagesCount: Int get() = studentPapers.count { it.status == "MISSING_PAGES" }
    val issueSetsCount: Int get() = studentPapers.count { it.status in listOf("UNMATCHED", "ERROR", "DUPLICATE_PAGES", "UNMATCHED_IDENTITY") }
    val expectedTotalPages: Int get() = pages.maxOfOrNull { it.totalPages }?.coerceAtLeast(configuredTotalPages) ?: configuredTotalPages

    val unmatchedPages: List<ExamPaperPageEntity>
        get() = pages.filter { page ->
            if (isHomework) {
                page.studentPaperId == 0L || !page.isManuallyAssigned || page.status != "VALID"
            } else if (page.isManuallyAssigned) {
                page.studentPaperId == 0L || page.status != "VALID"
            } else {
                page.studentPaperId == 0L || page.status != "VALID" || page.qrStudentSeq == null
            }
        }

    val wrongExamPages: List<ExamPaperPageEntity>
        get() = pages.filter { it.status == "WRONG_EXAM" }

    val filteredPapers: List<ExamStudentPaperEntity>
        get() = when (selectedFilter) {
            UploadPapersFilter.ALL -> studentPapers
            UploadPapersFilter.READY -> studentPapers.filter { it.status == "READY" }
            UploadPapersFilter.ISSUES -> studentPapers.filter { it.status != "READY" }
        }

    val canProceed: Boolean
        get() {
            val countIsValid = !hasFixedExpectedStudentCount || studentPapers.size == expectedStudentCount
            return !isLoading &&
                !isProcessing &&
                pages.isNotEmpty() &&
                studentPapers.isNotEmpty() &&
                countIsValid &&
                studentPapers.all { it.status == "READY" } &&
                unmatchedPages.isEmpty() &&
                wrongExamPages.isEmpty()
        }

    val proceedBlockReason: String?
        get() = when {
            isLoading -> "Öğrenci kâğıtları yükleniyor. İşlem tamamlanmadan devam edilemez."
            isProcessing -> processingMessage ?: "Öğrenci kâğıtlarında bir değişiklik kaydediliyor. İşlem tamamlanmadan devam edilemez."
            pages.isEmpty() -> if (isHomework) {
                "Lütfen önce öğrenci ödev teslimlerini yükleyin veya kamerayla çekin."
            } else {
                "Lütfen önce öğrenci cevap kâğıtlarını yükleyin veya kamerayla çekin."
            }
            wrongExamPages.isNotEmpty() -> "${wrongExamPages.size} adet başka çalışmaya ait sayfa var. Lütfen silin."
            unmatchedPages.isNotEmpty() -> if (isHomework) {
                "${unmatchedPages.size} adet öğrenciye bağlanmamış veya okunabilirlik sorunu olan ödev sayfası var. Sayfaları ilgili öğrencilere bağlayın ya da sorunlu sayfaları silin."
            } else {
                "${unmatchedPages.size} adet eşleşmemiş veya QR okunamayan sorunlu sayfa var. Lütfen inceleyin veya silin."
            }
            studentPapers.isEmpty() -> if (isHomework) {
                "Değerlendirilecek öğrenci ödev teslimi bulunamadı."
            } else {
                "Değerlendirilecek öğrenci kâğıdı bulunamadı."
            }
            hasFixedExpectedStudentCount && studentPapers.size < expectedStudentCount -> "Eksik öğrenci kâğıdı seti var! Beklenen: $expectedStudentCount, Yüklenen: ${studentPapers.size}."
            hasFixedExpectedStudentCount && studentPapers.size > expectedStudentCount -> "Fazla öğrenci kâğıdı seti var! Beklenen: $expectedStudentCount, Yüklenen: ${studentPapers.size}. Lütfen fazla setleri silin."
            missingPagesCount > 0 -> "$missingPagesCount öğrencinin eksik sayfası bulunmaktadır. Lütfen tamamlayın."
            issueSetsCount > 0 -> if (isHomework) {
                "$issueSetsCount ödev tesliminde öğrenci bilgisi, sayfa sırası veya okunabilirlik sorunu var. Lütfen düzeltin."
            } else {
                "$issueSetsCount kâğıt setinde eşleştirme, kimlik veya okuma hatası var. Lütfen düzeltin."
            }
            else -> null
        }
}
