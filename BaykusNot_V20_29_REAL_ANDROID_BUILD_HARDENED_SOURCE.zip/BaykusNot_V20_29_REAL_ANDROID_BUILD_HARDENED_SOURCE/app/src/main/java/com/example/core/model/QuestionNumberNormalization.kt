package com.example.core.model

import java.util.Locale

fun normalizeQuestionNumber(
    value: String
): String {
    return value
        .trim()
        .lowercase(Locale.ROOT)
}
