package com.example.feature.workflow

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ExamType
import com.example.core.ui.BaykusCard
import com.example.core.ui.BaykusPrimaryButton
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.StatusType
import com.example.ui.theme.WiseNavyPrimary

@Composable
fun RubricGenerationControls(
    uiState: RubricUiState,
    onSaveWritingPunctuationPreference: (Boolean) -> Unit,
    onGenerateRubric: () -> Unit,
    onEvaluationSourceTypeChange: (String) -> Unit,
    onOriginalAnswerKeyChange: (String) -> Unit,
    onOriginalRubricChange: (String) -> Unit,
    onIsAsIsChange: (Boolean) -> Unit,
    onMatchWithQuestionsClick: () -> Unit,
    onUploadDocumentClick: (targetType: String) -> Unit = {},
    onRemoveDocumentClick: (targetType: String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isHomework = uiState.examType == ExamType.HOMEWORK
    val isReadiness = uiState.examType == ExamType.READINESS
    val isMultipleChoice = uiState.examType == ExamType.MULTIPLE_CHOICE

    BaykusCard(
        modifier = modifier.fillMaxWidth(),
        elevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = when {
                    isReadiness -> "Hazırbulunuşluk Rubriği ve Değerlendirme Kaynağı"
                    isMultipleChoice -> "Test Cevap Anahtarı Kaynağı"
                    else -> "Rubrik Oluşturma ve Değerlendirme Kaynağı"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Teacher Mode handles writing/punctuation automatically per measured skill.
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                ),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isMultipleChoice) "Test puanlama kuralı" else "Öğretmen Modu",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isMultipleChoice) {
                            "Test sınavında puan yalnız işaretlenen seçeneğin kilitli cevap anahtarıyla eşleşmesine göre verilir."
                        } else {
                            "Yazım ve noktalama, sorunun gerçekten ölçtüğü beceriye göre otomatik ele alınır. İçerik sorusunda anlam doğruysa gereksiz puan kırılmaz; yazım doğrudan ölçülüyorsa rubriğe dahil edilir. Aynı hata iki kez cezalandırılmaz."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Evaluation Source Selection
            Text(
                text = "Değerlendirme Kaynağı:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            val options = listOf(
                "AI_GENERATED_RUBRIC" to Triple(
                    "Ayrıntılı Rubrik Hazırlasın (Yapay Zeka)",
                    if (isReadiness)
                        "Sorularda ölçülen konu/ünite öncesi ön koşul bilgi ve becerileri ayırt edecek tanılayıcı puanlama kriterlerini otomatik üretir."
                    else if (isHomework)
                        "Ödev görev/maddelerine uygun, ayrıntılı puanlama kriterlerini otomatik üretir."
                    else if (isMultipleChoice)
                        "Her soru için doğru seçeneği ve tam puanı içeren kilitlenebilir cevap anahtarı kaydı oluşturur."
                    else
                        "Sınav senaryosuna en uygun, detaylı puanlama kriterlerini otomatik üretir.",
                    Icons.Default.Refresh
                ),
                "TEACHER_ANSWER_KEY" to Triple(
                    "Kendi Cevap Anahtarımı Kullan",
                    if (isMultipleChoice) "Yüklediğiniz veya yazdığınız test cevap anahtarını sorularla eşleştirir ve kilitlenebilir hale getirir." else "Yüklediğiniz veya yazdığınız cevap anahtarını temel alarak kriterleri hazırlar.",
                    Icons.Default.Description
                ),
                "TEACHER_RUBRIC" to Triple(
                    "Kendi Rubriğimi Kullan",
                    "Doğrudan kendi hazırladığınız puanlama kriterlerini sisteme aktarır.",
                    Icons.Default.PictureAsPdf
                ),
                "TEACHER_ANSWER_KEY_AND_RUBRIC" to Triple(
                    "Cevap Anahtarı + Rubrik Kullan",
                    "Cevap anahtarınızı ve mevcut kriterlerinizi birlikte kullanarak ayrıntılandırır.",
                    Icons.Default.CheckCircle
                )
            )

            Column(
                modifier = Modifier
                    .selectableGroup()
                    .padding(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.forEach { (type, info) ->
                    val (title, description, icon) = info
                    val isSelected = (uiState.evaluationSourceType == type)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = isSelected,
                                onClick = { onEvaluationSourceTypeChange(type) },
                                role = Role.RadioButton
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.testTag("radio_source_$type")
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            // Document Upload & Input Area for Teacher Sources
            if (uiState.evaluationSourceType != "AI_GENERATED_RUBRIC") {
                // Answer Key Upload / Input
                if (uiState.evaluationSourceType == "TEACHER_ANSWER_KEY" || uiState.evaluationSourceType == "TEACHER_ANSWER_KEY_AND_RUBRIC") {
                    TeacherDocumentUploadBox(
                        title = "Cevap Anahtarı Yükleme / Girme",
                        targetType = "ANSWER_KEY",
                        documentInfo = uiState.answerKeyDocument,
                        textValue = uiState.originalTeacherAnswerKey ?: "",
                        onTextChange = onOriginalAnswerKeyChange,
                        onUploadClick = { onUploadDocumentClick("ANSWER_KEY") },
                        onRemoveClick = { onRemoveDocumentClick("ANSWER_KEY") },
                        placeholder = "PDF, Word (DOCX), Görsel (PNG/JPEG/WebP) yükleyin veya doğrudan cevap anahtarı metnini buraya yazın..."
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Rubric Upload / Input
                if (uiState.evaluationSourceType == "TEACHER_RUBRIC" || uiState.evaluationSourceType == "TEACHER_ANSWER_KEY_AND_RUBRIC") {
                    TeacherDocumentUploadBox(
                        title = "Rubrik / Kriter Yükleme / Girme",
                        targetType = "RUBRIC",
                        documentInfo = uiState.rubricDocument,
                        textValue = uiState.originalTeacherRubric ?: "",
                        onTextChange = onOriginalRubricChange,
                        onUploadClick = { onUploadDocumentClick("RUBRIC") },
                        onRemoveClick = { onRemoveDocumentClick("RUBRIC") },
                        placeholder = "PDF, Word (DOCX), Görsel (PNG/JPEG/WebP) yükleyin veya doğrudan puanlama kriterlerini buraya yazın..."
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // As-Is vs Elaborate Option Selector
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "İşleme Yöntemi",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Option 1: Olduğu Gibi Kullan (As-Is)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onIsAsIsChange(true) }
                                .padding(vertical = 4.dp, horizontal = 4.dp)
                        ) {
                            RadioButton(
                                selected = uiState.isAsIs,
                                onClick = { onIsAsIsChange(true) },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.testTag("checkbox_as_is")
                            )
                            Column(modifier = Modifier.padding(start = 8.dp)) {
                                Text(
                                    text = if (isHomework) "Olduğu Gibi Kullan (Sadece Görev/Maddelerle Eşleştir)" else "Olduğu Gibi Kullan (Sadece Sorularla Eşleştir)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = when {
                                        isHomework -> "Öğretmen içeriği doğrudan kilitli görev/maddelerle eşleştirilir; yeni değerlendirme kuralı eklenmez."
                                        isReadiness -> "Öğretmen içeriği kilitli hazırbulunuşluk sorularıyla eşleştirilir; soruda ölçülmeyen ileri kazanım veya yeni değerlendirme kuralı eklenmez."
                                        else -> "Öğretmen içeriği doğrudan kilitli sorularla eşleştirilir; yeni değerlendirme kuralı eklenmez."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Option 2: Ayrıntılandır (Elaborate)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onIsAsIsChange(false) }
                                .padding(vertical = 4.dp, horizontal = 4.dp)
                        ) {
                            RadioButton(
                                selected = !uiState.isAsIs,
                                onClick = { onIsAsIsChange(false) },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Column(modifier = Modifier.padding(start = 8.dp)) {
                                Text(
                                    text = "Ayrıntılandır (Yapay Zeka ile Detaylandır)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = when {
                                        isHomework -> "Orijinal içerik korunarak görev/maddelere uygun ayrıntılı puanlama rehberi ve kriterler türetilir."
                                        isReadiness -> "Orijinal içerik korunarak hazırbulunuşluk sorularındaki mevcut ön koşul bilgi/beceri kanıtını ayırt edecek ayrıntılı kriterler türetilir."
                                        else -> "Orijinal içerik korunarak kilitli sorulara uygun ayrıntılı puanlama rehberi ve kriterler türetilir."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                BaykusPrimaryButton(
                    text = if (isHomework) {
                        if (uiState.isMatching) "Görev/Maddelerle Eşleştiriliyor..." else "Görev/Maddelerle Eşleştir"
                    } else {
                        if (uiState.isMatching) "Sorularla Eşleştiriliyor..." else "Sorularla Eşleştir"
                    },
                    onClick = onMatchWithQuestionsClick,
                    enabled = !uiState.isMatching && !uiState.isGenerating && !uiState.isProcessingDocument,
                    isLoading = uiState.isMatching,
                    modifier = Modifier.fillMaxWidth().testTag("btn_match_with_questions")
                )
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                val isRubricReady = uiState.editableCriteria.isNotEmpty()
                if (isRubricReady) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("card_ai_rubric_ready")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Rubrik Hazır",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }

                        // Make regenerate button less prominent
                        OutlinedButton(
                            onClick = onGenerateRubric,
                            enabled = !uiState.isGenerating && !uiState.isMatching,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .height(40.dp)
                                .testTag("btn_regenerate_ai_rubric")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Yeniden Oluştur",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    BaykusPrimaryButton(
                        text = if (uiState.isGenerating) "Ayrıntılı Rubrik Hazırlanıyor..." else "Ayrıntılı Rubrik Hazırla",
                        onClick = onGenerateRubric,
                        enabled = !uiState.isGenerating && !uiState.isMatching,
                        isLoading = uiState.isGenerating,
                        modifier = Modifier.fillMaxWidth().testTag("btn_generate_ai_rubric")
                    )
                }
            }
        }
    }
}

@Composable
private fun TeacherDocumentUploadBox(
    title: String,
    targetType: String,
    documentInfo: UploadedDocumentInfo?,
    textValue: String,
    onTextChange: (String) -> Unit,
    onUploadClick: () -> Unit,
    onRemoveClick: () -> Unit,
    placeholder: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedButton(
                onClick = onUploadClick,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp).testTag("upload_btn_$targetType")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Dosya Yükle")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Uploaded File Info Card
        if (documentInfo != null) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = when {
                        documentInfo.fileType.contains("PDF", ignoreCase = true) -> Icons.Default.PictureAsPdf
                        documentInfo.fileType.contains("Görsel", ignoreCase = true) -> Icons.Default.Image
                        else -> Icons.Default.Description
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 10.dp)
                    ) {
                        Text(
                            text = documentInfo.fileName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        Text(
                            text = "${documentInfo.fileType}${documentInfo.pageCount?.let { " • $it Sayfa" } ?: ""} • ${documentInfo.sizeBytes / 1024} KB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        documentInfo.statusMessage?.let { msg ->
                            Spacer(modifier = Modifier.height(2.dp))
                            BaykusStatusChip(
                                text = msg,
                                type = when (documentInfo.status) {
                                    "SUCCESS", "READY_TO_MATCH" -> StatusType.SUCCESS
                                    "ERROR" -> StatusType.ERROR
                                    else -> StatusType.INFO
                                }
                            )
                        }
                    }
                    IconButton(onClick = onUploadClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Değiştir", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onRemoveClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Kaldır", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Text Field for manual entry or extracted text
        OutlinedTextField(
            value = textValue,
            onValueChange = onTextChange,
            placeholder = { Text(placeholder, fontSize = 12.sp) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag(if (targetType == "ANSWER_KEY") "teacher_answer_key_input" else "teacher_rubric_input"),
            minLines = 3,
            maxLines = 8,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp)
        )
    }
}
