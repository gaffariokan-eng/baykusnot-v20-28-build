package com.example.core.network

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class HttpGeminiConnectionTester(
    private val client: OkHttpClient
) : GeminiConnectionTester {
    override suspend fun testConnection(apiKey: String): ConnectionTestResult = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models")
                .addHeader("x-goog-api-key", apiKey)
                .build()

            client.executeCancellable(request).use { response ->
                when (response.code) {
                    200 -> ConnectionTestResult.Success
                    400, 401, 403 -> ConnectionTestResult.InvalidApiKey
                    429 -> ConnectionTestResult.RateLimited
                    in 500..599 -> ConnectionTestResult.ServiceUnavailable
                    else -> ConnectionTestResult.UnexpectedError
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            ConnectionTestResult.NoInternet
        } catch (e: ConnectException) {
            ConnectionTestResult.NoInternet
        } catch (e: SocketTimeoutException) {
            ConnectionTestResult.ServiceUnavailable
        } catch (e: IOException) {
            ConnectionTestResult.ServiceUnavailable
        } catch (e: Exception) {
            ConnectionTestResult.UnexpectedError
        }
    }
}
