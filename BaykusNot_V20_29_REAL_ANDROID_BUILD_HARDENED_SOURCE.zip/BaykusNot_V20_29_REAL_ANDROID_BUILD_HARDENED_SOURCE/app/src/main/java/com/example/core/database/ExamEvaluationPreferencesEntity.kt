package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.core.model.EvaluationMode
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel

@Entity(
    tableName = "exam_evaluation_preferences",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamEvaluationPreferencesEntity(
    @PrimaryKey
    val examDraftId: Long,
    val evaluationMode: EvaluationMode =
        EvaluationMode.PAPER_BY_PAPER,
    val rubricAdherenceLevel: RubricAdherenceLevel =
        RubricAdherenceLevel.BALANCED,
    val feedbackDetailLevel: FeedbackDetailLevel =
        FeedbackDetailLevel.BRIEF,
    val deductWritingAndPunctuationPoints: Boolean = false,
    val hasExplicitWritingPunctuationPreference: Boolean = false,
    val provideWritingAndPunctuationFeedback: Boolean = false,
    val modelQualityTier: ModelQualityTier =
        ModelQualityTier.STANDARD,
    val reportClass: Boolean = true,
    val reportIndividual: Boolean = true,
    val reportQuestion: Boolean = true,
    val useBatchApi: Boolean = false,
    val usePromptCaching: Boolean = true,
    val isLocked: Boolean = false,
    val lockedAt: Long? = null,
    val revision: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
