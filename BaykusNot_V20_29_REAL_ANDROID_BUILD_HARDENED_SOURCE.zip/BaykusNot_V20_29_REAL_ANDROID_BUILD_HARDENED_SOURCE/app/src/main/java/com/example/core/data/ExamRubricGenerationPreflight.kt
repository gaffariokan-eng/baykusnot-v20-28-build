package com.example.core.data

import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.network.RubricGenerationSourceContext

sealed interface ExamRubricGenerationPreflightResult {
    data object InvalidTarget : ExamRubricGenerationPreflightResult
    data object QuestionMetadataMissing : ExamRubricGenerationPreflightResult
    data object QuestionsMissing : ExamRubricGenerationPreflightResult
    data object QuestionSetUnlocked : ExamRubricGenerationPreflightResult
    data object ExistingRubric : ExamRubricGenerationPreflightResult
    data object PreferencesMissing : ExamRubricGenerationPreflightResult
    data object PreferencesIncomplete : ExamRubricGenerationPreflightResult
    data object ListeningSourceMissing : ExamRubricGenerationPreflightResult
    data object HomeworkSourceMissing : ExamRubricGenerationPreflightResult

    data class Ready(
        val questions: List<ExamQuestion>,
        val questionSetRevision: Int,
        val deductWritingPunctuationPoints: Boolean,
        val sourceContext: RubricGenerationSourceContext? = null,
        val examType: ExamType = ExamType.WRITTEN,
        val examDraftId: Long = 0L
    ) : ExamRubricGenerationPreflightResult
}

class ExamRubricGenerationPreflight(
    private val questionRepository: ExamQuestionRepository,
    private val rubricRepository: ExamRubricRepository,
    private val preferencesRepository: ExamEvaluationPreferencesRepository,
    private val draftRepository: ExamDraftRepository? = null,
    private val listeningMaterialRepository: ExamListeningMaterialRepository? = null,
    private val sourceDocumentRepository: ExamSourceDocumentRepository? = null
) {
    suspend fun check(
        examDraftId: Long
    ): ExamRubricGenerationPreflightResult {
        if (examDraftId <= 0) {
            return ExamRubricGenerationPreflightResult.InvalidTarget
        }

        val questionMetadata = questionRepository.getMetadataOnce(examDraftId)
            ?: return ExamRubricGenerationPreflightResult.QuestionMetadataMissing

        val questions = questionRepository.getQuestionsOnce(examDraftId)
        if (questions.isEmpty()) {
            return ExamRubricGenerationPreflightResult.QuestionsMissing
        }

        if (!questionMetadata.isLocked) {
            return ExamRubricGenerationPreflightResult.QuestionSetUnlocked
        }

        val rubricMetadata = rubricRepository.getMetadataOnce(examDraftId)
        val criteria = rubricRepository.getCriteriaOnce(examDraftId)
        if (rubricMetadata != null || criteria.isNotEmpty()) {
            return ExamRubricGenerationPreflightResult.ExistingRubric
        }

        val draft = draftRepository?.getDraftByIdOnce(examDraftId)
        val isMultipleChoice = draft?.examType == ExamType.MULTIPLE_CHOICE

        // Teacher Mode does not force the teacher to decide spelling/punctuation before
        // rubric generation. The rubric generator itself decides whether writing is a
        // measured skill for each locked question. Keep false only as a legacy field.
        val deductPoints = false

        var sourceContext: RubricGenerationSourceContext? = null
        when (draft?.examType) {
            ExamType.LISTENING -> {
                sourceContext = listeningMaterialRepository
                    ?.getRubricSourceContext(examDraftId)
                    ?: return ExamRubricGenerationPreflightResult.ListeningSourceMissing
            }
            ExamType.HOMEWORK -> {
                sourceContext = sourceDocumentRepository
                    ?.getHomeworkRubricSourceContext(examDraftId)
                    ?: return ExamRubricGenerationPreflightResult.HomeworkSourceMissing
            }
            else -> Unit
        }

        return ExamRubricGenerationPreflightResult.Ready(
            examDraftId = examDraftId,
            questions = questions,
            questionSetRevision = questionMetadata.revision,
            deductWritingPunctuationPoints = deductPoints,
            sourceContext = sourceContext,
            examType = draft?.examType ?: ExamType.WRITTEN
        )
    }
}
