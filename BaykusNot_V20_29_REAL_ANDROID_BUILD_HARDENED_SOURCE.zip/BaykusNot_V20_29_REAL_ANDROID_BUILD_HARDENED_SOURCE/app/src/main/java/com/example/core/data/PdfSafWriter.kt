package com.example.core.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** API 26+ Storage Access Framework writer with byte-count and read-back verification. */
object PdfSafWriter {
    fun writeVerified(context: Context, source: File, destination: Uri): Result<Long> = runCatching {
        require(source.exists() && source.isFile && source.length() > 0L) { "Kaynak PDF bulunamadı." }
        val resolver = context.contentResolver
        val expected = source.length()

        val copied = resolver.openFileDescriptor(destination, "w")?.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).use { output ->
                val count = source.inputStream().use { input -> input.copyTo(output) }
                output.flush()
                output.fd.sync()
                count
            }
        } ?: error("Seçilen dosya hedefi yazma için açılamadı.")

        check(copied == expected) { "PDF yazımı eksik kaldı: $copied/$expected byte." }

        val verified = resolver.openInputStream(destination)?.use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
            }
            total
        } ?: error("Kaydedilen PDF doğrulama için yeniden açılamadı.")

        check(verified == expected) { "Kaydedilen PDF boyutu doğrulanamadı: $verified/$expected byte." }
        verified
    }
}
