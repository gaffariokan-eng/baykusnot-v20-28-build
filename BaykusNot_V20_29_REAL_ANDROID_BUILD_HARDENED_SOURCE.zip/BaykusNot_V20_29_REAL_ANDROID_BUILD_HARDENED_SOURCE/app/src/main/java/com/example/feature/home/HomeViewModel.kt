package com.example.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.TeacherProfileRepository
import com.example.core.database.ExamDraftEntity
import com.example.core.database.TeacherProfileEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(
    profileRepository: TeacherProfileRepository,
    draftRepository: ExamDraftRepository
) : ViewModel() {

    val profile: StateFlow<TeacherProfileEntity?> = profileRepository.profile
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val drafts: StateFlow<List<ExamDraftEntity>> = draftRepository.allDrafts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    class Factory(
        private val profileRepository: TeacherProfileRepository,
        private val draftRepository: ExamDraftRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(profileRepository, draftRepository) as T
        }
    }
}
