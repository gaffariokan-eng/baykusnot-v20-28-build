package com.example.core.model

data class EvaluationPreferences(
    val evaluationMode: EvaluationMode =
        EvaluationMode.PAPER_BY_PAPER,

    val rubricAdherenceLevel: RubricAdherenceLevel =
        RubricAdherenceLevel.BALANCED,

    val feedbackDetailLevel: FeedbackDetailLevel =
        FeedbackDetailLevel.BRIEF,

    val writingAndPunctuation:
        WritingAndPunctuationPreferences =
        WritingAndPunctuationPreferences(),

    val modelQualityTier: ModelQualityTier =
        ModelQualityTier.STANDARD,

    val reportClass: Boolean = true,
    val reportIndividual: Boolean = true,
    val reportQuestion: Boolean = true,
    val useBatchApi: Boolean = false,
    val usePromptCaching: Boolean = true
)
