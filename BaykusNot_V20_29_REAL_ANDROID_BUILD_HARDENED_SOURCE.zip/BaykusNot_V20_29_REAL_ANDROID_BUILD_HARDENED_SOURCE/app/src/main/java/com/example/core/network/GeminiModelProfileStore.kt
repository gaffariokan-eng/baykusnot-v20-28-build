package com.example.core.network

import android.content.Context
import android.util.Base64
import com.example.BuildConfig
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Local technical profile store. Production approval is role-specific: a model approved for
 * evaluation is not automatically approved for feedback or authoring.
 */
class GeminiModelProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("gemini_model_profile", Context.MODE_PRIVATE)

    enum class BenchmarkRole { EVALUATION, FEEDBACK, AUTHORING }

    fun loadAndApply(): GeminiModelProfile {
        val d = GeminiModelRegistry.defaultProfile()
        val profile = GeminiModelProfile(
            evaluationModel = prefs.getString(KEY_EVAL_MODEL, d.evaluationModel) ?: d.evaluationModel,
            feedbackModel = prefs.getString(KEY_FEEDBACK_MODEL, d.feedbackModel) ?: d.feedbackModel,
            authoringModel = prefs.getString(KEY_AUTHORING_MODEL, d.authoringModel) ?: d.authoringModel,
            evaluationInputPerMillionUsd = readDouble(KEY_EVAL_INPUT, d.evaluationInputPerMillionUsd),
            evaluationOutputPerMillionUsd = readDouble(KEY_EVAL_OUTPUT, d.evaluationOutputPerMillionUsd),
            evaluationCachedInputPerMillionUsd = readDouble(KEY_EVAL_CACHED_INPUT, d.evaluationCachedInputPerMillionUsd),
            cacheStoragePerMillionTokenHourUsd = readDouble(KEY_CACHE_STORAGE, d.cacheStoragePerMillionTokenHourUsd),
            feedbackInputPerMillionUsd = readDouble(KEY_FEEDBACK_INPUT, d.feedbackInputPerMillionUsd),
            feedbackOutputPerMillionUsd = readDouble(KEY_FEEDBACK_OUTPUT, d.feedbackOutputPerMillionUsd),
            authoringInputPerMillionUsd = readDouble(KEY_AUTHORING_INPUT, d.authoringInputPerMillionUsd),
            authoringOutputPerMillionUsd = readDouble(KEY_AUTHORING_OUTPUT, d.authoringOutputPerMillionUsd),
            authoringCachedInputPerMillionUsd = readDouble(KEY_AUTHORING_CACHED_INPUT, d.authoringCachedInputPerMillionUsd),
            batchPriceFactor = readDouble(KEY_BATCH_FACTOR, d.batchPriceFactor),
            highImageTokens = prefs.getInt(KEY_HIGH_IMAGE_TOKENS, d.highImageTokens),
            supportsHighMediaResolution = prefs.getBoolean(KEY_SUPPORTS_HIGH_MEDIA, d.supportsHighMediaResolution),
            supportsBatch = prefs.getBoolean(KEY_SUPPORTS_BATCH, d.supportsBatch),
            supportsPromptCaching = prefs.getBoolean(KEY_SUPPORTS_CACHE, d.supportsPromptCaching),
            supportsThinkingLevel = prefs.getBoolean(KEY_SUPPORTS_THINKING, d.supportsThinkingLevel),
            preferBatchEvaluation = prefs.getBoolean(KEY_PREFER_BATCH, d.preferBatchEvaluation),
            updatedAt = prefs.getLong(KEY_UPDATED_AT, d.updatedAt)
        )
        syncApprovalSnapshotToRegistry()
        return runCatching {
            require(isProfileApproved(profile)) { "Kaydedilmiş model profili rol-bazlı benchmark onaylı değil." }
            GeminiModelRegistry.configure(profile)
            profile
        }.getOrElse {
            GeminiModelRegistry.configure(d)
            d
        }
    }

    fun saveAndApply(profile: GeminiModelProfile): Result<GeminiModelProfile> = runCatching {
        require(isProfileApproved(profile)) {
            "Üretim profili için evaluation, feedback ve authoring modellerinin kendi rollerinde benchmark onayı gerekir."
        }
        syncApprovalSnapshotToRegistry()
        GeminiModelRegistry.configure(profile)
        prefs.edit()
            .putString(KEY_EVAL_MODEL, profile.evaluationModel.trim())
            .putString(KEY_FEEDBACK_MODEL, profile.feedbackModel.trim())
            .putString(KEY_AUTHORING_MODEL, profile.authoringModel.trim())
            .putLong(KEY_EVAL_INPUT, java.lang.Double.doubleToRawLongBits(profile.evaluationInputPerMillionUsd))
            .putLong(KEY_EVAL_OUTPUT, java.lang.Double.doubleToRawLongBits(profile.evaluationOutputPerMillionUsd))
            .putLong(KEY_EVAL_CACHED_INPUT, java.lang.Double.doubleToRawLongBits(profile.evaluationCachedInputPerMillionUsd))
            .putLong(KEY_CACHE_STORAGE, java.lang.Double.doubleToRawLongBits(profile.cacheStoragePerMillionTokenHourUsd))
            .putLong(KEY_FEEDBACK_INPUT, java.lang.Double.doubleToRawLongBits(profile.feedbackInputPerMillionUsd))
            .putLong(KEY_FEEDBACK_OUTPUT, java.lang.Double.doubleToRawLongBits(profile.feedbackOutputPerMillionUsd))
            .putLong(KEY_AUTHORING_INPUT, java.lang.Double.doubleToRawLongBits(profile.authoringInputPerMillionUsd))
            .putLong(KEY_AUTHORING_OUTPUT, java.lang.Double.doubleToRawLongBits(profile.authoringOutputPerMillionUsd))
            .putLong(KEY_AUTHORING_CACHED_INPUT, java.lang.Double.doubleToRawLongBits(profile.authoringCachedInputPerMillionUsd))
            .putLong(KEY_BATCH_FACTOR, java.lang.Double.doubleToRawLongBits(profile.batchPriceFactor))
            .putInt(KEY_HIGH_IMAGE_TOKENS, profile.highImageTokens)
            .putBoolean(KEY_SUPPORTS_HIGH_MEDIA, profile.supportsHighMediaResolution)
            .putBoolean(KEY_SUPPORTS_BATCH, profile.supportsBatch)
            .putBoolean(KEY_SUPPORTS_CACHE, profile.supportsPromptCaching)
            .putBoolean(KEY_SUPPORTS_THINKING, profile.supportsThinkingLevel)
            .putBoolean(KEY_PREFER_BATCH, profile.preferBatchEvaluation)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
        GeminiModelRegistry.currentProfile()
    }

    data class BenchmarkApproval(
        val modelId: String,
        val role: BenchmarkRole,
        val protocol: String,
        val cases: Int,
        val metrics: Map<String, Double>,
        val decidedAtEpochSeconds: Long,
        val datasetClass: String,
        val coveragePass: Boolean,
        val highImageTokens: Int?,
        val supportsHighMedia: Boolean?,
        val supportsBatch: Boolean?,
        val supportsCache: Boolean?,
        val supportsThinking: Boolean?,
        val expiresAtEpochSeconds: Long,
        val promptPolicySha256: String,
        val responseSchemaSha256: String,
        val evaluationEngineRevision: String,
        val rawRecord: String
    )

    private fun validApprovals(role: BenchmarkRole): List<BenchmarkApproval> =
        approvalRecords().filter {
            it.role == role && it.datasetClass == DATASET_REAL_ANONYMIZED && passesRoleThresholds(it)
        }

    private fun syncApprovalSnapshotToRegistry() {
        fun expiryMap(role: BenchmarkRole): Map<String, Long> = validApprovals(role)
            .groupBy { it.modelId.trim() }
            .mapValues { (_, records) -> records.maxOf { it.expiresAtEpochSeconds } }
        GeminiModelRegistry.setBenchmarkApprovalSnapshot(
            evaluation = expiryMap(BenchmarkRole.EVALUATION),
            feedback = expiryMap(BenchmarkRole.FEEDBACK),
            authoring = expiryMap(BenchmarkRole.AUTHORING)
        )
    }

    fun approvedModelIds(): Set<String> = BenchmarkRole.entries.flatMap { approvedModelIds(it) }.toSet()

    fun approvedModelIds(role: BenchmarkRole): Set<String> = validApprovals(role).map { it.modelId.trim() }.toSet()

    /** Compatibility helper. Use the role overload for production decisions. */
    fun isModelApproved(modelId: String): Boolean = modelId.trim() in approvedModelIds()

    fun isModelApproved(modelId: String, role: BenchmarkRole): Boolean = modelId.trim() in approvedModelIds(role)

    fun isEvaluationModelApproved(
        modelId: String,
        highImageTokens: Int,
        supportsHighMedia: Boolean,
        supportsBatch: Boolean,
        supportsCache: Boolean,
        supportsThinking: Boolean
    ): Boolean = validApprovals(BenchmarkRole.EVALUATION).any { approval ->
        approval.modelId.trim() == modelId.trim() &&
            approval.highImageTokens == highImageTokens &&
            approval.supportsHighMedia == supportsHighMedia &&
            approval.supportsBatch == supportsBatch &&
            approval.supportsCache == supportsCache &&
            approval.supportsThinking == supportsThinking
    }

    fun isProfileApproved(profile: GeminiModelProfile): Boolean {
        if (!isEvaluationModelApproved(
                profile.evaluationModel,
                profile.highImageTokens,
                profile.supportsHighMediaResolution,
                profile.supportsBatch,
                profile.supportsPromptCaching,
                profile.supportsThinkingLevel
            )
        ) return false
        if (!isModelApproved(profile.feedbackModel, BenchmarkRole.FEEDBACK)) return false
        if (!isModelApproved(profile.authoringModel, BenchmarkRole.AUTHORING)) return false
        return true
    }

    /** Accepts only a developer-signed, role-bound, REAL_ANONYMIZED benchmark approval record. */
    fun approveModelFromBenchmark(modelId: String, approvalRecord: String): Result<Unit> = runCatching {
        val clean = modelId.trim()
        require(GeminiModelRegistry.isStableExplicitModelId(clean)) { "Geçersiz sabit model kimliği." }
        val parsed = parseBenchmarkApproval(approvalRecord.trim())
            ?: error("İmzalı benchmark onay kaydı geçersiz, süresi dolmuş veya değiştirilmiş.")
        require(parsed.modelId == clean) { "Benchmark kaydı model kimliğiyle eşleşmiyor." }
        require(parsed.datasetClass == DATASET_REAL_ANONYMIZED) {
            "Sentetik/örnek veri üretim modeli onayı için kullanılamaz; anonimleştirilmiş gerçek benchmark seti gerekir."
        }
        require(passesRoleThresholds(parsed)) { "Model ${parsed.role} rolü için BaykuşNot kalite eşiklerini karşılamıyor." }

        val records = prefs.getStringSet(KEY_APPROVED_BENCHMARK_RECORDS_V4, emptySet()).orEmpty().toMutableSet()
        records.removeAll {
            parseBenchmarkApproval(it)?.let { old -> old.modelId == clean && old.role == parsed.role } == true
        }
        records.add(parsed.rawRecord)
        prefs.edit().putStringSet(KEY_APPROVED_BENCHMARK_RECORDS_V4, records).apply()
        syncApprovalSnapshotToRegistry()
    }

    private fun expectedGovernanceFingerprint(role: BenchmarkRole): Triple<String, String, String> = when (role) {
        BenchmarkRole.EVALUATION -> Triple(
            BuildConfig.BENCH_EVALUATION_PROMPT_SHA256,
            BuildConfig.BENCH_EVALUATION_SCHEMA_SHA256,
            BuildConfig.BENCH_EVALUATION_ENGINE_REVISION
        )
        BenchmarkRole.FEEDBACK -> Triple(
            BuildConfig.BENCH_FEEDBACK_PROMPT_SHA256,
            BuildConfig.BENCH_FEEDBACK_SCHEMA_SHA256,
            BuildConfig.BENCH_FEEDBACK_ENGINE_REVISION
        )
        BenchmarkRole.AUTHORING -> Triple(
            BuildConfig.BENCH_AUTHORING_PROMPT_SHA256,
            BuildConfig.BENCH_AUTHORING_SCHEMA_SHA256,
            BuildConfig.BENCH_AUTHORING_ENGINE_REVISION
        )
    }

    private fun passesRoleThresholds(a: BenchmarkApproval): Boolean {
        if (a.cases < 20 || !a.coveragePass) return false
        val expectedFingerprint = expectedGovernanceFingerprint(a.role)
        if (a.promptPolicySha256 != expectedFingerprint.first ||
            a.responseSchemaSha256 != expectedFingerprint.second ||
            a.evaluationEngineRevision != expectedFingerprint.third
        ) return false
        fun m(name: String): Double = a.metrics[name] ?: Double.NaN
        return when (a.role) {
            BenchmarkRole.EVALUATION ->
                a.protocol == PROTOCOL_EVALUATION && m("within") >= 0.95 && m("sim") >= 0.90 && m("recall") >= 0.95
            BenchmarkRole.FEEDBACK ->
                a.protocol == PROTOCOL_FEEDBACK && m("consistency") >= 0.98 && m("pedagogy") >= 0.90 &&
                    m("turkish") >= 0.90 && m("safety") >= 0.99 && m("personalization") >= 0.85
            BenchmarkRole.AUTHORING ->
                a.protocol == PROTOCOL_AUTHORING && m("extraction") >= 0.95 && m("rubric") >= 0.90 &&
                    m("objective") >= 0.90 && m("hallucination") <= 0.02 && m("correction") <= 0.10
        }
    }

    private fun approvalRecords(): List<BenchmarkApproval> {
        val bundled = decodeBundledApprovalManifest()
        val local = prefs.getStringSet(KEY_APPROVED_BENCHMARK_RECORDS_V4, emptySet()).orEmpty().toList()
        return (bundled + local).mapNotNull(::parseBenchmarkApproval)
            .distinctBy { it.role to it.modelId }
    }

    private fun decodeBundledApprovalManifest(): List<String> = runCatching {
        val encoded = BuildConfig.MODEL_APPROVAL_MANIFEST_B64.trim()
        if (encoded.isBlank()) return@runCatching emptyList()
        val decoded = Base64.decode(encoded, Base64.DEFAULT).toString(Charsets.UTF_8)
        decoded.lineSequence().map(String::trim).filter { it.isNotBlank() }.toList()
    }.getOrDefault(emptyList())

    private fun verifyApprovalSignature(payload: String, signatureB64: String): Boolean = runCatching {
        val publicKeyB64 = BuildConfig.MODEL_APPROVAL_PUBLIC_KEY_B64.trim()
        require(publicKeyB64.isNotBlank())
        val publicKey = KeyFactory.getInstance("EC").generatePublic(
            X509EncodedKeySpec(Base64.decode(publicKeyB64, Base64.DEFAULT))
        )
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(publicKey)
        verifier.update(payload.toByteArray(Charsets.UTF_8))
        verifier.verify(Base64.decode(signatureB64, Base64.DEFAULT))
    }.getOrDefault(false)

    private fun parseBenchmarkApproval(record: String): BenchmarkApproval? = runCatching {
        val parts = record.split('|')
        require(parts.firstOrNull() == "BNBENCH4")
        val signaturePart = parts.last()
        require(signaturePart.startsWith("sig="))
        val signatureB64 = signaturePart.removePrefix("sig=")
        val payload = parts.dropLast(1).joinToString("|")
        require(verifyApprovalSignature(payload, signatureB64))
        val kv = parts.drop(1).dropLast(1).associate {
            val i = it.indexOf('='); require(i > 0); it.substring(0, i) to it.substring(i + 1)
        }
        require(kv["decision"] == "ADOPT")
        val role = BenchmarkRole.valueOf(kv.getValue("role"))
        val metricKeys = when (role) {
            BenchmarkRole.EVALUATION -> listOf("within", "sim", "recall", "mae")
            BenchmarkRole.FEEDBACK -> listOf("consistency", "pedagogy", "turkish", "safety", "personalization")
            BenchmarkRole.AUTHORING -> listOf("extraction", "rubric", "objective", "hallucination", "correction")
        }
        val decidedAt = kv.getValue("ts").toLong()
        val expiresAt = kv.getValue("expires").toLong()
        val now = System.currentTimeMillis() / 1000L
        require(decidedAt > 0 && expiresAt > decidedAt)
        require(expiresAt - decidedAt <= MAX_APPROVAL_LIFETIME_SECONDS)
        require(now in decidedAt..expiresAt)
        BenchmarkApproval(
            modelId = kv.getValue("model"),
            role = role,
            protocol = kv.getValue("protocol"),
            cases = kv.getValue("cases").toInt(),
            metrics = metricKeys.associateWith { kv.getValue(it).toDouble() },
            decidedAtEpochSeconds = decidedAt,
            datasetClass = kv.getValue("dataset"),
            coveragePass = kv["coverage"] == "PASS",
            highImageTokens = kv["highTokens"]?.toInt(),
            supportsHighMedia = kv["highMedia"]?.let { it == "1" },
            supportsBatch = kv["batch"]?.let { it == "1" },
            supportsCache = kv["cache"]?.let { it == "1" },
            supportsThinking = kv["thinking"]?.let { it == "1" },
            expiresAtEpochSeconds = expiresAt,
            promptPolicySha256 = kv.getValue("promptPolicySha256"),
            responseSchemaSha256 = kv.getValue("responseSchemaSha256"),
            evaluationEngineRevision = kv.getValue("evaluationEngineRevision"),
            rawRecord = record
        )
    }.getOrNull()

    companion object {
        const val KEY_EVAL_MODEL = "evaluation_model"
        const val KEY_FEEDBACK_MODEL = "feedback_model"
        const val KEY_AUTHORING_MODEL = "authoring_model"
        const val KEY_EVAL_INPUT = "evaluation_input_price"
        const val KEY_EVAL_OUTPUT = "evaluation_output_price"
        const val KEY_EVAL_CACHED_INPUT = "evaluation_cached_input_price"
        const val KEY_CACHE_STORAGE = "cache_storage_price"
        const val KEY_FEEDBACK_INPUT = "feedback_input_price"
        const val KEY_FEEDBACK_OUTPUT = "feedback_output_price"
        const val KEY_AUTHORING_INPUT = "authoring_input_price"
        const val KEY_AUTHORING_OUTPUT = "authoring_output_price"
        const val KEY_AUTHORING_CACHED_INPUT = "authoring_cached_input_price"
        const val KEY_BATCH_FACTOR = "batch_price_factor"
        const val KEY_HIGH_IMAGE_TOKENS = "high_image_tokens"
        const val KEY_SUPPORTS_HIGH_MEDIA = "supports_high_media"
        const val KEY_SUPPORTS_BATCH = "supports_batch"
        const val KEY_SUPPORTS_CACHE = "supports_cache"
        const val KEY_SUPPORTS_THINKING = "supports_thinking"
        const val KEY_PREFER_BATCH = "prefer_batch_evaluation"
        const val KEY_APPROVED_MODELS = "approved_model_ids" // legacy, ignored
        const val KEY_APPROVED_BENCHMARK_RECORDS = "approved_benchmark_records_v2" // legacy, never grants production approval
        const val KEY_APPROVED_BENCHMARK_RECORDS_V3 = "approved_benchmark_records_v3" // legacy unsigned; ignored
        const val KEY_APPROVED_BENCHMARK_RECORDS_V4 = "approved_benchmark_records_v4"
        const val MAX_APPROVAL_LIFETIME_SECONDS = 366L * 24L * 60L * 60L
        const val PROTOCOL_EVALUATION = "BN-EVAL-B"
        const val PROTOCOL_FEEDBACK = "BN-FEEDBACK-B"
        const val PROTOCOL_AUTHORING = "BN-AUTHOR-B"
        const val DATASET_REAL_ANONYMIZED = "REAL_ANONYMIZED"
        const val KEY_UPDATED_AT = "updated_at"

        private val PROFILE_SETTING_KEYS = listOf(
            KEY_EVAL_MODEL, KEY_FEEDBACK_MODEL, KEY_AUTHORING_MODEL,
            KEY_EVAL_INPUT, KEY_EVAL_OUTPUT, KEY_EVAL_CACHED_INPUT, KEY_CACHE_STORAGE,
            KEY_FEEDBACK_INPUT, KEY_FEEDBACK_OUTPUT,
            KEY_AUTHORING_INPUT, KEY_AUTHORING_OUTPUT, KEY_AUTHORING_CACHED_INPUT,
            KEY_BATCH_FACTOR, KEY_HIGH_IMAGE_TOKENS, KEY_SUPPORTS_HIGH_MEDIA,
            KEY_SUPPORTS_BATCH, KEY_SUPPORTS_CACHE, KEY_SUPPORTS_THINKING,
            KEY_PREFER_BATCH, KEY_UPDATED_AT
        )
    }

    fun restoreDefaults(): GeminiModelProfile {
        // Reset only mutable profile settings. Benchmark approval evidence is an audit record and
        // must survive a UI reset; deleting it would silently destroy production-governance state.
        val editor = prefs.edit()
        PROFILE_SETTING_KEYS.forEach(editor::remove)
        editor.apply()
        syncApprovalSnapshotToRegistry()
        val d = GeminiModelRegistry.defaultProfile()
        GeminiModelRegistry.configure(d)
        return d
    }

    private fun readDouble(key: String, default: Double): Double =
        if (prefs.contains(key)) java.lang.Double.longBitsToDouble(prefs.getLong(key, 0L)) else default
}
