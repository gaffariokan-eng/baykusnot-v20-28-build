package com.example.core.data

import com.example.core.network.ExamRubricGenerationResult

class ExamRubricGenerationCoordinator(
    private val preflight: ExamRubricGenerationPreflight,
    private val invoker: ExamRubricGenerationInvoker,
    private val validationStage: ExamRubricGenerationValidationStage,
    private val persistenceStage: ExamRubricGenerationPersistenceStage,
    private val stageValidator: suspend (Long) -> Boolean = { true }
) {

    suspend fun generate(
        examDraftId: Long
    ): ExamRubricGenerationCoordinatorResult {
        if (!stageValidator(examDraftId)) {
            return ExamRubricGenerationCoordinatorResult.GenerationFailed(ExamRubricGenerationResult.UnexpectedFailure)
        }
        val preflightResult = preflight.check(examDraftId)

        if (preflightResult !is ExamRubricGenerationPreflightResult.Ready) {
            return ExamRubricGenerationCoordinatorResult.PreflightBlocked(
                preflightResult
            )
        }

        val ready = preflightResult

        val generationResult = invoker.generate(ready)

        if (!stageValidator(examDraftId)) {
            return ExamRubricGenerationCoordinatorResult.GenerationFailed(ExamRubricGenerationResult.UnexpectedFailure)
        }
        if (generationResult !is ExamRubricGenerationResult.Generated) {
            return ExamRubricGenerationCoordinatorResult.GenerationFailed(
                generationResult
            )
        }

        val validation = validationStage.validate(
            ready = ready,
            generated = generationResult
        )

        if (!validation.isValid) {
            return ExamRubricGenerationCoordinatorResult.ValidationFailed(
                validation
            )
        }

        if (!stageValidator(examDraftId)) {
            return ExamRubricGenerationCoordinatorResult.GenerationFailed(ExamRubricGenerationResult.UnexpectedFailure)
        }
        val saveResult = persistenceStage.save(
            examDraftId = examDraftId,
            ready = ready,
            validation = validation
        )

        return ExamRubricGenerationCoordinatorResult.SaveResult(
            saveResult
        )
    }
}
