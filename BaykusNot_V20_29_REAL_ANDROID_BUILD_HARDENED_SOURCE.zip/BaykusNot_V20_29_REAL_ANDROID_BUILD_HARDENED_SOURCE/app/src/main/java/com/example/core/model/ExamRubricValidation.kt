package com.example.core.model

enum class ExamRubricValidationCode {
    INVALID_TARGET_DRAFT_ID,
    EMPTY_QUESTION_LIST,
    QUESTION_DRAFT_MISMATCH,
    DUPLICATE_QUESTION_ORDER_INDEX,
    QUESTION_SET_NOT_LOCKED,
    RUBRIC_METADATA_DRAFT_MISMATCH,
    QUESTION_SET_REVISION_MISMATCH,
    LOCK_STATE_TIMESTAMP_MISMATCH,
    EMPTY_CRITERION_LIST,
    CRITERION_DRAFT_MISMATCH,
    UNKNOWN_QUESTION_ORDER_INDEX,
    QUESTION_NUMBER_SNAPSHOT_MISMATCH,
    INVALID_CRITERION_ORDER_INDEX,
    DUPLICATE_CRITERION_ORDER_INDEX,
    BLANK_CRITERION_TITLE,
    BLANK_CRITERION_DESCRIPTION,
    BLANK_EXPECTED_ANSWER,
    NON_POSITIVE_MAX_POINTS,
    MISSING_CRITERIA_FOR_QUESTION,
    QUESTION_POINTS_MISMATCH,
    MULTIPLE_CHOICE_CRITERION_COUNT_MISMATCH,
    INVALID_MULTIPLE_CHOICE_EXPECTED_ANSWER
}

data class ExamRubricValidationIssue(
    val code: ExamRubricValidationCode,
    val questionOrderIndex: Int? = null,
    val criterionOrderIndex: Int? = null,
    val value: String? = null
)

data class ExamRubricValidationResult(
    val calculatedPointsByQuestionOrder: Map<Int, Long>,
    val issues: List<ExamRubricValidationIssue>
) {
    val isValid: Boolean
        get() = issues.isEmpty()
}

object ExamRubricValidator {

    fun validate(
        targetDraftId: Long,
        questions: List<ExamQuestion>,
        questionSetRevision: Int,
        questionSetLocked: Boolean,
        rubricMetadata: ExamRubricSetMetadata,
        criteria: List<ExamRubricCriterion>
    ): ExamRubricValidationResult {
        val issues = mutableListOf<ExamRubricValidationIssue>()

        // 1. target draft
        if (targetDraftId <= 0) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.INVALID_TARGET_DRAFT_ID))
        }

        // 2. question list
        if (questions.isEmpty()) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.EMPTY_QUESTION_LIST))
        }

        // 3. question draft and order issues
        val seenQuestionOrderIndices = mutableSetOf<Int>()
        for (question in questions) {
            if (question.examDraftId != targetDraftId) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.QUESTION_DRAFT_MISMATCH,
                        questionOrderIndex = question.orderIndex
                    )
                )
            }
            if (question.orderIndex > 0 && !seenQuestionOrderIndices.add(question.orderIndex)) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.DUPLICATE_QUESTION_ORDER_INDEX,
                        questionOrderIndex = question.orderIndex
                    )
                )
            }
        }

        // 4. question-set lock
        if (!questionSetLocked) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.QUESTION_SET_NOT_LOCKED))
        }

        // 5. rubric metadata
        if (rubricMetadata.examDraftId != targetDraftId) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.RUBRIC_METADATA_DRAFT_MISMATCH))
        }
        if (rubricMetadata.questionSetRevision != questionSetRevision) {
            issues.add(
                ExamRubricValidationIssue(
                    code = ExamRubricValidationCode.QUESTION_SET_REVISION_MISMATCH,
                    value = "expected=$questionSetRevision,actual=${rubricMetadata.questionSetRevision}"
                )
            )
        }

        // 6. metadata lock consistency
        if ((rubricMetadata.isLocked && rubricMetadata.lockedAt == null) ||
            (!rubricMetadata.isLocked && rubricMetadata.lockedAt != null)
        ) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.LOCK_STATE_TIMESTAMP_MISMATCH))
        }

        // 7. empty criterion
        if (criteria.isEmpty()) {
            issues.add(ExamRubricValidationIssue(code = ExamRubricValidationCode.EMPTY_CRITERION_LIST))
        }

        // 8. criteria, in input order
        val questionMap = questions.associateBy { it.orderIndex }
        val criteriaByQuestion = mutableMapOf<Int, MutableList<ExamRubricCriterion>>()
        
        for (criterion in criteria) {
            if (criterion.examDraftId != targetDraftId) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.CRITERION_DRAFT_MISMATCH,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }

            val question = questionMap[criterion.questionOrderIndex]
            if (question == null) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.UNKNOWN_QUESTION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            } else {
                if (criterion.questionNumberSnapshot.trim() != question.questionNumber.trim()) {
                    issues.add(
                        ExamRubricValidationIssue(
                            code = ExamRubricValidationCode.QUESTION_NUMBER_SNAPSHOT_MISMATCH,
                            questionOrderIndex = criterion.questionOrderIndex,
                            criterionOrderIndex = criterion.criterionOrderIndex
                        )
                    )
                }
            }

            if (criterion.criterionOrderIndex <= 0) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.INVALID_CRITERION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }

            val listForQuestion = criteriaByQuestion.getOrPut(criterion.questionOrderIndex) { mutableListOf() }
            if (listForQuestion.any { it.criterionOrderIndex == criterion.criterionOrderIndex }) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.DUPLICATE_CRITERION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            listForQuestion.add(criterion)

            if (criterion.title.isBlank()) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.BLANK_CRITERION_TITLE,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.description.isBlank()) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.BLANK_CRITERION_DESCRIPTION,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.expectedAnswer.isBlank()) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.BLANK_EXPECTED_ANSWER,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.maxPoints <= 0) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.NON_POSITIVE_MAX_POINTS,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
        }

        // Calculate points and check for missing criteria by question order index
        val calculatedPointsByQuestionOrder = linkedMapOf<Int, Long>()
        val sortedQuestions = questions.sortedBy { it.orderIndex }
        
        for (question in sortedQuestions) {
            val qCriteria = criteriaByQuestion[question.orderIndex].orEmpty()
            val total = qCriteria.sumOf { it.maxPoints.toLong() }
            calculatedPointsByQuestionOrder[question.orderIndex] = total

            if (qCriteria.isEmpty()) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.MISSING_CRITERIA_FOR_QUESTION,
                        questionOrderIndex = question.orderIndex
                    )
                )
            }
        }

        for (question in sortedQuestions) {
            val total = calculatedPointsByQuestionOrder.getValue(question.orderIndex)
            if (total != question.points.toLong()) {
                issues.add(
                    ExamRubricValidationIssue(
                        code = ExamRubricValidationCode.QUESTION_POINTS_MISMATCH,
                        questionOrderIndex = question.orderIndex,
                        value = "expected=${question.points},actual=$total"
                    )
                )
            }
        }

        return ExamRubricValidationResult(
            calculatedPointsByQuestionOrder = calculatedPointsByQuestionOrder,
            issues = issues
        )
    }
}
