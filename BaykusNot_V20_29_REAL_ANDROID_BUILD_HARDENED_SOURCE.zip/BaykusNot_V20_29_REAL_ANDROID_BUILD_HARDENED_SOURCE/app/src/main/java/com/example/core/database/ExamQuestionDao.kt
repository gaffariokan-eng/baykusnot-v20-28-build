package com.example.core.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamQuestionDao {
    @Query(
        """
        SELECT *
        FROM exam_question
        WHERE examDraftId = :examDraftId
        ORDER BY orderIndex ASC
        """
    )
    fun observeByExamDraftId(
        examDraftId: Long
    ): Flow<List<ExamQuestionEntity>>

    @Query(
        """
        SELECT *
        FROM exam_question
        WHERE examDraftId = :examDraftId
        ORDER BY orderIndex ASC
        """
    )
    suspend fun getByExamDraftIdOnce(
        examDraftId: Long
    ): List<ExamQuestionEntity>

    @Query(
        """
        SELECT *
        FROM exam_question
        WHERE id = :id
        LIMIT 1
        """
    )
    suspend fun getByIdOnce(
        id: Long
    ): ExamQuestionEntity?

    @Upsert
    suspend fun upsert(
        question: ExamQuestionEntity
    ): Long

    @Upsert
    suspend fun upsertAll(
        questions: List<ExamQuestionEntity>
    ): List<Long>

    @Delete
    suspend fun delete(
        question: ExamQuestionEntity
    )

    @Query(
        """
        DELETE FROM exam_question
        WHERE examDraftId = :examDraftId
        """
    )
    suspend fun deleteByExamDraftId(
        examDraftId: Long
    )

    @Query(
        """
        SELECT COUNT(*)
        FROM exam_question
        WHERE examDraftId = :examDraftId
        """
    )
    suspend fun countByExamDraftId(
        examDraftId: Long
    ): Int

    @Query(
        """
        SELECT *
        FROM exam_question_set_metadata
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    fun observeMetadataByExamDraftId(
        examDraftId: Long
    ): Flow<ExamQuestionSetMetadataEntity?>

    @Query(
        """
        SELECT *
        FROM exam_question_set_metadata
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    suspend fun getMetadataByExamDraftIdOnce(
        examDraftId: Long
    ): ExamQuestionSetMetadataEntity?

    @Upsert
    suspend fun upsertMetadata(
        metadata: ExamQuestionSetMetadataEntity
    )

    @Transaction
    suspend fun replaceQuestionsForDraftAndReturnIds(
        examDraftId: Long,
        questions: List<ExamQuestionEntity>,
        expectedRevision: Int,
        updatedAt: Long
    ): List<Long>? {
        val currentMetadata = getMetadataByExamDraftIdOnce(examDraftId)
        val currentRevision = currentMetadata?.revision ?: 0

        if (currentMetadata?.isLocked == true || currentRevision != expectedRevision) {
            return null
        }

        deleteByExamDraftId(examDraftId)
        val insertedIds = upsertAll(questions)

        upsertMetadata(
            ExamQuestionSetMetadataEntity(
                examDraftId = examDraftId,
                isLocked = false,
                lockedAt = null,
                revision = currentRevision + 1,
                createdAt = currentMetadata?.createdAt ?: updatedAt,
                updatedAt = updatedAt
            )
        )
        return insertedIds
    }
    @Transaction
    suspend fun replaceQuestionsForDraft(
        examDraftId: Long,
        questions: List<ExamQuestionEntity>,
        expectedRevision: Int,
        updatedAt: Long
    ): Boolean {
        val currentMetadata = getMetadataByExamDraftIdOnce(examDraftId)
        val currentRevision = currentMetadata?.revision ?: 0

        if (currentMetadata?.isLocked == true || currentRevision != expectedRevision) {
            return false
        }

        deleteByExamDraftId(examDraftId)
        upsertAll(questions)

        upsertMetadata(
            ExamQuestionSetMetadataEntity(
                examDraftId = examDraftId,
                isLocked = false,
                lockedAt = null,
                revision = currentRevision + 1,
                createdAt = currentMetadata?.createdAt ?: updatedAt,
                updatedAt = updatedAt
            )
        )

        return true
    }

    @Query(
        """
        UPDATE exam_question_set_metadata
        SET
            isLocked = 1,
            lockedAt = :lockedAt,
            revision = revision + 1,
            updatedAt = :lockedAt
        WHERE examDraftId = :examDraftId
          AND isLocked = 0
          AND revision = :expectedRevision
        """
    )
    suspend fun lockQuestionSet(
        examDraftId: Long,
        expectedRevision: Int,
        lockedAt: Long
    ): Int

    @Query(
        """
        UPDATE exam_question_set_metadata
        SET
            isLocked = 0,
            lockedAt = NULL,
            revision = revision + 1,
            updatedAt = :updatedAt
        WHERE examDraftId = :examDraftId
          AND isLocked = 1
          AND revision = :expectedRevision
        """
    )
    suspend fun unlockQuestionSet(
        examDraftId: Long,
        expectedRevision: Int,
        updatedAt: Long
    ): Int
}
