package com.example.core.network

import com.example.core.database.ExamObjectiveEntity
import com.example.core.model.ExamType

sealed interface ExamScenarioExtractionResult {
    data class Success(val objectives: List<ExamObjectiveEntity>, val metadata: ScenarioMetadata? = null) : ExamScenarioExtractionResult

    data class ScenarioMetadata(
        val courseName: String?,
        val gradeLevel: String?,
        val term: String?,
        val examSequenceNumber: String?
    )
    data object MissingApiKey : ExamScenarioExtractionResult
    data object InvalidInput : ExamScenarioExtractionResult
    data object NetworkFailure : ExamScenarioExtractionResult
    data object Unauthorized : ExamScenarioExtractionResult
    data object RateLimited : ExamScenarioExtractionResult
    data object ServiceUnavailable : ExamScenarioExtractionResult
    data object MalformedResponse : ExamScenarioExtractionResult
    data object NoObjectivesFound : ExamScenarioExtractionResult
    data object UnexpectedFailure : ExamScenarioExtractionResult
}

interface ExamScenarioExtractor {
    suspend fun extract(
        draftId: Long,
        input: ExamExtractionInput,
        examType: ExamType = ExamType.WRITTEN
    ): ExamScenarioExtractionResult
}
