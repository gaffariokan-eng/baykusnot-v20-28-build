package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TeacherProfileDao {
    @Query("SELECT * FROM teacher_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<TeacherProfileEntity?>

    @Query("SELECT * FROM teacher_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileOnce(): TeacherProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: TeacherProfileEntity)
}
