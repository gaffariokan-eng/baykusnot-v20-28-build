package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey

@Entity(
    tableName = "exam_ai_run_profile",
    primaryKeys = ["examDraftId"],
    foreignKeys = [ForeignKey(
        entity = ExamDraftEntity::class,
        parentColumns = ["id"],
        childColumns = ["examDraftId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class ExamAiRunProfileEntity(
    val examDraftId: Long,
    val evaluationModel: String,
    val feedbackModel: String,
    val authoringModel: String,
    val evaluationInputPerMillionUsd: Double,
    val evaluationOutputPerMillionUsd: Double,
    val evaluationCachedInputPerMillionUsd: Double,
    val cacheStoragePerMillionTokenHourUsd: Double,
    val feedbackInputPerMillionUsd: Double,
    val feedbackOutputPerMillionUsd: Double,
    val authoringInputPerMillionUsd: Double,
    val authoringOutputPerMillionUsd: Double,
    val authoringCachedInputPerMillionUsd: Double,
    val batchPriceFactor: Double,
    val highImageTokens: Int,
    val supportsHighMediaResolution: Boolean,
    val supportsBatch: Boolean,
    val supportsPromptCaching: Boolean,
    val supportsThinkingLevel: Boolean,
    val preferBatchEvaluation: Boolean,
    val promptPolicyVersion: String,
    val legacyPrivacyApprovedAt: Long? = null,
    val homeworkPrivacyApprovedAt: Long? = null,
    val profileUpdatedAt: Long,
    val lockedAt: Long
)
