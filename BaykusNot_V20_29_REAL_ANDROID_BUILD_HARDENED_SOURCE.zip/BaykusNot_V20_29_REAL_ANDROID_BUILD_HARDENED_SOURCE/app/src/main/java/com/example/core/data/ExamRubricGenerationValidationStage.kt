package com.example.core.data

import com.example.core.network.ExamRubricGenerationResult
import com.example.core.network.ExamRubricGenerationValidator
import com.example.core.network.ExamRubricGenerationValidationResult

object ExamRubricGenerationValidationStage {
    fun validate(
        ready: ExamRubricGenerationPreflightResult.Ready,
        generated: ExamRubricGenerationResult.Generated
    ): ExamRubricGenerationValidationResult {
        val input = ExamRubricGenerationInputMapper.map(ready)
        return ExamRubricGenerationValidator.validate(
            input = input,
            criteria = generated.criteria
        )
    }
}
