package com.example.core.data

import android.content.Context
import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamEvaluationPreferencesDao
import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.database.ExamObjectiveDao
import com.example.core.database.ExamObjectiveEntity
import com.example.core.database.ExamQuestionDao
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.database.ExamRubricDao
import com.example.core.database.ExamRubricSetMetadataEntity
import com.example.core.database.QuestionObjectiveCrossRef
import com.example.core.model.EvaluationPreferences
import com.example.core.model.WritingAndPunctuationPreferences
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.ExamRubricSetMetadata
import com.example.core.model.ExamRubricValidator
import com.example.core.model.ExamType
import com.example.core.model.MultipleChoiceAnswerKeyPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.cancellation.CancellationException

sealed interface TeacherRubricPdfStatus {
    data class UpToDate(val pdfFile: File) : TeacherRubricPdfStatus
    data class Stale(
        val pdfFile: File,
        val reason: String,
        val title: String,
        val subtitle: String
    ) : TeacherRubricPdfStatus
    object NotGenerated : TeacherRubricPdfStatus
}

class ExamRubricRepository(
    private val rubricDao: ExamRubricDao,
    private val questionDao: ExamQuestionDao,
    private val examDraftDao: ExamDraftDao,
    private val objectiveDao: ExamObjectiveDao? = null,
    private val preferencesDao: ExamEvaluationPreferencesDao? = null,
    private val nowProvider: () -> Long = System::currentTimeMillis
) {

    fun observeMetadata(examDraftId: Long): Flow<ExamRubricSetMetadata?> =
        rubricDao.observeMetadataByExamDraftId(examDraftId)
            .map { it?.let(::mapMetadataToDomain) }

    fun observeCriteria(examDraftId: Long): Flow<List<ExamRubricCriterion>> =
        rubricDao.observeCriteriaByExamDraftId(examDraftId)
            .map { list -> list.map(::mapCriterionToDomain) }

    suspend fun getMetadataOnce(examDraftId: Long): ExamRubricSetMetadata? =
        rubricDao.getMetadataByExamDraftIdOnce(examDraftId)?.let(::mapMetadataToDomain)

    suspend fun getCriteriaOnce(examDraftId: Long): List<ExamRubricCriterion> =
        rubricDao.getCriteriaByExamDraftIdOnce(examDraftId).map(::mapCriterionToDomain)

    suspend fun saveRubric(
        examDraftId: Long,
        expectedRevision: Int,
        criteria: List<ExamRubricCriterion>,
        metadataToMerge: ExamRubricSetMetadata? = null
    ): SaveExamRubricResult {
        try {
            // 1. Draft existence
            examDraftDao.getDraftByIdOnce(examDraftId)
                ?: return SaveExamRubricResult.DraftNotFound

            // 2. Question-set metadata
            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return SaveExamRubricResult.QuestionSetMetadataMissing

            // 3. Questions
            val questions = questionDao.getByExamDraftIdOnce(examDraftId).map(::mapQuestionToDomain)

            // 4. Existing Rubric metadata
            val existingMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)

            // 5. Existing locked priority
            if (existingMetadata?.isLocked == true) {
                return SaveExamRubricResult.Locked(
                    currentRevision = existingMetadata.revision
                )
            }

            // 6. Kesin revision guard
            val currentRevision = existingMetadata?.revision ?: 0
            if (currentRevision != expectedRevision) {
                return SaveExamRubricResult.RevisionConflict(
                    currentRevision = currentRevision
                )
            }

            // 7 & 8 & 9. Validation metadata & ExamRubricValidator.validate
            val validationMetadata = if (existingMetadata == null) {
                ExamRubricSetMetadata(
                    examDraftId = examDraftId,
                    questionSetRevision = questionMetadata.revision,
                    isLocked = false,
                    lockedAt = null,
                    revision = 1,
                    createdAt = 0L,
                    updatedAt = 0L
                )
            } else {
                ExamRubricSetMetadata(
                    examDraftId = examDraftId,
                    questionSetRevision = questionMetadata.revision,
                    isLocked = false,
                    lockedAt = null,
                    revision = expectedRevision + 1,
                    createdAt = existingMetadata.createdAt,
                    updatedAt = existingMetadata.updatedAt
                )
            }

            val validation = ExamRubricValidator.validate(
                targetDraftId = examDraftId,
                questions = questions,
                questionSetRevision = questionMetadata.revision,
                questionSetLocked = questionMetadata.isLocked,
                rubricMetadata = validationMetadata,
                criteria = criteria
            )

            if (!validation.isValid) {
                return SaveExamRubricResult.ValidationFailed(
                    validation = validation
                )
            }

            // 10. nowProvider
            val now = nowProvider()

            // 11. Persistence metadata
            val persistenceMetadata = if (existingMetadata == null) {
                ExamRubricSetMetadataEntity(
                    examDraftId = examDraftId,
                    questionSetRevision = questionMetadata.revision,
                    isLocked = false,
                    lockedAt = null,
                    revision = 1,
                    createdAt = now,
                    updatedAt = now,
                    evaluationSourceType = metadataToMerge?.evaluationSourceType ?: "AI_GENERATED_RUBRIC",
                    originalTeacherAnswerKey = metadataToMerge?.originalTeacherAnswerKey,
                    originalTeacherRubric = metadataToMerge?.originalTeacherRubric,
                    elaboratedAnswerKey = metadataToMerge?.elaboratedAnswerKey,
                    elaboratedRubric = metadataToMerge?.elaboratedRubric,
                    isAsIs = metadataToMerge?.isAsIs ?: false
                )
            } else {
                ExamRubricSetMetadataEntity(
                    examDraftId = examDraftId,
                    questionSetRevision = questionMetadata.revision,
                    isLocked = false,
                    lockedAt = null,
                    revision = expectedRevision + 1,
                    createdAt = existingMetadata.createdAt,
                    updatedAt = now,
                    evaluationSourceType = metadataToMerge?.evaluationSourceType ?: existingMetadata.evaluationSourceType,
                    originalTeacherAnswerKey = metadataToMerge?.originalTeacherAnswerKey ?: existingMetadata.originalTeacherAnswerKey,
                    originalTeacherRubric = metadataToMerge?.originalTeacherRubric ?: existingMetadata.originalTeacherRubric,
                    elaboratedAnswerKey = metadataToMerge?.elaboratedAnswerKey ?: existingMetadata.elaboratedAnswerKey,
                    elaboratedRubric = metadataToMerge?.elaboratedRubric ?: existingMetadata.elaboratedRubric,
                    isAsIs = metadataToMerge?.isAsIs ?: existingMetadata.isAsIs
                )
            }

            // 12. Criteria entity mapping
            val criteriaEntities = criteria.map { criterion ->
                ExamRubricCriterionEntity(
                    id = 0L,
                    examDraftId = examDraftId,
                    questionOrderIndex = criterion.questionOrderIndex,
                    questionNumberSnapshot = criterion.questionNumberSnapshot,
                    criterionOrderIndex = criterion.criterionOrderIndex,
                    title = criterion.title,
                    description = criterion.description,
                    maxPoints = criterion.maxPoints,
                    expectedAnswer = criterion.expectedAnswer,
                    partialCreditGuidance = criterion.partialCreditGuidance,
                    commonMistakes = criterion.commonMistakes,
                    createdAt = now,
                    updatedAt = now,
                    originalAnswerKey = criterion.originalAnswerKey,
                    originalRubric = criterion.originalRubric
                )
            }

            // 13. replaceRubricForDraftIfCurrent
            val affectedRows = rubricDao.replaceRubricForDraftIfCurrent(
                metadata = persistenceMetadata,
                expectedRubricRevision = expectedRevision,
                criteria = criteriaEntities
            )

            // 14. CAS sonucunu sınıflandır
            if (affectedRows == 0) {
                val latestRubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                val latestQuestionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)

                if (latestRubricMetadata?.isLocked == true) {
                    return SaveExamRubricResult.Locked(
                        currentRevision = latestRubricMetadata.revision
                    )
                }

                val latestRubricRevision = latestRubricMetadata?.revision ?: 0
                if (latestRubricRevision != expectedRevision) {
                    return SaveExamRubricResult.RevisionConflict(
                        currentRevision = latestRubricRevision
                    )
                }

                if (latestQuestionMetadata == null ||
                    !latestQuestionMetadata.isLocked ||
                    latestQuestionMetadata.revision != questionMetadata.revision
                ) {
                    return SaveExamRubricResult.StateConflict
                }

                return SaveExamRubricResult.StateConflict
            }

            // 15. Başarı metadata'sını tekrar oku
            val finalMetadataEntity = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return SaveExamRubricResult.StateConflict

            return SaveExamRubricResult.Success(
                metadata = mapMetadataToDomain(finalMetadataEntity),
                validation = validation
            )

        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return SaveExamRubricResult.Failure(error)
        }
    }

    suspend fun saveRubric(
        examDraftId: Long,
        expectedRevision: Int,
        expectedQuestionSetRevision: Int,
        criteria: List<ExamRubricCriterion>,
        metadataToMerge: ExamRubricSetMetadata? = null
    ): SaveExamRubricResult {
        try {
            // 1. Draft existence
            examDraftDao.getDraftByIdOnce(examDraftId)
                ?: return SaveExamRubricResult.DraftNotFound

            // 2. Question-set metadata
            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return SaveExamRubricResult.QuestionSetMetadataMissing

            // Captured question set revision check (early)
            if (questionMetadata.revision != expectedQuestionSetRevision) {
                return SaveExamRubricResult.StateConflict
            }

            // 3. Questions
            val questions = questionDao.getByExamDraftIdOnce(examDraftId).map(::mapQuestionToDomain)

            // 4. Existing Rubric metadata
            val existingMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)

            // 5. Existing locked priority
            if (existingMetadata?.isLocked == true) {
                return SaveExamRubricResult.Locked(
                    currentRevision = existingMetadata.revision
                )
            }

            // 6. Kesin revision guard
            val currentRevision = existingMetadata?.revision ?: 0
            if (currentRevision != expectedRevision) {
                return SaveExamRubricResult.RevisionConflict(
                    currentRevision = currentRevision
                )
            }

            // 7 & 8 & 9. Validation metadata & ExamRubricValidator.validate
            val validationMetadata = if (existingMetadata == null) {
                ExamRubricSetMetadata(
                    examDraftId = examDraftId,
                    questionSetRevision = expectedQuestionSetRevision,
                    isLocked = false,
                    lockedAt = null,
                    revision = 1,
                    createdAt = 0L,
                    updatedAt = 0L
                )
            } else {
                ExamRubricSetMetadata(
                    examDraftId = examDraftId,
                    questionSetRevision = expectedQuestionSetRevision,
                    isLocked = false,
                    lockedAt = null,
                    revision = expectedRevision + 1,
                    createdAt = existingMetadata.createdAt,
                    updatedAt = existingMetadata.updatedAt
                )
            }

            val validation = ExamRubricValidator.validate(
                targetDraftId = examDraftId,
                questions = questions,
                questionSetRevision = expectedQuestionSetRevision,
                questionSetLocked = questionMetadata.isLocked,
                rubricMetadata = validationMetadata,
                criteria = criteria
            )

            if (!validation.isValid) {
                return SaveExamRubricResult.ValidationFailed(
                    validation = validation
                )
            }

            // 10. nowProvider
            val now = nowProvider()

            // 11. Persistence metadata
            val persistenceMetadata = if (existingMetadata == null) {
                ExamRubricSetMetadataEntity(
                    examDraftId = examDraftId,
                    questionSetRevision = expectedQuestionSetRevision,
                    isLocked = false,
                    lockedAt = null,
                    revision = 1,
                    createdAt = now,
                    updatedAt = now,
                    evaluationSourceType = metadataToMerge?.evaluationSourceType ?: "AI_GENERATED_RUBRIC",
                    originalTeacherAnswerKey = metadataToMerge?.originalTeacherAnswerKey,
                    originalTeacherRubric = metadataToMerge?.originalTeacherRubric,
                    elaboratedAnswerKey = metadataToMerge?.elaboratedAnswerKey,
                    elaboratedRubric = metadataToMerge?.elaboratedRubric,
                    isAsIs = metadataToMerge?.isAsIs ?: false
                )
            } else {
                ExamRubricSetMetadataEntity(
                    examDraftId = examDraftId,
                    questionSetRevision = expectedQuestionSetRevision,
                    isLocked = false,
                    lockedAt = null,
                    revision = expectedRevision + 1,
                    createdAt = existingMetadata.createdAt,
                    updatedAt = now,
                    evaluationSourceType = metadataToMerge?.evaluationSourceType ?: existingMetadata.evaluationSourceType,
                    originalTeacherAnswerKey = metadataToMerge?.originalTeacherAnswerKey ?: existingMetadata.originalTeacherAnswerKey,
                    originalTeacherRubric = metadataToMerge?.originalTeacherRubric ?: existingMetadata.originalTeacherRubric,
                    elaboratedAnswerKey = metadataToMerge?.elaboratedAnswerKey ?: existingMetadata.elaboratedAnswerKey,
                    elaboratedRubric = metadataToMerge?.elaboratedRubric ?: existingMetadata.elaboratedRubric,
                    isAsIs = metadataToMerge?.isAsIs ?: existingMetadata.isAsIs
                )
            }

            // 12. Criteria entity mapping
            val criteriaEntities = criteria.map { criterion ->
                ExamRubricCriterionEntity(
                    id = 0L,
                    examDraftId = examDraftId,
                    questionOrderIndex = criterion.questionOrderIndex,
                    questionNumberSnapshot = criterion.questionNumberSnapshot,
                    criterionOrderIndex = criterion.criterionOrderIndex,
                    title = criterion.title,
                    description = criterion.description,
                    maxPoints = criterion.maxPoints,
                    expectedAnswer = criterion.expectedAnswer,
                    partialCreditGuidance = criterion.partialCreditGuidance,
                    commonMistakes = criterion.commonMistakes,
                    createdAt = now,
                    updatedAt = now,
                    originalAnswerKey = criterion.originalAnswerKey,
                    originalRubric = criterion.originalRubric
                )
            }

            // 13. replaceRubricForDraftIfCurrent
            val affectedRows = rubricDao.replaceRubricForDraftIfCurrent(
                metadata = persistenceMetadata,
                expectedRubricRevision = expectedRevision,
                criteria = criteriaEntities
            )

            // 14. CAS sonucunu sınıflandır
            if (affectedRows == 0) {
                val latestRubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                val latestQuestionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)

                if (latestRubricMetadata?.isLocked == true) {
                    return SaveExamRubricResult.Locked(
                        currentRevision = latestRubricMetadata.revision
                    )
                }

                val latestRubricRevision = latestRubricMetadata?.revision ?: 0
                if (latestRubricRevision != expectedRevision) {
                    return SaveExamRubricResult.RevisionConflict(
                        currentRevision = latestRubricRevision
                    )
                }

                if (latestQuestionMetadata == null ||
                    !latestQuestionMetadata.isLocked ||
                    latestQuestionMetadata.revision != expectedQuestionSetRevision
                ) {
                    return SaveExamRubricResult.StateConflict
                }

                return SaveExamRubricResult.StateConflict
            }

            // 15. Başarı metadata'sını tekrar oku
            val finalMetadataEntity = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return SaveExamRubricResult.StateConflict

            return SaveExamRubricResult.Success(
                metadata = mapMetadataToDomain(finalMetadataEntity),
                validation = validation
            )

        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return SaveExamRubricResult.Failure(error)
        }
    }

    suspend fun lockRubricSet(
        examDraftId: Long,
        expectedRevision: Int
    ): LockExamRubricSetResult {
        try {
            val draft = examDraftDao.getDraftByIdOnce(examDraftId)
            if (draft == null) {
                return LockExamRubricSetResult.DraftNotFound
            }

            val currentRubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (currentRubricMetadata == null) {
                return LockExamRubricSetResult.MetadataMissing
            }

            if (currentRubricMetadata.isLocked) {
                return LockExamRubricSetResult.AlreadyLocked(
                    currentRevision = currentRubricMetadata.revision
                )
            }

            if (currentRubricMetadata.revision != expectedRevision) {
                return LockExamRubricSetResult.RevisionConflict(
                    currentRevision = currentRubricMetadata.revision
                )
            }

            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (questionMetadata == null) {
                return LockExamRubricSetResult.QuestionSetMetadataMissing
            }

            val questionsEntities = questionDao.getByExamDraftIdOnce(examDraftId)
            val questions = questionsEntities.map { mapQuestionToDomain(it) }

            val criteriaEntities = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            val criteria = criteriaEntities.map { mapCriterionToDomain(it) }

            val baseValidation = ExamRubricValidator.validate(
                targetDraftId = examDraftId,
                questions = questions,
                questionSetRevision = questionMetadata.revision,
                questionSetLocked = questionMetadata.isLocked,
                rubricMetadata = mapMetadataToDomain(currentRubricMetadata),
                criteria = criteria
            )
            val validation = if (draft.examType == ExamType.MULTIPLE_CHOICE) {
                baseValidation.copy(
                    issues = baseValidation.issues + MultipleChoiceAnswerKeyPolicy.validate(questions, criteria)
                )
            } else baseValidation

            if (!validation.isValid) {
                return LockExamRubricSetResult.ValidationFailed(
                    validation = validation
                )
            }

            val now = nowProvider()
            val affectedRows = rubricDao.lockRubricSetIfQuestionSetCurrent(
                examDraftId = examDraftId,
                expectedRubricRevision = expectedRevision,
                expectedQuestionSetRevision = questionMetadata.revision,
                lockedAt = now,
                updatedAt = now
            )

            if (affectedRows == 0) {
                val latestRubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                val latestQuestionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)

                if (latestRubricMetadata?.isLocked == true) {
                    return LockExamRubricSetResult.AlreadyLocked(
                        currentRevision = latestRubricMetadata.revision
                    )
                }

                if (latestRubricMetadata != null && latestRubricMetadata.revision != expectedRevision) {
                    return LockExamRubricSetResult.RevisionConflict(
                        currentRevision = latestRubricMetadata.revision
                    )
                }

                if (latestRubricMetadata == null ||
                    latestQuestionMetadata == null ||
                    !latestQuestionMetadata.isLocked ||
                    latestQuestionMetadata.revision != questionMetadata.revision ||
                    latestRubricMetadata.questionSetRevision != questionMetadata.revision
                ) {
                    return LockExamRubricSetResult.StateConflict
                }

                return LockExamRubricSetResult.StateConflict
            }

            val finalMetadataEntity = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (finalMetadataEntity == null || !finalMetadataEntity.isLocked) {
                return LockExamRubricSetResult.StateConflict
            }

            return LockExamRubricSetResult.Success(
                metadata = mapMetadataToDomain(finalMetadataEntity)
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return LockExamRubricSetResult.Failure(cause = error)
        }
    }

    suspend fun unlockRubricSet(
        examDraftId: Long,
        expectedRevision: Int
    ): UnlockExamRubricSetResult {
        try {
            val currentMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (currentMetadata == null) {
                return UnlockExamRubricSetResult.MetadataMissing
            }

            if (!currentMetadata.isLocked) {
                return UnlockExamRubricSetResult.AlreadyUnlocked(
                    currentRevision = currentMetadata.revision
                )
            }

            if (currentMetadata.revision != expectedRevision) {
                return UnlockExamRubricSetResult.RevisionConflict(
                    currentRevision = currentMetadata.revision
                )
            }

            val now = nowProvider()
            val affectedRows = rubricDao.unlockRubricSet(
                examDraftId = examDraftId,
                expectedRevision = expectedRevision,
                updatedAt = now
            )

            if (affectedRows == 0) {
                val latestMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
                if (latestMetadata == null) {
                    return UnlockExamRubricSetResult.StateConflict
                }

                if (!latestMetadata.isLocked) {
                    return UnlockExamRubricSetResult.AlreadyUnlocked(
                        currentRevision = latestMetadata.revision
                    )
                }

                if (latestMetadata.revision != expectedRevision) {
                    return UnlockExamRubricSetResult.RevisionConflict(
                        currentRevision = latestMetadata.revision
                    )
                }

                return UnlockExamRubricSetResult.StateConflict
            }

            val finalMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (finalMetadata == null || finalMetadata.isLocked) {
                return UnlockExamRubricSetResult.StateConflict
            }

            return UnlockExamRubricSetResult.Success(
                metadata = mapMetadataToDomain(finalMetadata)
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return UnlockExamRubricSetResult.Failure(cause = error)
        }
    }

    private fun mapMetadataToDomain(entity: ExamRubricSetMetadataEntity): ExamRubricSetMetadata {
        return ExamRubricSetMetadata(
            examDraftId = entity.examDraftId,
            questionSetRevision = entity.questionSetRevision,
            isLocked = entity.isLocked,
            lockedAt = entity.lockedAt,
            revision = entity.revision,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt,
            evaluationSourceType = entity.evaluationSourceType,
            originalTeacherAnswerKey = entity.originalTeacherAnswerKey,
            originalTeacherRubric = entity.originalTeacherRubric,
            elaboratedAnswerKey = entity.elaboratedAnswerKey,
            elaboratedRubric = entity.elaboratedRubric,
            isAsIs = entity.isAsIs
        )
    }

    private fun mapCriterionToDomain(entity: ExamRubricCriterionEntity): ExamRubricCriterion {
        return ExamRubricCriterion(
            id = entity.id,
            examDraftId = entity.examDraftId,
            questionOrderIndex = entity.questionOrderIndex,
            questionNumberSnapshot = entity.questionNumberSnapshot,
            criterionOrderIndex = entity.criterionOrderIndex,
            title = entity.title,
            description = entity.description,
            maxPoints = entity.maxPoints,
            expectedAnswer = entity.expectedAnswer,
            partialCreditGuidance = entity.partialCreditGuidance,
            commonMistakes = entity.commonMistakes,
            originalAnswerKey = entity.originalAnswerKey,
            originalRubric = entity.originalRubric
        )
    }

    private fun mapQuestionToDomain(entity: ExamQuestionEntity): ExamQuestion {
        return ExamQuestion(
            id = entity.id,
            examDraftId = entity.examDraftId,
            orderIndex = entity.orderIndex,
            questionNumber = entity.questionNumber,
            questionText = entity.questionText,
            points = entity.points
        )
    }

    suspend fun getTeacherRubricPdfStatus(context: Context, examDraftId: Long): TeacherRubricPdfStatus {
        return withContext(Dispatchers.IO) {
            val file = File(context.filesDir, "exam_${examDraftId}_teacher_rubric.pdf")
            if (!file.exists() || file.length() == 0L) {
                return@withContext TeacherRubricPdfStatus.NotGenerated
            }
            val metaFile = File(context.filesDir, "exam_${examDraftId}_teacher_rubric.pdf.meta")
            if (!metaFile.exists()) {
                return@withContext TeacherRubricPdfStatus.Stale(
                    pdfFile = file,
                    reason = "PDF doğrulama bilgisi eksik.",
                    title = "Rubrik belgesi güncellendi",
                    subtitle = "Yeni değişiklikleri yansıtmak için PDF’yi yeniden oluşturun."
                )
            }

            val savedFingerprint = metaFile.readText().trim()
            val draft = examDraftDao.getDraftByIdOnce(examDraftId) ?: return@withContext TeacherRubricPdfStatus.NotGenerated
            val questions = questionDao.getByExamDraftIdOnce(examDraftId)
            val criteria = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            val metadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            val objectives = objectiveDao?.getApprovedObjectivesByDraftId(examDraftId) ?: emptyList()
            val crossRefs = objectiveDao?.getQuestionObjectiveCrossRefsByDraftId(examDraftId) ?: emptyList()
            val prefsEntity = preferencesDao?.getPreferencesOnce(examDraftId)

            val currentFingerprint = buildTeacherRubricFingerprint(draft, questions, criteria, metadata, objectives, crossRefs, prefsEntity)

            if (savedFingerprint == currentFingerprint) {
                TeacherRubricPdfStatus.UpToDate(file)
            } else {
                TeacherRubricPdfStatus.Stale(
                    pdfFile = file,
                    reason = "Rubrik veya sınav bilgileri değiştirildi.",
                    title = "Öğretmen Rubriği Güncel Değil",
                    subtitle = "Yapılan son değişiklikleri görmek için PDF’yi yeniden oluşturun."
                )
            }
        }
    }

    suspend fun generateTeacherRubricPdf(context: Context, examDraftId: Long): File {
        return withContext(Dispatchers.IO) {
            val metadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (metadata?.isLocked != true) {
                throw IllegalStateException("Yalnızca kilitli ve onaylanmış nihai rubrik için PDF üretilebilir.")
            }

            val draft = examDraftDao.getDraftByIdOnce(examDraftId) ?: throw IllegalStateException("Taslak bulunamadı")
            val questions = questionDao.getByExamDraftIdOnce(examDraftId).map(::mapQuestionToDomain)
            val criteria = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId).map(::mapCriterionToDomain)
            val qEntities = questionDao.getByExamDraftIdOnce(examDraftId)
            val cEntities = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)

            val objectives = objectiveDao?.getApprovedObjectivesByDraftId(examDraftId) ?: emptyList()
            val crossRefs = objectiveDao?.getQuestionObjectiveCrossRefsByDraftId(examDraftId) ?: emptyList()
            val prefsEntity = preferencesDao?.getPreferencesOnce(examDraftId)

            val evaluationPrefs = prefsEntity?.let {
                EvaluationPreferences(
                    writingAndPunctuation = WritingAndPunctuationPreferences(
                        deductPoints = it.deductWritingAndPunctuationPoints
                    )
                )
            }

            val pdfFile = TeacherRubricPdfGenerator.generateTeacherRubricPdf(
                context = context,
                draft = draft,
                questions = questions,
                criteria = criteria,
                objectives = objectives,
                crossRefs = crossRefs,
                preferences = evaluationPrefs,
                metadata = metadata
            )

            val targetFile = File(context.filesDir, "exam_${examDraftId}_teacher_rubric.pdf")
            pdfFile.copyTo(targetFile, overwrite = true)
            pdfFile.delete()

            val fingerprint = buildTeacherRubricFingerprint(draft, qEntities, cEntities, metadata, objectives, crossRefs, prefsEntity)
            try {
                File(context.filesDir, "exam_${examDraftId}_teacher_rubric.pdf.meta").writeText(fingerprint)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            targetFile
        }
    }

    private fun buildTeacherRubricFingerprint(
        draft: com.example.core.database.ExamDraftEntity,
        questions: List<ExamQuestionEntity>,
        criteria: List<ExamRubricCriterionEntity>,
        metadata: ExamRubricSetMetadataEntity?,
        objectives: List<ExamObjectiveEntity>,
        crossRefs: List<QuestionObjectiveCrossRef>,
        prefsEntity: ExamEvaluationPreferencesEntity?
    ): String {
        val draftStr = "INST:${draft.institutionName}|CRS:${draft.courseName}|TERM:${draft.term}|YR:${draft.academicYear}|PTS:${draft.totalPoints}|DATE:${draft.examDate}"
        
        val qStr = questions.sortedBy { it.orderIndex }.joinToString("||") { q ->
            "Q[${q.orderIndex},${q.questionNumber},${q.points}]::${q.questionText}"
        }
        
        val rStr = criteria.sortedBy { "${it.questionOrderIndex}_${it.criterionOrderIndex}" }.joinToString("||") { c ->
            "C[${c.questionOrderIndex},${c.criterionOrderIndex},${c.maxPoints}]::TITLE:${c.title}::DESC:${c.description}::EXP:${c.expectedAnswer}::PAR:${c.partialCreditGuidance}::ERR:${c.commonMistakes}::OAK:${c.originalAnswerKey ?: ""}::ORUB:${c.originalRubric ?: ""}"
        }
        
        val metaStr = "META::EST:${metadata?.evaluationSourceType ?: ""}::OTAK:${metadata?.originalTeacherAnswerKey ?: ""}::OTR:${metadata?.originalTeacherRubric ?: ""}::ASIS:${metadata?.isAsIs ?: false}::EAK:${metadata?.elaboratedAnswerKey ?: ""}::ERUB:${metadata?.elaboratedRubric ?: ""}"
        
        val objStr = objectives.sortedBy { it.id }.joinToString("||") { o ->
            "OBJ[${o.id}]::CODE:${o.objectiveCode ?: ""}::TEXT:${o.objectiveText}"
        }
        
        val refStr = crossRefs.sortedBy { "${it.questionId}_${it.objectiveId}" }.joinToString("||") { r ->
            "REF[${r.questionId},${r.objectiveId}]"
        }
        
        val prefStr = "PREF::DEDUCT:${prefsEntity?.deductWritingAndPunctuationPoints ?: false}"
        
        val combined = listOf(draftStr, qStr, rStr, metaStr, objStr, refStr, prefStr).joinToString("\n")
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(combined.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
