package com.example.core.data

import com.example.core.security.BoundedInputReader
import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamSourceDocumentDao
import com.example.core.database.ExamSourceDocumentEntity
import com.example.core.network.RubricGenerationSourceContext
import com.example.core.model.ExamType
import java.io.File
import java.io.InputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

class ExamSourceDocumentRepository(
    private val filesRoot: File,
    private val sourceDocumentDao: ExamSourceDocumentDao,
    private val examDraftDao: ExamDraftDao,
    private val pdfPageInspector: PdfPageInspector = AndroidPdfPageInspector(),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val nowProvider: () -> Long = System::currentTimeMillis
) {

    private fun resolveManagedFile(relativePath: String): File? {
        if (relativePath.isEmpty()) return null
        if (relativePath.startsWith("/")) return null
        if (relativePath.contains("..") || relativePath.contains(File.separator + "..") || relativePath.contains(".." + File.separator)) return null

        return try {
            val rootCanonical = filesRoot.canonicalFile
            val candidateCanonical = File(rootCanonical, relativePath).canonicalFile

            val rootPrefix = rootCanonical.path + File.separator
            if (!candidateCanonical.path.startsWith(rootPrefix)) {
                return null
            }
            if (candidateCanonical.path == rootCanonical.path) {
                return null
            }
            candidateCanonical
        } catch (e: Exception) {
            null
        }
    }

    fun observeByExamDraftId(examDraftId: Long): Flow<ExamSourceDocumentEntity?> {
        return sourceDocumentDao.observeByExamDraftId(examDraftId)
    }

    suspend fun getByExamDraftIdOnce(examDraftId: Long): ExamSourceDocumentEntity? {
        return withContext(ioDispatcher) {
            sourceDocumentDao.getByExamDraftIdOnce(examDraftId)
        }
    }

    /**
     * Returns the canonical homework source to AI rubric generation.
     * Plain text is preferred as text input. Other supported source types are passed as
     * managed documents/images so the rubric is grounded in the teacher's original task.
     */
    suspend fun getHomeworkRubricSourceContext(examDraftId: Long): RubricGenerationSourceContext? =
        withContext(ioDispatcher) {
            val draft = examDraftDao.getDraftByIdOnce(examDraftId)
                ?: return@withContext null
            if (draft.examType != ExamType.HOMEWORK) return@withContext null

            val document = sourceDocumentDao.getByExamDraftIdOnce(examDraftId)
                ?: return@withContext null
            if (!isUsable(document)) return@withContext null

            val file = resolveManagedFile(document.localRelativePath)
                ?.takeIf { it.exists() && it.isFile && it.canRead() && it.length() == document.sizeBytes }
                ?: return@withContext null

            if (document.mimeType == TEXT_MIME_TYPE) {
                val text = try {
                    String(
                        BoundedInputReader.readFile(file, BoundedInputReader.MAX_TEXT_BYTES, "Metin kaynağı"),
                        Charsets.UTF_8
                    ).trim()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    return@withContext null
                }
                if (text.isBlank()) return@withContext null
                return@withContext RubricGenerationSourceContext.HomeworkText(text)
            }

            RubricGenerationSourceContext.HomeworkDocument(
                file = file,
                mimeType = document.mimeType,
                displayName = document.displayName.ifBlank { file.name },
                sizeBytes = document.sizeBytes
            )
        }

    suspend fun isUsable(document: ExamSourceDocumentEntity): Boolean = withContext(ioDispatcher) {
        val isSupportedImage = document.mimeType.lowercase() in listOf("image/jpeg", "image/jpg", "image/png", "image/webp")
        if (document.mimeType != PDF_MIME_TYPE && document.mimeType != WORD_MIME_TYPE && document.mimeType != TEXT_MIME_TYPE && document.mimeType != ZIP_MIME_TYPE && !isSupportedImage) return@withContext false
        if (document.sizeBytes <= 0) return@withContext false
        val documentMaxBytes = if (document.mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES.toLong() else MAX_SOURCE_SIZE_BYTES
        if (document.sizeBytes > documentMaxBytes) return@withContext false
        if (document.pageCount <= 0) return@withContext false
        if (document.sha256.length != 64 || !document.sha256.matches(Regex("^[a-f0-9]+$"))) return@withContext false

        val file = resolveManagedFile(document.localRelativePath) ?: return@withContext false
        
        if (!file.exists()) return@withContext false
        if (!file.isFile) return@withContext false
        if (!file.canRead()) return@withContext false
        if (file.length() != document.sizeBytes) return@withContext false

        if (document.mimeType == PDF_MIME_TYPE) {
            try {
                file.inputStream().use {
                    val header = ByteArray(5)
                    val read = it.read(header)
                    if (read != 5) return@withContext false
                    if (String(header, Charsets.US_ASCII) != "%PDF-") return@withContext false
                }
            } catch (e: Exception) {
                return@withContext false
            }
        }

        return@withContext true
    }

    suspend fun readManagedBytes(
        document: ExamSourceDocumentEntity
    ): ByteArray? = withContext(ioDispatcher) {
        if (!isUsable(document)) return@withContext null

        val file = resolveManagedFile(document.localRelativePath) ?: return@withContext null
        if (!file.exists() || !file.isFile || !file.canRead()) return@withContext null

        try {
            val maxBytes = if (document.mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES else BoundedInputReader.MAX_DOCUMENT_BYTES
            BoundedInputReader.readFile(file, maxBytes, "Kaynak belge")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    suspend fun importDocument(
        examDraftId: Long,
        originalUri: String?,
        displayName: String,
        mimeType: String,
        declaredSizeBytes: Long?,
        openInputStream: () -> InputStream?
    ): ExamSourceImportResult = withContext(ioDispatcher) {
        val draft = examDraftDao.getDraftByIdOnce(examDraftId)
            ?: return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.DRAFT_NOT_FOUND)

        val isSupportedImage = mimeType.lowercase() in listOf("image/jpeg", "image/jpg", "image/png", "image/webp")
        if (mimeType != PDF_MIME_TYPE && mimeType != WORD_MIME_TYPE && mimeType != TEXT_MIME_TYPE && mimeType != ZIP_MIME_TYPE && !isSupportedImage) {
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.UNSUPPORTED_MIME_TYPE)
        }

        if (declaredSizeBytes == 0L) {
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.EMPTY_FILE)
        }

        val maxImportBytes = if (mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES.toLong() else MAX_SOURCE_SIZE_BYTES
        if (declaredSizeBytes != null && declaredSizeBytes > maxImportBytes) {
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.FILE_TOO_LARGE)
        }

        val inputStream = try {
            openInputStream()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } ?: return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.SOURCE_UNAVAILABLE)

        val draftDir = resolveManagedFile("exams/$examDraftId/source")
        if (draftDir == null) {
            inputStream.close()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.STORAGE_ERROR)
        }

        if (!draftDir.exists() && !draftDir.mkdirs()) {
            inputStream.close()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.STORAGE_ERROR)
        }

        val tempFile = File(draftDir, ".import_${System.nanoTime()}.tmp")
        
        var actualSizeBytes = 0L
        val digest = MessageDigest.getInstance("SHA-256")
        var isFileTooLarge = false

        try {
            inputStream.use { input ->
                tempFile.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        actualSizeBytes += bytesRead
                        if (actualSizeBytes > maxImportBytes) {
                            isFileTooLarge = true
                            break
                        }
                        output.write(buffer, 0, bytesRead)
                        digest.update(buffer, 0, bytesRead)
                    }
                }
            }
        } catch (e: CancellationException) {
            tempFile.delete()
            throw e
        } catch (e: Exception) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.STORAGE_ERROR)
        }

        if (isFileTooLarge) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.FILE_TOO_LARGE)
        }

        if (actualSizeBytes == 0L) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.EMPTY_FILE)
        }

        val generatedSha256 = digest.digest().joinToString("") { "%02x".format(it) }

        var isValidPdf = false
        try {
            tempFile.inputStream().use {
                val header = ByteArray(5)
                val read = it.read(header)
                if (read == 5 && String(header, Charsets.US_ASCII) == "%PDF-") {
                    isValidPdf = true
                }
            }
        } catch (e: CancellationException) {
            tempFile.delete()
            throw e
        } catch (e: Exception) {
            // Invalid PDF/header is handled below.
        }

        if (mimeType == PDF_MIME_TYPE && !isValidPdf) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.INVALID_PDF)
        }

        val pageCount = when (mimeType) {
            PDF_MIME_TYPE -> try {
                pdfPageInspector.readPageCount(tempFile)
            } catch (e: CancellationException) {
                tempFile.delete()
                throw e
            } catch (e: Exception) {
                -1
            }
            ZIP_MIME_TYPE -> try {
                var count = 0
                java.util.zip.ZipInputStream(tempFile.inputStream()).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        count++
                        require(count <= 100) { "ZIP kaynağında 100'den fazla girdi var." }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
                if (count > 0) count else 1
            } catch (e: CancellationException) {
                tempFile.delete()
                throw e
            } catch (e: Exception) {
                -1
            }
            else -> 1
        }

        if (pageCount <= 0) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.INVALID_PDF)
        }

        val existingDocument = sourceDocumentDao.getByExamDraftIdOnce(examDraftId)
        if (existingDocument != null && existingDocument.sha256 == generatedSha256) {
            if (isUsable(existingDocument)) {
                tempFile.delete()
                return@withContext ExamSourceImportResult.Success(
                    document = existingDocument,
                    replacedExisting = false,
                    reusedExisting = true
                )
            }
        }

        val importedAt = nowProvider()
        val baseFileName = "source_${importedAt}_${generatedSha256.take(12)}"
        val extension = when (mimeType) {
            PDF_MIME_TYPE -> ".pdf"
            WORD_MIME_TYPE -> ".docx"
            TEXT_MIME_TYPE -> ".txt"
            ZIP_MIME_TYPE -> ".zip"
            "image/png" -> ".png"
            "image/jpeg" -> ".jpg"
            "image/webp" -> ".webp"
            else -> ""
        }
        var permFileName = "$baseFileName$extension"
        var permFile = File(draftDir, permFileName)
        var suffixCounter = 1

        while (permFile.exists() && suffixCounter <= 100) {
            permFileName = "${baseFileName}_$suffixCounter$extension"
            permFile = File(draftDir, permFileName)
            suffixCounter++
        }

        if (permFile.exists()) {
            tempFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.STORAGE_ERROR)
        }

        try {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
        } catch (e: CancellationException) {
            tempFile.delete()
            throw e
        }

        val moved = try {
            try {
                Files.move(tempFile.toPath(), permFile.toPath(), StandardCopyOption.ATOMIC_MOVE)
                true
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(tempFile.toPath(), permFile.toPath())
                true
            }
        } catch (e: Exception) {
            false
        }

        if (!moved) {
            tempFile.delete()
            if (permFile.exists()) permFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.STORAGE_ERROR)
        }
        
        tempFile.delete()

        val generatedRelativePath = "exams/$examDraftId/source/$permFileName"

        val newDocument = ExamSourceDocumentEntity(
            examDraftId = examDraftId,
            localRelativePath = generatedRelativePath,
            originalUri = originalUri,
            displayName = displayName,
            mimeType = mimeType,
            sizeBytes = actualSizeBytes,
            sha256 = generatedSha256,
            pageCount = pageCount,
            importedAt = importedAt
        )

        // After the permanent file move, finish the short DB/file ownership commit even if
        // the UI coroutine is cancelled. Interrupting between move and DB upsert would leave
        // either an orphan file or a DB row pointing at a deleted file.
        try {
            withContext(NonCancellable) {
                sourceDocumentDao.upsert(newDocument)

                // Best-effort delete the superseded old file only after the new DB row exists.
                if (existingDocument != null && existingDocument.localRelativePath != generatedRelativePath) {
                    try {
                        val oldFile = resolveManagedFile(existingDocument.localRelativePath)
                        if (oldFile != null && oldFile.exists()) {
                            oldFile.delete()
                        }
                    } catch (e: Exception) {
                        // Old-file cleanup is recoverable and must not invalidate the new source row.
                    }
                }
            }

            return@withContext ExamSourceImportResult.Success(
                document = newDocument,
                replacedExisting = existingDocument != null,
                reusedExisting = false
            )
        } catch (e: Exception) {
            permFile.delete()
            return@withContext ExamSourceImportResult.Failure(ExamSourceImportFailure.DATABASE_ERROR)
        }
    }

    suspend fun removeByExamDraftId(examDraftId: Long): Boolean = withContext(ioDispatcher) {
        val existing = sourceDocumentDao.getByExamDraftIdOnce(examDraftId) ?: return@withContext true
        
        try {
            sourceDocumentDao.deleteByExamDraftId(examDraftId)
        } catch (e: Exception) {
            return@withContext false
        }
        
        try {
            val file = resolveManagedFile(existing.localRelativePath)
            if (file != null && file.exists()) {
                file.delete()
            }
            val dir = resolveManagedFile("exams/$examDraftId/source")
            if (dir != null && dir.exists() && dir.isDirectory) {
                if (dir.list()?.isEmpty() == true) {
                    dir.delete()
                }
            }
        } catch (e: Exception) {
            // Ignored
        }
        
        return@withContext true
    }

    companion object {
        const val PDF_MIME_TYPE = "application/pdf"
        const val WORD_MIME_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        const val TEXT_MIME_TYPE = "text/plain"
        const val ZIP_MIME_TYPE = "application/zip"
        const val MAX_SOURCE_SIZE_BYTES = 50L * 1024L * 1024L
    }
}
