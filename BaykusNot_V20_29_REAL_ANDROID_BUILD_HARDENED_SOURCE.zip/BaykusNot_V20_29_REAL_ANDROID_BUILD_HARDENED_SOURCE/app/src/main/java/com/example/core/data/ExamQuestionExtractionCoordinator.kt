package com.example.core.data

import com.example.core.database.ExamQuestionExtractionDraftEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.QuestionPointsValidationResult
import com.example.core.network.ExamExtractionInput
import com.example.core.network.ExamQuestionExtractionResult
import com.example.core.network.ExamQuestionExtractor
import com.example.core.network.ExtractedExamQuestion

sealed interface ExamQuestionExtractionCoordinatorResult {
    data class Promoted(
        val questions: List<ExamQuestion>,
        val metadata: ExamQuestionSetMetadata,
        val validation: QuestionPointsValidationResult
    ) : ExamQuestionExtractionCoordinatorResult

    data class Staged(
        val hasCanonicalQuestions: Boolean,
        val isStagingComplete: Boolean,
        val stagingCount: Int,
        val reusedExisting: Boolean
    ) : ExamQuestionExtractionCoordinatorResult

    data class ExistingCanonicalEquivalent(
        val questionCount: Int
    ) : ExamQuestionExtractionCoordinatorResult

    data class LockedCanonical(
        val currentRevision: Int
    ) : ExamQuestionExtractionCoordinatorResult

    data object InvalidArguments : ExamQuestionExtractionCoordinatorResult
    data object NoQuestionsFound : ExamQuestionExtractionCoordinatorResult
    data object MissingApiKey : ExamQuestionExtractionCoordinatorResult
    data object InvalidInput : ExamQuestionExtractionCoordinatorResult
    data object NetworkFailure : ExamQuestionExtractionCoordinatorResult
    data object Unauthorized : ExamQuestionExtractionCoordinatorResult
    data object RateLimited : ExamQuestionExtractionCoordinatorResult
    data object ServiceUnavailable : ExamQuestionExtractionCoordinatorResult
    data object MalformedResponse : ExamQuestionExtractionCoordinatorResult
    data object UnexpectedFailure : ExamQuestionExtractionCoordinatorResult

    data object PromotionDraftNotFound : ExamQuestionExtractionCoordinatorResult
    data class PromotionValidationFailed(val validation: QuestionPointsValidationResult) : ExamQuestionExtractionCoordinatorResult
    data class PromotionLocked(val currentRevision: Int) : ExamQuestionExtractionCoordinatorResult
    data class PromotionRevisionConflict(val currentRevision: Int) : ExamQuestionExtractionCoordinatorResult
    data class PromotionFailure(val cause: Throwable) : ExamQuestionExtractionCoordinatorResult
}

class ExamQuestionExtractionCoordinator(
    private val extractor: ExamQuestionExtractor,
    private val draftRepository: ExamQuestionExtractionDraftRepository,
    private val questionRepository: ExamQuestionRepository,
    private val stageValidator: suspend (Long) -> Boolean = { true }
) {
    suspend fun process(
        examDraftId: Long,
        sourceFingerprint: String,
        input: ExamExtractionInput,
        examType: ExamType = ExamType.WRITTEN
    ): ExamQuestionExtractionCoordinatorResult {
        if (examType == ExamType.MULTIPLE_CHOICE) {
            // Test Sınavı Phase 2: question structure comes from the teacher's
            // local answer-key setup. Never invoke an AI question extractor.
            return ExamQuestionExtractionCoordinatorResult.InvalidInput
        }
        if (examDraftId <= 0 || sourceFingerprint.isBlank()) {
            return ExamQuestionExtractionCoordinatorResult.InvalidArguments
        }
        if (!stageValidator(examDraftId)) {
            return ExamQuestionExtractionCoordinatorResult.UnexpectedFailure
        }

        val canonicalQuestions = questionRepository.getQuestionsOnce(examDraftId)
        val metadata = questionRepository.getMetadataOnce(examDraftId)

        if (metadata?.isLocked == true) {
            return ExamQuestionExtractionCoordinatorResult.LockedCanonical(metadata.revision)
        }

        val isPristine = canonicalQuestions.isEmpty() && metadata == null

        val existingStaging = draftRepository.getStagingOnce(examDraftId)
        val hasSameSourceStaging = existingStaging.isNotEmpty() &&
            existingStaging.all { it.sourceFingerprint == sourceFingerprint }

        if (hasSameSourceStaging) {
            val isStagingComplete = existingStaging.all {
                it.rawQuestionNumber.isNotBlank() &&
                it.rawQuestionText.isNotBlank() &&
                it.rawPoints != null &&
                it.rawPoints > 0
            }

            if (isPristine) {
                if (isStagingComplete) {
                    val mappedQuestions = existingStaging.map { toDomain(it) }
                    return attemptPromotion(examDraftId, mappedQuestions)
                } else {
                    return ExamQuestionExtractionCoordinatorResult.Staged(
                        hasCanonicalQuestions = false,
                        isStagingComplete = false,
                        stagingCount = existingStaging.size,
                        reusedExisting = true
                    )
                }
            } else {
                val isEquivalent = canonicalQuestions.size == existingStaging.size &&
                    canonicalQuestions.zip(existingStaging).all { (c, s) ->
                        c.orderIndex == s.orderIndex &&
                        c.questionNumber == s.rawQuestionNumber &&
                        c.questionText == s.rawQuestionText &&
                        c.points == s.rawPoints
                    }

                if (isStagingComplete && isEquivalent) {
                    draftRepository.clearStaging(examDraftId)
                    return ExamQuestionExtractionCoordinatorResult.ExistingCanonicalEquivalent(canonicalQuestions.size)
                } else {
                    return ExamQuestionExtractionCoordinatorResult.Staged(
                        hasCanonicalQuestions = canonicalQuestions.isNotEmpty(),
                        isStagingComplete = isStagingComplete,
                        stagingCount = existingStaging.size,
                        reusedExisting = true
                    )
                }
            }
        }

        val extractionResult = extractor.extractForExam(examDraftId, input, examType)
        if (!stageValidator(examDraftId)) {
            return ExamQuestionExtractionCoordinatorResult.UnexpectedFailure
        }
        return handleExtractionResult(
            examDraftId = examDraftId,
            sourceFingerprint = sourceFingerprint,
            isPristine = isPristine,
            hasCanonicalQuestions = canonicalQuestions.isNotEmpty(),
            result = extractionResult
        )
    }

    private suspend fun attemptPromotion(
        examDraftId: Long,
        questions: List<ExamQuestion>
    ): ExamQuestionExtractionCoordinatorResult {
        if (!stageValidator(examDraftId)) return ExamQuestionExtractionCoordinatorResult.UnexpectedFailure
        val saveResult = questionRepository.saveQuestions(
            examDraftId = examDraftId,
            expectedRevision = 0,
            questions = questions
        )

        return when (saveResult) {
            is SaveExamQuestionsResult.Success -> {
                draftRepository.clearStaging(examDraftId)
                ExamQuestionExtractionCoordinatorResult.Promoted(
                    questions = questions,
                    metadata = saveResult.metadata,
                    validation = saveResult.validation
                )
            }
            is SaveExamQuestionsResult.DraftNotFound -> ExamQuestionExtractionCoordinatorResult.PromotionDraftNotFound
            is SaveExamQuestionsResult.ValidationFailed -> ExamQuestionExtractionCoordinatorResult.PromotionValidationFailed(saveResult.validation)
            is SaveExamQuestionsResult.Locked -> ExamQuestionExtractionCoordinatorResult.PromotionLocked(saveResult.currentRevision)
            is SaveExamQuestionsResult.RevisionConflict -> ExamQuestionExtractionCoordinatorResult.PromotionRevisionConflict(saveResult.currentRevision)
            is SaveExamQuestionsResult.Failure -> ExamQuestionExtractionCoordinatorResult.PromotionFailure(saveResult.cause)
        }
    }

    private suspend fun handleExtractionResult(
        examDraftId: Long,
        sourceFingerprint: String,
        isPristine: Boolean,
        hasCanonicalQuestions: Boolean,
        result: ExamQuestionExtractionResult
    ): ExamQuestionExtractionCoordinatorResult {
        if (!stageValidator(examDraftId)) return ExamQuestionExtractionCoordinatorResult.UnexpectedFailure
        return when (result) {
            is ExamQuestionExtractionResult.Complete -> {
                val stagingRows = result.questions.mapIndexed { index, q ->
                    toEntity(examDraftId, sourceFingerprint, index, q)
                }
                draftRepository.replaceStaging(examDraftId, stagingRows)

                if (isPristine) {
                    val mappedQuestions = stagingRows.map { toDomain(it) }
                    attemptPromotion(examDraftId, mappedQuestions)
                } else {
                    ExamQuestionExtractionCoordinatorResult.Staged(
                        hasCanonicalQuestions = hasCanonicalQuestions,
                        isStagingComplete = true,
                        stagingCount = stagingRows.size,
                        reusedExisting = false
                    )
                }
            }
            is ExamQuestionExtractionResult.IncompleteExtraction -> {
                val stagingRows = result.questions.mapIndexed { index, q ->
                    toEntity(examDraftId, sourceFingerprint, index, q)
                }
                draftRepository.replaceStaging(examDraftId, stagingRows)

                ExamQuestionExtractionCoordinatorResult.Staged(
                    hasCanonicalQuestions = hasCanonicalQuestions,
                    isStagingComplete = false,
                    stagingCount = stagingRows.size,
                    reusedExisting = false
                )
            }
            is ExamQuestionExtractionResult.NoQuestionsFound -> ExamQuestionExtractionCoordinatorResult.NoQuestionsFound
            is ExamQuestionExtractionResult.MissingApiKey -> ExamQuestionExtractionCoordinatorResult.MissingApiKey
            is ExamQuestionExtractionResult.InvalidInput -> ExamQuestionExtractionCoordinatorResult.InvalidInput
            is ExamQuestionExtractionResult.NetworkFailure -> ExamQuestionExtractionCoordinatorResult.NetworkFailure
            is ExamQuestionExtractionResult.Unauthorized -> ExamQuestionExtractionCoordinatorResult.Unauthorized
            is ExamQuestionExtractionResult.RateLimited -> ExamQuestionExtractionCoordinatorResult.RateLimited
            is ExamQuestionExtractionResult.ServiceUnavailable -> ExamQuestionExtractionCoordinatorResult.ServiceUnavailable
            is ExamQuestionExtractionResult.MalformedResponse -> ExamQuestionExtractionCoordinatorResult.MalformedResponse
            is ExamQuestionExtractionResult.UnexpectedFailure -> ExamQuestionExtractionCoordinatorResult.UnexpectedFailure
        }
    }

    private fun toEntity(
        examDraftId: Long,
        sourceFingerprint: String,
        index: Int,
        q: ExtractedExamQuestion
    ): ExamQuestionExtractionDraftEntity {
        return ExamQuestionExtractionDraftEntity(
            examDraftId = examDraftId,
            sourceFingerprint = sourceFingerprint,
            orderIndex = index + 1,
            rawQuestionNumber = q.questionNumber,
            rawQuestionText = q.questionText,
            rawPoints = q.points
        )
    }

    private fun toDomain(entity: ExamQuestionExtractionDraftEntity): ExamQuestion {
        return ExamQuestion(
            id = 0L,
            examDraftId = entity.examDraftId,
            orderIndex = entity.orderIndex,
            questionNumber = entity.rawQuestionNumber,
            questionText = entity.rawQuestionText,
            points = entity.rawPoints!!
        )
    }
}
