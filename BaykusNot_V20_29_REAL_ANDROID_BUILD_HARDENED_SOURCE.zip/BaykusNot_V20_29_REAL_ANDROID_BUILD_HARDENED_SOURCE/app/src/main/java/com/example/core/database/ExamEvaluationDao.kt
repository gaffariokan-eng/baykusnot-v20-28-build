package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamEvaluationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEvaluationRunState(state: ExamEvaluationRunStateEntity)

    @Query("SELECT * FROM exam_evaluation_run_state WHERE examDraftId = :examDraftId LIMIT 1")
    suspend fun getEvaluationRunState(examDraftId: Long): ExamEvaluationRunStateEntity?

    @Query("DELETE FROM exam_evaluation_run_state WHERE examDraftId = :examDraftId")
    suspend fun deleteEvaluationRunState(examDraftId: Long)


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProcessingMode(mode: ExamProcessingModeEntity)

    @Query("SELECT * FROM exam_processing_mode WHERE examDraftId = :examDraftId LIMIT 1")
    suspend fun getProcessingMode(examDraftId: Long): ExamProcessingModeEntity?


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertYazekDeclarationAudit(audit: ExamYazekDeclarationEntity)

    @Query("SELECT * FROM exam_yazek_declaration WHERE examDraftId = :examDraftId LIMIT 1")
    suspend fun getYazekDeclarationAudit(examDraftId: Long): ExamYazekDeclarationEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAiRunProfile(profile: ExamAiRunProfileEntity): Long

    @Query("SELECT * FROM exam_ai_run_profile WHERE examDraftId = :examDraftId LIMIT 1")
    suspend fun getAiRunProfile(examDraftId: Long): ExamAiRunProfileEntity?

    @Query("UPDATE exam_ai_run_profile SET legacyPrivacyApprovedAt = :approvedAt WHERE examDraftId = :examDraftId")
    suspend fun approveLegacyPrivacy(examDraftId: Long, approvedAt: Long = System.currentTimeMillis())

    @Query("UPDATE exam_ai_run_profile SET homeworkPrivacyApprovedAt = :approvedAt WHERE examDraftId = :examDraftId")
    suspend fun approveHomeworkPrivacy(examDraftId: Long, approvedAt: Long = System.currentTimeMillis())

    @Insert
    suspend fun insertAiUsage(usage: ExamAiUsageEntity): Long

    @Query("SELECT * FROM exam_ai_usage WHERE examDraftId = :examDraftId ORDER BY id ASC")
    suspend fun getAiUsageForExam(examDraftId: Long): List<ExamAiUsageEntity>

    @Query("DELETE FROM exam_ai_usage WHERE examDraftId = :examDraftId")
    suspend fun deleteAiUsageForExam(examDraftId: Long)


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateStudentEvaluation(evaluation: ExamStudentEvaluationEntity)

    @Query("SELECT * FROM exam_student_evaluation WHERE studentPaperId = :studentPaperId")
    fun getStudentEvaluation(studentPaperId: Long): Flow<ExamStudentEvaluationEntity?>

    @Query("SELECT * FROM exam_student_evaluation WHERE studentPaperId = :studentPaperId")
    suspend fun getStudentEvaluationOnce(studentPaperId: Long): ExamStudentEvaluationEntity?

    @Query("SELECT * FROM exam_student_evaluation WHERE examDraftId = :examDraftId")
    fun getStudentEvaluationsForExam(examDraftId: Long): Flow<List<ExamStudentEvaluationEntity>>

    @Query("SELECT * FROM exam_student_evaluation WHERE examDraftId = :examDraftId")
    suspend fun getStudentEvaluationsForExamOnce(examDraftId: Long): List<ExamStudentEvaluationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestionEvaluations(evaluations: List<ExamQuestionEvaluationEntity>)

    @Query("DELETE FROM exam_question_evaluation WHERE studentPaperId = :studentPaperId")
    suspend fun deleteQuestionEvaluationsForPaper(studentPaperId: Long)

    @Query("SELECT * FROM exam_question_evaluation WHERE studentPaperId = :studentPaperId ORDER BY questionOrderIndex ASC")
    fun getQuestionEvaluationsForPaper(studentPaperId: Long): Flow<List<ExamQuestionEvaluationEntity>>

    @Query("SELECT * FROM exam_question_evaluation WHERE studentPaperId = :studentPaperId ORDER BY questionOrderIndex ASC")
    suspend fun getQuestionEvaluationsForPaperOnce(studentPaperId: Long): List<ExamQuestionEvaluationEntity>

    @Query("SELECT * FROM exam_question_evaluation WHERE examDraftId = :examDraftId ORDER BY studentPaperId ASC, questionOrderIndex ASC")
    fun getQuestionEvaluationsForExam(examDraftId: Long): Flow<List<ExamQuestionEvaluationEntity>>

    @Query("SELECT * FROM exam_question_evaluation WHERE examDraftId = :examDraftId ORDER BY studentPaperId ASC, questionOrderIndex ASC")
    suspend fun getQuestionEvaluationsForExamOnce(examDraftId: Long): List<ExamQuestionEvaluationEntity>

    @Query("DELETE FROM exam_student_evaluation WHERE examDraftId = :examDraftId")
    suspend fun deleteAllEvaluationsForExam(examDraftId: Long)

    @androidx.room.Transaction
    suspend fun saveCompleteEvaluationTransaction(
        evaluation: ExamStudentEvaluationEntity,
        questionEvaluations: List<ExamQuestionEvaluationEntity>
    ) {
        deleteQuestionEvaluationsForPaper(evaluation.studentPaperId)
        if (questionEvaluations.isNotEmpty()) {
            insertQuestionEvaluations(questionEvaluations)
        }
        insertOrUpdateStudentEvaluation(evaluation)
    }

    @Query("UPDATE exam_question_evaluation SET score = :score, isTeacherModified = :isTeacherModified, isResolved = :isResolved WHERE id = :questionEvalId")
    suspend fun updateQuestionScoreAndResolution(questionEvalId: Long, score: Double, isTeacherModified: Boolean, isResolved: Boolean)

    @Query("SELECT * FROM exam_question_evaluation WHERE id = :questionEvalId LIMIT 1")
    suspend fun getQuestionEvaluationByIdOnce(questionEvalId: Long): ExamQuestionEvaluationEntity?

    @Query("SELECT COALESCE(SUM(score), 0.0) FROM exam_question_evaluation WHERE studentPaperId = :studentPaperId")
    suspend fun sumQuestionScoresForPaper(studentPaperId: Long): Double

    @Query("""
        UPDATE exam_question_evaluation
        SET interpretedMeaning = NULL,
            gradingEvidence = NULL,
            strengths = '[]',
            missingElements = '[]',
            misconceptions = '[]',
            nextSteps = '[]',
            feedback = NULL
        WHERE id = :questionEvalId
    """)
    suspend fun clearAiDiagnosticsForQuestion(questionEvalId: Long)

    @androidx.room.Transaction
    suspend fun applyTeacherScoreChangeTransaction(
        questionEvalId: Long,
        score: Double,
        isResolved: Boolean = true
    ): Double {
        val current = getQuestionEvaluationByIdOnce(questionEvalId)
            ?: throw IllegalArgumentException("Soru değerlendirmesi bulunamadı.")
        require(score >= 0.0 && score <= current.maxScore) { "Puan soru üst sınırı dışında." }
        updateQuestionScoreAndResolution(questionEvalId, score, isTeacherModified = true, isResolved = isResolved)

        val majorChangeThreshold = kotlin.math.max(1.0, current.maxScore * 0.20)
        if (kotlin.math.abs(score - current.originalScore) >= majorChangeThreshold) {
            // A materially changed teacher score invalidates the AI's old pedagogical diagnosis.
            clearAiDiagnosticsForQuestion(questionEvalId)
        }

        val totalScore = sumQuestionScoresForPaper(current.studentPaperId)
        // Score, total, approval invalidation and final-feedback invalidation commit together.
        clearQuestionFeedbackForStudent(current.studentPaperId)
        invalidateStudentApprovalAndFeedback(current.studentPaperId, totalScore)
        return totalScore
    }

    @Query("""
        UPDATE exam_question_evaluation
        SET readAnswerText = :readAnswerText,
            score = :score,
            feedback = :feedback,
            readingConfidence = 1.0,
            evaluationConfidence = 1.0,
            answerType = :answerType,
            needsReview = 0,
            reviewReason = NULL,
            isTeacherModified = 1,
            isResolved = 1
        WHERE id = :questionEvalId
    """)
    suspend fun resolveMultipleChoiceAnswer(
        questionEvalId: Long,
        readAnswerText: String,
        score: Double,
        feedback: String,
        answerType: String
    )

    @Query("""
        UPDATE exam_question_evaluation
        SET needsReview = 1,
            reviewReason = :reason,
            isResolved = 0
        WHERE id = :questionEvaluationId AND isTeacherModified = 0
    """)
    suspend fun markQuestionNeedsReview(questionEvaluationId: Long, reason: String)

    @Query("""
        UPDATE exam_student_evaluation
        SET needsReview = 1,
            status = 'NEEDS_REVIEW',
            updatedAt = :updatedAt
        WHERE studentPaperId = :studentPaperId AND isTeacherApproved = 0
    """)
    suspend fun markStudentNeedsReview(studentPaperId: Long, updatedAt: Long = System.currentTimeMillis())


    @Query("UPDATE exam_question_evaluation SET feedback = :feedback WHERE id = :questionEvalId")
    suspend fun updateQuestionFeedback(questionEvalId: Long, feedback: String?)

    @Query("UPDATE exam_student_evaluation SET overallFeedback = :overallFeedback, spellingPunctuationFeedback = :writingFeedback, feedbackGeneratedAt = :generatedAt, updatedAt = :generatedAt WHERE studentPaperId = :studentPaperId")
    suspend fun updateStudentOverallFeedback(studentPaperId: Long, overallFeedback: String?, writingFeedback: String?, generatedAt: Long)

    @Query("SELECT currentWorkflowStage FROM exam_draft WHERE id = :examDraftId LIMIT 1")
    suspend fun getWorkflowStageForFinalFeedback(examDraftId: Long): String?

    @androidx.room.Transaction
    suspend fun saveFinalFeedbackIfSnapshotMatches(
        examDraftId: Long,
        expectedStudent: ExamStudentEvaluationEntity,
        expectedQuestionEvaluations: List<ExamQuestionEvaluationEntity>,
        questionFeedback: Map<Long, String?>,
        overallFeedback: String?,
        writingFeedback: String?,
        generatedAt: Long
    ): Boolean {
        if (getWorkflowStageForFinalFeedback(examDraftId) != "REPORTS") return false
        val currentStudent = getStudentEvaluationOnce(expectedStudent.studentPaperId) ?: return false
        if (!currentStudent.isTeacherApproved || currentStudent.feedbackGeneratedAt != null) return false
        if (currentStudent != expectedStudent) return false
        val currentQuestions = getQuestionEvaluationsForPaperOnce(expectedStudent.studentPaperId).sortedBy { it.questionOrderIndex }
        val expectedQuestions = expectedQuestionEvaluations.sortedBy { it.questionOrderIndex }
        if (currentQuestions != expectedQuestions) return false
        if (questionFeedback.keys != expectedQuestions.map { it.id }.toSet()) return false
        questionFeedback.forEach { (id, feedback) -> updateQuestionFeedback(id, feedback) }
        updateStudentOverallFeedback(expectedStudent.studentPaperId, overallFeedback, writingFeedback, generatedAt)
        return true
    }

    @androidx.room.Transaction
    suspend fun saveFinalFeedbackTransaction(
        studentPaperId: Long,
        questionFeedback: Map<Long, String?>,
        overallFeedback: String?,
        writingFeedback: String?,
        generatedAt: Long
    ) {
        questionFeedback.forEach { (id, feedback) -> updateQuestionFeedback(id, feedback) }
        updateStudentOverallFeedback(studentPaperId, overallFeedback, writingFeedback, generatedAt)
    }


    @Query("UPDATE exam_question_evaluation SET feedback = NULL WHERE studentPaperId = :studentPaperId")
    suspend fun clearQuestionFeedbackForStudent(studentPaperId: Long)

    @Query("UPDATE exam_student_evaluation SET overallFeedback = NULL, spellingPunctuationFeedback = NULL, feedbackGeneratedAt = NULL, isTeacherApproved = 0, totalScore = :totalScore, updatedAt = :updatedAt WHERE studentPaperId = :studentPaperId")
    suspend fun invalidateStudentApprovalAndFeedback(studentPaperId: Long, totalScore: Double, updatedAt: Long = System.currentTimeMillis())

    @androidx.room.Transaction
    suspend fun invalidateFinalFeedbackTransaction(studentPaperId: Long, totalScore: Double) {
        clearQuestionFeedbackForStudent(studentPaperId)
        invalidateStudentApprovalAndFeedback(studentPaperId, totalScore)
    }

    @Query("UPDATE exam_student_evaluation SET teacherNote = :teacherNote, updatedAt = :updatedAt WHERE studentPaperId = :studentPaperId")
    suspend fun updateTeacherNote(studentPaperId: Long, teacherNote: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE exam_student_evaluation SET totalScore = :totalScore, isTeacherApproved = :isTeacherApproved, updatedAt = :updatedAt WHERE studentPaperId = :studentPaperId")
    suspend fun updateStudentApprovalAndScore(studentPaperId: Long, totalScore: Double, isTeacherApproved: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT currentWorkflowStage FROM exam_draft WHERE id = :examDraftId LIMIT 1")
    suspend fun getWorkflowStageForApproval(examDraftId: Long): String?

    /**
     * Final academic approval is compare-and-commit: every student/question row inspected
     * by the teacher must still be byte-for-byte the same inside this Room transaction.
     * This closes the validation-to-commit race with concurrent score/review changes.
     */
    @androidx.room.Transaction
    suspend fun confirmAllStudentResultsIfSnapshotMatches(
        examDraftId: Long,
        expectedStudents: List<ExamStudentEvaluationEntity>,
        expectedQuestionEvaluations: List<ExamQuestionEvaluationEntity>,
        updates: List<ExamStudentEvaluationEntity>
    ): Boolean {
        if (getWorkflowStageForApproval(examDraftId) != "TEACHER_REVIEW") return false
        if (getReviewRequestsForExam(examDraftId).any { it.status == "OPEN" }) return false

        val currentStudents = getStudentEvaluationsForExamOnce(examDraftId).sortedBy { it.studentPaperId }
        val expectedStudentRows = expectedStudents.sortedBy { it.studentPaperId }
        if (currentStudents != expectedStudentRows) return false

        val currentQuestions = getQuestionEvaluationsForExamOnce(examDraftId)
            .sortedWith(compareBy<ExamQuestionEvaluationEntity> { it.studentPaperId }.thenBy { it.questionOrderIndex }.thenBy { it.id })
        val expectedQuestions = expectedQuestionEvaluations
            .sortedWith(compareBy<ExamQuestionEvaluationEntity> { it.studentPaperId }.thenBy { it.questionOrderIndex }.thenBy { it.id })
        if (currentQuestions != expectedQuestions) return false

        if (updates.map { it.studentPaperId }.toSet() != expectedStudentRows.map { it.studentPaperId }.toSet()) return false
        updates.forEach {
            updateStudentApprovalAndScore(it.studentPaperId, it.totalScore ?: 0.0, it.isTeacherApproved)
        }
        return true
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertReviewRequest(request: ExamReviewRequestEntity): Long

    @Query("SELECT * FROM exam_review_request WHERE studentPaperId = :studentPaperId ORDER BY requestedAt DESC")
    suspend fun getReviewRequestsForPaper(studentPaperId: Long): List<ExamReviewRequestEntity>

    @Query("SELECT * FROM exam_review_request WHERE examDraftId = :examDraftId ORDER BY requestedAt DESC")
    suspend fun getReviewRequestsForExam(examDraftId: Long): List<ExamReviewRequestEntity>

    @Query("SELECT * FROM exam_review_request WHERE id = :requestId LIMIT 1")
    suspend fun getReviewRequestById(requestId: Long): ExamReviewRequestEntity?

    @Query("""
        UPDATE exam_review_request
        SET status = 'RESOLVED', scoreAfter = :scoreAfter, resolvedAt = :resolvedAt, resolutionNote = :resolutionNote
        WHERE id = :requestId
    """)
    suspend fun resolveReviewRequest(
        requestId: Long,
        scoreAfter: Double?,
        resolvedAt: Long,
        resolutionNote: String
    )
}
