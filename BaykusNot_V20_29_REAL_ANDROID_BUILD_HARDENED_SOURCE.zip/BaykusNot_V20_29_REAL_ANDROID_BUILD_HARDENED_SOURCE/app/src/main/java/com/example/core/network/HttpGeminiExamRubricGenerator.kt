package com.example.core.network

import com.example.core.security.BoundedInputReader
import com.example.core.model.ExamType
import com.example.core.security.SecureApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.Base64
import kotlin.coroutines.cancellation.CancellationException

class HttpGeminiExamRubricGenerator(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta/interactions",
    private val aiUsageLedger: AiUsageLedger? = null
) : ExamRubricGenerator {

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override suspend fun generate(
        input: ExamRubricGenerationInput
    ): ExamRubricGenerationResult {
        if (input.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
            // Test Sınavı Phase 2: answer key is teacher-entered and OMR-scored locally.
            // Never spend an API call generating a rubric/answer key for tests.
            return ExamRubricGenerationResult.InvalidInput
        }
        if (input.questions.isEmpty()) {
            return ExamRubricGenerationResult.InvalidInput
        }
        for (q in input.questions) {
            if (q.questionText.isBlank() || q.points <= 0 || q.questionNumber.isBlank()) {
                return ExamRubricGenerationResult.InvalidInput
            }
        }

        val result = try {
            apiKeyStore.useApiKey { apiKey ->
                if (apiKey.isBlank()) {
                    return@useApiKey ExamRubricGenerationResult.MissingApiKey
                }
                val profileSnapshot = GeminiModelRegistry.currentProfile()
                val requestedAuthoringModel = profileSnapshot.authoringModel
                GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

                val questionsArray = buildJsonArray {
                    for (q in input.questions) {
                        add(buildJsonObject {
                            put("questionOrderIndex", q.questionOrderIndex)
                            put("questionNumber", q.questionNumber)
                            put("questionText", q.questionText)
                            put("points", q.points)
                        })
                    }
                }

                val taskInputObj = buildJsonObject {
                    put("questions", questionsArray)
                    put("deductWritingPunctuationPoints", input.deductWritingPunctuationPoints)
                }

                val sourceContextRule = when (input.sourceContext) {
                    is RubricGenerationSourceContext.ListeningText,
                    is RubricGenerationSourceContext.ListeningAudio ->
                        " Bu bir Dinleme Sınavıdır. İstekte verilen DİNLEME KAYNAĞINI soruların doğru/beklenen cevaplarını belirlemek ve doğrulamak için kullan; kaynakta olmayan bilgi uydurma."
                    is RubricGenerationSourceContext.HomeworkText,
                    is RubricGenerationSourceContext.HomeworkDocument ->
                        " Bu bir Ödev Kontrolüdür. İstekte verilen ÖDEV KAYNAĞINI görevlerin beklenen çıktısını, kapsamını ve varsa öğretmenin değerlendirme ölçütlerini anlamak için kullan; kaynakta olmayan görev, cevap veya ölçüt uydurma."
                    null -> ""
                }
                val isHomeworkRubric = input.sourceContext is RubricGenerationSourceContext.HomeworkText ||
                    input.sourceContext is RubricGenerationSourceContext.HomeworkDocument ||
                    input.examType == ExamType.HOMEWORK
                val isReadinessRubric = input.examType == ExamType.READINESS
                val isMultipleChoiceRubric = input.examType == ExamType.MULTIPLE_CHOICE
                val teacherRubricRules = """
                    BAYKUŞNOT ÖĞRETMEN RUBRİĞİ KURALLARI:
                    - Önce sorunun gerçekten ölçtüğü bilgi/beceri türünü belirle; rubriğe soruda istenmeyen ek beklenti ekleme.
                    - questionText içinde ortak paragraf/şiir/metin/tablo/görsel bağlamı varsa bunu sorunun ayrılmaz parçası kabul et.
                    - Kriterleri gözlenebilir ve mümkün olduğunca atomik anlam/işlem parçalarına böl. Kriter maxPoints toplamı kilitli soru puanına TAM eşit olsun.
                    - expectedAnswer yalnız tek bir ezber cümle olmasın: tam doğru cevabın özünü ve kabul edilebilir anlamca eşdeğer ifadeleri kısa biçimde tanımlasın.
                    - partialCreditGuidance, hangi anlam/işlem parçası varsa ne ölçüde kısmi puan verileceğini somutlaştırmalı; keyfî puan aralığı üretme.
                    - Açık uçlu, başlık önerme, tahmin veya kişisel görüş sorularında örnek cevapları tek doğruya dönüştürme. Sorunun görevini karşılayan makul alternatifleri kabul edecek ölçüt yaz.
                    - Yazım/noktalama/dil bilgisi doğrudan sorunun ölçtüğü beceriyse buna açık kriter ayır. Değilse sırf yazım hatası için bağımsız puan kriteri oluşturma.
                    - Yazım bozukluğu içeriğin anlamını gerçekten değiştiriyorsa bu durum içerik ölçütünün kanıt kalitesini etkileyebilir; aynı hatayı ayrıca ikinci kez cezalandıracak kriter yazma.
                    - commonMistakes alanı öğretmenin değerlendirmesine yardım eden tipik içerik yanılgılarını anlatsın; öğrenciyi etiketleyen dil kullanma.
                    - Rubrik öğretmen tarafından incelenip kilitlendikten sonra bütün öğrenciler aynı ölçütlerle puanlanacaktır; bu nedenle ölçütler tutarlı ve öğrenci kimliğinden bağımsız olsun.
                """.trimIndent()

                val instructionText = when {
                    isHomeworkRubric -> "Aşağıdaki ödev görevi için 100 puanlık öğretmen değerlendirme çerçevesi oluştur. Görev tanımına ve görünür beklenen çıktıya odaklan; kaynakta olmayan gereklilik uydurma.$sourceContextRule\n\n$teacherRubricRules"
                    isReadinessRubric -> "Aşağıdaki hazırbulunuşluk soruları için TANILAYICI rubrik oluştur. Yalnız konu/ünite öncesi mevcut ön koşul bilgi ve beceri kanıtını ölç; ileri kazanım ekleme.$sourceContextRule\n\n$teacherRubricRules"
                    isMultipleChoiceRubric -> "Aşağıdaki çoktan seçmeli test soruları için yalnız cevap anahtarı temelli kayıt oluştur. Her soru için tek kriter, doğru seçenek tam puan, yanlış/boş 0 puan; kısmi puan ve yazım ölçütü yok.$sourceContextRule"
                    else -> "Aşağıdaki sınav soruları için öğretmen onayına sunulacak ayrıntılı puanlama rubriği oluştur. Soruları, puanları ve sıraları değiştirme.$sourceContextRule\n\n$teacherRubricRules"
                }

                val sourceItems = buildRubricSourceInputItems(
                    apiKey = apiKey,
                    sourceContext = input.sourceContext
                )

                val inputItems = buildJsonArray {
                    sourceItems.forEach { add(it) }
                    add(buildJsonObject {
                        put("type", "text")
                        put("text", taskInputObj.toString())
                    })
                    add(buildJsonObject {
                        put("type", "text")
                        put("text", instructionText)
                    })
                }

                val criterionProperties = buildJsonObject {
                    put("questionOrderIndex", buildJsonObject { put("type", "integer") })
                    put("questionNumberSnapshot", buildJsonObject { put("type", "string") })
                    put("criterionOrderIndex", buildJsonObject { put("type", "integer") })
                    put("title", buildJsonObject { put("type", "string") })
                    put("description", buildJsonObject { put("type", "string") })
                    put("maxPoints", buildJsonObject { put("type", "integer") })
                    put("expectedAnswer", buildJsonObject { put("type", "string") })
                    put("partialCreditGuidance", buildJsonObject { put("type", "string") })
                    put("commonMistakes", buildJsonObject { put("type", "string") })
                }

                val criterionItemSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", criterionProperties)
                    put("required", buildJsonArray {
                        add("questionOrderIndex")
                        add("questionNumberSnapshot")
                        add("criterionOrderIndex")
                        add("title")
                        add("description")
                        add("maxPoints")
                        add("expectedAnswer")
                        add("partialCreditGuidance")
                        add("commonMistakes")
                    })
                    put("additionalProperties", false)
                }

                val criteriaArraySchema = buildJsonObject {
                    put("type", "array")
                    put("items", criterionItemSchema)
                }

                val topSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", buildJsonObject {
                        put("criteria", criteriaArraySchema)
                    })
                    put("required", buildJsonArray { add("criteria") })
                    put("additionalProperties", false)
                }

                val responseFormat = buildJsonObject {
                    put("type", "text")
                    put("mime_type", "application/json")
                    put("schema", topSchema)
                }

                val requestBodyJson = buildJsonObject {
                    put("model", requestedAuthoringModel)
                    put("store", false)
                    put("system_instruction", when {
                        isHomeworkRubric -> "Ödev görev/maddeleri için öğretmen onaylı değerlendirme rubriği oluştur. Görevleri ve kilitli puanları değiştirme. Unlocking ve persistence işlemleri sonraya bırakılacaktır."
                        isReadinessRubric -> "Hazırbulunuşluk soruları için tanılayıcı, öğretmen onayına sunulacak puanlama rubriği oluştur. Yalnız soruda gözlenebilen mevcut ön koşul bilgi/beceri kanıtını ölç; ileri kazanım ekleme, soruları ve kilitli puanları değiştirme."
                        else -> "Sınav soruları için öğretmen onaylı değerlendirme rubriği oluştur. Soruları mutasyona uğratma. Unlocking ve persistence işlemleri sonraya bırakılacaktır."
                    })
                    put("input", inputItems)
                    put("response_format", responseFormat)
                    put("generation_config", buildJsonObject {
                        put("thinking_level", "high")
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = requestBodyJson.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url(baseUrl)
                    .addHeader("x-goog-api-key", apiKey)
                    .post(body)
                    .build()

                val response = okHttpClient.executeCancellable(request)

                response.use { resp ->
                    if (!resp.isSuccessful) {
                        return@useApiKey when (resp.code) {
                            401, 403 -> ExamRubricGenerationResult.Unauthorized
                            429 -> ExamRubricGenerationResult.RateLimited
                            503 -> ExamRubricGenerationResult.ServiceUnavailable
                            else -> ExamRubricGenerationResult.UnexpectedFailure
                        }
                    }

                    val responseBodyString = resp.body?.string() ?: ""
                    val jsonResponse = try {
                        jsonParser.parseToJsonElement(responseBodyString).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }
                    input.examDraftId?.let { draftId -> runCatching {
                        aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_GENERATE", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(jsonResponse))
                    } }

                    val extractedText = extractModelOutputText(jsonResponse)
                        ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse

                    val structuredJson = try {
                        jsonParser.parseToJsonElement(extractedText).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val criteriaArray = structuredJson["criteria"]?.jsonArray
                        ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse

                    if (criteriaArray.isEmpty()) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val criteriaList = mutableListOf<GeneratedExamRubricCriterion>()
                    for (item in criteriaArray) {
                        val itemObj = try {
                            item.jsonObject
                        } catch (e: Exception) {
                            return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        }

                        val qOrderIndex = itemObj["questionOrderIndex"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val qNumSnap = itemObj["questionNumberSnapshot"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val cOrderIndex = itemObj["criterionOrderIndex"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val title = itemObj["title"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val desc = itemObj["description"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val maxPoints = itemObj["maxPoints"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val expectedAnswer = itemObj["expectedAnswer"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val partialCredit = itemObj["partialCreditGuidance"]?.jsonPrimitive?.content ?: ""
                        val commonMistakes = itemObj["commonMistakes"]?.jsonPrimitive?.content ?: ""

                        criteriaList.add(
                            GeneratedExamRubricCriterion(
                                questionOrderIndex = qOrderIndex,
                                questionNumberSnapshot = qNumSnap,
                                criterionOrderIndex = cOrderIndex,
                                title = title,
                                description = desc,
                                maxPoints = maxPoints,
                                expectedAnswer = expectedAnswer,
                                partialCreditGuidance = partialCredit,
                                commonMistakes = commonMistakes
                            )
                        )
                    }

                    if (criteriaList.isEmpty()) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val auditedCriteria = auditGeneratedRubric(
                        apiKey = apiKey,
                        examDraftId = input.examDraftId,
                        requestedAuthoringModel = requestedAuthoringModel,
                        profileSnapshot = profileSnapshot,
                        canonicalTaskJson = taskInputObj.toString(),
                        sourceItems = sourceItems,
                        generated = criteriaList
                    )
                    ExamRubricGenerationResult.Generated(auditedCriteria ?: criteriaList)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiHttpException) {
            when (e.statusCode) {
                401, 403 -> ExamRubricGenerationResult.Unauthorized
                429 -> ExamRubricGenerationResult.RateLimited
                503 -> ExamRubricGenerationResult.ServiceUnavailable
                else -> ExamRubricGenerationResult.UnexpectedFailure
            }
        } catch (e: IOException) {
            ExamRubricGenerationResult.NetworkFailure
        } catch (e: Exception) {
            ExamRubricGenerationResult.UnexpectedFailure
        }

        return result ?: ExamRubricGenerationResult.MissingApiKey
    }

    override suspend fun generateWithSource(
        input: ExamRubricGenerationInput,
        evaluationSourceType: String,
        originalTeacherAnswerKey: String?,
        originalTeacherRubric: String?,
        isAsIs: Boolean
    ): ExamRubricGenerationResult {
        if (input.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
            return ExamRubricGenerationResult.InvalidInput
        }
        if (input.questions.isEmpty()) {
            return ExamRubricGenerationResult.InvalidInput
        }
        for (q in input.questions) {
            if (q.questionText.isBlank() || q.points <= 0 || q.questionNumber.isBlank()) {
                return ExamRubricGenerationResult.InvalidInput
            }
        }

        val result = try {
            apiKeyStore.useApiKey { apiKey ->
                if (apiKey.isBlank()) {
                    return@useApiKey ExamRubricGenerationResult.MissingApiKey
                }
                val profileSnapshot = GeminiModelRegistry.currentProfile()
                val requestedAuthoringModel = profileSnapshot.authoringModel
                GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

                val questionsArray = buildJsonArray {
                    for (q in input.questions) {
                        add(buildJsonObject {
                            put("questionOrderIndex", q.questionOrderIndex)
                            put("questionNumber", q.questionNumber)
                            put("questionText", q.questionText)
                            put("points", q.points)
                        })
                    }
                }

                val taskInputObj = buildJsonObject {
                    put("questions", questionsArray)
                    put("deductWritingPunctuationPoints", input.deductWritingPunctuationPoints)
                }

                val isHomeworkRubric = input.sourceContext is RubricGenerationSourceContext.HomeworkText ||
                    input.sourceContext is RubricGenerationSourceContext.HomeworkDocument ||
                    input.examType == ExamType.HOMEWORK
                val isReadinessRubric = input.examType == ExamType.READINESS
                val isMultipleChoiceRubric = input.examType == ExamType.MULTIPLE_CHOICE
                val instructionText = buildString {
                    append(when {
                        isHomeworkRubric -> "Aşağıdaki ödev görev/maddeleri için öğretmen tarafından sağlanan kaynakları kullanarak puanlama rubriği oluştur.\n"
                        isReadinessRubric -> "Aşağıdaki hazırbulunuşluk soruları için öğretmen tarafından sağlanan kaynakları kullanarak tanılayıcı puanlama rubriği oluştur. Öğretmenin kaynağına sadık kal; soruda ölçülmeyen ileri kazanım veya yeni beklenti ekleme.\n"
                        isMultipleChoiceRubric -> "Aşağıdaki çoktan seçmeli test soruları için kilitlenecek cevap anahtarını ve puanlama kaydını oluştur. Her soruda doğru seçenek tek otorite olmalıdır.\n"
                        else -> "Aşağıdaki sınav soruları için öğretmen tarafından sağlanan kaynakları kullanarak puanlama rubriği oluştur.\n"
                    })
                    if (evaluationSourceType == "AI_GENERATED_RUBRIC") {
                        when (input.sourceContext) {
                            is RubricGenerationSourceContext.ListeningText,
                            is RubricGenerationSourceContext.ListeningAudio ->
                                append("Bu bir Dinleme Sınavıdır. İstekte ayrıca verilen DİNLEME KAYNAĞINI soruların bağlamını ve doğru cevaplarını doğrulamak için kullan; kaynakta olmayan bilgi uydurma.\n")
                            is RubricGenerationSourceContext.HomeworkText,
                            is RubricGenerationSourceContext.HomeworkDocument ->
                                append("Bu bir Ödev Kontrolüdür. İstekte ayrıca verilen ÖDEV KAYNAĞINI görevlerin beklenen çıktısını, kapsamını ve varsa öğretmenin değerlendirme ölçütlerini doğrulamak için kullan; kaynakta olmayan görev, cevap veya ölçüt uydurma.\n")
                            null -> Unit
                        }
                    }
                    append("Öğretmen Değerlendirme Kaynağı Türü: ")
                    when (evaluationSourceType) {
                        "TEACHER_ANSWER_KEY" -> {
                            append(if (isHomeworkRubric) "Öğretmenin Beklenen Yanıt/Çıktı Anahtarı. Öğretmenin verdiği anahtarı her bir canonical görev/madde ile eşleştir.\n" else "Öğretmenin Cevap Anahtarı. Öğretmenin verdiği cevap anahtarını her bir canonical soru ile eşleştir.\n")
                            if (!originalTeacherAnswerKey.isNullOrBlank()) {
                                append("Öğretmen Cevap Anahtarı İçeriği:\n\"\"\"\n")
                                append(originalTeacherAnswerKey)
                                append("\n\"\"\"\n")
                            }
                        }
                        "TEACHER_RUBRIC" -> {
                            append(if (isHomeworkRubric) "Öğretmenin Kendi Rubriği. Öğretmenin girdiği rubrik kriterlerini her bir canonical görev/maddeye uygun şekilde dağıt ve eşleştir.\n" else "Öğretmenin Kendi Rubriği. Öğretmenin kendi girdiği rubrik kriterlerini her bir canonical soruya uygun şekilde dağıt ve eşleştir.\n")
                            if (!originalTeacherRubric.isNullOrBlank()) {
                                append("Öğretmen Rubrik İçeriği:\n\"\"\"\n")
                                append(originalTeacherRubric)
                                append("\n\"\"\"\n")
                            }
                        }
                        "TEACHER_ANSWER_KEY_AND_RUBRIC" -> {
                            append(if (isHomeworkRubric) "Öğretmenin Beklenen Yanıt/Çıktı Anahtarı ve Rubriği. Her ikisini analiz ederek canonical görev/maddelerle eşleştir.\n" else "Öğretmenin Cevap Anahtarı ve Rubriği. Hem cevap anahtarını hem de rubriği analiz ederek canonical sorularla eşleştir.\n")
                            if (!originalTeacherAnswerKey.isNullOrBlank()) {
                                append("Öğretmen Cevap Anahtarı İçeriği:\n\"\"\"\n")
                                append(originalTeacherAnswerKey)
                                append("\n\"\"\"\n")
                            }
                            if (!originalTeacherRubric.isNullOrBlank()) {
                                append("Öğretmen Rubrik İçeriği:\n\"\"\"\n")
                                append(originalTeacherRubric)
                                append("\n\"\"\"\n")
                            }
                        }
                        else -> {
                            append("Yapay Zeka Ayrıntılı Rubrik Hazırlasın.\n")
                        }
                    }

                    append("\nYazım ve Noktalama: BaykuşNot Öğretmen Modu. ")
                    if (isMultipleChoiceRubric) {
                        append("Çoktan seçmeli testte uygulanmaz.\n")
                    } else {
                        append("Yalnız soru/öğretmen kaynağı doğrudan yazım, noktalama, dil bilgisi veya anlatım becerisini ölçüyorsa açık puan kriteri oluştur. Diğer içerik sorularında yazım hatasını otomatik puan cezasına dönüştürme; aynı hatayı iki kez cezalandırma.\n")
                    }

                    append("\nİşleme Modu (Olduğu Gibi vs Detaylandır): ")
                    if (isAsIs) {
                        append(if (isHomeworkRubric) "Olduğu Gibi Kullan (As-Is). Verilen girdiyi yalnızca oku, alanlara ayır (parser gibi). Detaylandırma veya ek ölçüt yazma. Sadece girdideki başlık, açıklama ve puanları her görev/maddenin canonical puanına sadık kalarak ayır. Her maddenin kriterlerinin maxPoints toplamı o maddenin puanına kesinlikle eşit olmalıdır.\n" else "Olduğu Gibi Kullan (As-Is). Verilen girdiyi yalnızca oku, alanlara ayır (parser gibi). Detaylandırma veya ek ölçüt yazma. Sadece girdideki başlık, açıklama ve puanları her bir sorunun canonical puanına sadık kalarak ayır. Her sorunun kriterlerinin maxPoints toplamı o sorunun puanına kesinlikle eşit olmalıdır.\n")
                    } else {
                        append(if (isHomeworkRubric) "Detaylandır (Elaborated). Öğretmenin girdilerini temel alarak, her görev/maddenin tam puanına sadık kalacak şekilde gerekirse ölçütü daha detaylı kriterlere veya alt puan kırılımlarına böl.\n" else "Detaylandır (Elaborated). Öğretmenin girdilerini temel alarak, her sorunun tam puanına sadık kalacak şekilde, gerekirse ölçütü daha detaylı kriterlere veya alt puan kırılımlarına böl.\n")
                    }

                    if (isReadinessRubric) {
                        append("\nHazırbulunuşluğa Özgü Kurallar:\n")
                        append("- Rubrik, konu/ünite öncesi mevcut ön koşul bilgi ve beceriyi ayırt edecek gözlenebilir kanıtlara odaklansın.\n")
                        append("- Öğrenciyi kalıcı başarı düzeyiyle etiketleyen kriter yazma; yalnız bu sorudaki performansı ölç.\n")
                        append("- Kısmi puan rehberi, hangi temel bilgi/beceri parçasının mevcut olduğunu açıkça ayırt etsin.\n")
                        append("- Öğretim sonrası öğrenilmiş olması beklenen ileri bilgi veya soruda istenmeyen ek açıklamayı tam puan koşulu yapma.\n")
                    }

                    if (isMultipleChoiceRubric) {
                        append("\nTest Sınavına Özgü Kurallar:\n")
                        append("- Her soru için TAM OLARAK 1 kriter oluştur.\n")
                        append("- criterion title alanını 'Doğru Seçenek' olarak kullan.\n")
                        append("- expectedAnswer alanına yalnız doğru seçenek harfini (A/B/C/D/E vb.) yaz. Öğretmen cevap anahtarı verdiyse onu mutlak otorite kabul et.\n")
                        append("- maxPoints doğrudan sorunun kilitli puanı olsun; kısmi puan üretme.\n")
                        append("- partialCreditGuidance alanına 'Kısmi puan yoktur; doğru seçenek tam puan, yanlış veya boş cevap 0 puandır.' yaz.\n")
                        append("- commonMistakes alanına cevap anahtarında olmayan yeni doğru seçenek veya alternatif cevap ekleme.\n")
                        append("- Yazım/noktalama ölçütü ekleme; test seçeneğinin doğruluğu dışında puanlama ölçütü oluşturma.\n")
                    }

                    append("\nÖğretmen Gibi Rubrik Kuralları:\n")
                    append("- Sorunun ölçtüğü bilgi/beceriyi esas al; soruda istenmeyen ek koşul uydurma.\n")
                    append("- Tam doğru cevabın özünü ve anlamca eşdeğer kabul edilebilir cevapları expectedAnswer alanında açıkla; kelime kelime eşleşme zorunluluğu yaratma.\n")
                    append("- Kısmi puanı, öğrencinin gösterdiği somut anlam/işlem parçalarına bağla.\n")
                    append("- Açık uçlu/kişisel görüş sorularında öğretmen örneğini tek doğruya dönüştürme.\n")
                    append("- Yazım/noktalama yalnız sorunun ölçtüğü beceri veya öğretmenin açık kriteriyse puana dahil olsun; aynı hatayı iki kez cezalandırma.\n")
                    append("- Ortak metin/görsel/tablo bağlamını sorunun ayrılmaz parçası kabul et.\n")
                    append("- Rubrik kilitlendikten sonra bütün öğrenciler aynı ölçütlerle değerlendirileceği için kriterleri öğrenci kimliğinden bağımsız ve tutarlı yaz.\n")

                    append("\nÖnemli Kurallar:\n")
                    append(if (isHomeworkRubric) "1. Canonical görev/maddeleri ve puanlarını değiştirme, madde sırasını koru.\n" else "1. Canonical soruları ve puanlarını değiştirme, soru sırasını koru.\n")
                    append(when {
                        isHomeworkRubric -> "2. Her görev/madde için en az 1 kriter oluştur ve o maddeye ait kriterlerin maxPoints toplamı madde puanına (points) TAM OLARAK eşit olmalıdır.\n"
                        isMultipleChoiceRubric -> "2. Her test sorusu için tam olarak 1 kriter oluştur; kriter maxPoints değeri soru puanına TAM OLARAK eşit olmalıdır.\n"
                        else -> "2. Her soru için en az 1 kriter oluştur ve o soruya ait kriterlerin maxPoints toplamı soru puanına (points) TAM OLARAK eşit olmalıdır.\n"
                    })
                    append("3. Her kriter için title, description, maxPoints, expectedAnswer, partialCreditGuidance ve commonMistakes alanlarını doldur.\n")
                }

                // Cost guard: teacher-provided answer keys/rubrics are already authoritative.
                // Exam-specific source media is sent only when AI itself is the rubric source.
                val sourceItems = buildRubricSourceInputItems(
                    apiKey = apiKey,
                    sourceContext = input.sourceContext.takeIf { evaluationSourceType == "AI_GENERATED_RUBRIC" }
                )

                val inputItems = buildJsonArray {
                    sourceItems.forEach { add(it) }
                    add(buildJsonObject {
                        put("type", "text")
                        put("text", taskInputObj.toString())
                    })
                    add(buildJsonObject {
                        put("type", "text")
                        put("text", instructionText)
                    })
                }

                val criterionProperties = buildJsonObject {
                    put("questionOrderIndex", buildJsonObject { put("type", "integer") })
                    put("questionNumberSnapshot", buildJsonObject { put("type", "string") })
                    put("criterionOrderIndex", buildJsonObject { put("type", "integer") })
                    put("title", buildJsonObject { put("type", "string") })
                    put("description", buildJsonObject { put("type", "string") })
                    put("maxPoints", buildJsonObject { put("type", "integer") })
                    put("expectedAnswer", buildJsonObject { put("type", "string") })
                    put("partialCreditGuidance", buildJsonObject { put("type", "string") })
                    put("commonMistakes", buildJsonObject { put("type", "string") })
                }

                val criterionItemSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", criterionProperties)
                    put("required", buildJsonArray {
                        add("questionOrderIndex")
                        add("questionNumberSnapshot")
                        add("criterionOrderIndex")
                        add("title")
                        add("description")
                        add("maxPoints")
                        add("expectedAnswer")
                        add("partialCreditGuidance")
                        add("commonMistakes")
                    })
                    put("additionalProperties", false)
                }

                val criteriaArraySchema = buildJsonObject {
                    put("type", "array")
                    put("items", criterionItemSchema)
                }

                val topSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", buildJsonObject {
                        put("criteria", criteriaArraySchema)
                    })
                    put("required", buildJsonArray { add("criteria") })
                    put("additionalProperties", false)
                }

                val responseFormat = buildJsonObject {
                    put("type", "text")
                    put("mime_type", "application/json")
                    put("schema", topSchema)
                }

                val requestBodyJson = buildJsonObject {
                    put("model", requestedAuthoringModel)
                    put("store", false)
                    put("system_instruction", when {
                        isHomeworkRubric -> "Ödev görev/maddeleri için öğretmen onaylı değerlendirme rubriği oluştur. Görevleri ve kilitli puanları değiştirme. Unlocking ve persistence işlemleri sonraya bırakılacaktır."
                        isReadinessRubric -> "Hazırbulunuşluk soruları için tanılayıcı, öğretmen onayına sunulacak puanlama rubriği oluştur. Öğretmen kaynağına ve kilitli puanlara sadık kal; yalnız mevcut ön koşul bilgi/beceri kanıtını ölç ve ileri kazanım ekleme."
                        else -> "Sınav soruları için öğretmen onaylı değerlendirme rubriği oluştur. Soruları mutasyona uğratma. Unlocking ve persistence işlemleri sonraya bırakılacaktır."
                    })
                    put("input", inputItems)
                    put("response_format", responseFormat)
                    put("generation_config", buildJsonObject {
                        put("thinking_level", "high")
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = requestBodyJson.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url(baseUrl)
                    .addHeader("x-goog-api-key", apiKey)
                    .post(body)
                    .build()

                val response = okHttpClient.executeCancellable(request)

                response.use { resp ->
                    if (!resp.isSuccessful) {
                        return@useApiKey when (resp.code) {
                            401, 403 -> ExamRubricGenerationResult.Unauthorized
                            429 -> ExamRubricGenerationResult.RateLimited
                            503 -> ExamRubricGenerationResult.ServiceUnavailable
                            else -> ExamRubricGenerationResult.UnexpectedFailure
                        }
                    }

                    val responseBodyString = resp.body?.string() ?: ""
                    val jsonResponse = try {
                        jsonParser.parseToJsonElement(responseBodyString).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }
                    input.examDraftId?.let { draftId -> runCatching {
                        aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_FROM_TEACHER_SOURCE", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(jsonResponse))
                    } }

                    val extractedText = extractModelOutputText(jsonResponse)
                        ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse

                    val structuredJson = try {
                        jsonParser.parseToJsonElement(extractedText).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val criteriaArray = structuredJson["criteria"]?.jsonArray
                        ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse

                    if (criteriaArray.isEmpty()) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val criteriaList = mutableListOf<GeneratedExamRubricCriterion>()
                    for (item in criteriaArray) {
                        val itemObj = try {
                            item.jsonObject
                        } catch (e: Exception) {
                            return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        }

                        val qOrderIndex = itemObj["questionOrderIndex"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val qNumSnap = itemObj["questionNumberSnapshot"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val cOrderIndex = itemObj["criterionOrderIndex"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val title = itemObj["title"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val desc = itemObj["description"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val maxPoints = itemObj["maxPoints"]?.jsonPrimitive?.intOrNull
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val expectedAnswer = itemObj["expectedAnswer"]?.jsonPrimitive?.content
                            ?: return@useApiKey ExamRubricGenerationResult.MalformedResponse
                        val partialCredit = itemObj["partialCreditGuidance"]?.jsonPrimitive?.content ?: ""
                        val commonMistakes = itemObj["commonMistakes"]?.jsonPrimitive?.content ?: ""

                        criteriaList.add(
                            GeneratedExamRubricCriterion(
                                questionOrderIndex = qOrderIndex,
                                questionNumberSnapshot = qNumSnap,
                                criterionOrderIndex = cOrderIndex,
                                title = title,
                                description = desc,
                                maxPoints = maxPoints,
                                expectedAnswer = expectedAnswer,
                                partialCreditGuidance = partialCredit,
                                commonMistakes = commonMistakes
                            )
                        )
                    }

                    if (criteriaList.isEmpty()) {
                        return@useApiKey ExamRubricGenerationResult.MalformedResponse
                    }

                    val finalCriteria = if (evaluationSourceType == "AI_GENERATED_RUBRIC") {
                        auditGeneratedRubric(
                            apiKey = apiKey,
                            examDraftId = input.examDraftId,
                            requestedAuthoringModel = requestedAuthoringModel,
                            profileSnapshot = profileSnapshot,
                            canonicalTaskJson = taskInputObj.toString(),
                            sourceItems = sourceItems,
                            generated = criteriaList
                        ) ?: criteriaList
                    } else {
                        // Teacher-provided answer keys/rubrics remain authoritative.
                        criteriaList
                    }
                    ExamRubricGenerationResult.Generated(finalCriteria)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiHttpException) {
            when (e.statusCode) {
                401, 403 -> ExamRubricGenerationResult.Unauthorized
                429 -> ExamRubricGenerationResult.RateLimited
                503 -> ExamRubricGenerationResult.ServiceUnavailable
                else -> ExamRubricGenerationResult.UnexpectedFailure
            }
        } catch (e: IOException) {
            ExamRubricGenerationResult.NetworkFailure
        } catch (e: Exception) {
            ExamRubricGenerationResult.UnexpectedFailure
        }

        return result ?: ExamRubricGenerationResult.MissingApiKey
    }

    override suspend fun extractDocumentText(
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String> = extractDocumentTextInternal(null, fileName, mimeType, bytes)

    override suspend fun extractDocumentTextForExam(
        examDraftId: Long,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String> = extractDocumentTextInternal(examDraftId, fileName, mimeType, bytes)

    private suspend fun extractDocumentTextInternal(
        examDraftId: Long?,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String> = withContext(Dispatchers.IO) {
        val profileSnapshot = GeminiModelRegistry.currentProfile()
        val requestedAuthoringModel = profileSnapshot.authoringModel
        val isPdf = mimeType.contains("pdf", ignoreCase = true) || fileName.endsWith(".pdf", ignoreCase = true)
        val isLegacyDoc = fileName.endsWith(".doc", ignoreCase = true) || mimeType.equals("application/msword", ignoreCase = true)
        if (isLegacyDoc) return@withContext Result.failure(IllegalArgumentException("Eski .doc biçimi desteklenmiyor. Dosyayı .docx veya PDF olarak kaydedip yeniden seçin."))
        val isDocx = mimeType.contains("officedocument", ignoreCase = true) || fileName.endsWith(".docx", ignoreCase = true)
        val isPng = mimeType.contains("png", ignoreCase = true) || fileName.endsWith(".png", ignoreCase = true)
        val isWebP = mimeType.contains("webp", ignoreCase = true) || fileName.endsWith(".webp", ignoreCase = true)
        val isJpeg = mimeType.contains("jpeg", ignoreCase = true) || mimeType.contains("jpg", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) || fileName.endsWith(".jpg", ignoreCase = true)

        if (!isPdf && !isDocx && !isPng && !isWebP && !isJpeg) {
            return@withContext Result.failure(IllegalArgumentException("Bu dosya türü desteklenmiyor. Yalnızca PDF, Word (DOCX), PNG, JPEG veya WebP yükleyebilirsiniz."))
        }

        // 1. DOCX Handling with strict embedded image processing
        if (isDocx) {
            return@withContext try {
                val parsed = com.example.core.data.DocxParser.parse(bytes)
                val docxText = parsed.parts
                    .filterIsInstance<com.example.core.network.ExamExtractionInput.WordPart.TextPart>()
                    .joinToString("\n") { it.text }
                    .trim()

                val imageParts = parsed.parts
                    .filterIsInstance<com.example.core.network.ExamExtractionInput.WordPart.ImagePart>()

                var imageTranscribedText = ""
                if (imageParts.isNotEmpty()) {
                    val res = apiKeyStore.useApiKey { apiKey ->
                        if (apiKey.isBlank()) {
                            return@useApiKey Result.failure<String>(Exception("Word belgesindeki gömülü görselleri işlemek için Gemini API anahtarı bulunamadı."))
                        }
                        GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

                        // Batch embedded images into chunks of max 8
                        val imageChunks = imageParts.chunked(8)
                        val chunkTranscripts = mutableListOf<String>()

                        for (chunk in imageChunks) {
                            val inputItems = buildJsonArray {
                                for (imgPart in chunk) {
                                    val base64Img = Base64.getEncoder().encodeToString(imgPart.image.bytes)
                                    add(buildJsonObject {
                                        put("type", "image")
                                        put("mime_type", imgPart.image.mimeType)
                                        put("data", base64Img)
                                    })
                                }
                                add(buildJsonObject {
                                    put("type", "text")
                                    put("text", "Word belgesindeki gömülü görsellerdeki tüm metin, tablo, puan ve öğretmen notlarını eksiksiz Türkçe metin olarak dök.")
                                })
                            }

                            val reqBody = buildJsonObject {
                                put("model", requestedAuthoringModel)
                                put("store", false)
                                put("input", inputItems)
                            }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

                            val req = Request.Builder().url(baseUrl).addHeader("x-goog-api-key", apiKey).post(reqBody).build()
                            val response = try {
                                okHttpClient.executeCancellable(req)
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                return@useApiKey Result.failure<String>(Exception("Word gömülü görselleri işlenirken ağ hatası: ${e.message}"))
                            }

                            response.use { resp ->
                                if (!resp.isSuccessful) {
                                    return@useApiKey Result.failure<String>(Exception("Word gömülü görselleri okunamadı (HTTP ${resp.code})."))
                                }
                                val bodyStr = resp.body?.string() ?: ""
                                val jsonObj = try {
                                    jsonParser.parseToJsonElement(bodyStr).jsonObject
                                } catch (e: Exception) {
                                    return@useApiKey Result.failure<String>(Exception("Word gömülü görsel yanıtı ayrıştırılamadı."))
                                }
                                examDraftId?.let { draftId -> runCatching {
                                    aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_DOCUMENT_EXTRACT", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(jsonObj))
                                } }
                                val text = extractModelOutputText(jsonObj)
                                if (text.isNullOrBlank()) {
                                    return@useApiKey Result.failure<String>(Exception("Word gömülü görsellerinden metin çıkarılamadı."))
                                }
                                chunkTranscripts.add(text)
                            }
                        }
                        Result.success(chunkTranscripts.joinToString("\n\n"))
                    } ?: Result.failure(Exception("Gemini API anahtarı bulunamadı."))

                    if (res.isFailure) {
                        return@withContext Result.failure(res.exceptionOrNull() ?: Exception("Gömülü görsel okuma hatası."))
                    }
                    imageTranscribedText = res.getOrDefault("")
                }

                val fullDocxText = buildString {
                    if (docxText.isNotBlank()) append(docxText)
                    if (imageTranscribedText.isNotBlank()) {
                        if (isNotEmpty()) append("\n\n-- Gömülü Görsel İçeriği --\n")
                        append(imageTranscribedText)
                    }
                }.trim()

                if (fullDocxText.isNotBlank()) {
                    Result.success(fullDocxText)
                } else {
                    Result.failure(Exception("Word belgesi boş veya metin okunamadı."))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(Exception("Word belgesi okunamadı: ${e.message}"))
            }
        }

        // 2. PDF & Image Handling without silent page truncation
        if (isPdf) {
            val tempFile = File.createTempFile("pdf_render_", ".pdf")
            return@withContext try {
                tempFile.writeBytes(bytes)
                val pfd = android.os.ParcelFileDescriptor.open(tempFile, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
                val extractedChunkTexts = mutableListOf<String>()

                val res = apiKeyStore.useApiKey { apiKey ->
                    if (apiKey.isBlank()) {
                        return@useApiKey Result.failure<String>(Exception("Gemini API anahtarı bulunamadı. Lütfen API anahtarınızı ayarlayın."))
                    }
                    GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

                    android.graphics.pdf.PdfRenderer(pfd).use { renderer ->
                        val totalPages = renderer.pageCount
                        if (totalPages == 0) {
                            return@useApiKey Result.failure<String>(Exception("PDF belgesi sayfa içermiyor."))
                        }

                        val chunkSize = 5
                        val pageIndices = (0 until totalPages).chunked(chunkSize)

                        for (chunkPages in pageIndices) {
                            val chunkImages = mutableListOf<Pair<ByteArray, String>>()
                            for (pageIdx in chunkPages) {
                                renderer.openPage(pageIdx).use { page ->
                                    val width = (page.width * 1.5).toInt()
                                    val height = (page.height * 1.5).toInt()
                                    val bitmap = android.graphics.Bitmap.createBitmap(
                                        width, height, android.graphics.Bitmap.Config.ARGB_8888
                                    )
                                    page.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val stream = ByteArrayOutputStream()
                                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, stream)
                                    chunkImages.add(Pair(stream.toByteArray(), "image/jpeg"))
                                    bitmap.recycle()
                                }
                            }

                            val inputItems = buildJsonArray {
                                for ((imgBytes, mime) in chunkImages) {
                                    val base64Data = Base64.getEncoder().encodeToString(imgBytes)
                                    add(buildJsonObject {
                                        put("type", "image")
                                        put("mime_type", mime)
                                        put("data", base64Data)
                                    })
                                }
                                add(buildJsonObject {
                                    put("type", "text")
                                    put("text", "Aşağıdaki öğretmen cevap anahtarı / rubrik belgesinin tüm metin içeriğini, soru numaralarını, beklenen yanıtlarını, puanlarını, puan kırılımlarını, tabloları ve öğretmen notlarını eksiksiz Türkçe metin olarak dök. Başka açıklama ekleme, doğrudan belgedeki gerçek içeriği dök.")
                                })
                            }
                            chunkImages.clear()

                            val requestBodyJson = buildJsonObject {
                                put("model", requestedAuthoringModel)
                                put("store", false)
                                put("input", inputItems)
                            }

                            val mediaType = "application/json; charset=utf-8".toMediaType()
                            val body = requestBodyJson.toString().toRequestBody(mediaType)

                            val request = Request.Builder()
                                .url(baseUrl)
                                .addHeader("x-goog-api-key", apiKey)
                                .post(body)
                                .build()

                            val response = try {
                                okHttpClient.executeCancellable(request)
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                return@useApiKey Result.failure<String>(Exception("PDF işlenirken ağ hatası oluştu: ${e.message}"))
                            }

                            response.use { resp ->
                                if (!resp.isSuccessful) {
                                    val msg = when (resp.code) {
                                        401, 403 -> "Gemini API anahtarı geçersiz veya yetkisiz."
                                        429 -> "Gemini kullanım sınırına ulaşıldı."
                                        else -> "Gemini API hatası (${resp.code})."
                                    }
                                    return@useApiKey Result.failure<String>(Exception(msg))
                                }

                                val responseBodyString = resp.body?.string() ?: ""
                                val jsonResponse = try {
                                    jsonParser.parseToJsonElement(responseBodyString).jsonObject
                                } catch (e: Exception) {
                                    return@useApiKey Result.failure<String>(Exception("Gemini yanıtı ayrıştırılamadı."))
                                }
                                examDraftId?.let { draftId -> runCatching {
                                    aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_DOCUMENT_EXTRACT", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(jsonResponse))
                                } }

                                val extractedText = extractModelOutputText(jsonResponse)
                                if (extractedText.isNullOrBlank()) {
                                    return@useApiKey Result.failure<String>(Exception("PDF Sayfa ${chunkPages.first() + 1}-${chunkPages.last() + 1} metin okunamadı."))
                                }
                                extractedChunkTexts.add(extractedText.trim())
                            }
                        }

                        val finalExtractedText = extractedChunkTexts.joinToString("\n\n").trim()
                        if (finalExtractedText.isNotBlank()) {
                            Result.success(finalExtractedText)
                        } else {
                            Result.failure(Exception("PDF belgesinden metin okunamadı."))
                        }
                    }
                } ?: Result.failure(Exception("Gemini API anahtarı bulunamadı."))
                res
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(Exception("PDF belgesi okunamadı: ${e.message}"))
            } finally {
                tempFile.delete()
            }
        }

        // Single Image handling (PNG, JPEG, WebP)
        val normMime = when {
            isPng -> "image/png"
            isWebP -> "image/webp"
            else -> "image/jpeg"
        }

        apiKeyStore.useApiKey { apiKey ->
            if (apiKey.isBlank()) {
                return@useApiKey Result.failure(Exception("Gemini API anahtarı bulunamadı. Lütfen API anahtarınızı ayarlayın."))
            }
            GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

            val base64Data = Base64.getEncoder().encodeToString(bytes)
            val inputItems = buildJsonArray {
                add(buildJsonObject {
                    put("type", "image")
                    put("mime_type", normMime)
                    put("data", base64Data)
                })
                add(buildJsonObject {
                    put("type", "text")
                    put("text", "Aşağıdaki öğretmen cevap anahtarı / rubrik belgesinin tüm metin içeriğini, soru numaralarını, beklenen yanıtlarını, puanlarını, puan kırılımlarını, tabloları ve öğretmen notlarını eksiksiz Türkçe metin olarak dök. Başka açıklama ekleme, doğrudan belgedeki gerçek içeriği dök.")
                })
            }

            val requestBodyJson = buildJsonObject {
                put("model", requestedAuthoringModel)
                put("store", false)
                put("input", inputItems)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(baseUrl)
                .addHeader("x-goog-api-key", apiKey)
                .post(body)
                .build()

            val response = try {
                okHttpClient.executeCancellable(request)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return@useApiKey Result.failure(Exception("Görsel işlenirken ağ hatası oluştu: ${e.message}"))
            }

            response.use { resp ->
                if (!resp.isSuccessful) {
                    val msg = when (resp.code) {
                        401, 403 -> "Gemini API anahtarı geçersiz veya yetkisiz."
                        429 -> "Gemini kullanım sınırına ulaşıldı."
                        else -> "Gemini API hatası (${resp.code})."
                    }
                    return@useApiKey Result.failure(Exception(msg))
                }

                val responseBodyString = resp.body?.string() ?: ""
                val jsonResponse = try {
                    jsonParser.parseToJsonElement(responseBodyString).jsonObject
                } catch (e: Exception) {
                    return@useApiKey Result.failure(Exception("Gemini yanıtı ayrıştırılamadı."))
                }
                examDraftId?.let { draftId -> runCatching {
                    aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_DOCUMENT_EXTRACT", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(jsonResponse))
                } }

                val extractedText = extractModelOutputText(jsonResponse)
                if (!extractedText.isNullOrBlank()) {
                    Result.success(extractedText.trim())
                } else {
                    Result.failure(Exception("Görselden metin okunamadı."))
                }
            }
        } ?: Result.failure(Exception("Gemini API anahtarı bulunamadı."))
    }

    private suspend fun buildRubricSourceInputItems(
        apiKey: String,
        sourceContext: RubricGenerationSourceContext?
    ): List<JsonObject> {
        return when (sourceContext) {
            null -> emptyList()
            is RubricGenerationSourceContext.ListeningText -> listOf(
                buildJsonObject {
                    put("type", "text")
                    put(
                        "text",
                        "DİNLEME SINAVI KAYNAK METNİ (öğretmenin sağladığı metin):\n\"\"\"\n${sourceContext.text}\n\"\"\""
                    )
                }
            )
            is RubricGenerationSourceContext.ListeningAudio -> {
                val fileUri = uploadListeningAudio(apiKey, sourceContext)
                listOf(
                    buildJsonObject {
                        put("type", "text")
                        put(
                            "text",
                            "DİNLEME SINAVI KAYNAK SESİ: Aşağıdaki ses öğrencilerin dinlediği asıl sınav kaynağıdır. Soruların doğru/beklenen cevaplarını bu ses içeriğine göre belirle."
                        )
                    },
                    buildJsonObject {
                        put("type", "audio")
                        put("uri", fileUri)
                        put("mime_type", normalizeAudioMimeType(sourceContext.mimeType, sourceContext.displayName))
                    }
                )
            }
            is RubricGenerationSourceContext.HomeworkText -> listOf(
                buildJsonObject {
                    put("type", "text")
                    put(
                        "text",
                        "ÖDEV KAYNAĞI (öğretmenin sağladığı ödev metni / yönergesi):\n\"\"\"\n${sourceContext.text}\n\"\"\""
                    )
                }
            )
            is RubricGenerationSourceContext.HomeworkDocument ->
                buildHomeworkDocumentInputItems(sourceContext)
        }
    }

    private fun buildHomeworkDocumentInputItems(
        source: RubricGenerationSourceContext.HomeworkDocument
    ): List<JsonObject> {
        val file = source.file
        if (!file.exists() || !file.isFile || !file.canRead() || file.length() <= 0L) {
            throw IllegalArgumentException("Homework source is not readable.")
        }
        if (source.sizeBytes <= 0L || source.sizeBytes != file.length()) {
            throw IllegalArgumentException("Homework source size changed.")
        }

        val bytes = BoundedInputReader.readFile(file, BoundedInputReader.MAX_DOCUMENT_BYTES, "Ödev kaynağı")
        val normalizedMime = source.mimeType.lowercase()
        val intro = buildJsonObject {
            put("type", "text")
            put(
                "text",
                "ÖDEV KAYNAĞI: Aşağıdaki içerik öğretmenin verdiği asıl ödev yönergesi/görev kaynağıdır. Görevlerin beklenen çıktısını ve varsa değerlendirme ölçütlerini bu kaynağa göre belirle."
            )
        }

        return when {
            normalizedMime == "text/plain" -> {
                val text = bytes.toString(Charsets.UTF_8).trim()
                if (text.isBlank()) throw IllegalArgumentException("Homework text source is empty.")
                listOf(
                    intro,
                    buildJsonObject {
                        put("type", "text")
                        put("text", text)
                    }
                )
            }
            normalizedMime == "application/pdf" -> listOf(
                intro,
                buildJsonObject {
                    put("type", "document")
                    put("data", Base64.getEncoder().encodeToString(bytes))
                    put("mime_type", "application/pdf")
                    put("resolution", "medium")
                }
            )
            normalizedMime.startsWith("image/") -> listOf(
                intro,
                buildJsonObject {
                    put("type", "image")
                    put("data", Base64.getEncoder().encodeToString(bytes))
                    put("mime_type", normalizeImageMimeType(normalizedMime, source.displayName))
                    put("resolution", "high")
                }
            )
            normalizedMime == com.example.core.data.ExamSourceDocumentRepository.WORD_MIME_TYPE -> {
                val parsed = com.example.core.data.DocxParser.parse(bytes)
                val items = mutableListOf<JsonObject>()
                items += intro

                val text = parsed.parts
                    .filterIsInstance<ExamExtractionInput.WordPart.TextPart>()
                    .joinToString("\n") { it.text }
                    .trim()
                if (text.isNotBlank()) {
                    items += buildJsonObject {
                        put("type", "text")
                        put("text", "ÖDEV WORD BELGESİ METNİ:\n$text")
                    }
                }

                parsed.parts
                    .filterIsInstance<ExamExtractionInput.WordPart.ImagePart>()
                    .forEach { imagePart ->
                        items += buildJsonObject {
                            put("type", "image")
                            put("data", Base64.getEncoder().encodeToString(imagePart.image.bytes))
                            put("mime_type", normalizeImageMimeType(imagePart.image.mimeType, source.displayName))
                            put("resolution", "high")
                        }
                    }

                if (items.size == 1) {
                    throw IllegalArgumentException("Homework Word source has no readable content.")
                }
                items
            }
            else -> throw IllegalArgumentException("Unsupported homework rubric source type: ${source.mimeType}")
        }
    }

    /**
     * A rubric is generated once but affects the whole class. For AI-generated rubrics,
     * run one independent high-thinking audit. If the audit call fails or returns a
     * malformed response, keep the already generated rubric and let the deterministic
     * validator + teacher review remain the safety net.
     */
    private suspend fun auditGeneratedRubric(
        apiKey: String,
        examDraftId: Long?,
        requestedAuthoringModel: String,
        profileSnapshot: GeminiModelProfile,
        canonicalTaskJson: String,
        sourceItems: List<JsonObject>,
        generated: List<GeneratedExamRubricCriterion>
    ): List<GeneratedExamRubricCriterion>? {
        if (generated.isEmpty()) return null
        return try {
            val generatedArray = buildJsonArray {
                generated.sortedWith(compareBy<GeneratedExamRubricCriterion> { it.questionOrderIndex }.thenBy { it.criterionOrderIndex })
                    .forEach { r ->
                        add(buildJsonObject {
                            put("questionOrderIndex", r.questionOrderIndex)
                            put("questionNumberSnapshot", r.questionNumberSnapshot)
                            put("criterionOrderIndex", r.criterionOrderIndex)
                            put("title", r.title)
                            put("description", r.description)
                            put("maxPoints", r.maxPoints)
                            put("expectedAnswer", r.expectedAnswer)
                            put("partialCreditGuidance", r.partialCreditGuidance)
                            put("commonMistakes", r.commonMistakes)
                        })
                    }
            }

            val criterionProperties = buildJsonObject {
                put("questionOrderIndex", buildJsonObject { put("type", "integer") })
                put("questionNumberSnapshot", buildJsonObject { put("type", "string") })
                put("criterionOrderIndex", buildJsonObject { put("type", "integer") })
                put("title", buildJsonObject { put("type", "string") })
                put("description", buildJsonObject { put("type", "string") })
                put("maxPoints", buildJsonObject { put("type", "integer") })
                put("expectedAnswer", buildJsonObject { put("type", "string") })
                put("partialCreditGuidance", buildJsonObject { put("type", "string") })
                put("commonMistakes", buildJsonObject { put("type", "string") })
            }
            val criterionItemSchema = buildJsonObject {
                put("type", "object")
                put("properties", criterionProperties)
                put("required", buildJsonArray {
                    add("questionOrderIndex"); add("questionNumberSnapshot"); add("criterionOrderIndex")
                    add("title"); add("description"); add("maxPoints"); add("expectedAnswer")
                    add("partialCreditGuidance"); add("commonMistakes")
                })
                put("additionalProperties", false)
            }
            val topSchema = buildJsonObject {
                put("type", "object")
                put("properties", buildJsonObject {
                    put("criteria", buildJsonObject {
                        put("type", "array")
                        put("items", criterionItemSchema)
                    })
                })
                put("required", buildJsonArray { add("criteria") })
                put("additionalProperties", false)
            }
            val responseFormat = buildJsonObject {
                put("type", "text")
                put("mime_type", "application/json")
                put("schema", topSchema)
            }
            val auditInput = buildJsonArray {
                sourceItems.forEach { add(it) }
                add(buildJsonObject {
                    put("type", "text")
                    put("text", "CANONICAL SORULAR VE PUANLAR:\n$canonicalTaskJson")
                })
                add(buildJsonObject {
                    put("type", "text")
                    put("text", "İLK RUBRİK:\n$generatedArray")
                })
                add(buildJsonObject {
                    put("type", "text")
                    put("text", """
                        BAĞIMSIZ ÖĞRETMEN RUBRİĞİ DENETİMİ:
                        İlk rubriği sıfırdan kontrol et ve TAM bir nihai rubrik döndür.
                        - Sorunun ölçmediği yeni koşul ekleme; canonical soru ve puanı değiştirme.
                        - Ortak metin/görsel/tablo bağlamını dikkate al.
                        - Anlamca eşdeğer doğru cevapları kabul edecek şekilde expectedAnswer yaz.
                        - Kısmi puanı somut anlam/işlem parçalarına bağla.
                        - Açık uçlu/kişisel yanıtta örnek cevabı tek doğruya dönüştürme.
                        - Yazım/noktalama yalnız doğrudan ölçülüyorsa puan kriteri olsun; aynı hatayı iki kez cezalandırma.
                        - Her sorudaki kriter puanları soru puanına tam eşit olsun.
                        İlk rubrik zaten doğruysa içeriği gereksiz yere değiştirme.
                    """.trimIndent())
                })
            }
            val requestJson = buildJsonObject {
                put("model", requestedAuthoringModel)
                put("store", false)
                put("system_instruction", "Deneyimli ve adil bir öğretmen gibi rubrik denetle. Öğretmenin kilitleyeceği rubrik bütün sınıfa tutarlı uygulanacaktır.")
                put("input", auditInput)
                put("response_format", responseFormat)
                put("generation_config", buildJsonObject { put("thinking_level", "high") })
            }
            val request = Request.Builder()
                .url(baseUrl)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            val response = okHttpClient.executeCancellable(request)
            response.use { resp ->
                if (!resp.isSuccessful) return@use null
                val root = jsonParser.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                examDraftId?.let { draftId -> runCatching {
                    aiUsageLedger?.recordAuthoring(draftId, "AUTHORING_RUBRIC_AUDIT", requestedAuthoringModel, profileSnapshot, GeminiUsageAuditParser.fromInteractions(root))
                } }
                val text = extractModelOutputText(root) ?: return@use null
                val array = jsonParser.parseToJsonElement(text).jsonObject["criteria"]?.jsonArray ?: return@use null
                val parsed = mutableListOf<GeneratedExamRubricCriterion>()
                for (item in array) {
                    val o = item.jsonObject
                    parsed += GeneratedExamRubricCriterion(
                        questionOrderIndex = o["questionOrderIndex"]?.jsonPrimitive?.intOrNull ?: return@use null,
                        questionNumberSnapshot = o["questionNumberSnapshot"]?.jsonPrimitive?.content ?: return@use null,
                        criterionOrderIndex = o["criterionOrderIndex"]?.jsonPrimitive?.intOrNull ?: return@use null,
                        title = o["title"]?.jsonPrimitive?.content ?: return@use null,
                        description = o["description"]?.jsonPrimitive?.content ?: return@use null,
                        maxPoints = o["maxPoints"]?.jsonPrimitive?.intOrNull ?: return@use null,
                        expectedAnswer = o["expectedAnswer"]?.jsonPrimitive?.content ?: return@use null,
                        partialCreditGuidance = o["partialCreditGuidance"]?.jsonPrimitive?.content.orEmpty(),
                        commonMistakes = o["commonMistakes"]?.jsonPrimitive?.content.orEmpty()
                    )
                }
                parsed.takeIf { it.isNotEmpty() }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizeImageMimeType(mimeType: String, displayName: String): String {
        val lower = mimeType.lowercase()
        return when {
            lower == "image/png" -> "image/png"
            lower == "image/webp" -> "image/webp"
            lower == "image/jpeg" || lower == "image/jpg" -> "image/jpeg"
            displayName.endsWith(".png", ignoreCase = true) -> "image/png"
            displayName.endsWith(".webp", ignoreCase = true) -> "image/webp"
            else -> "image/jpeg"
        }
    }

    private suspend fun uploadListeningAudio(
        apiKey: String,
        source: RubricGenerationSourceContext.ListeningAudio
    ): String = withContext(Dispatchers.IO) {
        val file = source.file
        if (!file.exists() || !file.isFile || !file.canRead() || file.length() <= 0L) {
            throw IllegalArgumentException("Listening audio source is not readable.")
        }
        if (source.sizeBytes <= 0L || source.sizeBytes != file.length()) {
            throw IllegalArgumentException("Listening audio source size changed.")
        }

        val mimeType = normalizeAudioMimeType(source.mimeType, source.displayName)
        val metadataBody = buildJsonObject {
            put("file", buildJsonObject {
                put("display_name", source.displayName.ifBlank { file.name })
            })
        }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val startRequest = Request.Builder()
            .url("https://generativelanguage.googleapis.com/upload/v1beta/files")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("X-Goog-Upload-Protocol", "resumable")
            .addHeader("X-Goog-Upload-Command", "start")
            .addHeader("X-Goog-Upload-Header-Content-Length", file.length().toString())
            .addHeader("X-Goog-Upload-Header-Content-Type", mimeType)
            .post(metadataBody)
            .build()

        val uploadUrl = okHttpClient.executeCancellable(startRequest).use { response ->
            if (!response.isSuccessful) throw GeminiHttpException(response.code)
            response.header("X-Goog-Upload-URL")
                ?: response.header("x-goog-upload-url")
                ?: throw IOException("Gemini File API upload URL missing.")
        }

        val uploadRequest = Request.Builder()
            .url(uploadUrl)
            .addHeader("X-Goog-Upload-Offset", "0")
            .addHeader("X-Goog-Upload-Command", "upload, finalize")
            .post(file.asRequestBody(mimeType.toMediaType()))
            .build()

        okHttpClient.executeCancellable(uploadRequest).use { response ->
            if (!response.isSuccessful) throw GeminiHttpException(response.code)
            val bodyString = response.body?.string().orEmpty()
            val root = try {
                jsonParser.parseToJsonElement(bodyString).jsonObject
            } catch (e: Exception) {
                throw IOException("Gemini File API response malformed.", e)
            }
            root["file"]?.jsonObject?.get("uri")?.jsonPrimitive?.content
                ?.takeIf { it.isNotBlank() }
                ?: throw IOException("Gemini File API file URI missing.")
        }
    }

    private fun normalizeAudioMimeType(mimeType: String, displayName: String): String {
        val normalized = mimeType.trim().lowercase()
        if (normalized in SUPPORTED_GEMINI_AUDIO_MIME_TYPES) return normalized
        if (normalized == "audio/mp4" || normalized == "audio/x-m4a") return "audio/m4a"
        if (normalized == "audio/x-wav" || normalized == "audio/wave") return "audio/wav"
        if (normalized == "audio/x-flac") return "audio/flac"
        if (normalized == "audio/mp3") return "audio/mp3"
        return when (displayName.substringAfterLast('.', "").lowercase()) {
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "m4a" -> "audio/m4a"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "flac" -> "audio/flac"
            else -> "audio/mpeg"
        }
    }

    private class GeminiHttpException(val statusCode: Int) : IOException("Gemini HTTP $statusCode")

    private companion object {
        val SUPPORTED_GEMINI_AUDIO_MIME_TYPES = setOf(
            "audio/wav",
            "audio/mp3",
            "audio/aiff",
            "audio/aac",
            "audio/ogg",
            "audio/flac",
            "audio/mpeg",
            "audio/m4a",
            "audio/l16",
            "audio/opus",
            "audio/alaw",
            "audio/mulaw"
        )
    }

    private fun extractModelOutputText(jsonResponse: kotlinx.serialization.json.JsonObject): String? {
        val steps = jsonResponse["steps"]?.jsonArray ?: return null
        for (stepElem in steps) {
            val step = try { stepElem.jsonObject } catch (e: Exception) { continue }
            if (step["type"]?.jsonPrimitive?.content == "model_output") {
                val content = step["content"]
                if (content != null) {
                    try {
                        val contentArr = content.jsonArray
                        for (itemElem in contentArr) {
                            val item = itemElem.jsonObject
                            if (item["type"]?.jsonPrimitive?.content == "text") {
                                val text = item["text"]?.jsonPrimitive?.content ?: ""
                                if (text.isNotBlank()) return text
                            }
                        }
                    } catch (e: Exception) {
                        try {
                            val item = content.jsonObject
                            if (item["type"]?.jsonPrimitive?.content == "text") {
                                val text = item["text"]?.jsonPrimitive?.content ?: ""
                                if (text.isNotBlank()) return text
                            }
                        } catch (ignored: Exception) {}
                    }
                }
                val textDirect = step["text"]?.jsonPrimitive?.content ?: ""
                if (textDirect.isNotBlank()) return textDirect
            }
        }
        return null
    }
}
