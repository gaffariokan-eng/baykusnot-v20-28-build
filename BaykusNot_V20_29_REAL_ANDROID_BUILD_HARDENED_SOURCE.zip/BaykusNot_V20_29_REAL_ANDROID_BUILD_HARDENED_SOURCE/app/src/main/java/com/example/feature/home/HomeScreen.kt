package com.example.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.database.ExamDraftEntity
import com.example.core.database.TeacherProfileEntity
import com.example.core.model.ExamType
import com.example.core.model.documentExamName
import com.example.core.model.WorkflowStage
import com.example.core.ui.BaykusEmptyState
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.BaykusTopAppBar
import com.example.core.ui.StatusType
import com.example.core.ui.WiseOwlLogo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToNewExam: (ExamType) -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToDraft: (Long) -> Unit
) {
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val drafts by viewModel.drafts.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            BaykusTopAppBar(
                title = stringResource(R.string.app_name),
                subtitle = "Öğretmen Sınav Değerlendirme Asistanı",
                actions = {
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Teacher Welcome & School Profile Banner
            item {
                ProfileWelcomeCard(
                    profile = profile,
                    onNavigateToProfile = onNavigateToProfile
                )
            }

            item {
                EvaluationPromptCard()
            }

            item {
                ExamTypePicker(
                    onWritten = { onNavigateToNewExam(ExamType.WRITTEN) },
                    onListening = { onNavigateToNewExam(ExamType.LISTENING) },
                    onHomework = { onNavigateToNewExam(ExamType.HOMEWORK) },
                    onReadiness = { onNavigateToNewExam(ExamType.READINESS) },
                    onMultipleChoice = { onNavigateToNewExam(ExamType.MULTIPLE_CHOICE) }
                )
            }

            // Registered Drafts / Ongoing Work
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Aktif Çalışmalar",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (drafts.isNotEmpty()) {
                        BaykusStatusChip(
                            text = "${drafts.size} Kayıt",
                            type = StatusType.INFO
                        )
                    }
                }
            }

            if (drafts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        BaykusEmptyState(
                            title = "Henüz Sınav Taslağınız Yok",
                            description = "Yukarıdaki sınav türlerinden birini seçerek yeni bir değerlendirme çalışması başlatabilirsiniz.",
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(drafts, key = { it.id }) { draft ->
                    DraftCard(
                        draft = draft,
                        onClick = { onNavigateToDraft(draft.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(64.dp)) // Spacing for FAB
            }
        }
    }
}

@Composable
fun ProfileWelcomeCard(
    profile: TeacherProfileEntity?,
    onNavigateToProfile: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onNavigateToProfile),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                if (profile == null) {
                    Text(
                        text = "Hoş Geldiniz, Öğretmenim",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Kurum ve öğretmen bilgilerinizi girmek için dokunun",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Text(
                        text = profile.institutionName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Öğretmen: ${profile.teacherNames.firstOrNull().orEmpty()} • Eğitim Yılı: ${profile.academicYear}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Düzenle",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EvaluationPromptCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            WiseOwlLogo(size = 42.dp)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Bugün neyi değerlendirmemi istersiniz?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Bir çalışma türü seçin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ExamTypePicker(
    onWritten: () -> Unit,
    onListening: () -> Unit,
    onHomework: () -> Unit,
    onReadiness: () -> Unit,
    onMultipleChoice: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CompactExamTypeCard(
                title = "Yazılı Sınav",
                icon = Icons.Default.Description,
                accent = primary,
                onClick = onWritten,
                modifier = Modifier.weight(1f)
            )
            CompactExamTypeCard(
                title = "Dinleme Sınavı",
                icon = Icons.Default.PlayArrow,
                accent = Color(0xFF55B8E8),
                onClick = onListening,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CompactExamTypeCard(
                title = "Ödev Kontrolü",
                icon = Icons.Default.ListAlt,
                accent = Color(0xFFFFB45B),
                onClick = onHomework,
                modifier = Modifier.weight(1f)
            )
            CompactExamTypeCard(
                title = "Hazırbulunuşluk",
                icon = Icons.Default.School,
                accent = Color(0xFF72C68A),
                onClick = onReadiness,
                modifier = Modifier.weight(1f)
            )
        }

        CompactExamTypeCard(
            title = "Test Sınavı",
            icon = Icons.Default.CheckCircle,
            accent = tertiary,
            onClick = onMultipleChoice,
            modifier = Modifier.fillMaxWidth(),
            wide = true
        )
    }
}

@Composable
private fun CompactExamTypeCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    wide: Boolean = false
) {
    Card(
        modifier = modifier
            .height(if (wide) 76.dp else 104.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            accent.copy(alpha = 0.35f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        if (wide) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ExamTypeIcon(icon = icon, accent = accent)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = accent
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    ExamTypeIcon(icon = icon, accent = accent)
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = accent.copy(alpha = 0.85f),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ExamTypeIcon(
    icon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .background(
                color = accent.copy(alpha = 0.16f),
                shape = RoundedCornerShape(13.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun DraftCard(draft: ExamDraftEntity, onClick: () -> Unit) {
    val formatter = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    val dateString = formatter.format(Date(draft.examDate))

    val (stageText, statusType) = getWorkflowStageStatus(draft.currentWorkflowStage)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = draft.draftName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                BaykusStatusChip(text = stageText, type = statusType)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${if (draft.examType == ExamType.WRITTEN) "" else "${draft.examType.documentExamName()} • "}${draft.courseName} • ${draft.gradeLevel}. Sınıf • ${draft.term} (${draft.academicYear})",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tarih: $dateString",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Devam Et",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

private fun getWorkflowStageStatus(stage: WorkflowStage): Pair<String, StatusType> {
    return when (stage) {
        WorkflowStage.EXAM_INFO -> "Sınav Bilgileri" to StatusType.INFO
        WorkflowStage.UPLOAD_SOURCE -> "Boş Sınav" to StatusType.INFO
        WorkflowStage.QUESTION_POINTS -> "Sorular" to StatusType.INFO
        WorkflowStage.RUBRIC -> "Rubrik" to StatusType.INFO
        WorkflowStage.ANSWER_SHEET -> "Cevap Kâğıdı" to StatusType.INFO
        WorkflowStage.UPLOAD_PAPERS -> "Öğrenci Kâğıtları" to StatusType.INFO
        WorkflowStage.READING_PREFS -> "Tercihler" to StatusType.LOCKED
        WorkflowStage.AI_EVALUATION -> "Değerlendirme" to StatusType.WARNING
        WorkflowStage.TEACHER_REVIEW -> "İnceleme Bekliyor" to StatusType.REVIEW_NEEDED
        WorkflowStage.REPORTS -> "Raporlar Hazır" to StatusType.SUCCESS
    }
}

