package com.example.core.model

data class ExamQuestionSetMetadata(
    val examDraftId: Long,
    val isLocked: Boolean,
    val lockedAt: Long?,
    val revision: Int,
    val createdAt: Long,
    val updatedAt: Long
)
