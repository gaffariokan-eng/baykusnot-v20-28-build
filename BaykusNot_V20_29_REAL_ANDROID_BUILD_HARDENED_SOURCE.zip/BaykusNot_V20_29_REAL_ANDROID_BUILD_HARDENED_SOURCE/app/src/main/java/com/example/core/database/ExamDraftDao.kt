package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDraftDao {
    @Query("SELECT * FROM exam_draft ORDER BY updatedAt DESC")
    fun getAllDrafts(): Flow<List<ExamDraftEntity>>

    @Query("SELECT * FROM exam_draft WHERE id = :id LIMIT 1")
    fun getDraftById(id: Long): Flow<ExamDraftEntity?>

    @Query("SELECT * FROM exam_draft WHERE id = :id LIMIT 1")
    suspend fun getDraftByIdOnce(id: Long): ExamDraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDraft(draft: ExamDraftEntity): Long

    @Update
    suspend fun updateDraft(draft: ExamDraftEntity)

    @Query("DELETE FROM exam_draft WHERE id = :id")
    suspend fun deleteDraftById(id: Long)

    @Query(
        """
        SELECT draft.*
        FROM exam_draft AS draft
        INNER JOIN exam_evaluation_preferences AS preferences
            ON preferences.examDraftId = draft.id
        WHERE draft.id != :targetExamDraftId
        ORDER BY
            draft.examDate DESC,
            draft.updatedAt DESC,
            draft.id DESC
        """
    )
    suspend fun getEvaluationPreferencesCopySourceDrafts(
        targetExamDraftId: Long
    ): List<ExamDraftEntity>
}
