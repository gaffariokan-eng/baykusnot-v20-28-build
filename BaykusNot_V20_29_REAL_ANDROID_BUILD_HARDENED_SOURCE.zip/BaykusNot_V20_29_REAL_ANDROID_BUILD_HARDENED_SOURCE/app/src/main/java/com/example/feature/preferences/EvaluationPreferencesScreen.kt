package com.example.feature.preferences

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.EvaluationMode
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel

/**
 * Test tags are intentionally kept stable so older UI tests and automation do not
 * break even though normal users now see a much simpler Teacher Mode screen.
 */
object EvaluationPreferencesTestTags {
    const val SCREEN = "eval_prefs_screen"
    const val LOADING = "eval_prefs_loading"
    const val NOT_FOUND = "eval_prefs_not_found"
    const val SAVE_BUTTON = "eval_prefs_save_button"
    const val LOCK_BUTTON = "eval_prefs_lock_button"
    const val LOAD_COPY_SOURCES_BUTTON = "eval_prefs_load_copy_sources_button"
    const val COPY_BUTTON = "eval_prefs_copy_button"
    const val CALCULATE_COST_BUTTON = "eval_prefs_calculate_cost_button"
    const val FEEDBACK_SWITCH = "eval_prefs_feedback_switch"
    const val DEDUCT_SWITCH = "eval_prefs_deduct_switch"

    fun evaluationMode(mode: EvaluationMode) = "eval_mode_${mode.name}"
    fun rubricLevel(level: RubricAdherenceLevel) = "rubric_level_${level.name}"
    fun feedbackDetail(level: FeedbackDetailLevel) = "feedback_detail_${level.name}"
    fun modelQuality(tier: ModelQualityTier) = "model_quality_${tier.name}"
    fun copySource(id: Long) = "copy_source_$id"
}

@Suppress("UNUSED_PARAMETER")
@Composable
fun EvaluationPreferencesScreen(
    uiState: EvaluationPreferencesUiState,
    onEvaluationModeChange: (EvaluationMode) -> Unit,
    onRubricAdherenceLevelChange: (RubricAdherenceLevel) -> Unit,
    onFeedbackDetailLevelChange: (FeedbackDetailLevel) -> Unit,
    onDeductWritingAndPunctuationPointsChange: (Boolean) -> Unit,
    onProvideWritingAndPunctuationFeedbackChange: (Boolean) -> Unit,
    onModelQualityTierChange: (ModelQualityTier) -> Unit,
    onReportClassChange: (Boolean) -> Unit = {},
    onReportIndividualChange: (Boolean) -> Unit = {},
    onReportQuestionChange: (Boolean) -> Unit = {},
    onUseBatchApiChange: (Boolean) -> Unit = {},
    onUsePromptCachingChange: (Boolean) -> Unit = {},
    onCalculateCost: () -> Unit = {},
    onShowConfirmation: (() -> Unit)? = null,
    onDismissConfirmation: () -> Unit = {},
    onConfirmAndLock: () -> Unit = {},
    onUnlockPreferences: (() -> Unit)? = null,
    onSavePreferences: () -> Unit,
    onLockPreferences: () -> Unit,
    onLoadCopySources: () -> Unit,
    onCopySourceSelected: (Long?) -> Unit,
    onCopyPreferences: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBusy = uiState.isLoading || uiState.isSaving || uiState.isLocking || uiState.isCopying
    val canEdit = !uiState.isLocked && !isBusy

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag(EvaluationPreferencesTestTags.SCREEN)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(EvaluationPreferencesTestTags.LOADING)
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Değerlendirme hazırlanıyor...")
                    }
                }
            }
            return@LazyColumn
        }

        if (uiState.examExists == false) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(EvaluationPreferencesTestTags.NOT_FOUND)
                ) {
                    Text("Sınav kaydı bulunamadı.", modifier = Modifier.padding(16.dp))
                }
            }
            return@LazyColumn
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Değerlendirme",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "BaykuşNot sınavı öğretmen gibi okumaya ayarlı. Siz yalnız dönütün ne kadar ayrıntılı olacağını seçin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.School, contentDescription = null)
                        Text("Öğretmen Modu", fontWeight = FontWeight.Bold)
                        if (uiState.isLocked) {
                            Icon(Icons.Default.Lock, contentDescription = "Kilitli")
                        }
                    }
                    TeacherModeLine("Öğrencinin yazdığı metin düzeltilmeden okunur; ne demek istediği ayrıca yorumlanır.")
                    TeacherModeLine("Puan yalnız kilitli soru, kaynak bağlamı ve öğretmenin onayladığı rubriğe göre verilir.")
                    TeacherModeLine("Yazım ve noktalama, yalnız sorunun ölçtüğü beceriye gerçekten uygunsa puanı etkiler.")
                    TeacherModeLine("Belirsiz veya çok düşük puanlı cevaplar otomatik ikinci kontrolden geçer; hâlâ belirsizse öğretmene bırakılır.")
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Dönüt Ayrıntısı",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                FeedbackDetailLevel.entries.forEach { level ->
                    FeedbackLevelCard(
                        level = level,
                        selected = uiState.feedbackDetailLevel == level,
                        enabled = canEdit,
                        onClick = { onFeedbackDetailLevelChange(level) }
                    )
                }
                Text(
                    "Dönüt seviyesi yalnız açıklamanın miktarını değiştirir; öğrencinin puanını değiştirmez.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (!uiState.message.isNullOrBlank()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(uiState.message, modifier = Modifier.padding(14.dp))
                }
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (uiState.isLocked) {
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onUnlockPreferences?.invoke() },
                        enabled = !isBusy
                    ) {
                        Text("Düzenlemeye Aç")
                    }
                } else {
                    val needsSave = !uiState.preferencesExist || uiState.isDirty
                    Button(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag(EvaluationPreferencesTestTags.LOCK_BUTTON),
                        onClick = if (needsSave) onSavePreferences else onLockPreferences,
                        enabled = !isBusy
                    ) {
                        Text(
                            when {
                                uiState.isSaving -> "Kaydediliyor..."
                                uiState.isLocking -> "Onaylanıyor..."
                                else -> "Kaydet ve İlerle"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        "Bu düğmeye basana kadar dönüt tercihini değiştirebilirsiniz.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TeacherModeLine(text: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun FeedbackLevelCard(
    level: FeedbackDetailLevel,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(EvaluationPreferencesTestTags.feedbackDetail(level))
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RadioButton(
                selected = selected,
                onClick = if (enabled) onClick else null,
                enabled = enabled
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(level.displayName, fontWeight = FontWeight.SemiBold)
                Text(
                    level.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
