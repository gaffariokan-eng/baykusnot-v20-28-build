package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_rubric_criterion",
    foreignKeys = [
        ForeignKey(
            entity = ExamRubricSetMetadataEntity::class,
            parentColumns = ["examDraftId"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["examDraftId"]),
        Index(
            value = [
                "examDraftId",
                "questionOrderIndex",
                "criterionOrderIndex"
            ],
            unique = true
        )
    ]
)
data class ExamRubricCriterionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val examDraftId: Long,
    val questionOrderIndex: Int,
    val questionNumberSnapshot: String,
    val criterionOrderIndex: Int,
    val title: String,
    val description: String,
    val maxPoints: Int,
    val expectedAnswer: String,
    val partialCreditGuidance: String,
    val commonMistakes: String,
    val createdAt: Long,
    val updatedAt: Long,
    val originalAnswerKey: String? = null,
    val originalRubric: String? = null
)
