package com.example.feature.workflow

import com.example.core.data.PdfSafWriter
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: ReportsViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    DisposableEffect(viewModel) {
        onDispose { viewModel.cancelActiveFeedbackGeneration() }
    }

    var fileToSave by remember { mutableStateOf<File?>(null) }
    var showCleanupConfirmation by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { ReportsPdfGenerator.cleanupTemporaryReports(context) }
    }
    
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val source = fileToSave
        if (uri != null && source != null) {
            coroutineScope.launch {
                try {
                    val verifiedBytes = withContext(Dispatchers.IO) {
                        PdfSafWriter.writeVerified(context, source, uri).getOrThrow()
                    }
                    Toast.makeText(context, "PDF doğrulandı ve kaydedildi (${verifiedBytes} byte).", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Kaydetme başarısız: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    ReportsPdfGenerator.deleteTemporaryReport(source)
                    fileToSave = null
                }
            }
        } else {
            ReportsPdfGenerator.deleteTemporaryReport(source)
            fileToSave = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        if (uiState.isLoading) {
            Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(8.dp))
                Text("Raporlar hazırlanıyor...", style = MaterialTheme.typography.bodyMedium)
            }
        } else if (uiState.error != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.align(Alignment.Center).padding(16.dp)
            ) {
                Text(
                    text = uiState.error!!,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            ReportsContent(
                uiState = uiState,
                onCleanupAnswerImages = { showCleanupConfirmation = true },
                onRetryMissingFeedback = viewModel::retryMissingFeedback,
                onSavePdf = { file -> 
                    fileToSave = file
                    createDocumentLauncher.launch(file.name)
                },
                onSharePdf = { file ->
                    try {
                        val uri: Uri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            file
                        )
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Raporu Paylaş"))
                    } catch (e: Exception) {
                        Toast.makeText(context, "Paylaşım hatası: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    if (showCleanupConfirmation) {
        AlertDialog(
            onDismissRequest = { showCleanupConfirmation = false },
            title = { Text("Cevap Görüntülerini Sil") },
            text = {
                Text("Bu işlem telefondaki taranmış/fotoğraflanmış cevap sayfalarını siler. Puanlar, öğretmen onayları ve dönütler korunur. Orijinal cevap kâğıtlarını ve gerekli basılı raporları arşivlediğinizden emin olun.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showCleanupConfirmation = false
                    viewModel.deleteAnswerImagesAfterArchive()
                }) { Text("Görüntüleri Sil") }
            },
            dismissButton = {
                TextButton(onClick = { showCleanupConfirmation = false }) { Text("İptal") }
            }
        )
    }
}

@Composable
fun ReportsContent(
    uiState: ReportsUiState,
    onCleanupAnswerImages: () -> Unit,
    onRetryMissingFeedback: () -> Unit,
    onSavePdf: (File) -> Unit,
    onSharePdf: (File) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val copy = reportCopy(uiState.draft?.examType ?: com.example.core.model.ExamType.WRITTEN)
    var selectedStudent by remember { mutableStateOf<IndividualReportData?>(null) }
    
    var isGeneratingClass by remember { mutableStateOf<String?>(null) }
    var isGeneratingIndividual by remember { mutableStateOf<Long?>(null) }
    var isGeneratingQuestions by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = copy.reportsTitle,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = copy.reportsDescription,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        uiState.aiUsageSummary?.takeIf { it.callCount > 0 }?.let { usage ->
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("AI Kullanım Özeti", fontWeight = FontWeight.Bold)
                        Text("Okuma modeli: ${usage.evaluationModel ?: "-"} • Dönüt modeli: ${usage.feedbackModel ?: "-"}", style = MaterialTheme.typography.bodySmall)
                        if (usage.authoringModels.isNotEmpty()) Text("Hazırlık modeli/model sürümleri: ${usage.authoringModels.joinToString()}", style = MaterialTheme.typography.bodySmall)
                        Text("Giriş: ${usage.inputTokens} token • Cache: ${usage.cachedInputTokens} • Çıkış: ${usage.outputTokens} • Thinking: ${usage.thinkingTokens}", style = MaterialTheme.typography.bodySmall)
                        Text("Gerçek çağrı maliyeti: $${String.format(java.util.Locale.US, "%.4f", usage.providerCallCostUsd)} • Cache saklama: $${String.format(java.util.Locale.US, "%.4f", usage.cacheStorageCostUsd)}", style = MaterialTheme.typography.bodySmall)
                        Text("Toplam sağlayıcı maliyeti (gerçek token + gerçek cache yaşam süresi): $${String.format(java.util.Locale.US, "%.4f", usage.estimatedCostUsd)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        if (usage.actualModelVersions.isNotEmpty()) Text("Gerçek model sürümü: ${usage.actualModelVersions.joinToString()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (usage.modelStatusStages.isNotEmpty()) Text("Model durumu: ${usage.modelStatusStages.joinToString()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (usage.modelRetirementTimes.isNotEmpty()) Text("UYARI — model kapanış/retirement zamanı bildirildi: ${usage.modelRetirementTimes.joinToString()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        if (usage.modelStatusMessages.isNotEmpty()) Text("Sağlayıcı model uyarısı: ${usage.modelStatusMessages.joinToString()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        if (usage.providerResponseIds.isNotEmpty()) Text("Sağlayıcı audit izi: ${usage.providerResponseIds.size} yanıt kimliği kaydedildi.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Vergi/kur farkları sağlayıcı faturasına göre ayrıca değişebilir.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        if (uiState.isGeneratingFeedback && uiState.individualReports.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(uiState.feedbackMessage ?: "Ayrıntılı öğrenci dönütleri hazırlanıyor...", fontWeight = FontWeight.SemiBold)
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text("Öğretmen onaylı puanlar değişmez; yalnız öğrenciye verilecek açıklamalar hazırlanıyor.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        if (uiState.answerImagesPresent || uiState.cleanupMessage != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Fiziksel Arşiv Sonrası Gizlilik", fontWeight = FontWeight.Bold)
                        Text(
                            "İki nüsha dönüt raporunu ve orijinal cevap kâğıtlarını arşivledikten sonra isterseniz yalnız telefondaki cevap görüntülerini silebilirsiniz. Puanlar ve dönüt kayıtları korunur.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        uiState.cleanupMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
                        if (uiState.answerImagesPresent) {
                            OutlinedButton(
                                onClick = onCleanupAnswerImages,
                                enabled = !uiState.isCleaningAnswerImages,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (uiState.isCleaningAnswerImages) {
                                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Siliniyor...")
                                } else {
                                    Text("Cihazdaki Cevap Görüntülerini Sil")
                                }
                            }
                        }
                    }
                }
            }
        }

        uiState.objectiveIntegrityError?.let { errorMsg ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Bütünlük Hatası",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = errorMsg,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        if (uiState.preferences?.reportClass == true && uiState.classReportGroups.isNotEmpty()) {
            item {
                Text(copy.classSectionTitle, style = MaterialTheme.typography.titleLarge)
            }
            items(uiState.classReportGroups.values.toList()) { report ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Sınıf/Şube: ${report.classAndBranch}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard(title = "Öğrenci Sayısı", value = report.studentCount.toString(), modifier = Modifier.weight(1f))
                                MetricCard(title = "Ortalama Puan", value = String.format("%.1f", report.classAverage), modifier = Modifier.weight(1f))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard(title = "En Yüksek", value = report.maxScore.toString(), modifier = Modifier.weight(1f))
                                MetricCard(title = "En Düşük", value = report.minScore.toString(), modifier = Modifier.weight(1f))
                            }
                            if (uiState.draft?.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    MetricCard(title = "Ort. Doğru", value = String.format("%.1f", report.testAverageCorrect), modifier = Modifier.weight(1f))
                                    MetricCard(title = "Ort. Yanlış", value = String.format("%.1f", report.testAverageWrong), modifier = Modifier.weight(1f))
                                    MetricCard(title = "Ort. Boş", value = String.format("%.1f", report.testAverageBlank), modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        
                        if (report.prioritySupportObjectives.isNotEmpty() && copy.prioritySupportTitle != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(copy.prioritySupportTitle, fontWeight = FontWeight.Bold)
                            copy.prioritySupportDescription?.let { description ->
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            report.prioritySupportObjectives.forEachIndexed { index, obj ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "${index + 1}. ${obj.objectiveCode ?: copy.objectiveDefaultLabel} — ${obj.objectiveText}",
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Desteğe ihtiyaç gösteren: ${obj.supportStudentCount}/${obj.measuredStudentCount} öğrenci (%${String.format("%.0f", obj.supportRatePercentage)}) • Sınıf karşılanma: %${String.format("%.1f", obj.successPercentage)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        if (report.classObjectiveScores.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(copy.classObjectiveTitle, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            report.classObjectiveScores.forEach { obj ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("${obj.objectiveCode ?: copy.objectiveDefaultLabel} (${obj.questionCount} ${copy.itemLabel})", fontWeight = FontWeight.SemiBold)
                                                Text(obj.objectiveText, style = MaterialTheme.typography.bodySmall)
                                            }
                                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 8.dp)) {
                                                if (obj.questionCount == 0) {
                                                    Text("Ölçülmedi", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                } else {
                                                    Text("%${String.format("%.1f", obj.successPercentage)}", fontWeight = FontWeight.Bold)
                                                    Text("${String.format("%.1f", obj.totalScore)}/${obj.maxScore}", style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                        }
                                        Text(obj.level, style = MaterialTheme.typography.labelSmall, color = if (obj.questionCount == 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary)
                                        if (obj.questionCount > 0) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            LinearProgressIndicator(progress = { (obj.successPercentage / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(4.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.primaryContainer)
                                        }
                                    }
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text("Öğrenci Listesi", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Sort by student number to ensure predictable order
                        val sortedStudents = report.students.sortedBy { 
                            it.studentNumber.filter { char -> char.isDigit() }.toIntOrNull() ?: 0 
                        }
                        
                        // Bound composition cost for large classes. A class card renders at most
                        // 50 student rows at once instead of composing all 500 inside one LazyColumn item.
                        val classStudentPageSize = 50
                        val classStudentPageCount = ((sortedStudents.size + classStudentPageSize - 1) / classStudentPageSize).coerceAtLeast(1)
                        var classStudentPage by rememberSaveable(report.classAndBranch) { mutableIntStateOf(0) }
                        val safeClassStudentPage = classStudentPage.coerceIn(0, classStudentPageCount - 1)
                        val classStudentFrom = safeClassStudentPage * classStudentPageSize
                        val visibleClassStudents = sortedStudents.drop(classStudentFrom).take(classStudentPageSize)

                        visibleClassStudents.forEach { student ->
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text("No ${student.studentNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(student.studentName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                }
                                Text("${student.totalScore} / ${student.totalMaxScore}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                        if (classStudentPageCount > 1) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { classStudentPage = (safeClassStudentPage - 1).coerceAtLeast(0) },
                                    enabled = safeClassStudentPage > 0
                                ) { Text("Önceki") }
                                Text(
                                    "${classStudentFrom + 1}-${(classStudentFrom + visibleClassStudents.size).coerceAtMost(sortedStudents.size)} / ${sortedStudents.size}",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                OutlinedButton(
                                    onClick = { classStudentPage = (safeClassStudentPage + 1).coerceAtMost(classStudentPageCount - 1) },
                                    enabled = safeClassStudentPage < classStudentPageCount - 1
                                ) { Text("Sonraki") }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    isGeneratingClass = report.classAndBranch
                                    coroutineScope.launch {
                                        try {
                                            val file = withContext(Dispatchers.IO) {
                                                ReportsPdfGenerator.generateClassReportPdf(context, uiState.draft, report)
                                            }
                                            onSavePdf(file)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                        } finally {
                                            isGeneratingClass = null
                                        }
                                    }
                                },
                                enabled = isGeneratingClass == null,
                                modifier = Modifier.weight(1f)
                            ) {
                                if (isGeneratingClass == report.classAndBranch) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Kaydet")
                            }
                            OutlinedButton(
                                onClick = {
                                    isGeneratingClass = report.classAndBranch
                                    coroutineScope.launch {
                                        try {
                                            val file = withContext(Dispatchers.IO) {
                                                ReportsPdfGenerator.generateClassReportPdf(context, uiState.draft, report)
                                            }
                                            onSharePdf(file)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                        } finally {
                                            isGeneratingClass = null
                                        }
                                    }
                                },
                                enabled = isGeneratingClass == null,
                                modifier = Modifier.weight(1f)
                            ) {
                                if (isGeneratingClass == report.classAndBranch) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Paylaş")
                            }
                        }
                    }
                }
            }
        }

        if (uiState.preferences?.reportIndividual == true && uiState.individualReports.isNotEmpty()) {
            item {
                if (uiState.isGeneratingFeedback || uiState.feedbackPendingCount > 0 || !uiState.feedbackMessage.isNullOrBlank()) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(uiState.feedbackMessage ?: "Kişisel dönüt durumu", fontWeight = FontWeight.SemiBold)
                            if (uiState.isGeneratingFeedback) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                            if (!uiState.isGeneratingFeedback && uiState.feedbackPendingCount > 0) {
                                OutlinedButton(onClick = onRetryMissingFeedback, modifier = Modifier.fillMaxWidth()) {
                                    Text("Sonraki Dönüt Grubunu Hazırla (en fazla 25)")
                                }
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                val file = withContext(Dispatchers.IO) {
                                    ReportsPdfGenerator.generateAllIndividualReportsPdf(context, uiState.draft, uiState.individualReports)
                                }
                                onSavePdf(file)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Toplu PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !uiState.isGeneratingFeedback && uiState.feedbackPendingCount == 0,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Tüm Öğrenci Dönütlerini Tek PDF Oluştur") }
                Text("Bu PDF'yi yazdırırken 2 kopya seçerek bir takımı öğrencilere, bir takımı öğretmen dosyasına ayırabilirsiniz.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Text("Bireysel Öğrenci Raporları", style = MaterialTheme.typography.titleLarge)
            }
            if (selectedStudent == null) {
                items(uiState.individualReports) { report ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedStudent = report }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${report.studentNumber} - ${report.studentName}",
                                    fontWeight = FontWeight.Bold
                                )
                                Text("Sınıf: ${report.classAndBranch}", style = MaterialTheme.typography.bodySmall)
                            }
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Seç", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            } else {
                val report = selectedStudent!!
                item {
                    Button(onClick = { selectedStudent = null }) {
                        Text("Öğrenci Listesine Dön")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${report.studentNumber} - ${report.studentName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "Sınıf: ${report.classAndBranch}")
                            Text(
                                text = "Toplam Puan: ${report.totalScore} / ${report.totalMaxScore}",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        isGeneratingIndividual = report.paperId
                                        coroutineScope.launch {
                                            try {
                                                val file = withContext(Dispatchers.IO) {
                                                    ReportsPdfGenerator.generateIndividualReportPdf(context, uiState.draft, report)
                                                }
                                                onSavePdf(file)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                isGeneratingIndividual = null
                                            }
                                        }
                                    },
                                    enabled = isGeneratingIndividual == null && uiState.feedbackPendingCount == 0,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (isGeneratingIndividual == report.paperId) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Kaydet")
                                }
                                OutlinedButton(
                                    onClick = {
                                        isGeneratingIndividual = report.paperId
                                        coroutineScope.launch {
                                            try {
                                                val file = withContext(Dispatchers.IO) {
                                                    ReportsPdfGenerator.generateIndividualReportPdf(context, uiState.draft, report)
                                                }
                                                onSharePdf(file)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                isGeneratingIndividual = null
                                            }
                                        }
                                    },
                                    enabled = isGeneratingIndividual == null && uiState.feedbackPendingCount == 0,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (isGeneratingIndividual == report.paperId) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Paylaş")
                                }
                            }
                            
                            if (uiState.draft?.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                                Spacer(modifier = Modifier.height(12.dp))
                                @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                                androidx.compose.foundation.layout.FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(
                                        "Doğru: ${report.testCorrectCount}",
                                        "Yanlış: ${report.testWrongCount}",
                                        "Boş: ${report.testBlankCount}"
                                    ).forEach { statusText ->
                                        Surface(
                                            shape = MaterialTheme.shapes.small,
                                            tonalElevation = 1.dp
                                        ) {
                                            Text(statusText, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                        }
                                    }
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
                            
                            Text(
                                text = copy.itemFeedbackTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            report.questionScores.forEach { qs ->
                                QuestionFeedbackItem(qs = qs, itemLabel = copy.itemLabel)
                            }
                            
                            if (report.prioritySupportObjectives.isNotEmpty() && copy.individualSupportTitle != null) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("${copy.individualSupportTitle}:", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                report.prioritySupportObjectives.forEachIndexed { index, obj ->
                                    val codeText = if (!obj.objectiveCode.isNullOrBlank()) "${obj.objectiveCode} " else ""
                                    Text(
                                        text = "${index + 1}. $codeText${obj.objectiveText} — Karşılanma %${String.format("%.0f", obj.successPercentage)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Text(
                                    text = "Bu sıralama not veya başarı sınırı değildir; konu/üniteye başlamadan önce desteklenebilecek alanları gösterir.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (report.objectiveScores.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("${copy.individualObjectiveTitle}:", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                report.objectiveScores.forEach { obj ->
                                    val codeText = if (!obj.objectiveCode.isNullOrBlank()) "${obj.objectiveCode} " else ""
                                    Text(
                                        text = "$codeText${obj.objectiveText} (${obj.questionCount} ${copy.itemLabel})",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        if (obj.questionCount == 0) {
                                            Text(text = copy.notMeasuredText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        } else {
                                            Text(text = "Puan: ${String.format("%.1f", obj.totalScore)} / ${obj.maxScore}", style = MaterialTheme.typography.bodySmall)
                                            Text(text = "${copy.successLabel}: %${String.format("%.0f", obj.successPercentage)} - ${obj.level}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                            }

                            if (!report.teacherNote.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("Öğretmen Notu", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(report.teacherNote, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }

                            if (!report.spellingPunctuationFeedback.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        val deductionVal = report.spellingPunctuationDeduction ?: 0.0
                                        val deductionText = if (deductionVal > 0.0) {
                                            val fmt = if (deductionVal == deductionVal.toLong().toDouble()) deductionVal.toLong().toString() else String.format("%.1f", deductionVal)
                                            " (Kesinti: -$fmt Puan)"
                                        } else ""
                                        Text(
                                            text = "Yazım ve Noktalama$deductionText",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = report.spellingPunctuationFeedback,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }


                        }
                    }
                }
            }
        }

        if (uiState.preferences?.reportQuestion == true && uiState.questionReports.isNotEmpty()) {
            item {
                Text(copy.itemAnalysisTitle, style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            isGeneratingQuestions = true
                            coroutineScope.launch {
                                try {
                                    val file = withContext(Dispatchers.IO) {
                                        ReportsPdfGenerator.generateQuestionReportPdf(context, uiState.draft, uiState.questionReports)
                                    }
                                    onSavePdf(file)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                } finally {
                                    isGeneratingQuestions = false
                                }
                            }
                        },
                        enabled = !isGeneratingQuestions,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isGeneratingQuestions) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Kaydet")
                    }
                    OutlinedButton(
                        onClick = {
                            isGeneratingQuestions = true
                            coroutineScope.launch {
                                try {
                                    val file = withContext(Dispatchers.IO) {
                                        ReportsPdfGenerator.generateQuestionReportPdf(context, uiState.draft, uiState.questionReports)
                                    }
                                    onSharePdf(file)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "PDF oluşturulamadı: ${e.message}", Toast.LENGTH_LONG).show()
                                } finally {
                                    isGeneratingQuestions = false
                                }
                            }
                        },
                        enabled = !isGeneratingQuestions,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isGeneratingQuestions) CircularProgressIndicator(modifier = Modifier.size(20.dp)) else Text("Paylaş")
                    }
                }
            }
            
            items(uiState.questionReports) { qReport ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "${copy.itemLabel} ${qReport.questionNumber}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = qReport.questionText,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        
                        Text("Ortalama Puan: ${String.format("%.1f", qReport.averageScore)} / ${qReport.maxScore}")
                        Text("${copy.successPercentageLabel}: %${String.format("%.1f", qReport.successPercentage)}")
                        if (uiState.draft?.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Doğru: ${qReport.correctCount} • Yanlış: ${qReport.wrongCount} • Boş: ${qReport.blankCount}" +
                                    (qReport.correctChoice?.let { " • Anahtar: $it" } ?: ""),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (qReport.choiceDistribution.isNotEmpty()) {
                                Text(
                                    text = "Seçenek dağılımı: " + qReport.choiceDistribution.entries.joinToString("   ") { "${it.key}: ${it.value}" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (qReport.successPercentage / 100).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.primaryContainer
                        )

                        if (qReport.objectives.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${copy.objectivePluralLabel}:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            qReport.objectives.forEach { obj ->
                                val codeText = if (!obj.objectiveCode.isNullOrBlank()) "${obj.objectiveCode} " else ""
                                Text("- $codeText${obj.objectiveText}", style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Öğrenci Dağılımı", fontWeight = FontWeight.Bold)
                        val questionStudentPageSize = 50
                        val questionStudentPageCount = ((qReport.students.size + questionStudentPageSize - 1) / questionStudentPageSize).coerceAtLeast(1)
                        var questionStudentPage by rememberSaveable(qReport.questionOrderIndex) { mutableIntStateOf(0) }
                        val safeQuestionStudentPage = questionStudentPage.coerceIn(0, questionStudentPageCount - 1)
                        val questionStudentFrom = safeQuestionStudentPage * questionStudentPageSize
                        val visibleQuestionStudents = qReport.students.drop(questionStudentFrom).take(questionStudentPageSize)
                        visibleQuestionStudents.forEach { std ->
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    text = "${std.classAndBranch} - ${std.studentNumber} ${std.studentName}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "${std.score} / ${std.maxScore}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (questionStudentPageCount > 1) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { questionStudentPage = (safeQuestionStudentPage - 1).coerceAtLeast(0) },
                                    enabled = safeQuestionStudentPage > 0
                                ) { Text("Önceki") }
                                Text(
                                    "${questionStudentFrom + 1}-${(questionStudentFrom + visibleQuestionStudents.size).coerceAtMost(qReport.students.size)} / ${qReport.students.size}",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                OutlinedButton(
                                    onClick = { questionStudentPage = (safeQuestionStudentPage + 1).coerceAtMost(questionStudentPageCount - 1) },
                                    enabled = safeQuestionStudentPage < questionStudentPageCount - 1
                                ) { Text("Sonraki") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun QuestionFeedbackItem(qs: IndividualQuestionScore, itemLabel: String = "Soru") {
    val maxScore = qs.maxScore
    val score = qs.score
    val ratio = if (maxScore > 0.0) (score / maxScore).toFloat() else 0f

    val isFullScore = score >= maxScore && maxScore > 0.0
    val isHighPartial = ratio >= 0.75f
    val isPartial = ratio > 0.0f

    val containerColor = when {
        isFullScore || isHighPartial -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
        isPartial -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f)
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    }

    val badgeColor = when {
        isFullScore || isHighPartial -> MaterialTheme.colorScheme.primaryContainer
        isPartial -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    val badgeTextColor = when {
        isFullScore || isHighPartial -> MaterialTheme.colorScheme.onPrimaryContainer
        isPartial -> MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    val formatScore = { v: Double ->
        if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$itemLabel ${qs.questionNumber}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor
                ) {
                    Text(
                        text = "${formatScore(score)} / ${formatScore(maxScore)} Puan",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = badgeTextColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (!qs.feedback.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = qs.feedback,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
