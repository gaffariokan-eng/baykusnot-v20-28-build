package com.example.feature.workflow

data class EditableExamQuestion(
    val localId: Long,
    val persistedId: Long,
    val orderIndex: Int,
    val questionNumber: String,
    val questionText: String,
    val pointsText: String,
    val selectedObjectiveIds: Set<Long> = emptySet()
)
