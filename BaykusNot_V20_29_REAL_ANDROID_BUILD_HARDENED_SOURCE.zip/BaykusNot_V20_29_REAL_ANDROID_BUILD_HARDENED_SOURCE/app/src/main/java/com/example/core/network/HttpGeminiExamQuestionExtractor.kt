package com.example.core.network

import com.example.core.security.SecureApiKeyStore
import com.example.core.model.ExamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.Base64
import kotlin.coroutines.cancellation.CancellationException

class HttpGeminiExamQuestionExtractor(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta/interactions",
    private val aiUsageLedger: AiUsageLedger? = null
) : ExamQuestionExtractor {

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override suspend fun extract(
        input: ExamExtractionInput
    ): ExamQuestionExtractionResult = extract(input, ExamType.WRITTEN)

    override suspend fun extract(
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamQuestionExtractionResult = extractInternal(null, input, examType)

    override suspend fun extractForExam(
        examDraftId: Long,
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamQuestionExtractionResult = extractInternal(examDraftId, input, examType)

    private suspend fun extractInternal(
        examDraftId: Long?,
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamQuestionExtractionResult {
        if (examType == ExamType.MULTIPLE_CHOICE) {
            // Test structure is teacher-defined locally; no Gemini/API call is allowed.
            return ExamQuestionExtractionResult.InvalidInput
        }
        when (input) {
            is ExamExtractionInput.Text -> {
                if (input.text.isBlank()) return ExamQuestionExtractionResult.InvalidInput
            }
            is ExamExtractionInput.WordExtracted -> {
                if (input.parts.isEmpty()) return ExamQuestionExtractionResult.InvalidInput
            }
            is ExamExtractionInput.Pdf -> {
                if (input.bytes.isEmpty()) return ExamQuestionExtractionResult.InvalidInput
            }
            is ExamExtractionInput.Images -> {
                if (input.images.isEmpty()) return ExamQuestionExtractionResult.InvalidInput
                for (img in input.images) {
                    if (img.bytes.isEmpty()) return ExamQuestionExtractionResult.InvalidInput
                    val mime = img.mimeType.lowercase()
                    if (mime != "image/jpeg" && mime != "image/jpg" && mime != "image/png" && mime != "image/webp") {
                        return ExamQuestionExtractionResult.InvalidInput
                    }
                }
            }
        }

        val result = try {
            apiKeyStore.useApiKey { apiKey ->
                if (apiKey.isBlank()) {
                    return@useApiKey ExamQuestionExtractionResult.MissingApiKey
                }

                val instructionText = extractionInstruction(examType)
                val profileSnapshot = GeminiModelRegistry.currentProfile()
                val requestedAuthoringModel = profileSnapshot.authoringModel
                GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)

                val inputItems = buildJsonArray {
                    when (input) {
                        is ExamExtractionInput.Text -> {
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", input.text)
                            })
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", instructionText)
                            })
                        }
                        is ExamExtractionInput.WordExtracted -> {
                            for (part in input.parts) {
                                when (part) {
                                    is ExamExtractionInput.WordPart.TextPart -> {
                                        if (part.text.isNotBlank()) {
                                            add(buildJsonObject {
                                                put("type", "text")
                                                put("text", part.text)
                                            })
                                        }
                                    }
                                    is ExamExtractionInput.WordPart.ImagePart -> {
                                        val base64Image = Base64.getEncoder().encodeToString(part.image.bytes)
                                        add(buildJsonObject {
                                            put("type", "inline_data")
                                            put("mime_type", part.image.mimeType)
                                            put("data", base64Image)
                                        })
                                    }
                                }
                            }
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", instructionText)
                            })
                        }
                        is ExamExtractionInput.Pdf -> {
                            val base64Pdf = Base64.getEncoder().encodeToString(input.bytes)
                            add(buildJsonObject {
                                put("type", "document")
                                put("mime_type", "application/pdf")
                                put("data", base64Pdf)
                                put("resolution", "medium")
                            })
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", instructionText)
                            })
                        }
                        is ExamExtractionInput.Images -> {
                            for (img in input.images) {
                                val base64Image = Base64.getEncoder().encodeToString(img.bytes)
                                add(buildJsonObject {
                                    put("type", "image")
                                    put("mime_type", img.mimeType)
                                    put("data", base64Image)
                                    put("resolution", "high")
                                })
                            }
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", instructionText)
                            })
                        }
                    }
                }

                val schemaPoints = buildJsonObject {
                    put("type", buildJsonArray {
                        add("integer")
                        add("null")
                    })
                }

                val questionItemProperties = buildJsonObject {
                    put("questionNumber", buildJsonObject { put("type", "string") })
                    put("questionText", buildJsonObject { put("type", "string") })
                    put("points", schemaPoints)
                }

                val questionItemSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", questionItemProperties)
                    put("required", buildJsonArray {
                        add("questionNumber")
                        add("questionText")
                        add("points")
                    })
                    put("additionalProperties", false)
                }

                val questionsArraySchema = buildJsonObject {
                    put("type", "array")
                    put("items", questionItemSchema)
                }

                val topSchema = buildJsonObject {
                    put("type", "object")
                    put("properties", buildJsonObject {
                        put("questions", questionsArraySchema)
                    })
                    put("required", buildJsonArray { add("questions") })
                    put("additionalProperties", false)
                }

                val responseFormat = buildJsonObject {
                    put("type", "text")
                    put("mime_type", "application/json")
                    put("schema", topSchema)
                }

                val requestBodyJson = buildJsonObject {
                    put("model", requestedAuthoringModel)
                    put("store", false)
                    put("system_instruction", extractionSystemInstruction(examType))
                    put("input", inputItems)
                    put("response_format", responseFormat)
                    put("generation_config", buildJsonObject {
                        put("thinking_level", "high")
                    })
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = requestBodyJson.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url(baseUrl)
                    .addHeader("x-goog-api-key", apiKey)
                    .post(body)
                    .build()

                val response = withContext(Dispatchers.IO) {
                    okHttpClient.executeCancellable(request)
                }

                response.use { resp ->
                    if (!resp.isSuccessful) {
                        return@useApiKey when (resp.code) {
                            401, 403 -> ExamQuestionExtractionResult.Unauthorized
                            429 -> ExamQuestionExtractionResult.RateLimited
                            503 -> ExamQuestionExtractionResult.ServiceUnavailable
                            else -> ExamQuestionExtractionResult.UnexpectedFailure
                        }
                    }

                    val responseBodyString = resp.body?.string() ?: ""
                    val jsonResponse = try {
                        jsonParser.parseToJsonElement(responseBodyString).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamQuestionExtractionResult.MalformedResponse
                    }
                    examDraftId?.let { draftId ->
                        runCatching {
                            aiUsageLedger?.recordAuthoring(
                                draftId, "AUTHORING_QUESTION_EXTRACT", requestedAuthoringModel, profileSnapshot,
                                GeminiUsageAuditParser.fromInteractions(jsonResponse)
                            )
                        }
                    }

                    val extractedText = extractModelOutputText(jsonResponse)
                        ?: return@useApiKey ExamQuestionExtractionResult.MalformedResponse

                    val structuredJson = try {
                        jsonParser.parseToJsonElement(extractedText).jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamQuestionExtractionResult.MalformedResponse
                    }

                    val questionsArray = structuredJson["questions"]?.jsonArray
                        ?: return@useApiKey ExamQuestionExtractionResult.MalformedResponse

                    if (questionsArray.isEmpty()) {
                        return@useApiKey ExamQuestionExtractionResult.NoQuestionsFound
                    }

                    val questionsList = mutableListOf<ExtractedExamQuestion>()
                    for (item in questionsArray) {
                        val itemObj = try {
                            item.jsonObject
                        } catch (e: Exception) {
                            return@useApiKey ExamQuestionExtractionResult.MalformedResponse
                        }

                        val qNumber = itemObj["questionNumber"]?.jsonPrimitive?.content ?: ""
                        val qText = itemObj["questionText"]?.jsonPrimitive?.content ?: ""
                        val pointsPrimitive = itemObj["points"]?.jsonPrimitive
                        val points = if (pointsPrimitive == null || pointsPrimitive.content == "null") null
                        else pointsPrimitive.intOrNull

                        questionsList.add(ExtractedExamQuestion(qNumber, qText, points))
                    }

                    if (questionsList.isEmpty()) {
                        return@useApiKey ExamQuestionExtractionResult.NoQuestionsFound
                    }

                    val isAllComplete = questionsList.all { q ->
                        q.questionNumber.isNotBlank() &&
                                q.questionText.isNotBlank() &&
                                q.points != null &&
                                q.points > 0
                    }

                    if (isAllComplete) {
                        ExamQuestionExtractionResult.Complete(questionsList)
                    } else {
                        ExamQuestionExtractionResult.IncompleteExtraction(questionsList)
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            return ExamQuestionExtractionResult.NetworkFailure
        } catch (e: Exception) {
            return ExamQuestionExtractionResult.UnexpectedFailure
        }

        return result ?: ExamQuestionExtractionResult.MissingApiKey
    }

    private fun extractModelOutputText(jsonResponse: kotlinx.serialization.json.JsonObject): String? {
        val steps = jsonResponse["steps"]?.jsonArray ?: return null
        for (stepElem in steps) {
            val step = try { stepElem.jsonObject } catch (e: Exception) { continue }
            if (step["type"]?.jsonPrimitive?.content == "model_output") {
                val content = step["content"]
                if (content != null) {
                    try {
                        val contentArr = content.jsonArray
                        for (itemElem in contentArr) {
                            val item = itemElem.jsonObject
                            if (item["type"]?.jsonPrimitive?.content == "text") {
                                val text = item["text"]?.jsonPrimitive?.content ?: ""
                                if (text.isNotBlank()) return text
                            }
                        }
                    } catch (e: Exception) {
                        try {
                            val item = content.jsonObject
                            if (item["type"]?.jsonPrimitive?.content == "text") {
                                val text = item["text"]?.jsonPrimitive?.content ?: ""
                                if (text.isNotBlank()) return text
                            }
                        } catch (ignored: Exception) {}
                    }
                }
                val textDirect = step["text"]?.jsonPrimitive?.content ?: ""
                if (textDirect.isNotBlank()) return textDirect
            }
        }
        return null
    }
}
