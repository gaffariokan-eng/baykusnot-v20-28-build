package com.example.core.data

import com.example.core.network.ExamRubricGenerator
import com.example.core.network.ExamRubricGenerationResult

class ExamRubricGenerationInvoker(
    private val generator: ExamRubricGenerator
) {
    suspend fun generate(
        ready: ExamRubricGenerationPreflightResult.Ready
    ): ExamRubricGenerationResult {
        val input = ExamRubricGenerationInputMapper.map(ready)
        return generator.generate(input)
    }
}
