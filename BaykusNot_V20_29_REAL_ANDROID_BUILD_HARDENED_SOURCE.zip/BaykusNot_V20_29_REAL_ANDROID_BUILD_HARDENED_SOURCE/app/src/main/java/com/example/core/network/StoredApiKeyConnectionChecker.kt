package com.example.core.network

import com.example.core.security.SecureApiKeyStore

class StoredApiKeyConnectionChecker(
    private val secureApiKeyStore: SecureApiKeyStore,
    private val connectionTester: GeminiConnectionTester
) {
    suspend fun testStoredApiKey(): ConnectionTestResult? {
        return secureApiKeyStore.useApiKey { apiKey ->
            connectionTester.testConnection(apiKey)
        }
    }
}
