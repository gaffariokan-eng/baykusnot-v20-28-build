package com.example.core.model

enum class FeedbackDetailLevel(
    val level: Int,
    val displayName: String,
    val description: String
) {
    SCORE_ONLY(
        level = 0,
        displayName = "Yok",
        description = "Yalnızca puan gösterilir; öğrenciye açıklamalı dönüt yazılmaz."
    ),

    BRIEF(
        level = 1,
        displayName = "Kısa",
        description = "En önemli doğru nokta veya geliştirme ihtiyacı tek kısa cümleyle belirtilir."
    ),

    INSTRUCTIONAL(
        level = 2,
        displayName = "Standart",
        description = "Yanlış ve kısmen doğru cevaplarda neden puan kırıldığı ve neyin geliştirilmesi gerektiği kısa ve öğretici biçimde açıklanır."
    ),

    DETAILED(
        level = 3,
        displayName = "Ayrıntılı",
        description = "Soru bazında puan gerekçesi, doğru/eksik noktalar ve somut geliştirme önerileri ayrıntılı verilir."
    )
}
