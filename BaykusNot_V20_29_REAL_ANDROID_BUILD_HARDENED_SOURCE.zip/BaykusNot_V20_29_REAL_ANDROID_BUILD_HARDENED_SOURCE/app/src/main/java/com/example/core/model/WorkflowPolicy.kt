package com.example.core.model

/**
 * Type-aware workflow policy for the shared evaluation pipeline.
 *
 * Homework submissions are existing student work, so HOMEWORK skips ANSWER_SHEET.
 * Multiple-choice tests are teacher-defined from a local answer key plus local
 * optical reading. MULTIPLE_CHOICE therefore skips blank-source upload, AI question
 * extraction and AI evaluation preferences while keeping the standard BaykuşNot
 * answer-form/upload/review/report pipeline.
 */
fun ExamType.workflowStages(): List<WorkflowStage> =
    WorkflowStage.values()
        .sortedBy { it.order }
        .filterNot {
            this == ExamType.HOMEWORK && it in setOf(
                WorkflowStage.QUESTION_POINTS,
                WorkflowStage.RUBRIC,
                WorkflowStage.ANSWER_SHEET,
                WorkflowStage.READING_PREFS
            )
        }
        .filterNot {
            this == ExamType.MULTIPLE_CHOICE && it in setOf(
                WorkflowStage.UPLOAD_SOURCE,
                WorkflowStage.QUESTION_POINTS,
                WorkflowStage.READING_PREFS
            )
        }

fun ExamType.isWorkflowStageSupported(stage: WorkflowStage): Boolean =
    stage in workflowStages()

fun ExamType.stageAfterRubric(): WorkflowStage =
    if (this == ExamType.HOMEWORK) WorkflowStage.UPLOAD_PAPERS else WorkflowStage.ANSWER_SHEET

fun ExamType.workflowStageLabel(stage: WorkflowStage): String = when (stage) {
    WorkflowStage.EXAM_INFO -> when (this) {
        ExamType.HOMEWORK -> "Ödev Bilgileri"
        ExamType.READINESS -> "Hazırbulunuşluk Bilgileri"
        ExamType.MULTIPLE_CHOICE -> "Test Sınavı Bilgileri"
        else -> "Sınav Bilgileri"
    }
    WorkflowStage.UPLOAD_SOURCE -> sourceStageLabel()
    WorkflowStage.QUESTION_POINTS -> when (this) {
        ExamType.HOMEWORK -> "Görevler"
        ExamType.READINESS -> "Hazırbulunuşluk Soruları"
        ExamType.MULTIPLE_CHOICE -> "Test Soruları"
        else -> "Sorular"
    }
    WorkflowStage.RUBRIC -> when (this) {
        ExamType.HOMEWORK -> "Ödev Değerlendirmesi"
        ExamType.READINESS -> "Tanılayıcı Rubrik"
        ExamType.MULTIPLE_CHOICE -> "Cevap Anahtarı"
        else -> "Rubrik"
    }
    WorkflowStage.ANSWER_SHEET -> when (this) {
        ExamType.READINESS -> "Hazırbulunuşluk Cevap Kâğıdı"
        ExamType.MULTIPLE_CHOICE -> "Test Cevap Kâğıdı"
        else -> "Cevap Kâğıdı"
    }
    WorkflowStage.UPLOAD_PAPERS -> when (this) {
        ExamType.HOMEWORK -> "Ödev Teslimleri"
        ExamType.READINESS -> "Hazırbulunuşluk Kâğıtları"
        ExamType.MULTIPLE_CHOICE -> "Test Cevap Kâğıtları"
        else -> "Öğrenci Kâğıtları"
    }
    WorkflowStage.READING_PREFS -> when (this) {
        ExamType.READINESS -> "Tanılayıcı Tercihler"
        ExamType.MULTIPLE_CHOICE -> "Test Ayarları"
        else -> "Tercihler"
    }
    WorkflowStage.AI_EVALUATION -> when (this) {
        ExamType.READINESS -> "Tanılayıcı Değerlendirme"
        ExamType.MULTIPLE_CHOICE -> "Yerel Optik Okuma"
        else -> "Değerlendirme"
    }
    WorkflowStage.TEACHER_REVIEW -> when (this) {
        ExamType.READINESS -> "Hazırbulunuşluk İncelemesi"
        ExamType.MULTIPLE_CHOICE -> "Test İncelemesi"
        else -> "Öğretmen İncelemesi"
    }
    WorkflowStage.REPORTS -> when (this) {
        ExamType.READINESS -> "Tanılayıcı Raporlar"
        ExamType.MULTIPLE_CHOICE -> "Test Raporları"
        else -> "Raporlar"
    }
}
