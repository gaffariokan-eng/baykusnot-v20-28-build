package com.example.feature.workflow

import com.example.core.model.ExamRubricCriterion

data class RubricEditableMapping(
    val editableCriteria: List<EditableExamRubricCriterion>,
    val nextLocalId: Long
)

object RubricEditableMapper {

    fun map(
        criteria: List<ExamRubricCriterion>,
        firstLocalId: Long
    ): RubricEditableMapping {
        require(firstLocalId > 0L) {
            "firstLocalId must be positive"
        }
        if (Long.MAX_VALUE - firstLocalId < criteria.size) {
            throw IllegalArgumentException("Local ID overflow")
        }

        val editableCriteria = criteria.mapIndexed { index, criterion ->
            EditableExamRubricCriterion(
                localId = firstLocalId + index,
                persistedId = criterion.id,
                questionOrderIndex = criterion.questionOrderIndex,
                questionNumberSnapshot = criterion.questionNumberSnapshot,
                criterionOrderIndex = criterion.criterionOrderIndex,
                title = criterion.title,
                description = criterion.description,
                maxPointsText = criterion.maxPoints.toString(),
                expectedAnswer = criterion.expectedAnswer,
                partialCreditGuidance = criterion.partialCreditGuidance,
                commonMistakes = criterion.commonMistakes
            )
        }

        val nextLocalId = firstLocalId + criteria.size

        return RubricEditableMapping(
            editableCriteria = editableCriteria,
            nextLocalId = nextLocalId
        )
    }
}
