package com.example.core.data

import com.example.core.database.TeacherProfileDao
import com.example.core.database.TeacherProfileEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class TeacherProfileRepository(
    private val dao: TeacherProfileDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    val profile: Flow<TeacherProfileEntity?> = dao.getProfile()

    suspend fun getProfileOnce(): TeacherProfileEntity? = withContext(ioDispatcher) {
        dao.getProfileOnce()
    }

    suspend fun saveProfile(profile: TeacherProfileEntity) = withContext(ioDispatcher) {
        dao.insertOrUpdateProfile(profile.copy(updatedAt = System.currentTimeMillis()))
    }
}
