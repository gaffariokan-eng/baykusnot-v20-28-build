package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Persistent provenance/control for an exam's evaluation path.
 * MANUAL is fail-closed: no evaluation, second-read or final-feedback AI call may run until the
 * teacher explicitly re-enables AI for this exam.
 */
@Entity(
    tableName = "exam_processing_mode",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamProcessingModeEntity(
    @PrimaryKey val examDraftId: Long,
    val evaluationSource: String = "AI", // AI | MANUAL | LOCAL_OPTICAL
    val feedbackSource: String = "AI",   // AI | NONE
    val changedAt: Long = System.currentTimeMillis(),
    val reason: String? = null
)
