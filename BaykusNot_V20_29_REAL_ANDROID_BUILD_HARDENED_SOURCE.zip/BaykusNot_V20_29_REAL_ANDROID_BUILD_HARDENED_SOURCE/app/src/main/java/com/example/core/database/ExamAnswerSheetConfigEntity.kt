package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_answer_sheet_config",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamAnswerSheetConfigEntity(
    @PrimaryKey val examDraftId: Long,
    val studentCount: Int = 20,
    val layoutDensity: String = "AUTOMATIC",
    val layoutVersion: Int = 2,
    val isGenerated: Boolean = false,
    val pdfPath: String? = null,
    val generatedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
