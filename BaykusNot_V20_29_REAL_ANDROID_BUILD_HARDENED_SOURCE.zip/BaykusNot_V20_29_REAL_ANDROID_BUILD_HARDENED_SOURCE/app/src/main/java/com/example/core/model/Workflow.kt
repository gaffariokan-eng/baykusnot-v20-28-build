package com.example.core.model

enum class WorkflowStage(val order: Int) {
    EXAM_INFO(1),           // Sınav bilgileri
    UPLOAD_SOURCE(2),       // Sınav kaynağını yükleme
    QUESTION_POINTS(3),     // Soru ve puan kontrolü
    RUBRIC(4),              // Rubrik
    ANSWER_SHEET(5),        // Cevap kâğıdı
    UPLOAD_PAPERS(6),       // Öğrenci kâğıtlarını yükleme
    READING_PREFS(7),       // Okuma tercihleri
    AI_EVALUATION(8),       // Yapay zekâ değerlendirmesi
    TEACHER_REVIEW(9),      // Öğretmen incelemesi
    REPORTS(10)             // Raporlar
}

enum class WorkflowState {
    NOT_STARTED,    // Başlanmadı
    IN_PROGRESS,    // Devam ediyor
    COMPLETED,      // Tamamlandı
    LOCKED,         // Kilitli
    ERROR           // Sorun var
}
