package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ExamAnswerSheetConfigDao {
    @Query("SELECT * FROM exam_answer_sheet_config WHERE examDraftId = :examDraftId")
    suspend fun getConfig(examDraftId: Long): ExamAnswerSheetConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConfig(config: ExamAnswerSheetConfigEntity)
}
