package com.example.core.data

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

internal enum class ExamDeletionStage { PREPARED, COMMITTED }

internal data class ExamDeletionIntent(
    val examId: Long,
    val pageIds: List<Long>,
    val stage: ExamDeletionStage
)

/** Crash-safe local journal for destructive exam deletion. */
internal class ExamDeletionJournal(context: Context) {
    private val dir = File(context.filesDir, "exam_delete_journal").apply { mkdirs() }

    fun prepare(examId: Long, pageIds: List<Long>) {
        write(ExamDeletionIntent(examId, pageIds.distinct(), ExamDeletionStage.PREPARED))
    }

    fun markCommitted(examId: Long) {
        val current = read(examId) ?: error("DELETE_JOURNAL_MISSING")
        write(current.copy(stage = ExamDeletionStage.COMMITTED))
    }

    fun read(examId: Long): ExamDeletionIntent? = readFile(fileFor(examId))

    fun all(): List<ExamDeletionIntent> =
        dir.listFiles { f -> f.isFile && f.name.startsWith("exam_") && f.name.endsWith(".json") }
            ?.mapNotNull(::readFile)
            .orEmpty()

    fun clear(examId: Long): Boolean {
        val f = fileFor(examId)
        return !f.exists() || f.delete()
    }

    private fun write(intent: ExamDeletionIntent) {
        val payload = JSONObject()
            .put("examId", intent.examId)
            .put("stage", intent.stage.name)
            .put("pageIds", JSONArray(intent.pageIds))
            .toString()
        val atomic = AtomicFile(fileFor(intent.examId))
        val out = atomic.startWrite()
        try {
            out.write(payload.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
        check(read(intent.examId) == intent) { "DELETE_JOURNAL_VERIFY_FAILED" }
    }

    private fun readFile(file: File): ExamDeletionIntent? = runCatching {
        val obj = JSONObject(AtomicFile(file).readFully().toString(Charsets.UTF_8))
        val pages = obj.getJSONArray("pageIds")
        ExamDeletionIntent(
            examId = obj.getLong("examId"),
            pageIds = List(pages.length()) { i -> pages.getLong(i) },
            stage = ExamDeletionStage.valueOf(obj.getString("stage"))
        )
    }.getOrNull()

    private fun fileFor(examId: Long) = File(dir, "exam_${examId}.json")
}
