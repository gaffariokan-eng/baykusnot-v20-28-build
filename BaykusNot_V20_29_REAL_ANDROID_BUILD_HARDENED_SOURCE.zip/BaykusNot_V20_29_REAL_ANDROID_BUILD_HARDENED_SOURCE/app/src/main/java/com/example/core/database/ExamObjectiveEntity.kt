package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_objective",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("examDraftId")
    ]
)
data class ExamObjectiveEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val examDraftId: Long,
    val learningArea: String?,
    val objectiveCode: String?,
    val objectiveText: String,
    val notes: String?,
    val expectedQuestionCount: Int?,
    val isStaging: Boolean = false
)

@Entity(
    tableName = "question_objective_cross_ref",
    primaryKeys = ["questionId", "objectiveId"],
    foreignKeys = [
        ForeignKey(
            entity = ExamQuestionEntity::class,
            parentColumns = ["id"],
            childColumns = ["questionId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ExamObjectiveEntity::class,
            parentColumns = ["id"],
            childColumns = ["objectiveId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("objectiveId"),
        Index("questionId")
    ]
)
data class QuestionObjectiveCrossRef(
    val questionId: Long,
    val objectiveId: Long
)
