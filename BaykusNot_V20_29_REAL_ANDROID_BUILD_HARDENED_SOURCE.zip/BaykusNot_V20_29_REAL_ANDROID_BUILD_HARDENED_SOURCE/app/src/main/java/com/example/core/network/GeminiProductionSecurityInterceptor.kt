package com.example.core.network

import com.example.BuildConfig
import com.example.core.security.GatewayAuthTokenStore
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.IOException

/** Production transport boundary for Gemini. */
class GeminiProductionSecurityInterceptor(
    private val gatewayAuthTokenStore: GatewayAuthTokenStore? = null,
    private val gatewaySessionManager: GatewaySessionManager? = null
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!request.url.host.equals(GEMINI_HOST, ignoreCase = true)) {
            return chain.proceed(request)
        }

        val gateway = BuildConfig.AI_GATEWAY_BASE_URL.trim().trimEnd('/').toHttpUrlOrNull()
        if (gateway != null) {
            if (!BuildConfig.ALLOW_DIRECT_GEMINI && gateway.scheme != "https") {
                throw IOException("Production AI gateway yalnız HTTPS üzerinden kullanılabilir.")
            }
            val original = request.url
            val pathPrefix = gateway.encodedPath.trimEnd('/')
            val rewrittenUrl = original.newBuilder()
                .scheme(gateway.scheme)
                .host(gateway.host)
                .port(gateway.port)
                .encodedPath(pathPrefix + original.encodedPath)
                .removeAllQueryParameters("key")
                .build()

            fun validTokenOrRefresh(): String? {
                gatewayAuthTokenStore?.bearerToken()?.let { return it }
                val manager = gatewaySessionManager ?: return null
                return runCatching { runBlocking { manager.ensureValidSession() } }.getOrNull()
            }

            val token = validTokenOrRefresh()
            if (!BuildConfig.ALLOW_DIRECT_GEMINI && token.isNullOrBlank()) {
                throw IOException("Production AI gateway kimlik oturumu yok. Kurumsal eşleştirme ve kısa ömürlü gateway tokenı doğrulanmadan öğrenci verisi gönderilemez.")
            }

            fun authenticatedRequest(accessToken: String?): okhttp3.Request {
                val builder = request.newBuilder()
                    .url(rewrittenUrl)
                    .removeHeader("x-goog-api-key")
                    .removeHeader("Authorization")
                    .header("X-BaykusNot-Upstream", "gemini")
                if (!accessToken.isNullOrBlank()) builder.header("Authorization", "Bearer $accessToken")
                return builder.build()
            }

            val first = chain.proceed(authenticatedRequest(token))
            val sessionManager = gatewaySessionManager
            if (first.code != 401 || sessionManager == null || BuildConfig.ALLOW_DIRECT_GEMINI) {
                return first
            }

            // A gateway may expire/revoke a token slightly before the client TTL. Retry exactly once
            // with a fresh session; never loop on authentication failures.
            first.close()
            gatewayAuthTokenStore?.clear()
            val refreshed = runCatching { runBlocking { sessionManager.ensureValidSession() } }.getOrNull()
                ?: throw IOException("Gateway oturumu yenilenemedi; öğrenci verisi gönderimi durduruldu.")
            return chain.proceed(authenticatedRequest(refreshed))
        }

        if (BuildConfig.ALLOW_DIRECT_GEMINI) {
            return chain.proceed(request)
        }

        throw IOException(
            "Production AI gateway yapılandırılmamış. Release sürümünde Gemini API anahtarı " +
                "mobil istemciden doğrudan kullanılamaz."
        )
    }

    companion object {
        private const val GEMINI_HOST = "generativelanguage.googleapis.com"
    }
}
