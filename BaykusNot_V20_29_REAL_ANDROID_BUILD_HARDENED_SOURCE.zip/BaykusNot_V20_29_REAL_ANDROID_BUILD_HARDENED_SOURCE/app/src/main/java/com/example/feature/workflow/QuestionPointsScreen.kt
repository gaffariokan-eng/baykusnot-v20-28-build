package com.example.feature.workflow

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.ExamType
import com.example.core.model.QuestionPointsValidationCode
import com.example.core.model.QuestionPointsValidationIssue
import com.example.core.database.ExamObjectiveEntity
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.StatusType
import com.example.ui.theme.WiseAmberSecondary

internal object QuestionPointsTestTags {
    const val CONTENT = "question_points_content"
    const val LOADING = "question_points_loading"
    const val NOT_FOUND = "question_points_not_found"
    const val SUMMARY_CARD = "question_points_summary_card"
    const val EXPECTED_POINTS = "question_points_expected_points"
    const val CALCULATED_POINTS = "question_points_calculated_points"
    const val REMAINING_POINTS = "question_points_remaining_points"
    const val EMPTY_STATE = "question_points_empty_state"
    const val ADD_QUESTION_BUTTON = "question_points_add_question_button"
    const val MESSAGE = "question_points_message"
    const val DISMISS_MESSAGE_BUTTON = "question_points_dismiss_message_button"
    const val VALIDATION_PANEL = "question_points_validation_panel"
    const val ACTION_PANEL = "question_points_action_panel"
    const val SAVE_BUTTON = "question_points_save_button"
    const val LOCK_BUTTON = "question_points_lock_button"
    const val LOCKED_ACTION_PANEL = "question_points_locked_action_panel"
    const val UNLOCK_BUTTON = "question_points_unlock_button"
    const val CONTINUE_BUTTON = "question_points_continue_button"
    const val LISTENING_CONTEXT_CARD = "question_points_listening_context_card"
    const val LISTENING_TRANSCRIPT = "question_points_listening_transcript"
    const val LISTENING_TRANSCRIPT_TOGGLE = "question_points_listening_transcript_toggle"
    const val LISTENING_NOT_READY = "question_points_listening_not_ready"

    fun validationIssue(index: Int): String =
        "question_points_validation_issue_$index"

    fun questionCard(localId: Long): String = "question_points_question_card_$localId"
    fun questionNumberInput(localId: Long): String = "question_points_question_number_$localId"
    fun questionTextInput(localId: Long): String = "question_points_question_text_$localId"
    fun questionPointsInput(localId: Long): String = "question_points_question_points_$localId"
    fun moveUpButton(localId: Long): String = "question_points_move_up_$localId"
    fun moveDownButton(localId: Long): String = "question_points_move_down_$localId"
    fun removeButton(localId: Long): String = "question_points_remove_$localId"
    fun pointsIssue(localId: Long): String = "question_points_points_issue_$localId"
}

private fun QuestionPointsValidationIssue.userMessage(examType: ExamType): String =
    when (code) {
        QuestionPointsValidationCode.INVALID_TARGET_DRAFT_ID ->
            "Sınav taslağı geçersiz. Geçerli bir sınav taslağı açın."

        QuestionPointsValidationCode.INVALID_EXPECTED_TOTAL_POINTS ->
            "Hedef toplam puan sıfırdan büyük olmalıdır."

        QuestionPointsValidationCode.EMPTY_QUESTION_LIST ->
            if (examType == ExamType.HOMEWORK) "Görev seti boş olamaz. En az bir görev/madde ekleyin." else "Soru seti boş olamaz. En az bir soru ekleyin."

        QuestionPointsValidationCode.QUESTION_DRAFT_MISMATCH ->
            if (examType == ExamType.HOMEWORK) "Bir veya daha fazla görev/madde farklı bir ödev taslağına bağlı." else "Bir veya daha fazla soru farklı bir sınav taslağına bağlı."

        QuestionPointsValidationCode.INVALID_ORDER_INDEX ->
            if (examType == ExamType.HOMEWORK) "Görev/madde sıraları 1 veya daha büyük olmalıdır." else "Soru sıraları 1 veya daha büyük olmalıdır."

        QuestionPointsValidationCode.BLANK_QUESTION_NUMBER ->
            if (examType == ExamType.HOMEWORK) "Bütün görev/maddelerin madde numarası doldurulmalıdır." else "Bütün soruların soru numarası doldurulmalıdır."

        QuestionPointsValidationCode.BLANK_QUESTION_TEXT ->
            if (examType == ExamType.HOMEWORK) "Bütün görev/maddelerin metni doldurulmalıdır." else "Bütün soruların soru metni doldurulmalıdır."

        QuestionPointsValidationCode.NON_POSITIVE_POINTS ->
            if (examType == ExamType.HOMEWORK) "Bütün görev/madde puanları sıfırdan büyük olmalıdır." else "Bütün soru puanları sıfırdan büyük olmalıdır."

        QuestionPointsValidationCode.DUPLICATE_ORDER_INDEX ->
            if (examType == ExamType.HOMEWORK) "Aynı görev/madde sırası birden fazla maddede kullanılamaz." else "Aynı soru sırası birden fazla soruda kullanılamaz."

        QuestionPointsValidationCode.DUPLICATE_QUESTION_NUMBER ->
            if (examType == ExamType.HOMEWORK) "Aynı madde numarası birden fazla görevde kullanılamaz." else "Aynı soru numarası birden fazla soruda kullanılamaz."

        QuestionPointsValidationCode.TOTAL_POINTS_MISMATCH ->
            "Hesaplanan toplam puan hedef puan ile eşleşmelidir."
    }

private fun QuestionPointsInputIssue.userMessage(): String {
    return when (code) {
        QuestionPointsInputIssueCode.BLANK_POINTS -> "Puan alanı boş bırakılamaz."
        QuestionPointsInputIssueCode.INVALID_POINTS_FORMAT -> "Puan geçerli bir sayı olmalıdır."
        QuestionPointsInputIssueCode.POINTS_OUT_OF_RANGE -> "Puan izin verilen aralığın dışında."
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
internal fun QuestionPointsContent(
    uiState: QuestionPointsUiState,
    onAddQuestion: () -> Unit,
    onRemoveQuestion: (Long) -> Unit,
    onMoveQuestionUp: (Long) -> Unit,
    onMoveQuestionDown: (Long) -> Unit,
    onQuestionNumberChange: (Long, String) -> Unit,
    onQuestionTextChange: (Long, String) -> Unit,
    onQuestionPointsChange: (Long, String) -> Unit,
    onSave: () -> Unit,
    onLock: () -> Unit,
    onUnlock: () -> Unit,
    onContinue: () -> Unit,
    onDismissMessage: () -> Unit,
    onSuggestObjectives: () -> Unit = {},
    onApproveObjectivesMapping: () -> Unit = {},
    onToggleObjective: (Long, Long) -> Unit = { _, _ -> },
    onAcceptMismatch: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val copy = questionPointsCopy(uiState.examType)

    if (uiState.isLoading) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .testTag(QuestionPointsTestTags.LOADING),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(16.dp))
                Text(copy.loadingText)
            }
        }
        return
    }

    if (!uiState.draftExists) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .testTag(QuestionPointsTestTags.NOT_FOUND),
            contentAlignment = Alignment.Center
        ) {
            Text(copy.missingDraftText)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag(QuestionPointsTestTags.CONTENT),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = copy.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Text(
                    text = copy.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Modern status chip overview line
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    BaykusStatusChip(
                        text = "${copy.countLabel}: ${uiState.editableQuestions.size}",
                        type = StatusType.INFO
                    )
                    
                    if (uiState.isLocked) {
                        BaykusStatusChip(
                            text = "Kilitli",
                            type = StatusType.SUCCESS
                        )
                    } else {
                        BaykusStatusChip(
                            text = "Düzenlenebilir",
                            type = StatusType.WARNING
                        )
                    }
                }
            }
        }

        if (uiState.examType == ExamType.LISTENING) {
            item {
                var transcriptExpanded by rememberSaveable(uiState.draftId) { mutableStateOf(false) }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(QuestionPointsTestTags.LISTENING_CONTEXT_CARD),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Dinleme Kaynağı",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            BaykusStatusChip(
                                text = if (uiState.isListeningMaterialReady) "Kaynak Hazır" else "Kaynak Eksik",
                                type = if (uiState.isListeningMaterialReady) StatusType.SUCCESS else StatusType.WARNING
                            )
                        }

                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (uiState.hasListeningAudio) {
                                BaykusStatusChip(text = "Ses dosyası", type = StatusType.INFO)
                            }
                            if (uiState.listeningTranscript.isNotBlank()) {
                                BaykusStatusChip(text = "Dinleme metni", type = StatusType.INFO)
                            }
                            BaykusStatusChip(
                                text = "${uiState.listeningPlaybackCount} kez dinletme",
                                type = StatusType.INFO
                            )
                            if (uiState.listeningInstructions.isNotBlank()) {
                                BaykusStatusChip(
                                    text = "Sınav yönergesi var",
                                    type = StatusType.INFO
                                )
                            }
                        }

                        if (!uiState.isListeningMaterialReady) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag(QuestionPointsTestTags.LISTENING_NOT_READY),
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.errorContainer
                            ) {
                                Text(
                                    text = "Dinleme kaynağı eksik. Ses dosyası veya dinleme metni ekleyip Dinleme Materyali aşamasını tamamlayın.",
                                    modifier = Modifier.padding(10.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }

                        if (uiState.listeningTranscript.isNotBlank()) {
                            Text(
                                text = uiState.listeningTranscript,
                                modifier = Modifier.testTag(QuestionPointsTestTags.LISTENING_TRANSCRIPT),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = if (transcriptExpanded) Int.MAX_VALUE else 6,
                                overflow = TextOverflow.Ellipsis
                            )
                            TextButton(
                                onClick = { transcriptExpanded = !transcriptExpanded },
                                modifier = Modifier.testTag(QuestionPointsTestTags.LISTENING_TRANSCRIPT_TOGGLE)
                            ) {
                                Text(if (transcriptExpanded) "Metni daralt" else "Metnin tamamını göster")
                            }
                        } else {
                            Text(
                                text = if (uiState.hasListeningAudio)
                                    "Ses dosyası dinleme kaynağı olarak kullanılıyor; ayrıca metin girmeniz zorunlu değildir."
                                else
                                    "Dinleme kaynağı henüz eklenmedi.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (uiState.listeningInstructions.isNotBlank()) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Text(
                                text = "Sınav yönergesi",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = uiState.listeningInstructions,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            val isMatching = uiState.remainingPoints == 0L
            val cardBg = if (isMatching) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f)
            } else {
                MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
            }
            val strokeColor = if (isMatching) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
            } else {
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)
            }
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(QuestionPointsTestTags.SUMMARY_CARD),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.5.dp, strokeColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Sınav Puan Dengesi",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isMatching) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Beklenen Puan",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${uiState.expectedTotalPoints}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag(QuestionPointsTestTags.EXPECTED_POINTS)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(24.dp)
                                .width(1.dp)
                                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Mevcut Toplam",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${uiState.calculatedTotalPoints}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag(QuestionPointsTestTags.CALCULATED_POINTS)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(24.dp)
                                .width(1.dp)
                                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Kalan Fark",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${uiState.remainingPoints}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isMatching) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.testTag(QuestionPointsTestTags.REMAINING_POINTS)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isMatching) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (isMatching) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (isMatching) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isMatching) {
                                    "Puan dağılımı hedef toplamla eşleşiyor."
                                } else if (uiState.remainingPoints > 0L) {
                                    "${uiState.remainingPoints} puan eksik."
                                } else {
                                    "${-uiState.remainingPoints} puan fazla."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isMatching) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
        }


        if (uiState.objectives != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                copy.objectiveSectionTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            
                            val isFullyMapped = uiState.isObjectivesMappingValid
                            if (!isFullyMapped) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.errorContainer
                                ) {
                                    Text(
                                        "Eşleşme Eksik",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.tertiaryContainer
                                ) {
                                    Text(
                                        "Eşleşme Tamam",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                        
                        Text(
                            copy.objectiveDescription,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        // Mapping alert
                        val isFullyMapped = uiState.isObjectivesMappingValid
                        if (!isFullyMapped) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(copy.objectiveMissingText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(copy.objectiveCompleteText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                                }
                            }
                        }
                        
                        // Warning if mismatch
                        val expectedTotalCount = uiState.objectives?.sumOf { it.expectedQuestionCount ?: 0 } ?: 0
                        val actualTotalCount = uiState.editableQuestions.size
                        var anyMismatch = expectedTotalCount != actualTotalCount
                        
                        if (expectedTotalCount != actualTotalCount && uiState.objectives?.isNotEmpty() == true) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Senaryoda beklenen toplam soru sayısı: $expectedTotalCount, Mevcut soru sayısı: $actualTotalCount", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                        }
 
                        val counts = uiState.objectives?.associate { it.id to 0L }?.toMutableMap() ?: mutableMapOf()
                        uiState.editableQuestions.forEach { eq ->
                            eq.selectedObjectiveIds.forEach { oid -> counts[oid] = (counts[oid] ?: 0L) + 1L }
                        }
                        uiState.objectives?.forEach { obj ->
                            val c = counts[obj.id] ?: 0L
                            if (obj.expectedQuestionCount != null && c != obj.expectedQuestionCount.toLong()) {
                                anyMismatch = true
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("${obj.objectiveCode ?: ""}: Beklenen: ${obj.expectedQuestionCount}, Eşleşen: $c", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    }
                                }
                            }
                        }
 
                        if (anyMismatch) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = uiState.isMismatchAccepted,
                                    onCheckedChange = { onAcceptMismatch(it) },
                                    enabled = !uiState.isLocked
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = copy.objectiveMismatchAcceptText,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedButton(
                                onClick = onSuggestObjectives,
                                enabled = !uiState.isLocked && !uiState.isSuggestingObjectives,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (uiState.isSuggestingObjectives) "Eşleştiriliyor..." else "Otomatik Eşleştir",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            val canApprove = isFullyMapped && !uiState.isLocked && !uiState.hasUnsavedChanges && (!anyMismatch || uiState.isMismatchAccepted)
                            Button(
                                onClick = onApproveObjectivesMapping,
                                enabled = canApprove && !uiState.isObjectiveMappingApproved,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (uiState.isObjectiveMappingApproved) "Eşleşme Onaylandı" else "Eşleşmeyi Onayla",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (uiState.hasUnsavedChanges) {
                            Text("Eşleşmeyi onaylamadan önce değişiklikleri kaydetmelisiniz.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        } else if (!uiState.isObjectiveMappingApproved) {
                            Text(copy.objectiveApprovalRequiredText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        if (uiState.validationIssues.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(QuestionPointsTestTags.VALIDATION_PANEL),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Düzeltilmesi gerekenler",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        uiState.validationIssues.forEachIndexed { index, issue ->
                            Text(
                                text = issue.userMessage(uiState.examType),
                                modifier = Modifier.testTag(
                                    QuestionPointsTestTags.validationIssue(index)
                                ),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }
        }

        itemsIndexed(
            items = uiState.editableQuestions,
            key = { _, question -> question.localId }
        ) { index, question ->
            val controlsEnabled = !uiState.isLocked && !uiState.isSaving && !uiState.isLocking && !uiState.isUnlocking
            val pointsIssue = uiState.inputIssues.firstOrNull { it.localId == question.localId }
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(QuestionPointsTestTags.questionCard(question.localId)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${copy.itemCardPrefix} ${question.orderIndex}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = WiseAmberSecondary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${question.pointsText} Puan",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = question.questionNumber,
                            onValueChange = { onQuestionNumberChange(question.localId, it) },
                            label = { Text(copy.itemNumberLabel) },
                            singleLine = true,
                            enabled = controlsEnabled,
                            modifier = Modifier
                                .weight(1f)
                                .testTag(QuestionPointsTestTags.questionNumberInput(question.localId))
                        )

                        OutlinedTextField(
                            value = question.pointsText,
                            onValueChange = { onQuestionPointsChange(question.localId, it) },
                            label = { Text("Puan Değeri") },
                            singleLine = true,
                            enabled = controlsEnabled,
                            isError = pointsIssue != null,
                            supportingText = if (pointsIssue != null) {
                                {
                                    Text(
                                        text = pointsIssue.userMessage(),
                                        modifier = Modifier.testTag(QuestionPointsTestTags.pointsIssue(question.localId)),
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            } else null,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag(QuestionPointsTestTags.questionPointsInput(question.localId))
                        )
                    }

                    OutlinedTextField(
                        value = question.questionText,
                        onValueChange = { onQuestionTextChange(question.localId, it) },
                        label = { Text(copy.itemTextLabel) },
                        singleLine = false,
                        minLines = 2,
                        enabled = controlsEnabled,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag(QuestionPointsTestTags.questionTextInput(question.localId))
                    )

                    if (uiState.objectives != null && uiState.objectives.isNotEmpty()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = copy.objectiveSelectionTitle,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            androidx.compose.foundation.layout.FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                uiState.objectives.forEach { obj ->
                                    val selected = question.selectedObjectiveIds.contains(obj.id)
                                    androidx.compose.material3.FilterChip(
                                        selected = selected,
                                        onClick = { onToggleObjective(question.localId, obj.id) },
                                        label = { Text(obj.objectiveCode ?: obj.learningArea ?: copy.objectiveFallbackLabel, style = MaterialTheme.typography.bodySmall) },
                                        enabled = controlsEnabled
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onMoveQuestionUp(question.localId) },
                            enabled = controlsEnabled && index > 0,
                            modifier = Modifier.testTag(QuestionPointsTestTags.moveUpButton(question.localId))
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = copy.moveUpDescription,
                                tint = if (controlsEnabled && index > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                            )
                        }
                        IconButton(
                            onClick = { onMoveQuestionDown(question.localId) },
                            enabled = controlsEnabled && index < uiState.editableQuestions.lastIndex,
                            modifier = Modifier.testTag(QuestionPointsTestTags.moveDownButton(question.localId))
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = copy.moveDownDescription,
                                tint = if (controlsEnabled && index < uiState.editableQuestions.lastIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { onRemoveQuestion(question.localId) },
                            enabled = controlsEnabled,
                            modifier = Modifier.testTag(QuestionPointsTestTags.removeButton(question.localId))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = copy.removeDescription,
                                tint = if (controlsEnabled) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                            )
                        }
                    }
                }
            }
        }

        if (uiState.editableQuestions.isEmpty()) {
            item {
                Text(
                    text = copy.emptyStateText,
                    modifier = Modifier.testTag(QuestionPointsTestTags.EMPTY_STATE)
                )
            }
        }

        if (!uiState.isLocked) {
            item {
                Button(
                    onClick = onAddQuestion,
                    enabled = !uiState.isSaving && !uiState.isLocking && !uiState.isUnlocking,
                    modifier = Modifier.testTag(QuestionPointsTestTags.ADD_QUESTION_BUTTON)
                ) {
                    Text(copy.addButtonText)
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val isSaveSuccess = uiState.message != null && (
                        uiState.message == "Sorular kaydedildi." || 
                        uiState.message == "Değişiklikler kaydedildi."
                    )
                    if (uiState.message != null && !isSaveSuccess) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (uiState.message.contains("kaydedildi", ignoreCase = true))
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag(QuestionPointsTestTags.MESSAGE)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (uiState.message == "Sorular kaydedildi.") "Değişiklikler kaydedildi." else uiState.message,
                                    color = if (uiState.message.contains("kaydedildi", ignoreCase = true))
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else
                                        MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = onDismissMessage,
                                    modifier = Modifier.testTag(QuestionPointsTestTags.DISMISS_MESSAGE_BUTTON)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Mesajı kapat",
                                        tint = if (uiState.message.contains("kaydedildi", ignoreCase = true))
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        else
                                            MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }
                    } else if (uiState.hasUnsavedChanges) {
                        Text(
                            text = "⚠️ Kaydedilmemiş değişiklikler var.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    Button(
                        onClick = if (uiState.hasUnsavedChanges) onSave else onLock,
                        enabled = !uiState.isSaving && !uiState.isLocking && (uiState.canSave || uiState.canLock),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .heightIn(min = 52.dp)
                            .testTag(QuestionPointsTestTags.ACTION_PANEL),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            when {
                                uiState.isSaving -> "Kaydediliyor..."
                                uiState.isLocking -> "Onaylanıyor..."
                                else -> "Kaydet ve İlerle"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .testTag(QuestionPointsTestTags.LOCKED_ACTION_PANEL),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onUnlock,
                        enabled = !uiState.isSaving && !uiState.isLocking && !uiState.isUnlocking,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 46.dp)
                            .testTag(QuestionPointsTestTags.UNLOCK_BUTTON),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Düzenlemeye Aç", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onContinue,
                        enabled = uiState.canContinue,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 46.dp)
                            .testTag(QuestionPointsTestTags.CONTINUE_BUTTON),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("İlerle", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
