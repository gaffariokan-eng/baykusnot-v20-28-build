package com.example.core.database

import android.database.sqlite.SQLiteDatabase as FrameworkSQLiteDatabase
import java.io.File
import java.io.FileInputStream
import net.zetetic.database.sqlcipher.SQLiteDatabase

/**
 * Plain Room SQLite -> SQLCipher one-time conversion performed before Room opens the database.
 *
 * V20.10 makes the swap restart-safe. A process/device interruption may leave one of three files:
 * the active DB, `.encrypted.tmp`, or `.plaintext.backup`. Startup recovery resolves those states
 * before Room is allowed to open anything. A verified encrypted DB is never opened while a
 * plaintext backup/WAL/journal is still present.
 */
object DatabaseEncryptionManager {
    private val sqliteHeader = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)

    fun ensureEncrypted(databaseFile: File, passphrase: String) {
        System.loadLibrary("sqlcipher")
        databaseFile.parentFile?.mkdirs()

        val encryptedTemp = File(databaseFile.parentFile, databaseFile.name + ".encrypted.tmp")
        val plaintextBackup = File(databaseFile.parentFile, databaseFile.name + ".plaintext.backup")

        recoverInterruptedMigration(databaseFile, encryptedTemp, plaintextBackup, passphrase)

        if (!databaseFile.exists() || databaseFile.length() == 0L) return
        if (!isPlaintextSqlite(databaseFile)) {
            verifyEncrypted(databaseFile, passphrase)
            requirePlaintextArtifactsRemoved(databaseFile, plaintextBackup)
            return
        }

        // Flush a possible plaintext WAL before exporting.
        runCatching {
            FrameworkSQLiteDatabase.openDatabase(
                databaseFile.absolutePath,
                null,
                FrameworkSQLiteDatabase.OPEN_READWRITE
            ).use { db ->
                db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { cursor ->
                    while (cursor.moveToNext()) Unit
                }
            }
        }.getOrElse { throw IllegalStateException("Plaintext WAL güvenli biçimde checkpoint edilemedi.", it) }

        deleteIfPresentOrFail(encryptedTemp, "Eski geçici şifreli veritabanı")
        // A backup at this point is an unresolved privacy artifact; recovery should have handled it.
        if (plaintextBackup.exists()) {
            throw IllegalStateException("Önceki plaintext veritabanı yedeği temizlenemedi; güvenli geçiş durduruldu.")
        }

        var plaintextDb: SQLiteDatabase? = null
        try {
            plaintextDb = SQLiteDatabase.openDatabase(
                databaseFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.CREATE_IF_NECESSARY
            )
            val oldUserVersion = plaintextDb.rawQuery("PRAGMA user_version", emptyArray<String>()).use { cursor ->
                if (cursor.moveToFirst()) cursor.getInt(0) else 0
            }
            plaintextDb.execSQL(
                "ATTACH DATABASE ? AS encrypted KEY ?;",
                arrayOf(encryptedTemp.absolutePath, passphrase)
            )
            plaintextDb.rawExecSQL("SELECT sqlcipher_export('encrypted');")
            plaintextDb.rawExecSQL("PRAGMA encrypted.user_version = $oldUserVersion;")
            plaintextDb.execSQL("DETACH DATABASE encrypted;")
            plaintextDb.close(); plaintextDb = null

            verifyEncrypted(encryptedTemp, passphrase, expectedUserVersion = oldUserVersion)

            check(databaseFile.renameTo(plaintextBackup)) {
                "Plaintext veritabanı güvenli yedeğe taşınamadı."
            }
            try {
                check(encryptedTemp.renameTo(databaseFile)) {
                    "Şifreli veritabanı etkinleştirilemedi."
                }
                verifyEncrypted(databaseFile, passphrase, expectedUserVersion = oldUserVersion)
                requirePlaintextArtifactsRemoved(databaseFile, plaintextBackup)
            } catch (swapError: Throwable) {
                // If the encrypted active DB was not established, restore the original. If it was
                // established but plaintext cleanup failed, leave both files for startup recovery
                // and fail closed rather than silently opening with a plaintext artifact present.
                if (!databaseFile.exists() && plaintextBackup.exists()) {
                    check(plaintextBackup.renameTo(databaseFile)) {
                        "Kesilen SQLCipher geçişinden sonra plaintext DB geri yüklenemedi."
                    }
                }
                throw swapError
            }
        } catch (t: Throwable) {
            plaintextDb?.close()
            // Do not blindly delete a verified encrypted temp after the original has moved; startup
            // recovery may need it. It is safe to remove only while the original plaintext DB exists.
            if (databaseFile.exists() && isPlaintextSqlite(databaseFile)) {
                deleteIfPresentOrFail(encryptedTemp, "Başarısız şifreli geçiş dosyası")
            }
            throw IllegalStateException(
                "Mevcut BaykuşNot veritabanı SQLCipher'a güvenli biçimde dönüştürülemedi; plaintext DB ile devam edilmedi.",
                t
            )
        }
    }

    private fun recoverInterruptedMigration(
        databaseFile: File,
        encryptedTemp: File,
        plaintextBackup: File,
        passphrase: String
    ) {
        // 1) Active encrypted DB exists: it wins. Verify it, then remove every plaintext artifact.
        if (databaseFile.exists() && !isPlaintextSqlite(databaseFile)) {
            verifyEncrypted(databaseFile, passphrase)
            deleteIfPresentOrFail(encryptedTemp, "Artık geçersiz şifreli geçici DB")
            requirePlaintextArtifactsRemoved(databaseFile, plaintextBackup)
            return
        }

        // 2) Active plaintext DB exists: this is either the original or a successful rollback.
        // A stale backup is duplicate plaintext and must be removed before a new export.
        if (databaseFile.exists() && isPlaintextSqlite(databaseFile)) {
            deleteIfPresentOrFail(plaintextBackup, "Eski plaintext DB yedeği")
            deleteIfPresentOrFail(encryptedTemp, "Eski şifreli geçici DB")
            return
        }

        // 3) No active DB, but encrypted temp exists: prefer a verified encrypted copy. If that
        // temp is corrupt/incomplete and a valid plaintext backup is available, recover the backup
        // and let the normal export run again instead of permanently blocking a recoverable user.
        if (!databaseFile.exists() && encryptedTemp.exists()) {
            val tempVerified = runCatching { verifyEncrypted(encryptedTemp, passphrase) }.isSuccess
            if (tempVerified) {
                check(encryptedTemp.renameTo(databaseFile)) {
                    "Kesilen SQLCipher geçişindeki doğrulanmış şifreli DB etkinleştirilemedi."
                }
                verifyEncrypted(databaseFile, passphrase)
                requirePlaintextArtifactsRemoved(databaseFile, plaintextBackup)
                return
            }
            if (plaintextBackup.exists() && isPlaintextSqlite(plaintextBackup)) {
                deleteIfPresentOrFail(encryptedTemp, "Bozuk/yarım şifreli geçici DB")
                check(plaintextBackup.renameTo(databaseFile)) {
                    "Kesilen SQLCipher geçişindeki sağlam plaintext yedek geri yüklenemedi."
                }
                return
            }
            throw IllegalStateException(
                "Kesilen SQLCipher geçişindeki şifreli geçici DB doğrulanamadı ve güvenli plaintext yedek bulunamadı."
            )
        }

        // 4) No active DB and only plaintext backup remains: restore it, then normal migration runs.
        if (!databaseFile.exists() && plaintextBackup.exists()) {
            check(isPlaintextSqlite(plaintextBackup)) {
                "SQLCipher kurtarma yedeğinin biçimi beklenmiyor; otomatik veri kaybı riski nedeniyle açılış durduruldu."
            }
            check(plaintextBackup.renameTo(databaseFile)) {
                "Kesilen SQLCipher geçişindeki plaintext yedek geri yüklenemedi."
            }
        }
    }

    private fun verifyEncrypted(file: File, passphrase: String, expectedUserVersion: Int? = null) {
        check(file.exists() && file.length() > 0L) { "Doğrulanacak şifreli DB bulunamadı." }
        val db = SQLiteDatabase.openDatabase(
            file.absolutePath,
            passphrase,
            null,
            SQLiteDatabase.OPEN_READWRITE,
            null
        )
        try {
            db.rawQuery("SELECT COUNT(*) FROM sqlite_master", emptyArray<String>()).use { c ->
                check(c.moveToFirst()) { "SQLCipher doğrulama sorgusu başarısız." }
            }
            if (expectedUserVersion != null) {
                db.rawQuery("PRAGMA user_version", emptyArray<String>()).use { c ->
                    check(c.moveToFirst() && c.getInt(0) == expectedUserVersion) {
                        "SQLCipher user_version aktarımı doğrulanamadı."
                    }
                }
            }
        } finally {
            db.close()
        }
    }

    private fun requirePlaintextArtifactsRemoved(databaseFile: File, plaintextBackup: File) {
        deleteIfPresentOrFail(plaintextBackup, "Plaintext veritabanı yedeği")
        listOf("-wal", "-shm", "-journal").forEach { suffix ->
            deleteIfPresentOrFail(File(databaseFile.absolutePath + suffix), "Plaintext SQLite yan dosyası $suffix")
        }
        check(!plaintextBackup.exists()) {
            "Plaintext veritabanı yedeği cihazdan kaldırılamadı; BaykuşNot güvenli biçimde açılmayacak."
        }
    }

    private fun deleteIfPresentOrFail(file: File, label: String) {
        if (file.exists() && !file.delete()) {
            throw IllegalStateException("$label silinemedi: ${file.absolutePath}")
        }
    }

    fun isPlaintextSqlite(file: File): Boolean {
        if (!file.exists() || file.length() < sqliteHeader.size) return false
        val header = ByteArray(sqliteHeader.size)
        FileInputStream(file).use { input ->
            if (input.read(header) != header.size) return false
        }
        return header.contentEquals(sqliteHeader)
    }
}
