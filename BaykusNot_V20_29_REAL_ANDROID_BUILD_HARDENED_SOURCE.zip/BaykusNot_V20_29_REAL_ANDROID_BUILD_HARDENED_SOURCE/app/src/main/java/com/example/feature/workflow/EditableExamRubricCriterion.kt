package com.example.feature.workflow

data class EditableExamRubricCriterion(
    val localId: Long,
    val persistedId: Long,
    val questionOrderIndex: Int,
    val questionNumberSnapshot: String,
    val criterionOrderIndex: Int,
    val title: String,
    val description: String,
    val maxPointsText: String,
    val expectedAnswer: String,
    val partialCreditGuidance: String,
    val commonMistakes: String
)
