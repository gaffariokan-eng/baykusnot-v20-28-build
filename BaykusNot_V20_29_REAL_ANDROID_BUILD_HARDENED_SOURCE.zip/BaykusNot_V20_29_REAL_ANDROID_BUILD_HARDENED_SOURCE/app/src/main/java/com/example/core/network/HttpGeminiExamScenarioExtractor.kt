package com.example.core.network

import com.example.core.database.ExamObjectiveEntity
import com.example.core.model.ExamType
import com.example.core.security.SecureApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.Base64
import kotlin.coroutines.cancellation.CancellationException

class HttpGeminiExamScenarioExtractor(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta/interactions",
    private val aiUsageLedger: AiUsageLedger? = null
) : ExamScenarioExtractor {

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override suspend fun extract(
        draftId: Long,
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamScenarioExtractionResult {
        return apiKeyStore.useApiKey { apiKey ->
            if (apiKey.isBlank()) {
                return@useApiKey ExamScenarioExtractionResult.MissingApiKey
            }

            val isReadiness = examType == ExamType.READINESS
            val profileSnapshot = GeminiModelRegistry.currentProfile()
            val requestedAuthoringModel = profileSnapshot.authoringModel
                GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)
            val instructionText = if (isReadiness) {
                "Aşağıdaki hazırbulunuşluk/ön değerlendirme senaryosu belgesinden konu veya ünite başlamadan önce öğrencide bulunması beklenen ön koşul bilgi ve beceri hedeflerini ve varsa öngörülen soru sayılarını çıkarın. İleri düzey, henüz öğretilmesi planlanan kazanımları ön koşulmuş gibi eklemeyin. Ayrıca belgenin üst kısmında varsa ders adı, sınıf düzeyi, dönem ve hazırbulunuşluk/ön değerlendirme bilgisini metadata alanında döndürün."
            } else {
                "Aşağıdaki sınav senaryosu belgesinden kazanımları (öğrenme alanlarını) ve öngörülen soru sayılarını çıkarın. Ayrıca belgenin üst kısmında (varsa) ders adı, sınıf düzeyi, dönem, ve sınav/yazılı bilgisini (örn. 1. Dönem 1. Yazılı) json içindeki metadata alanında döndürün."
            }

            val inputItems = buildJsonArray {
                when (input) {
                    is ExamExtractionInput.Text -> {
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", input.text)
                        })
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", instructionText)
                        })
                    }
                    is ExamExtractionInput.WordExtracted -> {
                        for (part in input.parts) {
                            when (part) {
                                is ExamExtractionInput.WordPart.TextPart -> {
                                    if (part.text.isNotBlank()) {
                                        add(buildJsonObject {
                                            put("type", "text")
                                            put("text", part.text)
                                        })
                                    }
                                }
                                is ExamExtractionInput.WordPart.ImagePart -> {
                                    val base64Image = Base64.getEncoder().encodeToString(part.image.bytes)
                                    add(buildJsonObject {
                                        put("type", "inline_data")
                                        put("mime_type", part.image.mimeType)
                                        put("data", base64Image)
                                    })
                                }
                            }
                        }
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", instructionText)
                        })
                    }
                    is ExamExtractionInput.Pdf -> {
                        val base64Pdf = Base64.getEncoder().encodeToString(input.bytes)
                        add(buildJsonObject {
                            put("type", "document")
                            put("mime_type", "application/pdf")
                            put("data", base64Pdf)
                        })
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", instructionText)
                        })
                    }
                    is ExamExtractionInput.Images -> {
                        for (img in input.images) {
                            val base64Image = Base64.getEncoder().encodeToString(img.bytes)
                            add(buildJsonObject {
                                put("type", "image")
                                put("mime_type", img.mimeType)
                                put("data", base64Image)
                            })
                        }
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", instructionText)
                        })
                    }
                }
            }

            val schemaNullableString = buildJsonObject {
                put("type", buildJsonArray {
                    add("string")
                    add("null")
                })
            }
            
            val schemaNullableInteger = buildJsonObject {
                put("type", buildJsonArray {
                    add("integer")
                    add("null")
                })
            }

            val objectiveItemProperties = buildJsonObject {
                put("learningArea", schemaNullableString)
                put("objectiveCode", schemaNullableString)
                put("objectiveText", buildJsonObject { put("type", "string") })
                put("notes", schemaNullableString)
                put("expectedQuestionCount", schemaNullableInteger)
            }

            val objectiveItemSchema = buildJsonObject {
                put("type", "object")
                put("properties", objectiveItemProperties)
                put("required", buildJsonArray {
                    add("learningArea")
                    add("objectiveCode")
                    add("objectiveText")
                    add("notes")
                    add("expectedQuestionCount")
                })
                put("additionalProperties", false)
            }

            val objectivesArraySchema = buildJsonObject {
                put("type", "array")
                put("items", objectiveItemSchema)
            }

            val topSchema = buildJsonObject {
                put("type", "object")
                put("properties", buildJsonObject {
                    put("metadata", buildJsonObject {
                        put("type", "object")
                        put("properties", buildJsonObject {
                            put("courseName", buildJsonObject { put("type", "string") })
                            put("gradeLevel", buildJsonObject { put("type", "string") })
                            put("term", buildJsonObject { put("type", "string") })
                            put("examSequenceNumber", buildJsonObject { put("type", "string") })
                        })
                    })
                    put("objectives", objectivesArraySchema)
                })
                put("required", buildJsonArray { add("objectives") })
                put("additionalProperties", false)
            }

            val responseFormat = buildJsonObject {
                put("type", "text")
                put("mime_type", "application/json")
                put("schema", topSchema)
            }

            val requestBodyJson = buildJsonObject {
                put("model", requestedAuthoringModel)
                put("store", false)
                put(
                    "system_instruction",
                    if (isReadiness)
                        "Sen bir hazırbulunuşluk senaryosu çözümleyicisisin. Yalnız konu/ünite öncesi ölçülebilir ön koşul bilgi ve beceri hedeflerini çıkar; ileride öğretilecek kazanımları ekleme. Geçerli JSON döndür."
                    else
                        "Sen bir sınav senaryosu çözümleyicisisin. Verilen metinden kazanımları ve soru sayılarını çıkar. Geçerli JSON döndür."
                )
                put("input", inputItems)
                put("response_format", responseFormat)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(baseUrl)
                .addHeader("x-goog-api-key", apiKey)
                .post(body)
                .build()

            val response = withContext(Dispatchers.IO) {
                okHttpClient.executeCancellable(request)
            }

            response.use { resp ->
                if (!resp.isSuccessful) {
                    return@useApiKey when (resp.code) {
                        401, 403 -> ExamScenarioExtractionResult.Unauthorized
                        429 -> ExamScenarioExtractionResult.RateLimited
                        503 -> ExamScenarioExtractionResult.ServiceUnavailable
                        else -> ExamScenarioExtractionResult.UnexpectedFailure
                    }
                }

                val responseBodyString = resp.body?.string() ?: ""
                val jsonResponse = try {
                    jsonParser.parseToJsonElement(responseBodyString).jsonObject
                } catch (e: Exception) {
                    return@useApiKey ExamScenarioExtractionResult.MalformedResponse
                }
                runCatching {
                    aiUsageLedger?.recordAuthoring(
                        draftId, "AUTHORING_SCENARIO_EXTRACT", requestedAuthoringModel, profileSnapshot,
                        GeminiUsageAuditParser.fromInteractions(jsonResponse)
                    )
                }

                val extractedText = extractModelOutputText(jsonResponse)
                    ?: return@useApiKey ExamScenarioExtractionResult.MalformedResponse

                val structuredJson = try {
                    jsonParser.parseToJsonElement(extractedText).jsonObject
                } catch (e: Exception) {
                    return@useApiKey ExamScenarioExtractionResult.MalformedResponse
                }

                val objectivesArray = structuredJson["objectives"]?.jsonArray
                    ?: return@useApiKey ExamScenarioExtractionResult.MalformedResponse

                if (objectivesArray.isEmpty()) {
                    return@useApiKey ExamScenarioExtractionResult.NoObjectivesFound
                }

                val objectivesList = mutableListOf<ExamObjectiveEntity>()
                for (item in objectivesArray) {
                    val itemObj = try {
                        item.jsonObject
                    } catch (e: Exception) {
                        return@useApiKey ExamScenarioExtractionResult.MalformedResponse
                    }

                    val learningArea = itemObj["learningArea"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() && it != "null" }
                    val objectiveCode = itemObj["objectiveCode"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() && it != "null" }
                    val objectiveText = itemObj["objectiveText"]?.jsonPrimitive?.content ?: "Kazanım"
                    val notes = itemObj["notes"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() && it != "null" }
                    val expectedCount = itemObj["expectedQuestionCount"]?.jsonPrimitive?.intOrNull

                    objectivesList.add(
                        ExamObjectiveEntity(
                            examDraftId = draftId,
                            learningArea = learningArea,
                            objectiveCode = objectiveCode,
                            objectiveText = objectiveText,
                            notes = notes,
                            expectedQuestionCount = expectedCount
                        )
                    )
                }

                
                val metaObj = structuredJson["metadata"]?.jsonObject
                val metadata = if (metaObj != null) {
                    ExamScenarioExtractionResult.ScenarioMetadata(
                        courseName = metaObj["courseName"]?.jsonPrimitive?.content?.takeIf { it != "null" && it.isNotBlank() },
                        gradeLevel = metaObj["gradeLevel"]?.jsonPrimitive?.content?.takeIf { it != "null" && it.isNotBlank() },
                        term = metaObj["term"]?.jsonPrimitive?.content?.takeIf { it != "null" && it.isNotBlank() },
                        examSequenceNumber = metaObj["examSequenceNumber"]?.jsonPrimitive?.content?.takeIf { it != "null" && it.isNotBlank() }
                    )
                } else null
                ExamScenarioExtractionResult.Success(objectivesList, metadata)

            }
        } ?: ExamScenarioExtractionResult.MissingApiKey
    }

    private fun extractModelOutputText(responseObj: JsonObject): String? {
        return try {
            val interactions = responseObj["interactions"]?.jsonArray
            val firstInteraction = interactions?.firstOrNull()?.jsonObject
            val parts = firstInteraction?.get("parts")?.jsonArray
            val firstPart = parts?.firstOrNull()?.jsonObject
            firstPart?.get("text")?.jsonPrimitive?.content
        } catch (e: Exception) {
            null
        }
    }
}
