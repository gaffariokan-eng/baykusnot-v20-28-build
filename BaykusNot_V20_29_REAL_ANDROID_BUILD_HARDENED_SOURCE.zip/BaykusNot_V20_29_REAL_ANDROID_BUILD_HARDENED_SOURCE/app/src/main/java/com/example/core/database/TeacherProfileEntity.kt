package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "teacher_profile")
data class TeacherProfileEntity(
    @PrimaryKey val id: Int = 1,
    val academicYear: String,
    val institutionName: String,
    val teacherNames: List<String>,
    val defaultCourseName: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
