package com.example.core.navigation

import kotlinx.serialization.Serializable

sealed class Screen {
    @Serializable data object Splash : Screen()
    @Serializable data object Home : Screen()
    @Serializable data object ExamTypeSelection : Screen()
    @Serializable data object Profile : Screen()
    @Serializable data object ApiKeySettings : Screen()
    
    // id = 0 means new draft, otherwise edit existing
    @Serializable data class NewDraft(val examTypeId: String, val draftId: Long = 0) : Screen()
    
    // Workflow container screen
    @Serializable data class Workflow(val draftId: Long) : Screen()
}
