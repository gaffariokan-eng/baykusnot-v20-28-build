package com.example.feature.listening

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ListeningAudioImportResult
import com.example.core.data.ListeningMaterialFailure
import com.example.core.database.ExamListeningMaterialEntity
import com.example.core.database.hasAudio
import com.example.core.model.ListeningSourcePolicy
import java.io.InputStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ListeningMaterialUiState(
    val isLoading: Boolean = true,
    val draftExists: Boolean? = null,
    val material: ExamListeningMaterialEntity? = null,
    val transcript: String = "",
    val playbackCount: Int = 2,
    val instructions: String = "",
    val isDirty: Boolean = false,
    val isImporting: Boolean = false,
    val isSaving: Boolean = false,
    val isRemovingAudio: Boolean = false,
    val isQuestionSetLocked: Boolean = false,
    val message: String? = null,
    val isMessageError: Boolean = false
) {
    val hasAudio: Boolean get() = material?.hasAudio() == true
    val isBusy: Boolean get() = isImporting || isSaving || isRemovingAudio
    val canEditSource: Boolean get() = !isQuestionSetLocked && !isBusy
    val canContinue: Boolean
        get() = ListeningSourcePolicy.isReady(hasUsableAudio = hasAudio, listeningText = transcript) && !isBusy
}

class ListeningMaterialViewModel(
    private val repository: ExamListeningMaterialRepository,
    private val questionRepository: ExamQuestionRepository,
    private val draftId: Long
) : ViewModel() {
    private val _uiState = MutableStateFlow(ListeningMaterialUiState())
    val uiState: StateFlow<ListeningMaterialUiState> = _uiState.asStateFlow()

    init {
        load()
        observeQuestionLock()
    }

    private fun observeQuestionLock() {
        viewModelScope.launch {
            questionRepository.observeMetadata(draftId).collectLatest { metadata ->
                _uiState.update { state ->
                    state.copy(isQuestionSetLocked = metadata?.isLocked == true)
                }
            }
        }
    }

    private fun load() {
        viewModelScope.launch {
            try {
                val material = repository.getOnce(draftId)
                val questionMetadata = questionRepository.getMetadataOnce(draftId)
                _uiState.value = ListeningMaterialUiState(
                    isLoading = false,
                    draftExists = true,
                    material = material,
                    transcript = material?.transcript.orEmpty(),
                    playbackCount = material?.playbackCount ?: 2,
                    instructions = material?.instructions.orEmpty(),
                    isQuestionSetLocked = questionMetadata?.isLocked == true
                )
            } catch (_: Exception) {
                _uiState.value = ListeningMaterialUiState(
                    isLoading = false,
                    draftExists = null,
                    message = "Dinleme materyali yüklenemedi.",
                    isMessageError = true
                )
            }
        }
    }

    fun updateTranscript(value: String) {
        if (_uiState.value.isQuestionSetLocked) return
        _uiState.update {
            it.copy(
                transcript = value,
                isDirty = true,
                message = null
            )
        }
    }

    fun updatePlaybackCount(value: Int) {
        if (_uiState.value.isQuestionSetLocked || value !in 1..3) return
        _uiState.update { it.copy(playbackCount = value, isDirty = true, message = null) }
    }

    fun updateInstructions(value: String) {
        if (_uiState.value.isQuestionSetLocked) return
        _uiState.update { it.copy(instructions = value, isDirty = true, message = null) }
    }

    fun importAudio(
        originalUri: String?,
        displayName: String,
        mimeType: String,
        declaredSizeBytes: Long?,
        openInputStream: () -> InputStream?
    ) {
        val state = _uiState.value
        if (state.isLoading || state.isQuestionSetLocked || state.isImporting || state.isSaving || state.isRemovingAudio) return
        _uiState.update { it.copy(isImporting = true, message = null) }

        viewModelScope.launch {
            if (!questionRepository.invalidateUnlockedQuestionSet(draftId)) {
                _uiState.update { it.copy(isImporting = false, message = "Eski soru yapısı güvenli biçimde geçersizleştirilemedi. Ses kaynağı değiştirilmedi.", isMessageError = true) }
                return@launch
            }
            when (
                val result = repository.importAudio(
                    examDraftId = draftId,
                    originalUri = originalUri,
                    displayName = displayName,
                    mimeType = mimeType,
                    declaredSizeBytes = declaredSizeBytes,
                    openInputStream = openInputStream
                )
            ) {
                is ListeningAudioImportResult.Success -> {
                    _uiState.update {
                        it.copy(
                            material = result.material,
                            isImporting = false,
                            isDirty = true,
                            message = if (result.replacedExisting) "Ses dosyası değiştirildi." else "Ses dosyası eklendi.",
                            isMessageError = false
                        )
                    }
                }
                is ListeningAudioImportResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            isImporting = false,
                            message = messageFor(result.reason),
                            isMessageError = true
                        )
                    }
                }
            }
        }
    }

    fun removeAudio() {
        val state = _uiState.value
        if (state.isQuestionSetLocked || !state.hasAudio || state.isImporting || state.isSaving || state.isRemovingAudio) return
        _uiState.update { it.copy(isRemovingAudio = true, message = null) }
        viewModelScope.launch {
            if (!questionRepository.invalidateUnlockedQuestionSet(draftId)) {
                _uiState.update { it.copy(isRemovingAudio = false, message = "Eski soru yapısı güvenli biçimde geçersizleştirilemedi. Ses kaynağı kaldırılmadı.", isMessageError = true) }
                return@launch
            }
            val success = repository.removeAudio(draftId)
            if (success) {
                val refreshed = repository.getOnce(draftId)
                _uiState.update {
                    it.copy(
                        material = refreshed,
                        isRemovingAudio = false,
                        isDirty = true,
                        message = "Ses dosyası kaldırıldı.",
                        isMessageError = false
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isRemovingAudio = false,
                        message = "Ses dosyası kaldırılamadı.",
                        isMessageError = true
                    )
                }
            }
        }
    }

    fun save(onSaved: (() -> Unit)? = null) {
        val state = _uiState.value
        if (state.isLoading || state.isQuestionSetLocked || state.isImporting || state.isSaving || state.isRemovingAudio) return
        persist(state, onSaved)
    }

    fun saveAndContinue(onContinue: () -> Unit) {
        val state = _uiState.value
        if (state.isLoading || state.isImporting || state.isSaving || state.isRemovingAudio) return

        if (!ListeningSourcePolicy.isReady(hasUsableAudio = state.hasAudio, listeningText = state.transcript)) {
            _uiState.update {
                it.copy(
                    message = "Devam etmek için ses dosyası ekleyin veya dinleme metnini girin.",
                    isMessageError = true
                )
            }
            return
        }

        // Once canonical questions are locked the listening source becomes read-only.
        // Navigating back is still allowed; returning forward must not rewrite the source.
        if (state.isQuestionSetLocked) {
            viewModelScope.launch {
                if (repository.isReadyForQuestions(draftId)) {
                    onContinue()
                } else {
                    _uiState.update {
                        it.copy(
                            message = "Dinleme kaynağı artık kullanılamıyor. Soru kilidini açmadan önce kaynağı kontrol edin.",
                            isMessageError = true
                        )
                    }
                }
            }
            return
        }

        persist(state) {
            viewModelScope.launch {
                if (repository.isReadyForQuestions(draftId)) {
                    onContinue()
                } else {
                    _uiState.update {
                        it.copy(
                            message = "Dinleme kaynağı doğrulanamadı. Ses dosyasını veya dinleme metnini yeniden kontrol edin.",
                            isMessageError = true
                        )
                    }
                }
            }
        }
    }

    private fun persist(state: ListeningMaterialUiState, onSaved: (() -> Unit)? = null) {
        _uiState.update { it.copy(isSaving = true, message = null) }
        viewModelScope.launch {
            val transcriptChanged = state.transcript.trim() != state.material?.transcript.orEmpty().trim()
            if (transcriptChanged && !questionRepository.invalidateUnlockedQuestionSet(draftId)) {
                _uiState.update { it.copy(isSaving = false, message = "Eski soru yapısı güvenli biçimde geçersizleştirilemedi. Dinleme metni kaydedilmedi.", isMessageError = true) }
                return@launch
            }
            val result = repository.saveDetails(
                examDraftId = draftId,
                transcript = state.transcript,
                playbackCount = state.playbackCount,
                instructions = state.instructions
            )
            result.fold(
                onSuccess = { saved ->
                    _uiState.update {
                        it.copy(
                            material = saved,
                            transcript = saved.transcript,
                            playbackCount = saved.playbackCount,
                            instructions = saved.instructions,
                            isDirty = false,
                            isSaving = false,
                            message = "Dinleme materyali kaydedildi.",
                            isMessageError = false
                        )
                    }
                    onSaved?.invoke()
                },
                onFailure = {
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            message = "Dinleme materyali kaydedilemedi.",
                            isMessageError = true
                        )
                    }
                }
            )
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null, isMessageError = false) }
    }

    fun reportTextFileSelectionError(error: String) {
        _uiState.update { it.copy(message = error.take(300), isMessageError = true) }
    }

    private fun messageFor(reason: ListeningMaterialFailure): String = when (reason) {
        ListeningMaterialFailure.DRAFT_NOT_FOUND -> "Sınav taslağı bulunamadı."
        ListeningMaterialFailure.WRONG_EXAM_TYPE -> "Bu materyal yalnız Dinleme Sınavı için kullanılabilir."
        ListeningMaterialFailure.UNSUPPORTED_AUDIO_TYPE -> "Desteklenmeyen ses biçimi. MP3, WAV, M4A, AAC, OGG veya FLAC kullanın."
        ListeningMaterialFailure.EMPTY_FILE -> "Seçilen ses dosyası boş."
        ListeningMaterialFailure.FILE_TOO_LARGE -> "Ses dosyası 200 MB sınırını aşıyor."
        ListeningMaterialFailure.SOURCE_UNAVAILABLE -> "Seçilen ses dosyasına erişilemiyor."
        ListeningMaterialFailure.STORAGE_ERROR -> "Ses dosyası güvenli uygulama alanına kaydedilemedi."
        ListeningMaterialFailure.INVALID_PLAYBACK_COUNT -> "Dinletme sayısı 1 ile 3 arasında olmalıdır."
        ListeningMaterialFailure.SOURCE_LOCKED -> "Soru seti kilitli olduğu için dinleme kaynağı değiştirilemez."
    }

    class Factory(
        private val repository: ExamListeningMaterialRepository,
        private val questionRepository: ExamQuestionRepository,
        private val draftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ListeningMaterialViewModel::class.java)) {
                return ListeningMaterialViewModel(repository, questionRepository, draftId) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
