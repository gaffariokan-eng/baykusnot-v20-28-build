package com.example.core.data

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

fun interface PdfPageInspector {

    fun readPageCount(
        pdfFile: File
    ): Int
}

class AndroidPdfPageInspector :
    PdfPageInspector {

    override fun readPageCount(pdfFile: File): Int {
        ParcelFileDescriptor.open(
            pdfFile,
            ParcelFileDescriptor.MODE_READ_ONLY
        ).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                return renderer.pageCount
            }
        }
    }
}
