package com.example.core.data

import android.content.Context
import android.util.AtomicFile
import com.example.core.database.ExamAnswerSheetConfigDao
import com.example.core.database.ExamAnswerSheetConfigEntity
import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamQuestionDao
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.database.ExamPaperUploadDao
import com.example.core.database.ExamListeningMaterialDao
import com.example.core.database.ExamRubricDao
import com.example.core.database.hasAudio
import com.example.core.model.ExamType
import com.example.core.model.ListeningSourcePolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

sealed interface ExamAnswerSheetPreflightResult {
    data class Success(
        val draft: ExamDraftEntity,
        val questions: List<ExamQuestionEntity>,
        val rubricCriteria: List<ExamRubricCriterionEntity>,
        val isQuestionSetLocked: Boolean,
        val isRubricSetLocked: Boolean,
        val listeningGuidance: ListeningAnswerSheetGuidance? = null
    ) : ExamAnswerSheetPreflightResult

    data class Failure(val reason: String) : ExamAnswerSheetPreflightResult
}

enum class StaleCause {
    LAYOUT_DENSITY_CHANGED,
    LINE_OVERRIDES_CHANGED,
    STUDENT_COUNT_CHANGED,
    QUESTION_OR_RUBRIC_CHANGED,
    LAYOUT_VERSION_CHANGED,
    EXAM_DATE_CHANGED,
    LISTENING_GUIDANCE_CHANGED,
    OTHER_CONTENT_CHANGED
}

sealed interface PdfStatus {
    data class UpToDate(val pdfFile: File, val generatedStudentCount: Int) : PdfStatus
    data class Stale(
        val pdfFile: File?,
        val generatedStudentCount: Int?,
        val reason: String,
        val title: String = "PDF Güncel Değil",
        val subtitle: String = "Yeni PDF oluşturulmalıdır.",
        val cause: StaleCause = StaleCause.OTHER_CONTENT_CHANGED
    ) : PdfStatus
    object NotGenerated : PdfStatus
}

class ExamAnswerSheetRepository(
    private val configDao: ExamAnswerSheetConfigDao,
    private val draftDao: ExamDraftDao,
    private val questionDao: ExamQuestionDao,
    private val rubricDao: ExamRubricDao,
    private val paperUploadDao: ExamPaperUploadDao? = null,
    private val context: Context? = null,
    private val listeningMaterialDao: ExamListeningMaterialDao? = null
) {

    suspend fun hasUploadedPapers(examDraftId: Long): Boolean {
        return withContext(Dispatchers.IO) {
            val dao = paperUploadDao ?: throw IllegalStateException("PAPER_UPLOAD_DAO_REQUIRED")
            dao.getPapersForExamOnce(examDraftId).isNotEmpty()
        }
    }

    fun getLineOverrides(examDraftId: Long, customContext: Context? = null): Map<Int, Int> {
        return Companion.getLineOverrides(examDraftId, customContext ?: context)
    }

    fun saveLineOverrides(examDraftId: Long, overrides: Map<Int, Int>, customContext: Context? = null): Boolean {
        val ctx = customContext ?: context ?: return false
        val file = File(ctx.filesDir, "line_overrides_${examDraftId}.json")
        val atomic = AtomicFile(file)
        return try {
            if (overrides.isEmpty()) {
                atomic.delete()
                !file.exists()
            } else {
                val jsonStr = overrides.entries.sortedBy { it.key }.joinToString(prefix = "{", postfix = "}") { "\"${it.key}\":${it.value}" }
                var stream: java.io.FileOutputStream? = null
                try {
                    stream = atomic.startWrite()
                    stream.write(jsonStr.toByteArray(Charsets.UTF_8))
                    atomic.finishWrite(stream)
                    stream = null
                } catch (error: Throwable) {
                    stream?.let { runCatching { atomic.failWrite(it) } }
                    throw error
                }
                file.exists() && getLineOverrides(examDraftId, ctx) == overrides
            }
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        const val CURRENT_LAYOUT_VERSION = 6

        fun getLineOverrides(examDraftId: Long, context: Context?): Map<Int, Int> {
            if (context == null) return emptyMap()
            val file = File(context.filesDir, "line_overrides_${examDraftId}.json")
            if (!file.exists()) return emptyMap()
            return try {
                val jsonStr = file.readText().trim()
                parseLineOverrides(jsonStr)
            } catch (_: Exception) {
                emptyMap()
            }
        }

        private fun parseLineOverrides(json: String): Map<Int, Int> {
            if (!json.startsWith("{") || !json.endsWith("}")) return emptyMap()
            val content = json.substring(1, json.length - 1).trim()
            if (content.isEmpty()) return emptyMap()
            val map = mutableMapOf<Int, Int>()
            content.split(",").forEach { pair ->
                val parts = pair.split(":")
                if (parts.size == 2) {
                    val key = parts[0].trim().removeSurrounding("\"").toIntOrNull()
                    val value = parts[1].trim().toIntOrNull()
                    if (key != null && value != null) {
                        map[key] = value
                    }
                }
            }
            return map
        }
    }

    suspend fun getConfig(examDraftId: Long): ExamAnswerSheetConfigEntity? {
        return withContext(Dispatchers.IO) {
            configDao.getConfig(examDraftId)
        }
    }

    suspend fun saveConfig(config: ExamAnswerSheetConfigEntity) {
        withContext(Dispatchers.IO) {
            configDao.insertOrUpdateConfig(config)
        }
    }

    suspend fun saveConfigIfNoUploadedPapers(config: ExamAnswerSheetConfigEntity): Boolean {
        return withContext(Dispatchers.IO) {
            val dao = paperUploadDao
            if (dao != null && dao.getPapersForExamOnce(config.examDraftId).isNotEmpty()) {
                return@withContext false
            }
            configDao.insertOrUpdateConfig(config)
            true
        }
    }

    suspend fun getListeningGuidance(examDraftId: Long): ListeningAnswerSheetGuidance? {
        return withContext(Dispatchers.IO) {
            val draft = draftDao.getDraftByIdOnce(examDraftId) ?: return@withContext null
            if (draft.examType != ExamType.LISTENING) return@withContext null
            val material = listeningMaterialDao?.getByExamDraftIdOnce(examDraftId) ?: return@withContext null
            ListeningAnswerSheetGuidance(
                playbackCount = material.playbackCount,
                instructions = material.instructions
            )
        }
    }

    suspend fun validatePreflight(examDraftId: Long): ExamAnswerSheetPreflightResult {
        return withContext(Dispatchers.IO) {
            val draft = draftDao.getDraftByIdOnce(examDraftId)
                ?: return@withContext ExamAnswerSheetPreflightResult.Failure("Sınav taslağı bulunamadı.")

            val questionSetMeta = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (questionSetMeta == null || !questionSetMeta.isLocked) {
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    "Soru ve puan seti kilitlenmemiş. Cevap kâğıdı oluşturulabilmesi için öncelikle soru ve puan aşamasının tamamlanmış ve kilitlenmiş olması gerekmektedir."
                )
            }

            val questions = questionDao.getByExamDraftIdOnce(examDraftId)
            if (questions.isEmpty()) {
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    "Sınava ait soru bulunamadı."
                )
            }

            val rubricSetMeta = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (rubricSetMeta == null || !rubricSetMeta.isLocked) {
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    if (draft.examType == ExamType.MULTIPLE_CHOICE)
                        "Cevap anahtarı kilitlenmemiş. Test cevap formunu oluşturmadan önce doğru seçenekleri kaydedip kilitleyin."
                    else
                        "Detaylı rubrik kilitlenmemiş. Cevap kâğıdı oluşturulabilmesi için rubrik aşamasının kilitlenmiş ve onaylanmış olması gerekmektedir."
                )
            }

            if (rubricSetMeta.questionSetRevision != questionSetMeta.revision) {
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    if (draft.examType == ExamType.MULTIPLE_CHOICE)
                        "Cevap anahtarı güncel test soru setiyle uyuşmuyor. Cevap anahtarını yeniden kontrol edip kilitleyin."
                    else
                        "Detaylı rubrik, güncel soru ve puan seti ile uyumlu değil (Soru revizyonu uyuşmazlığı). Lütfen rubrik aşamasını güncelleyip yeniden onaylayın ve kilitleyin."
                )
            }

            val rubricCriteria = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            if (rubricCriteria.isEmpty()) {
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    if (draft.examType == ExamType.MULTIPLE_CHOICE) "Cevap anahtarında doğru seçenek kaydı bulunamadı." else "Detaylı rubrik kriterleri bulunamadı."
                )
            }

            val questionsWithoutCriteria = questions.filter { q ->
                rubricCriteria.none { c ->
                    c.questionOrderIndex == q.orderIndex || c.questionNumberSnapshot.trim().equals(q.questionNumber.trim(), ignoreCase = true)
                }
            }
            if (questionsWithoutCriteria.isNotEmpty()) {
                val missingNums = questionsWithoutCriteria.joinToString(", ") { it.questionNumber }
                return@withContext ExamAnswerSheetPreflightResult.Failure(
                    if (draft.examType == ExamType.MULTIPLE_CHOICE)
                        "Şu test soruları için doğru seçenek bulunamadı: $missingNums. Tüm cevap anahtarı tamamlanıp kilitlenmelidir."
                    else
                        "Şu sorular için detaylı rubrik kriteri bulunamadı: $missingNums. Tüm soruların rubrik kriterleri kilitli olmalıdır."
                )
            }

            val listeningGuidance = if (draft.examType == ExamType.LISTENING) {
                val material = listeningMaterialDao?.getByExamDraftIdOnce(examDraftId)
                    ?: return@withContext ExamAnswerSheetPreflightResult.Failure(
                        "Dinleme kaynağı bulunamadı. Cevap kâğıdını oluşturmadan önce Dinleme Materyali aşamasını kontrol edin."
                    )

                val managedAudioUsable = material.hasAudio() && (
                    context == null || material.localRelativePath?.let { relativePath ->
                        File(context.filesDir, relativePath).let { it.isFile && it.length() > 0L }
                    } == true
                )
                if (!ListeningSourcePolicy.isReady(managedAudioUsable, material.transcript)) {
                    return@withContext ExamAnswerSheetPreflightResult.Failure(
                        "Dinleme kaynağı artık kullanılamıyor. Ses dosyasını veya dinleme metnini kontrol edin."
                    )
                }

                ListeningAnswerSheetGuidance(
                    playbackCount = material.playbackCount,
                    instructions = material.instructions
                )
            } else {
                null
            }

            ExamAnswerSheetPreflightResult.Success(
                draft = draft,
                questions = questions,
                rubricCriteria = rubricCriteria,
                isQuestionSetLocked = true,
                isRubricSetLocked = true,
                listeningGuidance = listeningGuidance
            )
        }
    }

    suspend fun getPdfStatus(examDraftId: Long, targetStudentCount: Int, customContext: Context? = null): PdfStatus {
        return withContext(Dispatchers.IO) {
            val config = configDao.getConfig(examDraftId) ?: return@withContext PdfStatus.NotGenerated
            val pdfPath = config.pdfPath ?: return@withContext PdfStatus.NotGenerated
            val pdfFile = File(pdfPath)
            if (!pdfFile.exists() || pdfFile.length() == 0L) {
                return@withContext PdfStatus.NotGenerated
            }

            val metaFile = File("${pdfFile.absolutePath}.meta")
            if (!metaFile.exists()) {
                return@withContext PdfStatus.Stale(
                    pdfFile = pdfFile,
                    generatedStudentCount = config.studentCount,
                    reason = "PDF doğrulama bilgisi eksik.",
                    title = "Cevap kâğıdı düzeni değiştirildi",
                    subtitle = "Yeni yerleşimi kullanmak için PDF’yi yeniden oluşturun.",
                    cause = StaleCause.OTHER_CONTENT_CHANGED
                )
            }

            val savedFingerprintStr = metaFile.readText().trim()

            val preflight = validatePreflight(examDraftId)
            if (preflight !is ExamAnswerSheetPreflightResult.Success) {
                val failReason = (preflight as ExamAnswerSheetPreflightResult.Failure).reason
                return@withContext PdfStatus.Stale(
                    pdfFile = pdfFile,
                    generatedStudentCount = parseStudentCountFromMeta(savedFingerprintStr) ?: config.studentCount,
                    reason = failReason,
                    title = "Sınav yapısı kilitli değil",
                    subtitle = failReason,
                    cause = StaleCause.QUESTION_OR_RUBRIC_CHANGED
                )
            }

            val qSetMeta = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            val rSetMeta = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)

            val currentDensity = config.layoutDensity
            val currentVersion = CURRENT_LAYOUT_VERSION
            val lineOverrides = getLineOverrides(examDraftId, customContext)

            val currentFingerprintStr = buildFingerprintString(
                studentCount = targetStudentCount,
                qRevision = qSetMeta?.revision ?: 0,
                rRevision = rSetMeta?.revision ?: 0,
                questions = preflight.questions,
                rubricCriteria = preflight.rubricCriteria,
                draft = preflight.draft,
                densitySetting = currentDensity,
                lineOverrides = lineOverrides,
                layoutVersion = currentVersion,
                listeningGuidance = preflight.listeningGuidance
            )

            val generatedCountInMeta = parseStudentCountFromMeta(savedFingerprintStr) ?: config.studentCount

            if (savedFingerprintStr == currentFingerprintStr) {
                PdfStatus.UpToDate(pdfFile = pdfFile, generatedStudentCount = generatedCountInMeta)
            } else {
                val savedDensity = parseValueFromMeta(savedFingerprintStr, "DENSITY") ?: "AUTOMATIC"
                val savedOverrides = parseValueFromMeta(savedFingerprintStr, "OVERRIDES") ?: ""
                val currentOverridesStr = lineOverrides.entries.sortedBy { it.key }.joinToString(";") { "${it.key}:${it.value}" }

                val savedQRev = parseValueFromMeta(savedFingerprintStr, "QREV")?.toIntOrNull() ?: 0
                val savedRRev = parseValueFromMeta(savedFingerprintStr, "RREV")?.toIntOrNull() ?: 0
                val savedQHash = parseValueFromMeta(savedFingerprintStr, "QHASH")?.toIntOrNull() ?: 0
                val savedRHash = parseValueFromMeta(savedFingerprintStr, "RHASH")?.toIntOrNull() ?: 0
                val savedMdHash = parseValueFromMeta(savedFingerprintStr, "MDHASH")?.toIntOrNull() ?: 0
                val savedDate = parseValueFromMeta(savedFingerprintStr, "DATE")?.toLongOrNull() ?: 0L

                val currentQRev = qSetMeta?.revision ?: 0
                val currentRRev = rSetMeta?.revision ?: 0
                val currentQHash = preflight.questions.sortedBy { it.orderIndex }.joinToString(";") { "${it.orderIndex}:${it.questionNumber}:${it.points}" }.hashCode()
                val currentRHash = preflight.rubricCriteria.sortedBy { "${it.questionOrderIndex}_${it.criterionOrderIndex}" }.joinToString(";") { "${it.questionOrderIndex}:${it.criterionOrderIndex}:${it.title}:${it.expectedAnswer.length}" }.hashCode()
                val currentMetaDraftStr = "${preflight.draft.teachers.sorted().joinToString(",")}_${preflight.draft.totalPoints}_${preflight.draft.courseName}_${preflight.draft.term}_${preflight.draft.academicYear}"
                val currentMdHash = currentMetaDraftStr.hashCode()
                val currentDate = preflight.draft.examDate
                val savedLayoutVer = parseValueFromMeta(savedFingerprintStr, "LAYOUT_VER")?.toIntOrNull() ?: 2
                val savedListeningContextHash = parseValueFromMeta(savedFingerprintStr, "LCTXHASH")?.toIntOrNull()
                val currentListeningContextHash = preflight.listeningGuidance?.fingerprintHash()

                val (title, subtitle, cause) = when {
                    savedLayoutVer != CURRENT_LAYOUT_VERSION -> Triple(
                        "Cevap kâğıdı düzeni güncellendi",
                        "Yeni akıllı düzeni kullanmak için PDF’yi yeniden oluşturun.",
                        StaleCause.LAYOUT_VERSION_CHANGED
                    )
                    savedOverrides != currentOverridesStr -> Triple(
                        "Cevap alanları değiştirildi",
                        "Yeni satır sayılarını kullanmak için PDF’yi yeniden oluşturun.",
                        StaleCause.LINE_OVERRIDES_CHANGED
                    )
                    savedDensity != currentDensity -> Triple(
                        "Cevap kâğıdı düzeni değiştirildi",
                        "Yeni yerleşimi kullanmak için PDF’yi yeniden oluşturun.",
                        StaleCause.LAYOUT_DENSITY_CHANGED
                    )
                    generatedCountInMeta != targetStudentCount -> Triple(
                        "Öğrenci sayısı değiştirildi",
                        "Önceki PDF $generatedCountInMeta öğrenci içindi. Yeni $targetStudentCount öğrenci için PDF’yi yeniden oluşturun.",
                        StaleCause.STUDENT_COUNT_CHANGED
                    )
                    currentListeningContextHash != null && savedListeningContextHash != currentListeningContextHash -> Triple(
                        "Dinleme sınavı yönergesi değiştirildi",
                        "Dinletme sayısı veya öğrenci yönergesini cevap kâğıdına yansıtmak için PDF’yi yeniden oluşturun.",
                        StaleCause.LISTENING_GUIDANCE_CHANGED
                    )
                    savedQRev == currentQRev && savedRRev == currentRRev && savedQHash == currentQHash && savedRHash == currentRHash && savedMdHash == currentMdHash && savedDate != currentDate -> Triple(
                        "Sınav tarihi değiştirildi",
                        "Yeni tarihi cevap kâğıdına yansıtmak için PDF’yi yeniden oluşturun.",
                        StaleCause.EXAM_DATE_CHANGED
                    )
                    else -> Triple(
                        "Sınav verileri güncellendi",
                        "Yeni sınav içeriğini yansıtmak için PDF’yi yeniden oluşturun.",
                        StaleCause.QUESTION_OR_RUBRIC_CHANGED
                    )
                }

                PdfStatus.Stale(
                    pdfFile = pdfFile,
                    generatedStudentCount = generatedCountInMeta,
                    reason = "$title — $subtitle",
                    title = title,
                    subtitle = subtitle,
                    cause = cause
                )
            }
        }
    }

    suspend fun canProceedToUpload(examDraftId: Long, targetStudentCount: Int): Pair<Boolean, String?> {
        val preflight = validatePreflight(examDraftId)
        if (preflight !is ExamAnswerSheetPreflightResult.Success) {
            return Pair(false, (preflight as ExamAnswerSheetPreflightResult.Failure).reason)
        }
        val pdfStatus = getPdfStatus(examDraftId, targetStudentCount)
        return when (pdfStatus) {
            is PdfStatus.UpToDate -> Pair(true, null)
            is PdfStatus.Stale -> Pair(false, pdfStatus.reason)
            is PdfStatus.NotGenerated -> Pair(false, "Öğrenci kâğıtlarını yükleme aşamasına geçebilmek için önce güncel toplu PDF oluşturulmalıdır.")
        }
    }

    suspend fun generateBatchPdf(
        context: Context,
        examDraftId: Long,
        studentCount: Int,
        onProgress: ((currentStudent: Int, totalStudents: Int) -> Unit)? = null
    ): File {
        return withContext(Dispatchers.IO) {
            val preflight = validatePreflight(examDraftId)
            if (preflight !is ExamAnswerSheetPreflightResult.Success) {
                throw IllegalStateException((preflight as ExamAnswerSheetPreflightResult.Failure).reason)
            }

            val currentConfig = configDao.getConfig(examDraftId)
            val densitySetting = currentConfig?.layoutDensity ?: "AUTOMATIC"
            val lineOverrides = getLineOverrides(examDraftId, context)

            val qSetMeta = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            val rSetMeta = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)

            val fingerprintStr = buildFingerprintString(
                studentCount = studentCount,
                qRevision = qSetMeta?.revision ?: 0,
                rRevision = rSetMeta?.revision ?: 0,
                questions = preflight.questions,
                rubricCriteria = preflight.rubricCriteria,
                draft = preflight.draft,
                densitySetting = densitySetting,
                lineOverrides = lineOverrides,
                layoutVersion = CURRENT_LAYOUT_VERSION,
                listeningGuidance = preflight.listeningGuidance
            )
            val formToken = fingerprintToken(fingerprintStr)

            val pdfFile = ExamAnswerSheetPdfGenerator.generateBatchPdf(
                context = context,
                draft = preflight.draft,
                questions = preflight.questions,
                rubricCriteria = preflight.rubricCriteria,
                studentCount = studentCount,
                densitySetting = densitySetting,
                lineOverrides = lineOverrides,
                listeningGuidance = preflight.listeningGuidance,
                formToken = formToken,
                onProgress = onProgress
            )

            try {
                File("${pdfFile.absolutePath}.meta").writeText(fingerprintStr)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val updatedConfig = (currentConfig ?: ExamAnswerSheetConfigEntity(examDraftId = examDraftId)).copy(
                studentCount = studentCount,
                layoutDensity = densitySetting,
                layoutVersion = CURRENT_LAYOUT_VERSION,
                isGenerated = true,
                pdfPath = pdfFile.absolutePath,
                generatedAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            configDao.insertOrUpdateConfig(updatedConfig)

            pdfFile
        }
    }

    suspend fun getCurrentFormToken(examDraftId: Long): String = withContext(Dispatchers.IO) {
        val preflight = validatePreflight(examDraftId)
        require(preflight is ExamAnswerSheetPreflightResult.Success) {
            (preflight as? ExamAnswerSheetPreflightResult.Failure)?.reason ?: "Cevap kâğıdı yapısı doğrulanamadı."
        }
        preflight as ExamAnswerSheetPreflightResult.Success
        val config = configDao.getConfig(examDraftId)
            ?: throw IllegalStateException("Cevap kâğıdı ayarları bulunamadı.")
        val qSetMeta = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
        val rSetMeta = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
        val density = config.layoutDensity
        val overrides = getLineOverrides(examDraftId, context)
        val fingerprint = buildFingerprintString(
            studentCount = config.studentCount,
            qRevision = qSetMeta?.revision ?: 0,
            rRevision = rSetMeta?.revision ?: 0,
            questions = preflight.questions,
            rubricCriteria = preflight.rubricCriteria,
            draft = preflight.draft,
            densitySetting = density,
            lineOverrides = overrides,
            layoutVersion = CURRENT_LAYOUT_VERSION,
            listeningGuidance = preflight.listeningGuidance
        )
        fingerprintToken(fingerprint)
    }

    private fun fingerprintToken(fingerprint: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(fingerprint.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(20)

    private fun buildFingerprintString(
        studentCount: Int,
        qRevision: Int,
        rRevision: Int,
        questions: List<ExamQuestionEntity>,
        rubricCriteria: List<ExamRubricCriterionEntity>,
        draft: ExamDraftEntity,
        densitySetting: String = "AUTOMATIC",
        lineOverrides: Map<Int, Int> = emptyMap(),
        layoutVersion: Int = CURRENT_LAYOUT_VERSION,
        listeningGuidance: ListeningAnswerSheetGuidance? = null
    ): String {
        val qStr = questions.sortedBy { it.orderIndex }.joinToString(";") { "${it.orderIndex}:${it.questionNumber}:${it.points}" }
        val rStr = rubricCriteria.sortedBy { "${it.questionOrderIndex}_${it.criterionOrderIndex}" }.joinToString(";") { "${it.questionOrderIndex}:${it.criterionOrderIndex}:${it.title}:${it.expectedAnswer.length}" }
        val metaDraftStr = "${draft.teachers.sorted().joinToString(",")}_${draft.totalPoints}_${draft.courseName}_${draft.term}_${draft.academicYear}"
        val oStr = lineOverrides.entries.sortedBy { it.key }.joinToString(";") { "${it.key}:${it.value}" }
        val base = "S:$studentCount|LAYOUT_VER:$layoutVersion|DENSITY:$densitySetting|OVERRIDES:$oStr|QREV:$qRevision|RREV:$rRevision|QHASH:${qStr.hashCode()}|RHASH:${rStr.hashCode()}|MDHASH:${metaDraftStr.hashCode()}|DATE:${draft.examDate}"
        return if (listeningGuidance != null) {
            "$base|LCTXHASH:${listeningGuidance.fingerprintHash()}"
        } else {
            base
        }
    }

    private fun parseValueFromMeta(metaStr: String, key: String): String? {
        val part = metaStr.split("|").firstOrNull { it.startsWith("$key:") } ?: return null
        return part.removePrefix("$key:")
    }

    private fun parseStudentCountFromMeta(metaStr: String): Int? {
        val part = metaStr.split("|").firstOrNull { it.startsWith("S:") } ?: return null
        return part.removePrefix("S:").toIntOrNull()
    }
}
