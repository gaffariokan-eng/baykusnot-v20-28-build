package com.example.core.security

import java.util.concurrent.atomic.AtomicReference

/** RAM-only short-lived gateway access token. */
class GatewayAuthTokenStore {
    private data class Session(val token: String, val expiresAtEpochMs: Long)
    private val session = AtomicReference<Session?>(null)

    fun updateShortLivedToken(value: String?, expiresAtEpochMs: Long) {
        val normalized = value?.trim()?.takeIf { it.isNotBlank() }
        session.set(if (normalized == null) null else Session(normalized, expiresAtEpochMs))
    }

    /** Legacy helper retained for tests; expires quickly instead of creating an unbounded token. */
    fun updateShortLivedToken(value: String?) {
        updateShortLivedToken(value, System.currentTimeMillis() + 5 * 60_000L)
    }

    fun bearerToken(minValidityMs: Long = 30_000L): String? {
        val current = session.get() ?: return null
        if (current.expiresAtEpochMs <= System.currentTimeMillis() + minValidityMs) {
            session.compareAndSet(current, null)
            return null
        }
        return current.token
    }

    fun expiresAtEpochMs(): Long? = session.get()?.expiresAtEpochMs

    fun clear() = session.set(null)
}
