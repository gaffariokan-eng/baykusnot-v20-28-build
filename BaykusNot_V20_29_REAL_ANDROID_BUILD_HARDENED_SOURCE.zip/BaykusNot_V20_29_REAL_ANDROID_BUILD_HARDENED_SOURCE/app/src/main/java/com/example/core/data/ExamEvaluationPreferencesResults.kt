package com.example.core.data

import com.example.core.database.ExamEvaluationPreferencesEntity

sealed interface SaveEvaluationPreferencesResult {

    data class Created(
        val preferences: ExamEvaluationPreferencesEntity
    ) : SaveEvaluationPreferencesResult

    data class Updated(
        val preferences: ExamEvaluationPreferencesEntity
    ) : SaveEvaluationPreferencesResult

    data object Locked :
        SaveEvaluationPreferencesResult

    data object ExamNotFound :
        SaveEvaluationPreferencesResult

    data object ConcurrentModification :
        SaveEvaluationPreferencesResult
}

sealed interface LockEvaluationPreferencesResult {

    data class Success(
        val preferences: ExamEvaluationPreferencesEntity
    ) : LockEvaluationPreferencesResult

    data object PreferencesNotFound :
        LockEvaluationPreferencesResult

    data object AlreadyLocked :
        LockEvaluationPreferencesResult

    data object ConcurrentModification :
        LockEvaluationPreferencesResult
}

sealed interface CopyEvaluationPreferencesResult {

    data class Success(
        val preferences: ExamEvaluationPreferencesEntity
    ) : CopyEvaluationPreferencesResult

    data object SourcePreferencesNotFound :
        CopyEvaluationPreferencesResult

    data object TargetExamNotFound :
        CopyEvaluationPreferencesResult

    data object TargetAlreadyHasPreferences :
        CopyEvaluationPreferencesResult

    data object ConcurrentModification :
        CopyEvaluationPreferencesResult
}
