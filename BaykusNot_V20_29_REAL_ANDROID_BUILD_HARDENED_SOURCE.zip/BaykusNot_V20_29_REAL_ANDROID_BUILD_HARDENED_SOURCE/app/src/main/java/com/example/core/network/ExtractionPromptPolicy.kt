package com.example.core.network

import com.example.core.model.ExamType

/**
 * Human/AI-facing extraction instructions for the shared source pipeline.
 * Internal storage keeps the historical questionNumber/questionText field names,
 * but HOMEWORK is semantically task/item based.
 */
internal fun extractionInstruction(examType: ExamType): String =
    if (examType == ExamType.HOMEWORK) {
        "Aşağıdaki ödev kaynağındaki değerlendirilebilir tüm görev/maddeleri çıkarın. " +
            "Görevlerin sırasını, varsa madde numaralarını, görev metinlerini ve kaynakta açıkça belirtilen puanlarını aynen koruyun. " +
            "Başlık, genel açıklama, teslim tarihi, öğrenci adı alanı gibi tek başına değerlendirilecek görev olmayan metinleri görev olarak eklemeyin. " +
            "Puan yazmıyorsa puan tahmin etmeyin (null bırakın). " +
            "İç sistem alanları questionNumber/questionText adını taşısa da bunları görev/madde numarası ve görev/madde metni olarak doldurun."
    } else if (examType == ExamType.MULTIPLE_CHOICE) {
        "Aşağıdaki çoktan seçmeli test sınavından tüm soruları çıkarın. Soru numarasını, soru kökünü ve A/B/C/D/E gibi görünen TÜM seçenekleri questionText içinde eksiksiz ve sıralı biçimde koruyun. " +
            "Seçeneklerden hiçbirini atlamayın, doğru seçeneği soru metnine işaretlemeyin ve cevap uydurmayın. Sınavda açıkça puan yazıyorsa çıkarın; puan yazmıyorsa null bırakın."
    } else {
        "Aşağıdaki sınav dokümanından tüm soruları çıkarın. Soruların sırasını, soru numaralarını, soru metinlerini ve sınavda açıkça belirtilen puanlarını aynen koruyun. " +
            "KRİTİK BAĞLAM KURALI: Bir soru paragraf, şiir, ortak okuma metni, açıklama, tablo, grafik, görsel, yönerge veya başka bir uyarıcıya dayanıyorsa o uyarıcıyı atlama. Hangi soruların aynı ortak kaynağa dayandığını kendin belirle. " +
            "Her ilişkili sorunun questionText alanına, soru cümlesinden önce gerekli ortak kaynak metnini/bağlamı da ekle. Aynı kaynak birden fazla soruya aitse o soruların her birinde değerlendirme için yeterli bağlam bulunmalıdır. Görsel/tablo ise yalnız görünür ve gerekli içeriği sadık biçimde betimle; bilgi uydurma. " +
            "Sınavda puan yazmıyorsa puan tahmin etmeyin (null bırakın)."
    }

internal fun extractionSystemInstruction(examType: ExamType): String =
    if (examType == ExamType.HOMEWORK) {
        "Ödev kaynağından yalnız değerlendirilebilir görev/maddeleri çıkar. Genel yönerge, başlık, teslim bilgisi ve öğrenci kimlik alanlarını ayrı görev olarak üretme. " +
            "Görev sırasını ve metnini koru; yalnız açıkça yazılmış puanı çıkar, puan yoksa uydurma. " +
            "İç JSON alanlarındaki question ifadesi teknik şemadır ve görev/madde anlamında kullanılacaktır."
    } else if (examType == ExamType.MULTIPLE_CHOICE) {
        "Sadece çoktan seçmeli test sorularını çıkar. Yönerge, başlık ve öğrenci kimlik alanlarını soru olarak alma. Her sorunun köküyle birlikte görünen tüm seçenekleri questionText içinde aynen koru; seçenek atlama, doğru cevabı tahmin edip işaretleme. " +
            "Açıkça yazılan puanı çıkar, puan yazmıyorsa uydurma."
    } else {
        "Sadece sınav sorularını çıkar. Yönergeleri, başlıkları ve ad/soyad alanlarını bağımsız soru olarak alma. Soru sırasını koru. " +
            "Bir veya birden fazla sorunun dayandığı ortak paragraf/şiir/metin/tablo/grafik/görsel/açıklama varsa bunu kesinlikle kaybetme: hangi sorularla ilişkili olduğunu belirle ve gerekli kaynak bağlamını her ilgili questionText içinde soru cümlesinden önce koru. " +
            "Kaynak bağlam olmadan anlaşılamayan bir soruyu tek başına döndürme. Görsel bağlamı yalnız görülebilen unsurlara dayanarak kısa ve sadık biçimde betimle; uydurma yapma. " +
            "Açıkça yazılan puanı çıkar, puan yazmıyorsa uydurma."
    }
