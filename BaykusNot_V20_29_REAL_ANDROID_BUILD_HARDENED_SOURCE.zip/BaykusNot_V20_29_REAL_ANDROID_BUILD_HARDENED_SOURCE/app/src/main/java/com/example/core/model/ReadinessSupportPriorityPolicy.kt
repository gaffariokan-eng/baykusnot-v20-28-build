package com.example.core.model

/**
 * Diagnostic support-priority rules for readiness reports.
 * The threshold is not a pass/fail boundary; it only separates objectives that
 * are already broadly met from objectives that may deserve instructional support.
 */
object ReadinessSupportPriorityPolicy {
    const val SUPPORT_THRESHOLD_PERCENTAGE: Double = 70.0

    fun needsSupport(percentage: Double): Boolean =
        percentage.isFinite() && percentage < SUPPORT_THRESHOLD_PERCENTAGE

    fun supportRatePercentage(supportStudentCount: Int, measuredStudentCount: Int): Double {
        if (measuredStudentCount <= 0) return 0.0
        return (supportStudentCount.coerceIn(0, measuredStudentCount).toDouble() / measuredStudentCount.toDouble()) * 100.0
    }
}
