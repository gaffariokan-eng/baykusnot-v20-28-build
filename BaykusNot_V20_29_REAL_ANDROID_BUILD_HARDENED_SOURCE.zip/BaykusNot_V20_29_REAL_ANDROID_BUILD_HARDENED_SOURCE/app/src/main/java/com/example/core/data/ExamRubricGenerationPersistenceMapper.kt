package com.example.core.data

import com.example.core.model.ExamRubricCriterion
import com.example.core.network.ExamRubricGenerationValidationResult

object ExamRubricGenerationPersistenceMapper {
    fun map(
        examDraftId: Long,
        validation: ExamRubricGenerationValidationResult
    ): List<ExamRubricCriterion> {
        require(examDraftId > 0) { "examDraftId must be positive" }
        require(validation.isValid) { "validation result must be valid" }

        return validation.criteria.map { generated ->
            ExamRubricCriterion(
                id = 0L,
                examDraftId = examDraftId,
                questionOrderIndex = generated.questionOrderIndex,
                questionNumberSnapshot = generated.questionNumberSnapshot,
                criterionOrderIndex = generated.criterionOrderIndex,
                title = generated.title,
                description = generated.description,
                maxPoints = generated.maxPoints,
                expectedAnswer = generated.expectedAnswer,
                partialCreditGuidance = generated.partialCreditGuidance,
                commonMistakes = generated.commonMistakes
            )
        }
    }
}
