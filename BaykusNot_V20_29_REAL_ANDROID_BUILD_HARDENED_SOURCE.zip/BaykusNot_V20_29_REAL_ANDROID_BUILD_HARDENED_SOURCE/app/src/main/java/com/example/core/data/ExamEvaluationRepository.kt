package com.example.core.data

import com.example.core.database.ExamEvaluationDao
import com.example.core.database.ExamEvaluationPreferencesDao
import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamPaperUploadDao
import com.example.core.database.ExamQuestionDao
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamQuestionEvaluationEntity
import com.example.core.database.ExamRubricDao
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.database.ExamStudentEvaluationEntity
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.database.ExamAiRunProfileEntity
import com.example.core.database.ExamAiUsageEntity
import com.example.core.database.ExamReviewRequestEntity
import com.example.core.database.ExamYazekDeclarationEntity
import com.example.core.database.ExamObjectiveDao
import com.example.core.database.ExamProcessingModeEntity
import com.example.core.database.ExamEvaluationRunStateEntity
import com.example.core.network.ExamEvaluator
import com.example.core.network.ExamImagePrivacyProcessor
import com.example.core.network.ExamStudentEvaluationInput
import com.example.core.network.GeminiBatchJobManager
import com.example.core.network.HttpGeminiExamEvaluator
import com.example.core.network.HttpGeminiStudentFeedbackWriter
import com.example.core.network.GeminiModelProfileStore
import com.example.core.network.GeminiModelRegistry
import com.example.core.network.AiUsageMetadata
import com.example.core.network.ApprovedFeedbackQuestionEvidence
import com.example.core.network.ApprovedFeedbackRequest
import com.example.core.network.EvaluationPromptPolicy
import com.example.core.network.QuestionEvaluationOutput
import com.example.core.model.ExamType
import com.example.core.model.WorkflowStage
import com.example.core.model.MultipleChoiceManualReviewPolicy
import com.example.core.model.EvaluationMode
import com.example.core.security.SecureApiKeyStore
import com.example.core.security.StudentImageCrypto
import com.example.core.security.StudentAiComplianceGate
import com.example.core.security.HomeworkPrivacyMaskStore
import com.example.core.security.YazekDeclarationScope
import com.example.core.security.ProviderDataProtectionProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import com.example.core.database.ExamPaperPageEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.security.MessageDigest
import java.util.Locale

class ExamEvaluationRepository(
    private val evaluationDao: ExamEvaluationDao,
    private val paperUploadDao: ExamPaperUploadDao,
    private val questionDao: ExamQuestionDao,
    private val objectiveDao: ExamObjectiveDao,
    private val rubricDao: ExamRubricDao,
    private val preferencesDao: ExamEvaluationPreferencesDao,
    private val evaluator: ExamEvaluator,
    private val apiKeyStore: SecureApiKeyStore? = null,
    private val batchJobManager: GeminiBatchJobManager? = null,
    private val draftDao: ExamDraftDao? = null,
    private val paperUploadRepository: ExamPaperUploadRepository? = null,
    private val feedbackWriter: HttpGeminiStudentFeedbackWriter? = null,
    private val studentAiComplianceGate: StudentAiComplianceGate? = null,
    private val modelProfileStore: GeminiModelProfileStore? = null,
    private val homeworkPrivacyMaskStore: HomeworkPrivacyMaskStore? = null,
    private val evaluationPauseGuard: EvaluationPauseGuard? = null
) {

    private val evaluationMutex = Mutex()
    private val activeEvaluations = mutableSetOf<Long>()

    private val activeDraftEvaluations = mutableMapOf<Long, Job>()
    private val activeDirectRetryJobs = mutableMapOf<Long, MutableMap<Long, Job>>()
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val evaluationErrors = mutableMapOf<Long, String?>()
    private val evaluationProgress = mutableMapOf<Long, String>()
    private val currentEvaluatingPaper = mutableMapOf<Long, Long?>()
    private val remoteCleanupPendingCounts = java.util.concurrent.ConcurrentHashMap<Long, Int>()

    private val bypassCacheMap = java.util.concurrent.ConcurrentHashMap<Long, Boolean>()
    private val cacheCreationFailedMap = java.util.concurrent.ConcurrentHashMap<Long, Boolean>()

    private companion object {
        const val LARGE_EXAM_AUTO_BATCH_THRESHOLD = 50
    }

    private suspend fun buildYazekDeclarationScope(examDraftId: Long): YazekDeclarationScope {
        val draft = requireNotNull(draftDao?.getDraftByIdOnce(examDraftId)) { "Çalışma bulunamadı." }
        val allPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
        val eligiblePapers = allPapers.filter { paper ->
            paper.status == "READY" &&
                validateStudentIdentity(paper.classLevel, paper.branch, paper.schoolNumber).isValid
        }
        require(eligiblePapers.isNotEmpty()) {
            "YAZEK hedef kitlesi için READY ve kimliği doğrulanmış öğrenci kâğıdı bulunamadı."
        }
        require(eligiblePapers.size == allPapers.size) {
            "Kimliği doğrulanmamış veya READY olmayan öğrenci kâğıdı bulundu. Tüm kâğıtlar çözümlenmeden öğrenci verisi AI hizmetine gönderilemez."
        }
        val branches = eligiblePapers
            .mapNotNull { it.branch?.trim()?.uppercase(Locale.forLanguageTag("tr-TR")) }
            .filter { it.isNotBlank() }
            .toSortedSet()
        val approvedObjectives = objectiveDao.getApprovedObjectivesByDraftId(examDraftId)
        val lockedQuestions = questionDao.getByExamDraftIdOnce(examDraftId).sortedBy { it.orderIndex }
        val outcomeParts = if (approvedObjectives.isNotEmpty()) {
            approvedObjectives.map { objective ->
                listOfNotNull(
                    objective.learningArea?.trim()?.takeIf { it.isNotBlank() },
                    objective.objectiveCode?.trim()?.takeIf { it.isNotBlank() },
                    objective.objectiveText.trim().takeIf { it.isNotBlank() }
                ).joinToString(" — ")
            }
        } else {
            lockedQuestions.map { q -> "${q.questionNumber}: ${q.questionText.trim()}" }
        }.filter { it.isNotBlank() }
        require(outcomeParts.isNotEmpty()) {
            "YAZEK eğitsel amacı için onaylı öğrenme çıktısı/kazanım veya kilitli soru kapsamı bulunamadı."
        }
        val outcomeSignature = MessageDigest.getInstance("SHA-256")
            .digest(outcomeParts.joinToString(" || ").toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val purposePrefix = when (draft.examType) {
            ExamType.HOMEWORK -> "Ödev ürünlerinin öğretmen gözetiminde değerlendirilmesi"
            ExamType.LISTENING -> "Dinleme sınavı öğrenci cevaplarının öğretmen gözetiminde değerlendirilmesi"
            ExamType.READINESS -> "Hazırbulunuşluk düzeyinin öğretmen gözetiminde belirlenmesi"
            ExamType.MULTIPLE_CHOICE -> "Çoktan seçmeli ölçmenin yerel optik/öğretmen anahtarıyla yürütülmesi; yalnız kullanılan hazırlık AI rollerinin beyan edilmesi"
            ExamType.WRITTEN -> "Yazılı sınav öğrenci cevaplarının öğretmen gözetiminde değerlendirilmesi"
            ExamType.MIXED -> "Karma ölçme çalışmasının öğretmen gözetiminde değerlendirilmesi"
        }
        val purpose = "$purposePrefix — öğrenme alanı/çıktıları: ${outcomeParts.take(8).joinToString("; ")}"
        val applicationName = when (draft.examType) {
            ExamType.HOMEWORK -> "BaykuşNot — Ödev değerlendirme ve geri bildirim"
            ExamType.LISTENING -> "BaykuşNot — Dinleme sınavı değerlendirme ve geri bildirim"
            ExamType.READINESS -> "BaykuşNot — Hazırbulunuşluk ölçme ve geri bildirim"
            ExamType.MULTIPLE_CHOICE -> "BaykuşNot — Test ölçme desteği"
            ExamType.WRITTEN -> "BaykuşNot — Yazılı sınav değerlendirme ve geri bildirim"
            ExamType.MIXED -> "BaykuşNot — Karma ölçme değerlendirme ve geri bildirim"
        }
        val applicationSummary =
            "Öğrenci cevapları, kimlik başlığı cihazda ayrıldıktan sonra Google Gemini ile ölçme, değerlendirme ve geri bildirim desteği için işlenir. " +
                "Yapay zekâ yalnız öneri ve pedagojik teşhis üretir; öğretmen sonuçları inceler, düzeltebilir ve nihai akademik kararı verir."
        val providerProfile = ProviderDataProtectionProfile.current()
        return YazekDeclarationScope(
            academicYear = draft.academicYear.trim(),
            institutionName = draft.institutionName.trim(),
            courseName = draft.courseName.trim(),
            gradeLevel = draft.gradeLevel.trim(),
            examType = draft.examType.name,
            targetBranches = branches,
            applicationName = applicationName,
            applicationScopeLabels = setOf("Ölçme, Değerlendirme ve Geri Bildirim"),
            applicationSummary = applicationSummary,
            educationalPurpose = purpose,
            learningOutcomeSignature = outcomeSignature,
            providerPolicySignature = providerProfile.signature(),
            providerPolicySummary = providerProfile.noticeText()
        )
    }

    suspend fun getYazekDeclarationScope(examDraftId: Long): YazekDeclarationScope = withContext(Dispatchers.IO) {
        buildYazekDeclarationScope(examDraftId)
    }

    suspend fun isYazekDeclarationAcknowledged(examDraftId: Long): Boolean = withContext(Dispatchers.IO) {
        val scope = buildYazekDeclarationScope(examDraftId)
        studentAiComplianceGate?.isAllowed(scope) ?: false
    }

    suspend fun acknowledgeYazekDeclaration(
        examDraftId: Long,
        referenceNote: String? = null,
        officialDeclarationApplied: Boolean,
        noticeAndConsentCompleted: Boolean
    ) = withContext(Dispatchers.IO) {
        val scope = buildYazekDeclarationScope(examDraftId)
        requireNotNull(studentAiComplianceGate) { "YAZEK güvenlik kapısı yapılandırılmamış." }
            .acknowledge(
                scope = scope,
                referenceNote = referenceNote,
                officialDeclarationApplied = officialDeclarationApplied,
                noticeAndConsentCompleted = noticeAndConsentCompleted
            )
        bindYazekDeclarationAudit(examDraftId, scope)
    }

    private suspend fun bindYazekDeclarationAudit(examDraftId: Long, scope: YazekDeclarationScope) {
        val confirmedAt = studentAiComplianceGate?.acknowledgementTime(scope) ?: System.currentTimeMillis()
        evaluationDao.upsertYazekDeclarationAudit(
            ExamYazekDeclarationEntity(
                examDraftId = examDraftId,
                scopeFingerprint = scope.fingerprint(),
                scopeSummary = scope.humanSummary() +
                    "\nUygulama içi kontrol: Resmî YAZEK beyanının uygulamaya alındığı ve gerekli öğrenci/veli veri bilgilendirme/açık rıza-aydınlatılmış onam sürecinin tamamlandığı birlikte doğrulandı.",
                academicYear = scope.academicYear,
                confirmedAt = confirmedAt,
                referenceNote = studentAiComplianceGate?.referenceNote(scope)
            )
        )
    }

    private suspend fun requireStudentAiCompliance(examDraftId: Long) {
        val scope = buildYazekDeclarationScope(examDraftId)
        requireNotNull(studentAiComplianceGate) { "YAZEK güvenlik kapısı yapılandırılmamış." }
            .requireAllowed(scope)
        bindYazekDeclarationAudit(examDraftId, scope)
    }

    private suspend fun processingMode(examDraftId: Long): ExamProcessingModeEntity {
        evaluationDao.getProcessingMode(examDraftId)?.let { return it }
        val source = if (resolveExamType(examDraftId) == ExamType.MULTIPLE_CHOICE) "LOCAL_OPTICAL" else "AI"
        val mode = ExamProcessingModeEntity(
            examDraftId = examDraftId,
            evaluationSource = source,
            feedbackSource = if (source == "AI") "AI" else "NONE",
            reason = "Varsayılan çalışma modu"
        )
        evaluationDao.upsertProcessingMode(mode)
        return mode
    }

    suspend fun getProcessingMode(examDraftId: Long): ExamProcessingModeEntity = withContext(Dispatchers.IO) { processingMode(examDraftId) }

    private suspend fun requireAiEvaluationEnabled(examDraftId: Long) {
        val mode = processingMode(examDraftId)
        require(mode.evaluationSource == "AI") {
            "Bu çalışma manuel değerlendirme modunda. AI yeniden açıkça etkinleştirilmeden öğrenci verisi AI değerlendirmesine gönderilemez."
        }
    }

    suspend fun enableAiProcessing(examDraftId: Long) = withContext(Dispatchers.IO) {
        require(resolveExamType(examDraftId) != ExamType.MULTIPLE_CHOICE) { "Test sınavında AI öğrenci puanlaması kullanılamaz." }
        evaluationDao.upsertProcessingMode(
            ExamProcessingModeEntity(examDraftId, "AI", "AI", System.currentTimeMillis(), "Öğretmen AI değerlendirmesini açıkça yeniden etkinleştirdi")
        )
    }

    private suspend fun disableAiForManualProcessing(examDraftId: Long) {
        evaluationDao.upsertProcessingMode(
            ExamProcessingModeEntity(examDraftId, "MANUAL", "NONE", System.currentTimeMillis(), "AI hizmeti kullanılmadan öğretmen manuel değerlendirmesi")
        )
    }

    private fun privacyMasksFor(pages: List<ExamPaperPageEntity>): Map<Long, List<com.example.core.security.PrivacyMaskRect>> =
        homeworkPrivacyMaskStore?.let { store ->
            pages.associate { it.id to store.masksForPage(it.id) }.filterValues { it.isNotEmpty() }
        }.orEmpty()

    private suspend fun ensureAiRunProfile(examDraftId: Long): ExamAiRunProfileEntity {
        val approvalStore = requireNotNull(modelProfileStore) {
            "AI model onay deposu yapılandırılmamış; öğrenci verisiyle AI işlemi başlatılamaz."
        }
        evaluationDao.getAiRunProfile(examDraftId)?.let { existing ->
            val evaluationApproved = approvalStore.isEvaluationModelApproved(
                existing.evaluationModel,
                existing.highImageTokens,
                existing.supportsHighMediaResolution,
                existing.supportsBatch,
                existing.supportsPromptCaching,
                existing.supportsThinkingLevel
            )
            val feedbackApproved = approvalStore.isModelApproved(
                existing.feedbackModel,
                GeminiModelProfileStore.BenchmarkRole.FEEDBACK
            )
            val authoringApproved = approvalStore.isModelApproved(
                existing.authoringModel,
                GeminiModelProfileStore.BenchmarkRole.AUTHORING
            )
            require(evaluationApproved && feedbackApproved && authoringApproved) {
                "Bu sınavın imzalı üretim model onayı eksik veya süresi dolmuş. Onaylı güncel BaykuşNot sürümünü kullanın ya da uygulama yöneticisine başvurun."
            }
            return existing
        }
        val profile = GeminiModelRegistry.currentProfile()
        require(approvalStore.isProfileApproved(profile)) {
            "Bu sürümün imzalı üretim model onayı eksik veya süresi dolmuş. Onaylı güncel BaykuşNot sürümünü kullanın ya da uygulama yöneticisine başvurun."
        }
        val entity = ExamAiRunProfileEntity(
            examDraftId = examDraftId,
            evaluationModel = profile.evaluationModel,
            feedbackModel = profile.feedbackModel,
            authoringModel = profile.authoringModel,
            evaluationInputPerMillionUsd = profile.evaluationInputPerMillionUsd,
            evaluationOutputPerMillionUsd = profile.evaluationOutputPerMillionUsd,
            evaluationCachedInputPerMillionUsd = profile.evaluationCachedInputPerMillionUsd,
            cacheStoragePerMillionTokenHourUsd = profile.cacheStoragePerMillionTokenHourUsd,
            feedbackInputPerMillionUsd = profile.feedbackInputPerMillionUsd,
            feedbackOutputPerMillionUsd = profile.feedbackOutputPerMillionUsd,
            authoringInputPerMillionUsd = profile.authoringInputPerMillionUsd,
            authoringOutputPerMillionUsd = profile.authoringOutputPerMillionUsd,
            authoringCachedInputPerMillionUsd = profile.authoringCachedInputPerMillionUsd,
            batchPriceFactor = profile.batchPriceFactor,
            highImageTokens = profile.highImageTokens,
            supportsHighMediaResolution = profile.supportsHighMediaResolution,
            supportsBatch = profile.supportsBatch,
            supportsPromptCaching = profile.supportsPromptCaching,
            supportsThinkingLevel = profile.supportsThinkingLevel,
            preferBatchEvaluation = profile.preferBatchEvaluation,
            promptPolicyVersion = "EVAL_POLICY_V20_4",
            legacyPrivacyApprovedAt = null,
            homeworkPrivacyApprovedAt = null,
            profileUpdatedAt = profile.updatedAt,
            lockedAt = System.currentTimeMillis()
        )
        evaluationDao.insertAiRunProfile(entity)
        return evaluationDao.getAiRunProfile(examDraftId) ?: entity
    }

    suspend fun getReviewRequestsForPaper(studentPaperId: Long): List<ExamReviewRequestEntity> = withContext(Dispatchers.IO) {
        evaluationDao.getReviewRequestsForPaper(studentPaperId)
    }

    suspend fun getReviewRequestsForExam(examDraftId: Long): List<ExamReviewRequestEntity> = withContext(Dispatchers.IO) {
        evaluationDao.getReviewRequestsForExam(examDraftId)
    }

    suspend fun recordStudentParentReviewRequest(
        examDraftId: Long,
        studentPaperId: Long,
        reason: String
    ): Long = withContext(Dispatchers.IO) {
        val normalizedReason = reason.trim()
        require(normalizedReason.length >= 3) { "Yeniden inceleme gerekçesi en az 3 karakter olmalıdır." }
        val currentScore = evaluationDao.getStudentEvaluationOnce(studentPaperId)?.totalScore
        evaluationDao.insertReviewRequest(
            ExamReviewRequestEntity(
                examDraftId = examDraftId,
                studentPaperId = studentPaperId,
                reason = normalizedReason,
                scoreBefore = currentScore
            )
        )
    }

    suspend fun resolveStudentParentReviewRequest(requestId: Long, resolutionNote: String) = withContext(Dispatchers.IO) {
        val request = requireNotNull(evaluationDao.getReviewRequestById(requestId)) { "Yeniden inceleme talebi bulunamadı." }
        require(request.status == "OPEN") { "Bu yeniden inceleme talebi zaten kapatılmış." }
        val currentScore = evaluationDao.getStudentEvaluationOnce(request.studentPaperId)?.totalScore
        evaluationDao.resolveReviewRequest(
            requestId = requestId,
            scoreAfter = currentScore,
            resolvedAt = System.currentTimeMillis(),
            resolutionNote = resolutionNote.trim().ifBlank { "Öğretmen yeniden inceledi; güncel puan ve değerlendirme kaydı esas alındı." }
        )
    }

    suspend fun prepareManualTeacherReview(examDraftId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            stopEvaluationAndAwait(examDraftId, cleanupRemoteBatch = true)
            val examType = resolveExamType(examDraftId)
            require(examType != ExamType.MULTIPLE_CHOICE) { "Test sınavı için yerel optik değerlendirme akışını kullanın." }
            val questions = questionDao.getByExamDraftIdOnce(examDraftId)
            require(questions.isNotEmpty()) { "Manuel değerlendirme için soru/görev listesi bulunamadı." }
            val papers = paperUploadDao.getPapersForExamOnce(examDraftId)
            require(papers.isNotEmpty()) { "Manuel değerlendirme için öğrenci kâğıdı bulunamadı." }
            val totalMax = questions.sumOf { it.points.toDouble() }
            disableAiForManualProcessing(examDraftId)

            papers.forEach { paper ->
                val existingQ = evaluationDao.getQuestionEvaluationsForPaperOnce(paper.id)
                    .associateBy { it.questionOrderIndex }
                val manualQuestions = questions.map { q ->
                    val existing = existingQ[q.orderIndex]
                    ExamQuestionEvaluationEntity(
                        id = existing?.id ?: 0L,
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        questionNumber = q.questionNumber,
                        questionOrderIndex = q.orderIndex,
                        readAnswerText = "",
                        score = 0.0,
                        maxScore = q.points.toDouble(),
                        feedback = null,
                        interpretedMeaning = null,
                        gradingEvidence = null,
                        readingConfidence = 0.0,
                        evaluationConfidence = 0.0,
                        answerType = "MANUAL",
                        needsReview = true,
                        reviewReason = "AI kullanılmadan öğretmen manuel değerlendirmesi",
                        originalScore = 0.0,
                        isTeacherModified = true,
                        isResolved = false
                    )
                }
                val currentTotal = manualQuestions.sumOf { it.score }
                evaluationDao.saveCompleteEvaluationTransaction(
                    ExamStudentEvaluationEntity(
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        status = "NEEDS_REVIEW",
                        totalScore = currentTotal,
                        totalMaxScore = totalMax,
                        overallConfidence = 0.0,
                        needsReview = true,
                        errorMessage = null,
                        isTeacherApproved = false
                    ),
                    manualQuestions
                )
            }
        }
    }

    suspend fun getLockedEvaluationModel(examDraftId: Long): String? = withContext(Dispatchers.IO) {
        evaluationDao.getAiRunProfile(examDraftId)?.evaluationModel
    }

    suspend fun getLegacyPrivacyPages(examDraftId: Long, limit: Int = Int.MAX_VALUE): List<ExamPaperPageEntity> = withContext(Dispatchers.IO) {
        paperUploadDao.getPagesForExamOnce(examDraftId)
            .filter { page ->
                val raw = page.qrRawContent.orEmpty()
                raw.isNotBlank() && Regex("(?:^|\\|)V:(\\d+)(?:\\||$)").find(raw) == null
            }
            .take(limit.coerceAtLeast(0))
    }

    suspend fun requiresLegacyPrivacyApproval(examDraftId: Long): Boolean = withContext(Dispatchers.IO) {
        val run = ensureAiRunProfile(examDraftId)
        val legacy = getLegacyPrivacyPages(examDraftId)
        legacy.any { page -> run.legacyPrivacyApprovedAt == null || page.createdAt > run.legacyPrivacyApprovedAt }
    }

    suspend fun approveLegacyPrivacy(examDraftId: Long, viewedPageIds: Set<Long>) = withContext(Dispatchers.IO) {
        ensureAiRunProfile(examDraftId)
        val pages = getLegacyPrivacyPages(examDraftId)
        require(pages.isNotEmpty()) { "Onaylanacak eski form sayfası bulunamadı." }
        require(pages.all { it.id in viewedPageIds }) {
            "Tüm eski form sayfaları öğretmen tarafından görüntülenmeden gizlilik onayı verilemez."
        }
        require(pages.all { page ->
            runCatching {
                ExamImagePrivacyProcessor.prepareLegacyPrivacyPreview(page.imagePath, page.pageIndex)?.let { bitmap ->
                    bitmap.recycle()
                    true
                } ?: false
            }.getOrDefault(false)
        }) {
            "En az bir eski form sayfasının güvenli AI önizlemesi üretilemedi. AI değerlendirmesi engellendi."
        }
        evaluationDao.approveLegacyPrivacy(examDraftId)
    }

    private suspend fun requireLegacyPrivacyIfNeeded(examDraftId: Long, run: ExamAiRunProfileEntity) {
        val legacy = getLegacyPrivacyPages(examDraftId)
        if (legacy.any { page -> run.legacyPrivacyApprovedAt == null || page.createdAt > run.legacyPrivacyApprovedAt }) {
            throw IllegalStateException("Eski veya sonradan eklenen BaykuşNot cevap kâğıdı için gizlilik önizlemesi onaylanmadan öğrenci verisi AI'a gönderilemez.")
        }
    }


    suspend fun requiresHomeworkPrivacyApproval(examDraftId: Long): Boolean = withContext(Dispatchers.IO) {
        if (resolveExamType(examDraftId) != ExamType.HOMEWORK) return@withContext false
        val run = ensureAiRunProfile(examDraftId)
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        pages.any { page -> run.homeworkPrivacyApprovedAt == null || page.createdAt > run.homeworkPrivacyApprovedAt }
    }

    suspend fun approveHomeworkPrivacy(examDraftId: Long, viewedPageIds: Set<Long>) = withContext(Dispatchers.IO) {
        ensureAiRunProfile(examDraftId)
        require(resolveExamType(examDraftId) == ExamType.HOMEWORK) { "Bu gizlilik onayı yalnız ödev akışı içindir." }
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        require(pages.isNotEmpty()) { "Onaylanacak ödev sayfası bulunamadı." }
        require(pages.all { it.id in viewedPageIds }) {
            "Tüm ödev sayfaları öğretmen tarafından görüntülenmeden gizlilik onayı verilemez."
        }
        require(pages.all { page ->
            runCatching {
                StudentImageCrypto.decodeBitmap(page.imagePath)?.let { bitmap ->
                    bitmap.recycle()
                    true
                } ?: false
            }.getOrDefault(false)
        }) {
            "En az bir ödev sayfası güvenli biçimde görüntülenemedi. AI değerlendirmesi engellendi."
        }
        evaluationDao.approveHomeworkPrivacy(examDraftId)
    }

    private suspend fun requireHomeworkPrivacyIfNeeded(examDraftId: Long, run: ExamAiRunProfileEntity) {
        if (resolveExamType(examDraftId) != ExamType.HOMEWORK) return
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        if (pages.any { page -> run.homeworkPrivacyApprovedAt == null || page.createdAt > run.homeworkPrivacyApprovedAt }) {
            throw IllegalStateException("Ödev gizlilik kontrolü onaylanmadan öğrenci verisi AI'a gönderilemez.")
        }
    }

    private fun usageCostUsd(usage: AiUsageMetadata, run: ExamAiRunProfileEntity, feedback: Boolean, batch: Boolean): Double {
        val batchFactor = if (batch) run.batchPriceFactor else 1.0
        val cached = usage.cachedInputTokens.coerceAtMost(usage.inputTokens).coerceAtLeast(0)
        val uncached = (usage.inputTokens - cached).coerceAtLeast(0)
        val inputPrice = if (feedback) run.feedbackInputPerMillionUsd else run.evaluationInputPerMillionUsd
        val cachedPrice = if (feedback) inputPrice else run.evaluationCachedInputPerMillionUsd
        val outputPrice = if (feedback) run.feedbackOutputPerMillionUsd else run.evaluationOutputPerMillionUsd
        val uncachedInputCost = uncached * inputPrice * batchFactor
        // Gemini Batch also discounts cache-hit token usage; storage is accounted separately.
        val cachedInputCost = cached * cachedPrice * batchFactor
        val outputCost = (usage.outputTokens + usage.thinkingTokens) * outputPrice * batchFactor
        return (uncachedInputCost + cachedInputCost + outputCost) / 1_000_000.0
    }

    private suspend fun recordUsage(examDraftId: Long, paperId: Long?, stage: String, modelId: String, usage: AiUsageMetadata, run: ExamAiRunProfileEntity, feedback: Boolean = false, batch: Boolean = false) {
        if (usage.inputTokens <= 0 && usage.outputTokens <= 0 && usage.thinkingTokens <= 0 && usage.cachedInputTokens <= 0) return
        evaluationDao.insertAiUsage(
            ExamAiUsageEntity(
                examDraftId = examDraftId,
                studentPaperId = paperId,
                stage = stage,
                modelId = modelId,
                useBatchPricing = batch,
                inputTokens = usage.inputTokens,
                cachedInputTokens = usage.cachedInputTokens,
                outputTokens = usage.outputTokens,
                thinkingTokens = usage.thinkingTokens,
                estimatedCostUsd = usageCostUsd(usage, run, feedback, batch),
                actualModelVersion = usage.actualModelVersion,
                responseId = usage.responseId,
                modelStatusStage = usage.modelStatusStage,
                modelRetirementTime = usage.modelRetirementTime,
                modelStatusMessage = usage.modelStatusMessage
            )
        )
    }

    private suspend fun resolveExamType(examDraftId: Long): ExamType =
        draftDao?.getDraftByIdOnce(examDraftId)?.examType ?: ExamType.WRITTEN

    /** Rebuild the exact printed answer-sheet geometry so AI privacy crops match the paper 1:1. */
    private suspend fun buildAnswerSheetLayouts(
        examDraftId: Long,
        questions: List<ExamQuestionEntity>,
        rubrics: List<ExamRubricCriterionEntity>,
        examType: ExamType
    ): List<AnswerSheetPageLayout> {
        if (examType == ExamType.HOMEWORK || examType == ExamType.MULTIPLE_CHOICE) return emptyList()
        val repo = paperUploadRepository ?: return ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = questions,
            rubricCriteria = rubrics,
            examType = examType
        )
        return ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = questions,
            rubricCriteria = rubrics,
            densitySetting = repo.getLayoutDensity(examDraftId),
            lineOverrides = repo.getLineOverrides(examDraftId),
            listeningGuidance = repo.getAnswerSheetGuidance(examDraftId),
            examType = examType
        )
    }

    private fun itemLabel(examType: ExamType): String = if (examType == ExamType.HOMEWORK) "Görev/madde" else "Soru"
    private fun itemSetLabel(examType: ExamType): String = if (examType == ExamType.HOMEWORK) "Görev/madde seti" else "Soru seti"
    private fun submissionLabel(examType: ExamType): String = when (examType) {
        ExamType.HOMEWORK -> "ödev teslimi"
        ExamType.READINESS -> "hazırbulunuşluk öğrenci kâğıdı"
        else -> "öğrenci kâğıdı"
    }

    private fun missingSubmissionPageMessage(examType: ExamType): String = when (examType) {
        ExamType.HOMEWORK -> "Ödev teslimine ait sayfa bulunamadı."
        ExamType.READINESS -> "Hazırbulunuşluk öğrenci kâğıdına ait sayfa bulunamadı."
        else -> "Öğrenci kâğıdına ait sayfa bulunamadı."
    }

    private fun wrongAssessmentPageMessage(examType: ExamType): String = when (examType) {
        ExamType.HOMEWORK -> "Sayfa başka bir ödev kontrolüne ait."
        ExamType.READINESS -> "Sayfa başka bir hazırbulunuşluk sınavına ait."
        else -> "Sayfa başka bir sınava ait."
    }

    private fun missingImageMessage(examType: ExamType): String = when (examType) {
        ExamType.HOMEWORK -> "Ödev teslimi görseli diskte bulunamadı."
        ExamType.READINESS -> "Hazırbulunuşluk öğrenci kâğıdı görseli diskte bulunamadı."
        else -> "Öğrenci kâğıdı görseli diskte bulunamadı."
    }

    fun allowBypassCacheForDraft(examDraftId: Long, allow: Boolean) {
        bypassCacheMap[examDraftId] = allow
        if (allow) {
            cacheCreationFailedMap[examDraftId] = false
        }
    }

    private suspend fun checkAndGetCache(
        examDraftId: Long,
        apiKey: String,
        questions: List<com.example.core.database.ExamQuestionEntity>,
        rubrics: List<com.example.core.database.ExamRubricCriterionEntity>,
        systemInstructionText: String,
        usePromptCachingPreference: Boolean,
        ttlSeconds: Int,
        examType: ExamType = ExamType.WRITTEN,
        evaluationModelId: String
    ): String? {
        if (evaluator !is HttpGeminiExamEvaluator) return null
        val cacheMgr = evaluator.getCacheManager() ?: return null
        if (!cacheMgr.shouldPerformCaching(questions, rubrics, systemInstructionText, usePromptCachingPreference)) {
            return null
        }
        
        if (bypassCacheMap[examDraftId] == true) {
            return null
        }
        
        if (cacheCreationFailedMap[examDraftId] == true) {
            throw Exception("PROMPT_CACHE_FAILED: Prompt Cache oluşturulamadı. Güvenliğiniz ve bütçeniz için değerlendirme durduruldu. Cache olmadan devam etmek istiyor musunuz?")
        }
        
        val cachedRes = cacheMgr.getOrCreateCache(
            draftId = examDraftId,
            questions = questions,
            rubrics = rubrics,
            systemInstructionText = systemInstructionText,
            apiKey = apiKey,
            ttlSeconds = ttlSeconds,
            examType = examType,
            evaluationModelId = evaluationModelId
        )
        
        if (cachedRes == null) {
            cacheCreationFailedMap[examDraftId] = true
            throw Exception("PROMPT_CACHE_FAILED: Prompt Cache oluşturulamadı. Güvenliğiniz ve bütçeniz için değerlendirme durduruldu. Cache olmadan devam etmek istiyor musunuz?")
        }
        
        return cachedRes
    }

    @Synchronized
    fun isEvaluating(examDraftId: Long): Boolean {
        return synchronized(this) {
            activeDraftEvaluations[examDraftId]?.isActive == true ||
                activeDirectRetryJobs[examDraftId]?.values?.any { it.isActive } == true
        }
    }

    @Synchronized
    fun getProgress(examDraftId: Long): String {
        return evaluationProgress[examDraftId] ?: ""
    }

    @Synchronized
    fun getEvaluationError(examDraftId: Long): String? {
        return evaluationErrors[examDraftId]
    }

    @Synchronized
    fun clearEvaluationError(examDraftId: Long) {
        evaluationErrors[examDraftId] = null
    }

    @Synchronized
    fun getCurrentEvaluatingPaperId(examDraftId: Long): Long? {
        return currentEvaluatingPaper[examDraftId]
    }

    fun hasUnprocessedBatchJobs(examDraftId: Long): Boolean {
        return batchJobManager?.getUnprocessedJobsForDraft(examDraftId)?.isNotEmpty() ?: false
    }

    private suspend fun persistEvaluationRunState(
        examDraftId: Long,
        requestedMode: String,
        status: String,
        lastError: String? = null
    ) {
        val total = paperUploadDao.getPapersForExamOnce(examDraftId).size
        val terminal = evaluationDao.getStudentEvaluationsForExamOnce(examDraftId).count {
            it.status == "COMPLETED" || it.status == "NEEDS_REVIEW" || it.status == "ERROR"
        }
        evaluationDao.upsertEvaluationRunState(
            ExamEvaluationRunStateEntity(
                examDraftId = examDraftId,
                requestedMode = requestedMode,
                status = status,
                completedCount = terminal,
                totalCount = total,
                lastError = lastError,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * Restores a user-requested long evaluation after Android process death. Completed student
     * transactions are skipped; recoverable remote Batch jobs are polled instead of duplicated.
     */
    suspend fun resumeDurableEvaluationIfNeeded(examDraftId: Long): Boolean {
        if (isEvaluating(examDraftId)) return false
        val state = evaluationDao.getEvaluationRunState(examDraftId)
        // Only a durable RUNNING request may auto-resume. PAUSED/ERROR are terminal for automatic
        // recovery even when a remote Batch job still exists.
        if (state?.status != "RUNNING") return false
        if (evaluationPauseGuard?.isPaused(examDraftId) == true) return false
        val hasRecoverableBatch = hasUnprocessedBatchJobs(examDraftId)
        val processing = evaluationDao.getProcessingMode(examDraftId)
        if (processing?.evaluationSource == "MANUAL") return false
        val draft = draftDao?.getDraftByIdOnce(examDraftId) ?: return false
        if (draft.currentWorkflowStage != WorkflowStage.AI_EVALUATION) return false
        startEvaluation(examDraftId, useBatch = hasRecoverableBatch || state.requestedMode == "BATCH", userInitiated = false)
        return true
    }

    private suspend fun requireAiEvaluationWorkflowStage(examDraftId: Long) {
        val draft = requireNotNull(draftDao?.getDraftByIdOnce(examDraftId)) { "Çalışma bulunamadı." }
        require(draft.currentWorkflowStage == WorkflowStage.AI_EVALUATION) {
            "AI değerlendirmesi yalnız AI Değerlendirme aşamasında başlatılabilir. Güncel aşama: ${draft.currentWorkflowStage}."
        }
    }

    @Synchronized
    fun startEvaluation(examDraftId: Long, useBatch: Boolean, userInitiated: Boolean = true) {
        if (isEvaluating(examDraftId)) return
        val durableState = runBlocking(Dispatchers.IO) { evaluationDao.getEvaluationRunState(examDraftId) }
        if (durableState?.status == "PAUSE_REMOTE_CANCEL_PENDING" || durableState?.status == "PAUSE_REQUESTED") {
            evaluationErrors[examDraftId] = "Önceki uzak Batch iptali/temizliği tamamlanmadan yeni değerlendirme başlatılamaz."
            return
        }
        if (userInitiated) {
            if (evaluationPauseGuard?.clearPause(examDraftId) == false) {
                evaluationErrors[examDraftId] = "Değerlendirme duraklatma kilidi güvenli biçimde kaldırılamadı."
                return
            }
        } else if (evaluationPauseGuard?.isPaused(examDraftId) == true) {
            return
        }

        evaluationErrors[examDraftId] = null
        evaluationProgress[examDraftId] = "Başlatılıyor..."

        val job = repositoryScope.launch {
            var requestedMode = if (useBatch) "BATCH" else "AUTO"
            try {
                requireAiEvaluationWorkflowStage(examDraftId)
                requireAiEvaluationEnabled(examDraftId)
                requireStudentAiCompliance(examDraftId)
                if (resolveExamType(examDraftId) == ExamType.MULTIPLE_CHOICE) {
                    val message = "Test Sınavı yapay zekâ ile değerlendirilmez. Yerel Optik Okuma ekranını kullanın."
                    synchronized(this@ExamEvaluationRepository) {
                        evaluationErrors[examDraftId] = message
                        evaluationProgress[examDraftId] = ""
                    }
                    persistEvaluationRunState(examDraftId, requestedMode, "ERROR", message)
                    return@launch
                }

                // Defensive runtime normalization in addition to Room 29->30 migration.
                preferencesDao.canonicalizeTeacherMode(examDraftId, System.currentTimeMillis())
                val runProfile = ensureAiRunProfile(examDraftId)
                val preferences = preferencesDao.getPreferencesOnce(examDraftId)
                val paperCount = paperUploadDao.getPapersForExamOnce(examDraftId).size
                val questionByQuestion = preferences?.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION
                val largeExamAutoBatch = paperCount >= LARGE_EXAM_AUTO_BATCH_THRESHOLD &&
                    batchJobManager != null && runProfile.supportsBatch && !questionByQuestion
                val batchRequested = useBatch || (preferences?.useBatchApi == true) ||
                    runProfile.preferBatchEvaluation || largeExamAutoBatch
                val effectiveBatch = batchRequested && runProfile.supportsBatch && !questionByQuestion && batchJobManager != null
                requestedMode = if (effectiveBatch) "BATCH" else "SEQUENTIAL"
                persistEvaluationRunState(examDraftId, requestedMode, "RUNNING")

                if (largeExamAutoBatch) {
                    synchronized(this@ExamEvaluationRepository) {
                        evaluationProgress[examDraftId] = "Büyük sınıf güvenli ve devam ettirilebilir Batch değerlendirmesine alındı..."
                    }
                }

                if (effectiveBatch) {
                    val res = evaluateExamBatch(examDraftId) { msg ->
                        synchronized(this@ExamEvaluationRepository) { evaluationProgress[examDraftId] = msg }
                    }
                    if (res.isFailure) throw res.exceptionOrNull() ?: IllegalStateException("Batch değerlendirmesi başarısız.")
                } else {
                    evaluateStandardSequentially(examDraftId) { msg ->
                        synchronized(this@ExamEvaluationRepository) { evaluationProgress[examDraftId] = msg }
                    }
                    evaluationErrors[examDraftId]?.let { throw IllegalStateException(it) }
                }
                persistEvaluationRunState(examDraftId, requestedMode, "COMPLETED")
            } catch (e: CancellationException) {
                // A user-requested remote pause writes PAUSE_REQUESTED before cancelling this job.
                // Never overwrite that durable cleanup state with PAUSED; otherwise a process death
                // between local cancellation and provider cancellation could strand a live remote Batch.
                runCatching {
                    val current = evaluationDao.getEvaluationRunState(examDraftId)
                    if (current?.status !in setOf("PAUSE_REQUESTED", "PAUSE_REMOTE_CANCEL_PENDING")) {
                        persistEvaluationRunState(examDraftId, requestedMode, "PAUSED")
                    }
                }
                throw e
            } catch (e: Exception) {
                synchronized(this@ExamEvaluationRepository) { evaluationErrors[examDraftId] = e.message }
                runCatching { persistEvaluationRunState(examDraftId, requestedMode, "ERROR", e.message) }
            } finally {
                synchronized(this@ExamEvaluationRepository) { evaluationProgress[examDraftId] = "" }
            }
        }
        activeDraftEvaluations[examDraftId] = job
    }

    /**
     * User-facing pause boundary. A local pause alone is not sufficient for provider Batch work:
     * every known remote Batch/file resource is cancelled/cleaned before PAUSED is certified.
     * If provider cancellation is still pending, the durable state remains
     * PAUSE_REMOTE_CANCEL_PENDING and a new evaluation cannot start.
     */
    suspend fun pauseEvaluationAndCancelRemote(examDraftId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val guardOk = evaluationPauseGuard?.markPaused(examDraftId) ?: true
            check(guardOk) { "Duraklatma güvenlik işareti kalıcılaştırılamadı." }
            val previous = evaluationDao.getEvaluationRunState(examDraftId)
            val requestedMode = previous?.requestedMode ?: "AUTO"
            persistEvaluationRunState(examDraftId, requestedMode, "PAUSE_REQUESTED")

            val (job, retryJobs) = synchronized(this@ExamEvaluationRepository) {
                activeDraftEvaluations.remove(examDraftId) to
                    activeDirectRetryJobs.remove(examDraftId)?.values?.toList().orEmpty()
            }
            job?.cancelAndJoin()
            retryJobs.forEach { it.cancelAndJoin() }
            synchronized(this@ExamEvaluationRepository) {
                evaluationProgress[examDraftId] = "Uzak Batch durduruluyor ve veri kaynakları temizleniyor..."
                currentEvaluatingPaper[examDraftId] = null
            }

            val manager = batchJobManager
            if (manager != null && manager.getUnprocessedJobsForDraft(examDraftId).isNotEmpty()) {
                var cleanup: com.example.core.network.BatchCleanupResult? = null
                if (apiKeyStore != null) {
                    apiKeyStore.useApiKey { key ->
                        cleanup = manager.cleanupDraft(examDraftId, key)
                    }
                }
                if (cleanup == null) cleanup = manager.cleanupDraft(examDraftId, null)
                val pending = cleanup?.pendingRemoteDeletion ?: 0
                remoteCleanupPendingCounts[examDraftId] = pending
                if (pending > 0) {
                    val message = "Uzak Batch iptali başlatıldı ancak sağlayıcı terminal durumu henüz doğrulanmadı. Yeni değerlendirme başlatılmayacak; bu ekran tekrar açıldığında yalnız iptal/temizlik kontrolü sürdürülecek."
                    persistEvaluationRunState(examDraftId, requestedMode, "PAUSE_REMOTE_CANCEL_PENDING", message)
                    synchronized(this@ExamEvaluationRepository) {
                        evaluationErrors[examDraftId] = message
                        evaluationProgress[examDraftId] = ""
                    }
                    error(message)
                }
            }

            persistEvaluationRunState(examDraftId, requestedMode, "PAUSED")
            synchronized(this@ExamEvaluationRepository) {
                evaluationErrors[examDraftId] = null
                evaluationProgress[examDraftId] = ""
            }
        }
    }

    /** Retry only remote pause cleanup after process death; never resumes evaluation work. */
    suspend fun retryPendingPauseRemoteCleanup(examDraftId: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val state = evaluationDao.getEvaluationRunState(examDraftId) ?: return@runCatching false
            if (state.status !in setOf("PAUSE_REQUESTED", "PAUSE_REMOTE_CANCEL_PENDING")) return@runCatching false
            val manager = batchJobManager ?: error("Uzak Batch temizleme bileşeni kullanılamıyor.")
            var cleanup: com.example.core.network.BatchCleanupResult? = null
            if (apiKeyStore != null) {
                apiKeyStore.useApiKey { key -> cleanup = manager.cleanupDraft(examDraftId, key) }
            }
            if (cleanup == null) cleanup = manager.cleanupDraft(examDraftId, null)
            val pending = cleanup?.pendingRemoteDeletion ?: 0
            remoteCleanupPendingCounts[examDraftId] = pending
            if (pending > 0) {
                val message = "Uzak Batch iptali/temizliği sağlayıcıda hâlâ bekliyor; değerlendirme yeniden başlatılamaz."
                persistEvaluationRunState(examDraftId, state.requestedMode, "PAUSE_REMOTE_CANCEL_PENDING", message)
                synchronized(this@ExamEvaluationRepository) { evaluationErrors[examDraftId] = message }
                return@runCatching false
            }
            persistEvaluationRunState(examDraftId, state.requestedMode, "PAUSED")
            synchronized(this@ExamEvaluationRepository) { evaluationErrors[examDraftId] = null }
            true
        }
    }

    /** Compatibility entry point; callers should prefer the suspend pause API above. */
    fun stopEvaluation(examDraftId: Long) {
        runBlocking(Dispatchers.IO) { pauseEvaluationAndCancelRemote(examDraftId).getOrThrow() }
    }

    /**
     * Used by the MANUAL transition: local coroutine termination is awaited before records are
     * rewritten, then every known remote Batch/file resource is cancelled/deleted or retained as
     * REMOTE_DELETE_PENDING. This closes the AI->MANUAL write race.
     */
    suspend fun stopEvaluationAndAwait(examDraftId: Long, cleanupRemoteBatch: Boolean = false) {
        if (cleanupRemoteBatch) {
            pauseEvaluationAndCancelRemote(examDraftId).getOrElse { throw it }
            return
        }
        val (job, retryJobs) = synchronized(this) {
            activeDraftEvaluations.remove(examDraftId) to
                activeDirectRetryJobs.remove(examDraftId)?.values?.toList().orEmpty()
        }
        job?.cancelAndJoin()
        retryJobs.forEach { it.cancelAndJoin() }
        synchronized(this) {
            evaluationProgress[examDraftId] = ""
            currentEvaluatingPaper[examDraftId] = null
        }
    }

    fun getPendingRemoteCleanupCount(examDraftId: Long): Int = remoteCleanupPendingCounts[examDraftId] ?: 0

    private suspend fun evaluateStandardSequentially(examDraftId: Long, onProgress: (String) -> Unit) {
        val runProfile = ensureAiRunProfile(examDraftId)
        requireLegacyPrivacyIfNeeded(examDraftId, runProfile)
        requireHomeworkPrivacyIfNeeded(examDraftId, runProfile)
        val allPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
        val sortedPapers = allPapers.sortedBy { it.studentSequenceIndex }

        val questions = questionDao.getByExamDraftIdOnce(examDraftId).sortedBy { it.orderIndex }
        val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
        val preferences = preferencesDao.getPreferencesOnce(examDraftId)
        val examType = resolveExamType(examDraftId)

        var sharedCacheResourceName: String? = null
        if (preferences != null && preferences.usePromptCaching && runProfile.supportsPromptCaching && bypassCacheMap[examDraftId] != true) {
            var apiKey = ""
            apiKeyStore?.useApiKey { key -> apiKey = key }
            if (apiKey.isNotBlank()) {
                val systemInstructionText = EvaluationPromptPolicy.build(
                    examType = examType,
                    rubricAdherenceLevel = preferences.rubricAdherenceLevel,
                    feedbackDetailLevel = preferences.feedbackDetailLevel,
                    provideWritingAndPunctuationFeedback = preferences.provideWritingAndPunctuationFeedback
                ).systemInstruction

                try {
                    onProgress("Prompt Caching kuruluyor...")
                    sharedCacheResourceName = checkAndGetCache(
                        examDraftId = examDraftId,
                        apiKey = apiKey,
                        questions = questions,
                        rubrics = rubrics,
                        systemInstructionText = systemInstructionText,
                        usePromptCachingPreference = true,
                        ttlSeconds = 300,
                        examType = examType,
                        evaluationModelId = runProfile.evaluationModel
                    )
                } catch (e: Exception) {
                    synchronized(this) {
                        evaluationErrors[examDraftId] = e.message
                    }
                    return
                }
            }
        }

        if (preferences?.evaluationMode == EvaluationMode.QUESTION_BY_QUESTION) {
            evaluateQuestionByQuestionSequentially(
                examDraftId = examDraftId,
                sortedPapers = sortedPapers,
                questions = questions,
                rubrics = rubrics,
                preferences = preferences,
                examType = examType,
                sharedCacheResourceName = sharedCacheResourceName,
                onProgress = onProgress
            )
        } else {
            for (paper in sortedPapers) {
                val existingEval = evaluationDao.getStudentEvaluationOnce(paper.id)
                val status = existingEval?.status ?: "WAITING"

                // Skip completed or needs_review papers
                if (status == "COMPLETED" || status == "NEEDS_REVIEW") {
                    continue
                }

                synchronized(this) {
                    currentEvaluatingPaper[examDraftId] = paper.id
                }

                onProgress("Değerlendiriliyor: ${paper.studentName ?: "Öğrenci #${paper.studentSequenceIndex}"}...")

                val result = evaluateStudentPaper(paper.id, examDraftId)
                if (result.isFailure) {
                    val errMsg = result.exceptionOrNull()?.message ?: "Değerlendirme hatası."
                    synchronized(this) {
                        evaluationErrors[examDraftId] = "HATA (${paper.studentName ?: "Öğrenci #${paper.studentSequenceIndex}"}): $errMsg"
                    }
                    break
                }
            }
        }

        // Cheap deterministic class-wide safety net: identical/near-identical written
        // answers to the same question should not silently receive materially different
        // scores. Flag those cases for teacher review instead of changing scores.
        onProgress("Sınıf içi puanlama tutarlılığı kontrol ediliyor...")
        auditClassConsistency(examDraftId)

        synchronized(this) {
            currentEvaluatingPaper[examDraftId] = null
        }
        if (evaluator is HttpGeminiExamEvaluator && apiKeyStore != null) {
            val cacheMgr = evaluator.getCacheManager()
            if (cacheMgr != null) {
                apiKeyStore.useApiKey { key ->
                    if (key.isNotBlank()) {
                        cacheMgr.deleteCacheForDraft(examDraftId, key)
                    }
                }
            }
        }
    }

    private data class QuestionModeAccumulator(
        val questionOutputs: MutableList<QuestionEvaluationOutput> = mutableListOf(),
        val writingStrengths: MutableList<String> = mutableListOf(),
        val writingIssues: MutableList<String> = mutableListOf(),
        val writingNextSteps: MutableList<String> = mutableListOf()
    )

    /**
     * Executes the selected QUESTION_BY_QUESTION mode literally: the same locked
     * question/task is evaluated for every eligible student before moving to the
     * next one. Results are accumulated in memory and committed per student only
     * after all locked items have been processed, preventing half-complete reports.
     */
    private suspend fun evaluateQuestionByQuestionSequentially(
        examDraftId: Long,
        sortedPapers: List<ExamStudentPaperEntity>,
        questions: List<ExamQuestionEntity>,
        rubrics: List<ExamRubricCriterionEntity>,
        preferences: ExamEvaluationPreferencesEntity,
        examType: ExamType,
        sharedCacheResourceName: String?,
        onProgress: (String) -> Unit
    ) {
        val runProfile = ensureAiRunProfile(examDraftId)
        requireLegacyPrivacyIfNeeded(examDraftId, runProfile)
        requireHomeworkPrivacyIfNeeded(examDraftId, runProfile)
        val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
        val rubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)

        if (questionMetadata == null || !questionMetadata.isLocked || questions.isEmpty() ||
            questions.any { it.points <= 0 || it.questionText.isBlank() }
        ) {
            throw IllegalStateException("${itemSetLabel(examType)} kilitli değil veya geçersiz.")
        }
        if (rubricMetadata == null || !rubricMetadata.isLocked ||
            rubricMetadata.questionSetRevision != questionMetadata.revision || rubrics.isEmpty()
        ) {
            throw IllegalStateException("Rubrik seti kilitli değil veya ${itemSetLabel(examType).lowercase()} revizyonu ile uyuşmuyor.")
        }
        if (!preferences.isLocked) {
            throw IllegalStateException("Değerlendirme tercihleri kilitli değil.")
        }

        val eligiblePapers = mutableListOf<Pair<ExamStudentPaperEntity, List<ExamPaperPageEntity>>>()
        for (paper in sortedPapers) {
            val existingEval = evaluationDao.getStudentEvaluationOnce(paper.id)
            if (existingEval?.status == "COMPLETED" || existingEval?.status == "NEEDS_REVIEW") {
                continue
            }

            val pages = paperUploadDao.getPagesForPaperOnce(paper.id)
            val validationError = validatePaperIntegrity(paper, pages, examType)
            if (validationError != null) {
                evaluationDao.insertOrUpdateStudentEvaluation(
                    ExamStudentEvaluationEntity(
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        status = "ERROR",
                        needsReview = true,
                        errorMessage = validationError,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                continue
            }

            evaluationDao.insertOrUpdateStudentEvaluation(
                ExamStudentEvaluationEntity(
                    studentPaperId = paper.id,
                    examDraftId = examDraftId,
                    status = "EVALUATING",
                    updatedAt = System.currentTimeMillis()
                )
            )
            eligiblePapers += paper to pages
        }

        if (eligiblePapers.isEmpty()) {
            onProgress("Değerlendirilecek ${submissionLabel(examType)} bulunamadı.")
            return
        }

        val accumulators = eligiblePapers.associate { it.first.id to QuestionModeAccumulator() }.toMutableMap()
        val failedPaperIds = mutableSetOf<Long>()
        // A full shared cache is injected when available. Per-item calls must not
        // create their own one-item cache, which would churn cache resources.
        val callPreferences = preferences.copy(usePromptCaching = false, useBatchApi = false)
        val gradeLevel = draftDao?.getDraftByIdOnce(examDraftId)?.gradeLevel
        val pageLayouts = buildAnswerSheetLayouts(examDraftId, questions, rubrics, examType)
        val itemWord = if (examType == ExamType.HOMEWORK) "Görev" else "Soru"

        for ((questionPosition, question) in questions.withIndex()) {
            val questionRubrics = rubrics.filter { it.questionOrderIndex == question.orderIndex }
            if (questionRubrics.isEmpty()) {
                throw IllegalStateException("$itemWord ${question.questionNumber} için kilitli rubrik kriteri bulunamadı.")
            }

            for ((paperPosition, paperAndPages) in eligiblePapers.withIndex()) {
                val (paper, pages) = paperAndPages
                if (paper.id in failedPaperIds) continue

                synchronized(this) {
                    currentEvaluatingPaper[examDraftId] = paper.id
                }
                val studentLabel = paper.studentName ?: "Öğrenci #${paper.studentSequenceIndex}"
                onProgress(
                    "$itemWord ${questionPosition + 1}/${questions.size} • " +
                        "Öğrenci ${paperPosition + 1}/${eligiblePapers.size}: $studentLabel"
                )

                val rawOutput = evaluator.evaluateStudent(
                    ExamStudentEvaluationInput(
                        studentPaperId = paper.id,
                        studentPages = pages,
                        questions = listOf(question),
                        rubrics = questionRubrics,
                        preferences = callPreferences,
                        examType = examType,
                        gradeLevel = gradeLevel,
                        targetQuestionOrderIndex = question.orderIndex,
                        cachedContentResourceName = sharedCacheResourceName,
                        pageLayouts = pageLayouts,
                        evaluationModelId = runProfile.evaluationModel,
                        supportsHighMediaResolution = runProfile.supportsHighMediaResolution,
                        supportsThinkingLevel = runProfile.supportsThinkingLevel,
                        supportsPromptCaching = runProfile.supportsPromptCaching,
                        allowLegacyPrivacyCrop = runProfile.legacyPrivacyApprovedAt != null,
                        privacyMasksByPageId = privacyMasksFor(pages)
                    )
                )
                val output = if (examType == ExamType.MULTIPLE_CHOICE && rawOutput.isSuccess) {
                    MultipleChoiceScoringPolicy.normalize(listOf(question), questionRubrics, rawOutput)
                } else rawOutput
                recordUsage(examDraftId, paper.id, "QUESTION_PASS", runProfile.evaluationModel, output.usage + output.secondaryUsage, runProfile, batch = false)

                if (!output.isSuccess) {
                    failedPaperIds += paper.id
                    evaluationDao.insertOrUpdateStudentEvaluation(
                        ExamStudentEvaluationEntity(
                            studentPaperId = paper.id,
                            examDraftId = examDraftId,
                            status = "ERROR",
                            needsReview = true,
                            errorMessage = output.errorMessage ?: "$itemWord değerlendirmesi başarısız.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    continue
                }

                val questionOutput = output.questionEvaluations.singleOrNull()
                if (questionOutput == null || questionOutput.questionOrderIndex != question.orderIndex) {
                    failedPaperIds += paper.id
                    evaluationDao.insertOrUpdateStudentEvaluation(
                        ExamStudentEvaluationEntity(
                            studentPaperId = paper.id,
                            examDraftId = examDraftId,
                            status = "ERROR",
                            needsReview = true,
                            errorMessage = "$itemWord ${question.questionNumber} için AI çıktısı tek ve eşleşen bir değerlendirme içermiyor.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    continue
                }

                val accumulator = accumulators.getValue(paper.id)
                accumulator.questionOutputs += questionOutput
                accumulator.writingStrengths += output.writingStrengths.filterNot { it in accumulator.writingStrengths }
                accumulator.writingIssues += output.writingIssues.filterNot { it in accumulator.writingIssues }
                accumulator.writingNextSteps += output.writingNextSteps.filterNot { it in accumulator.writingNextSteps }
            }
        }

        for ((paper, _) in eligiblePapers) {
            if (paper.id in failedPaperIds) continue
            val accumulator = accumulators.getValue(paper.id)
            val outputs = accumulator.questionOutputs.sortedBy { it.questionOrderIndex }
            if (outputs.size != questions.size || outputs.map { it.questionOrderIndex }.toSet().size != questions.size) {
                evaluationDao.insertOrUpdateStudentEvaluation(
                    ExamStudentEvaluationEntity(
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        status = "ERROR",
                        needsReview = true,
                        errorMessage = "${itemSetLabel(examType)} değerlendirmesi eksik veya yinelenmiş.",
                        updatedAt = System.currentTimeMillis()
                    )
                )
                continue
            }

            val questionEntities = outputs.map { q ->
                ExamQuestionEvaluationEntity(
                    studentPaperId = paper.id,
                    examDraftId = examDraftId,
                    questionNumber = q.questionNumber,
                    questionOrderIndex = q.questionOrderIndex,
                    readAnswerText = q.readAnswerText,
                    score = q.score,
                    maxScore = q.maxScore,
                    feedback = q.feedback,
                    interpretedMeaning = q.interpretedMeaning,
                    gradingEvidence = q.gradingEvidence,
                    readingConfidence = q.readingConfidence,
                    evaluationConfidence = q.evaluationConfidence,
                    answerType = q.answerType,
                    needsReview = q.needsReview,
                    reviewReason = q.reviewReason,
                    originalScore = q.score,
                    isTeacherModified = false,
                    isResolved = !q.needsReview,
                    strengths = q.strengths,
                    missingElements = q.missingElements,
                    misconceptions = q.misconceptions,
                    nextSteps = q.nextSteps
                )
            }

            val totalScore = outputs.sumOf { it.score }
            val totalMaxScore = outputs.sumOf { it.maxScore }
            val overallConfidence = if (outputs.isEmpty()) 1.0 else outputs
                .map { (it.readingConfidence + it.evaluationConfidence) / 2.0 }
                .average()
            val needsReview = outputs.any { it.needsReview } || overallConfidence < 0.70
            val finalStatus = if (needsReview) "NEEDS_REVIEW" else "COMPLETED"
            val completedEval = ExamStudentEvaluationEntity(
                studentPaperId = paper.id,
                examDraftId = examDraftId,
                status = finalStatus,
                totalScore = totalScore,
                totalMaxScore = totalMaxScore,
                spellingPunctuationFeedback = null,
                writingStrengths = if (preferences.provideWritingAndPunctuationFeedback) accumulator.writingStrengths.distinct().take(5) else emptyList(),
                writingIssues = if (preferences.provideWritingAndPunctuationFeedback) accumulator.writingIssues.distinct().take(6) else emptyList(),
                writingNextSteps = if (preferences.provideWritingAndPunctuationFeedback) accumulator.writingNextSteps.distinct().take(5) else emptyList(),
                spellingPunctuationDeduction = 0.0,
                overallConfidence = overallConfidence,
                needsReview = needsReview,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
            evaluationDao.saveCompleteEvaluationTransaction(completedEval, questionEntities)
        }
    }

    private suspend fun auditClassConsistency(examDraftId: Long) {
        val rows = evaluationDao.getQuestionEvaluationsForExamOnce(examDraftId)
            .filter {
                !it.isTeacherModified &&
                    it.answerType == "NORMAL" &&
                    it.readAnswerText.isNotBlank() &&
                    it.maxScore > 0.0
            }

        val groups = rows.groupBy { row ->
            row.questionOrderIndex to normalizeAnswerForConsistency(row.readAnswerText)
        }
        for ((key, group) in groups) {
            if (key.second.isBlank() || group.size < 2) continue
            val minScore = group.minOf { it.score }
            val maxScore = group.maxOf { it.score }
            val questionMax = group.first().maxScore
            val allowedDifference = kotlin.math.max(1.0, questionMax * 0.15)
            if (maxScore - minScore <= allowedDifference) continue

            val reason = "Aynı/çok benzer cevap aynı soruda farklı puanlandı; sınıf içi tutarlılık için öğretmen kontrolü gerekiyor."
            group.forEach { row ->
                evaluationDao.markQuestionNeedsReview(row.id, reason)
                evaluationDao.markStudentNeedsReview(row.studentPaperId)
            }
        }
    }

    private fun normalizeAnswerForConsistency(text: String): String {
        return text
            .lowercase(Locale.forLanguageTag("tr-TR"))
            .replace(Regex("""[^\p{L}\p{N}]+"""), " ")
            .trim()
            .replace(Regex("""\s+"""), " ")
    }

    private fun validatePaperIntegrity(
        paper: ExamStudentPaperEntity,
        pages: List<ExamPaperPageEntity>,
        examType: ExamType = ExamType.WRITTEN
    ): String? {
        if (paper.id <= 0) {
            return "Geçersiz öğrenci kimliği."
        }
        if (paper.status != "READY") {
            return "Öğrenci kâğıdı AI değerlendirmesine hazır değil: ${paper.status} (${paper.statusReason ?: "neden belirtilmedi"})."
        }
        val identity = validateStudentIdentity(paper.classLevel, paper.branch, paper.schoolNumber)
        if (!identity.isValid) {
            return "Öğrenci kimliği doğrulanamadı: ${identity.reason ?: "Sınıf/şube/okul no geçersiz."}"
        }
        if (pages.isEmpty()) {
            return missingSubmissionPageMessage(examType)
        }
        val expectedTotal = pages.first().totalPages
        if (expectedTotal <= 0) {
            return "Geçersiz toplam sayfa sayısı."
        }
        if (pages.size != expectedTotal) {
            return "Sayfa sayısı uyuşmuyor: Beklenen $expectedTotal, Mevcut ${pages.size}."
        }
        
        // Check for duplicates or missing page indexes
        val indexes = pages.map { it.pageIndex }.sorted()
        if (indexes != (1..expectedTotal).toList()) {
            return "Eksik veya çakışan sayfalar tespit edildi: $indexes."
        }

        for (page in pages) {
            if (page.examDraftId != paper.examDraftId) {
                return wrongAssessmentPageMessage(examType)
            }
            if (page.imagePath.isBlank() || !File(page.imagePath).exists()) {
                return missingImageMessage(examType)
            }
            if (page.status != "VALID") {
                return "Geçersiz veya sorunlu sayfa durumu: ${page.status} (${page.statusReason ?: ""})."
            }
        }
        return null // Valid!
    }


    fun getStudentEvaluationsForExam(examDraftId: Long): Flow<List<ExamStudentEvaluationEntity>> {
        return evaluationDao.getStudentEvaluationsForExam(examDraftId)
    }

    suspend fun getRubricsOnce(examDraftId: Long): List<com.example.core.database.ExamRubricCriterionEntity> {
        return rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
    }

    suspend fun getStudentEvaluationsForExamOnce(examDraftId: Long): List<ExamStudentEvaluationEntity> {
        return evaluationDao.getStudentEvaluationsForExamOnce(examDraftId)
    }

    fun getQuestionEvaluationsForPaper(studentPaperId: Long): Flow<List<ExamQuestionEvaluationEntity>> {
        return evaluationDao.getQuestionEvaluationsForPaper(studentPaperId)
    }

    suspend fun getQuestionEvaluationsForPaperOnce(studentPaperId: Long): List<ExamQuestionEvaluationEntity> {
        return evaluationDao.getQuestionEvaluationsForPaperOnce(studentPaperId)
    }

    fun getQuestionEvaluationsForExam(examDraftId: Long): Flow<List<ExamQuestionEvaluationEntity>> {
        return evaluationDao.getQuestionEvaluationsForExam(examDraftId)
    }

    suspend fun getQuestionEvaluationsForExamOnce(examDraftId: Long): List<ExamQuestionEvaluationEntity> {
        return evaluationDao.getQuestionEvaluationsForExamOnce(examDraftId)
    }

    /**
     * Direct single-paper retry participates in the same lifecycle boundary as a full evaluation run.
     * Stop/rewind cancels and joins these jobs before workflow state can change. A retry never clears
     * a global pause; only an explicit main Start action may do that.
     */
    suspend fun retryStudentPaper(studentPaperId: Long, examDraftId: Long): Result<ExamStudentEvaluationEntity> {
        val currentJob = currentCoroutineContext()[Job]
            ?: return Result.failure(IllegalStateException("Retry coroutine yaşam döngüsü bulunamadı."))

        if (evaluationPauseGuard?.isPaused(examDraftId) == true) {
            return Result.failure(IllegalStateException("Değerlendirme durdurulmuş durumda. Yeniden başlatmadan tek öğrenci retry yapılamaz."))
        }
        val durableState = evaluationDao.getEvaluationRunState(examDraftId)
        if (durableState?.status in setOf("PAUSE_REQUESTED", "PAUSE_REMOTE_CANCEL_PENDING", "PAUSED")) {
            return Result.failure(IllegalStateException("Önceki durdurma/uzak Batch temizliği tamamlanmadan tek öğrenci retry başlatılamaz."))
        }
        runCatching { requireAiEvaluationWorkflowStage(examDraftId) }
            .getOrElse { return Result.failure(it) }

        synchronized(this) {
            if (activeDraftEvaluations[examDraftId]?.isActive == true) {
                return Result.failure(IllegalStateException("Ana değerlendirme çalışırken tek öğrenci retry başlatılamaz."))
            }
            val perDraft = activeDirectRetryJobs.getOrPut(examDraftId) { mutableMapOf() }
            if (perDraft[studentPaperId]?.isActive == true) {
                return Result.failure(IllegalStateException("Bu öğrenci için retry zaten çalışıyor."))
            }
            perDraft[studentPaperId] = currentJob
        }

        return try {
            currentCoroutineContext().ensureActive()
            evaluateStudentPaper(studentPaperId, examDraftId)
        } finally {
            synchronized(this) {
                activeDirectRetryJobs[examDraftId]?.let { perDraft ->
                    if (perDraft[studentPaperId] === currentJob) perDraft.remove(studentPaperId)
                    if (perDraft.isEmpty()) activeDirectRetryJobs.remove(examDraftId)
                }
            }
        }
    }

    suspend fun evaluateStudentPaper(studentPaperId: Long, examDraftId: Long): Result<ExamStudentEvaluationEntity> = withContext(Dispatchers.IO) {
        runCatching { requireAiEvaluationWorkflowStage(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireAiEvaluationEnabled(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireStudentAiCompliance(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        val runProfile = runCatching { ensureAiRunProfile(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireLegacyPrivacyIfNeeded(examDraftId, runProfile) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireHomeworkPrivacyIfNeeded(examDraftId, runProfile) }.getOrElse { return@withContext Result.failure(it) }
        val examType = resolveExamType(examDraftId)
        if (examType == ExamType.MULTIPLE_CHOICE) {
            return@withContext Result.failure(Exception("Test Sınavı için AI değerlendirmesi kapalıdır; Yerel Optik Okuma kullanılmalıdır."))
        }
        evaluationMutex.withLock {
            if (activeEvaluations.contains(studentPaperId)) {
                return@withContext Result.failure(Exception(
                    if (examType == ExamType.HOMEWORK)
                        "Bu ödev teslimi için zaten bir değerlendirme işlemi yürütülüyor."
                    else
                        "Bu öğrenci kâğıdı için zaten bir değerlendirme işlemi yürütülüyor."
                ))
            }
            activeEvaluations.add(studentPaperId)
        }

        try {
            // Requirement 9: Pre-check existing evaluation status before triggering paid AI call
            val existingEval = evaluationDao.getStudentEvaluationOnce(studentPaperId)
            if (existingEval != null && (existingEval.status == "COMPLETED" || existingEval.status == "NEEDS_REVIEW")) {
                return@withContext Result.success(existingEval)
            }

            // Requirement 3: Resource Integrity Checks
            val existingPaper = paperUploadDao.getPaperByIdOnce(studentPaperId)
                ?: return@withContext Result.failure(Exception(when (examType) {
                    ExamType.HOMEWORK -> "Ödev teslimi bulunamadı (ID: $studentPaperId)."
                    ExamType.READINESS -> "Hazırbulunuşluk öğrenci kâğıdı bulunamadı (ID: $studentPaperId)."
                    else -> "Öğrenci kâğıdı bulunamadı (ID: $studentPaperId)."
                }))

            val pages = paperUploadDao.getPagesForPaperOnce(studentPaperId)
            val validationError = validatePaperIntegrity(existingPaper, pages, examType)
            if (validationError != null) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = validationError,
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception(validationError))
            }

            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (questionMetadata == null || !questionMetadata.isLocked) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = "${itemSetLabel(examType)} kilitli değil veya bulunamadı.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception("${itemSetLabel(examType)} kilitli değil veya bulunamadı."))
            }

            val questions = questionDao.getByExamDraftIdOnce(examDraftId)
            if (questions.isEmpty() || questions.any { it.points <= 0 || it.questionText.isBlank() }) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = "Geçersiz veya boş ${itemSetLabel(examType).lowercase()}.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception("Geçersiz veya boş ${itemSetLabel(examType).lowercase()}."))
            }

            val rubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (rubricMetadata == null || !rubricMetadata.isLocked || rubricMetadata.questionSetRevision != questionMetadata.revision) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = "Rubrik seti kilitli değil veya ${itemSetLabel(examType).lowercase()} revizyonu ile uyuşmuyor.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception("Rubrik seti kilitli değil veya ${itemSetLabel(examType).lowercase()} revizyonu ile uyuşmuyor."))
            }

            val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            if (rubrics.isEmpty()) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = "Kilitli rubrik kriterleri bulunamadı.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception("Kilitli rubrik kriterleri bulunamadı."))
            }

            val rawPreferences = preferencesDao.getPreferencesOnce(examDraftId)
            if (rawPreferences == null || !rawPreferences.isLocked) {
                val errEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = "Değerlendirme tercihleri kilitli değil.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                return@withContext Result.failure(Exception("Değerlendirme tercihleri kilitli değil."))
            }

            val preferences = if (bypassCacheMap[examDraftId] == true) {
                rawPreferences.copy(usePromptCaching = false)
            } else {
                rawPreferences
            }

            // 1. Mark status as EVALUATING
            val currentEval = ExamStudentEvaluationEntity(
                studentPaperId = studentPaperId,
                examDraftId = examDraftId,
                status = "EVALUATING",
                updatedAt = System.currentTimeMillis()
            )
            evaluationDao.insertOrUpdateStudentEvaluation(currentEval)

            // 2. Perform privacy-preserving first pass evaluation.
            val pageLayouts = buildAnswerSheetLayouts(examDraftId, questions, rubrics, examType)
            val input = ExamStudentEvaluationInput(
                studentPaperId = studentPaperId,
                studentPages = pages,
                questions = questions,
                rubrics = rubrics,
                preferences = preferences,
                examType = examType,
                gradeLevel = draftDao?.getDraftByIdOnce(examDraftId)?.gradeLevel,
                pageLayouts = pageLayouts,
                evaluationModelId = runProfile.evaluationModel,
                supportsHighMediaResolution = runProfile.supportsHighMediaResolution,
                supportsThinkingLevel = runProfile.supportsThinkingLevel,
                        supportsPromptCaching = runProfile.supportsPromptCaching,
                        allowLegacyPrivacyCrop = runProfile.legacyPrivacyApprovedAt != null,
                        privacyMasksByPageId = privacyMasksFor(pages)
            )

            val rawOutput = evaluator.evaluateStudent(input)
            val output = if (examType == ExamType.MULTIPLE_CHOICE && rawOutput.isSuccess) {
                MultipleChoiceScoringPolicy.normalize(questions, rubrics, rawOutput)
            } else rawOutput
            recordUsage(examDraftId, studentPaperId, "EVALUATION", runProfile.evaluationModel, output.usage + output.secondaryUsage, runProfile, batch = false)

            if (!output.isSuccess) {
                val errorEval = ExamStudentEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    status = "ERROR",
                    needsReview = true,
                    errorMessage = output.errorMessage ?: "Bilinmeyen bir AI hatası oluştu.",
                    updatedAt = System.currentTimeMillis()
                )
                evaluationDao.insertOrUpdateStudentEvaluation(errorEval)
                return@withContext Result.failure(Exception(output.errorMessage ?: "AI Değerlendirme hatası."))
            }

            // 3. Construct Question Evaluations
            val questionEntities = output.questionEvaluations.map { q ->
                ExamQuestionEvaluationEntity(
                    studentPaperId = studentPaperId,
                    examDraftId = examDraftId,
                    questionNumber = q.questionNumber,
                    questionOrderIndex = q.questionOrderIndex,
                    readAnswerText = q.readAnswerText,
                    score = q.score,
                    maxScore = q.maxScore,
                    feedback = q.feedback,
                    interpretedMeaning = q.interpretedMeaning,
                    gradingEvidence = q.gradingEvidence,
                    readingConfidence = q.readingConfidence,
                    evaluationConfidence = q.evaluationConfidence,
                    answerType = q.answerType,
                    needsReview = q.needsReview,
                    reviewReason = q.reviewReason,
                    originalScore = q.score,
                    isTeacherModified = false,
                    isResolved = !q.needsReview,
                    strengths = q.strengths,
                    missingElements = q.missingElements,
                    misconceptions = q.misconceptions,
                    nextSteps = q.nextSteps
                )
            }

            // 4. Save Student Evaluation and Question Evaluations atomically in a single transaction
            val finalStatus = if (output.needsReview) "NEEDS_REVIEW" else "COMPLETED"
            val completedEval = ExamStudentEvaluationEntity(
                studentPaperId = studentPaperId,
                examDraftId = examDraftId,
                status = finalStatus,
                totalScore = output.totalScore,
                totalMaxScore = output.totalMaxScore,
                spellingPunctuationFeedback = null,
                writingStrengths = output.writingStrengths,
                writingIssues = output.writingIssues,
                writingNextSteps = output.writingNextSteps,
                spellingPunctuationDeduction = output.spellingPunctuationDeduction,
                overallConfidence = output.overallConfidence,
                needsReview = output.needsReview,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )

            requireAiEvaluationWorkflowStage(examDraftId)
            evaluationDao.saveCompleteEvaluationTransaction(completedEval, questionEntities)

            Result.success(completedEval)
        } catch (e: CancellationException) {
            // Stop/rewind is not an evaluation failure. Never persist ERROR after cancellation.
            throw e
        } catch (e: Exception) {
            // A workflow rewind may race with a non-cancellation provider failure. Do not write a
            // stale ERROR into an earlier workflow stage.
            runCatching { requireAiEvaluationWorkflowStage(examDraftId) }
                .getOrElse { return@withContext Result.failure(e) }
            val failEval = ExamStudentEvaluationEntity(
                studentPaperId = studentPaperId,
                examDraftId = examDraftId,
                status = "ERROR",
                needsReview = true,
                errorMessage = e.message ?: "İşlem sırasında beklenmeyen bir hata oluştu.",
                updatedAt = System.currentTimeMillis()
            )
            evaluationDao.insertOrUpdateStudentEvaluation(failEval)
            Result.failure(e)
        } finally {
            evaluationMutex.withLock {
                activeEvaluations.remove(studentPaperId)
            }
        }
    }

    /**
     * Persists a deterministic local OMR result for Test Sınavı.
     * This path intentionally never invokes [evaluator], API keys, Batch API or Prompt Cache.
     */
    suspend fun saveLocalMultipleChoiceEvaluation(
        studentPaperId: Long,
        examDraftId: Long,
        opticalRead: TestOpticalPaperRead
    ): Result<ExamStudentEvaluationEntity> = withContext(Dispatchers.IO) {
        val initialDraft = draftDao?.getDraftByIdOnce(examDraftId)
        if (initialDraft != null && initialDraft.currentWorkflowStage != WorkflowStage.AI_EVALUATION) {
            return@withContext Result.failure(Exception("Yerel optik okuma yalnız Yerel Optik Okuma / AI Değerlendirme aşamasında sonuç kaydedebilir."))
        }
        try {
            if (resolveExamType(examDraftId) != ExamType.MULTIPLE_CHOICE) {
                return@withContext Result.failure(Exception("Yerel optik okuma yalnız Test Sınavı için kullanılabilir."))
            }
            val paper = paperUploadDao.getPaperByIdOnce(studentPaperId)
                ?: return@withContext Result.failure(Exception("Test cevap kâğıdı bulunamadı."))
            val pages = paperUploadDao.getPagesForPaperOnce(studentPaperId)
            validatePaperIntegrity(paper, pages, ExamType.MULTIPLE_CHOICE)?.let {
                return@withContext Result.failure(Exception(it))
            }

            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (questionMetadata == null || !questionMetadata.isLocked) {
                return@withContext Result.failure(Exception("Test soru seti kilitli değil."))
            }
            val answerKeyMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (answerKeyMetadata == null || !answerKeyMetadata.isLocked || answerKeyMetadata.questionSetRevision != questionMetadata.revision) {
                return@withContext Result.failure(Exception("Cevap anahtarı kilitli değil veya güncel soru setiyle uyuşmuyor."))
            }
            val questions = questionDao.getByExamDraftIdOnce(examDraftId).sortedBy { it.orderIndex }
            val keyRows = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            val keyByOrder = keyRows.groupBy { it.questionOrderIndex }.mapValues { (_, rows) ->
                rows.asSequence()
                    .mapNotNull { MultipleChoiceScoringPolicy.normalizeChoice(it.expectedAnswer.ifBlank { it.originalAnswerKey.orEmpty() }) }
                    .firstOrNull()
            }
            if (questions.any { keyByOrder[it.orderIndex] == null }) {
                return@withContext Result.failure(Exception("Kilitli cevap anahtarında eksik doğru seçenek var."))
            }

            val readByOrder = opticalRead.questions.associateBy { it.questionOrderIndex }
            val now = System.currentTimeMillis()
            val questionEvaluations = questions.map { question ->
                val read = readByOrder[question.orderIndex]
                val expected = keyByOrder[question.orderIndex]!!
                val maxScore = question.points.toDouble().coerceAtLeast(0.0)
                when (read?.status) {
                    com.example.core.model.OpticalChoiceStatus.MARKED -> {
                        val choice = MultipleChoiceScoringPolicy.normalizeChoice(read.markedChoice)
                        if (choice == null) {
                            ExamQuestionEvaluationEntity(
                                studentPaperId = studentPaperId, examDraftId = examDraftId,
                                questionNumber = question.questionNumber, questionOrderIndex = question.orderIndex,
                                readAnswerText = "", score = 0.0, maxScore = maxScore,
                                feedback = null, readingConfidence = 0.0, evaluationConfidence = 1.0,
                                answerType = "UNREADABLE", needsReview = true,
                                reviewReason = "İşaretlenen seçenek belirlenemedi.", originalScore = 0.0,
                                isTeacherModified = false, isResolved = false
                            )
                        } else {
                            val score = if (choice == expected) maxScore else 0.0
                            ExamQuestionEvaluationEntity(
                                studentPaperId = studentPaperId, examDraftId = examDraftId,
                                questionNumber = question.questionNumber, questionOrderIndex = question.orderIndex,
                                readAnswerText = choice, score = score, maxScore = maxScore,
                                feedback = if (score == maxScore) "Doğru" else "Yanlış — doğru cevap: $expected",
                                readingConfidence = read.confidence, evaluationConfidence = 1.0,
                                answerType = "MULTIPLE_CHOICE", needsReview = false, reviewReason = null,
                                originalScore = score, isTeacherModified = false, isResolved = true
                            )
                        }
                    }
                    com.example.core.model.OpticalChoiceStatus.BLANK -> ExamQuestionEvaluationEntity(
                        studentPaperId = studentPaperId, examDraftId = examDraftId,
                        questionNumber = question.questionNumber, questionOrderIndex = question.orderIndex,
                        readAnswerText = "", score = 0.0, maxScore = maxScore,
                        feedback = "Boş", readingConfidence = read.confidence, evaluationConfidence = 1.0,
                        answerType = "UNANSWERED", needsReview = false, reviewReason = null,
                        originalScore = 0.0, isTeacherModified = false, isResolved = true
                    )
                    com.example.core.model.OpticalChoiceStatus.MULTIPLE -> ExamQuestionEvaluationEntity(
                        studentPaperId = studentPaperId, examDraftId = examDraftId,
                        questionNumber = question.questionNumber, questionOrderIndex = question.orderIndex,
                        readAnswerText = "", score = 0.0, maxScore = maxScore,
                        feedback = null, readingConfidence = read.confidence, evaluationConfidence = 1.0,
                        answerType = "LOW_CONFIDENCE", needsReview = true,
                        reviewReason = read.reason ?: "Birden fazla seçenek işaretli görünüyor.",
                        originalScore = 0.0, isTeacherModified = false, isResolved = false
                    )
                    else -> ExamQuestionEvaluationEntity(
                        studentPaperId = studentPaperId, examDraftId = examDraftId,
                        questionNumber = question.questionNumber, questionOrderIndex = question.orderIndex,
                        readAnswerText = "", score = 0.0, maxScore = maxScore,
                        feedback = null, readingConfidence = read?.confidence ?: 0.0, evaluationConfidence = 1.0,
                        answerType = "UNREADABLE", needsReview = true,
                        reviewReason = read?.reason ?: "İşaret güvenilir biçimde okunamadı.",
                        originalScore = 0.0, isTeacherModified = false, isResolved = false
                    )
                }
            }

            val totalScore = questionEvaluations.sumOf { it.score }
            val totalMaxScore = questions.sumOf { it.points.toDouble().coerceAtLeast(0.0) }
            val needsReview = questionEvaluations.any { it.needsReview }
            val overallConfidence = if (questionEvaluations.isEmpty()) 0.0 else questionEvaluations.map { it.readingConfidence }.average()
            val completed = ExamStudentEvaluationEntity(
                studentPaperId = studentPaperId,
                examDraftId = examDraftId,
                status = if (needsReview) "NEEDS_REVIEW" else "COMPLETED",
                totalScore = totalScore,
                totalMaxScore = totalMaxScore,
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                overallConfidence = overallConfidence,
                needsReview = needsReview,
                errorMessage = opticalRead.errorMessage,
                updatedAt = now
            )
            val latestDraft = draftDao?.getDraftByIdOnce(examDraftId)
            if (latestDraft != null && latestDraft.currentWorkflowStage != WorkflowStage.AI_EVALUATION) {
                return@withContext Result.failure(Exception("İş akışı değiştiği için eski optik okuma sonucu kaydedilmedi."))
            }
            evaluationDao.saveCompleteEvaluationTransaction(completed, questionEvaluations)
            Result.success(completed)
        } catch (e: Exception) {
            val currentDraft = runCatching { draftDao?.getDraftByIdOnce(examDraftId) }.getOrNull()
            if (currentDraft != null && currentDraft.currentWorkflowStage != WorkflowStage.AI_EVALUATION) {
                return@withContext Result.failure(e)
            }
            val failed = ExamStudentEvaluationEntity(
                studentPaperId = studentPaperId,
                examDraftId = examDraftId,
                status = "ERROR",
                needsReview = true,
                errorMessage = e.message ?: "Yerel optik okuma sırasında hata oluştu.",
                updatedAt = System.currentTimeMillis()
            )
            evaluationDao.insertOrUpdateStudentEvaluation(failed)
            Result.failure(e)
        }
    }

    suspend fun resetEvaluationsForExam(examDraftId: Long) = withContext(Dispatchers.IO) {
        evaluationDao.deleteAllEvaluationsForExam(examDraftId)
    }

    suspend fun evaluateExamBatch(
        examDraftId: Long,
        onProgress: ((String) -> Unit)? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching { requireAiEvaluationWorkflowStage(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireStudentAiCompliance(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        val runProfile = runCatching { ensureAiRunProfile(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireLegacyPrivacyIfNeeded(examDraftId, runProfile) }.getOrElse { return@withContext Result.failure(it) }
        runCatching { requireHomeworkPrivacyIfNeeded(examDraftId, runProfile) }.getOrElse { return@withContext Result.failure(it) }
        if (!runProfile.supportsBatch) return@withContext Result.failure(Exception("Bu sınav için kilitlenen model Batch değerlendirmeyi desteklemiyor."))
        if (resolveExamType(examDraftId) == ExamType.MULTIPLE_CHOICE) {
            return@withContext Result.failure(Exception("Test Sınavı için Batch/AI değerlendirmesi kapalıdır; Yerel Optik Okuma kullanılmalıdır."))
        }
        if (apiKeyStore == null || batchJobManager == null || evaluator !is HttpGeminiExamEvaluator) {
            return@withContext Result.failure(Exception("Batch API bileşenleri yapılandırılmamış."))
        }

        var apiKey = ""
        apiKeyStore.useApiKey { key -> apiKey = key }
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("Gemini API anahtarı eksik veya geçersiz."))
        }

        val httpEvaluator = evaluator
        val examType = resolveExamType(examDraftId)

        // 1. Recover uncertain creation jobs first
        onProgress?.invoke("Belirsiz gönderimler kontrol ediliyor...")
        try {
            batchJobManager.recoverUncertainJobs(examDraftId, apiKey)
        } catch (e: Exception) {
            return@withContext Result.failure(Exception("Önceki belirsiz Batch gönderimi güvenli biçimde çözülemedi. Yeni Batch oluşturulmadı.", e))
        }

        // 2. Check if there are active or unprocessed Batch Jobs
        val unprocessedJobs = batchJobManager.getUnprocessedJobsForDraft(examDraftId)
        val activeStudentPaperIds = unprocessedJobs.flatMap { it.studentPaperIds }.toSet()
        var batchCreationFailures = 0
        var createdBatchJobs = 0

        if (unprocessedJobs.isNotEmpty()) {
            onProgress?.invoke("Mevcut ${unprocessedJobs.size} Batch işinin takibi devam ettiriliyor...")
        } else {
            // Need to create new Batch jobs
            val allPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
            val eligiblePapers = mutableListOf<ExamStudentPaperEntity>()

            // Requirement 8: Pre-validate each student paper right before batch creation
            for (paper in allPapers) {
                if (activeStudentPaperIds.contains(paper.id)) {
                    continue // Skip papers that are already in an active/unprocessed batch job!
                }
                val existingEval = evaluationDao.getStudentEvaluationOnce(paper.id)
                if (existingEval != null && (existingEval.status == "COMPLETED" || existingEval.status == "NEEDS_REVIEW")) {
                    continue
                }
                // A stale EVALUATING row without a live/unprocessed Batch job must be retryable.
                if (existingEval?.status == "EVALUATING" && paper.id in activeStudentPaperIds) {
                    continue
                }

                val pages = paperUploadDao.getPagesForPaperOnce(paper.id)
                val validationError = validatePaperIntegrity(paper, pages, examType)
                if (validationError != null) {
                    val errEval = ExamStudentEvaluationEntity(
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        status = "ERROR",
                        needsReview = true,
                        errorMessage = validationError,
                        updatedAt = System.currentTimeMillis()
                    )
                    evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                    continue
                }

                eligiblePapers.add(paper)
            }

            if (eligiblePapers.isEmpty()) {
                onProgress?.invoke("Değerlendirilecek ${submissionLabel(examType)} bulunamadı.")
                return@withContext Result.success(Unit)
            }

            // Verify Question Set, Rubric, and Preferences
            val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            val questions = questionDao.getByExamDraftIdOnce(examDraftId)
            val rubricMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
            val preferences = preferencesDao.getPreferencesOnce(examDraftId)

            if (questionMetadata == null || !questionMetadata.isLocked || questions.isEmpty() || questions.any { it.points <= 0 || it.questionText.isBlank() }) {
                return@withContext Result.failure(Exception("${itemSetLabel(examType)} kilitli değil veya geçersiz."))
            }

            if (rubricMetadata == null || !rubricMetadata.isLocked || rubricMetadata.questionSetRevision != questionMetadata.revision || rubrics.isEmpty()) {
                return@withContext Result.failure(Exception("Rubrik seti kilitli değil veya uyuşmuyor."))
            }

            if (preferences == null || !preferences.isLocked) {
                return@withContext Result.failure(Exception("Değerlendirme tercihleri kilitli değil."))
            }

            val pageLayouts = buildAnswerSheetLayouts(examDraftId, questions, rubrics, examType)

            // Prompt Caching
            val systemInstructionText = EvaluationPromptPolicy.build(
                examType = examType,
                rubricAdherenceLevel = preferences.rubricAdherenceLevel,
                feedbackDetailLevel = preferences.feedbackDetailLevel,
                provideWritingAndPunctuationFeedback = preferences.provideWritingAndPunctuationFeedback
            ).systemInstruction

            var cachedContentResourceName: String? = null
            if (preferences.usePromptCaching && runProfile.supportsPromptCaching) {
                onProgress?.invoke("Prompt Caching kuruluyor...")
                try {
                    cachedContentResourceName = checkAndGetCache(
                        examDraftId = examDraftId,
                        apiKey = apiKey,
                        questions = questions,
                        rubrics = rubrics,
                        systemInstructionText = systemInstructionText,
                        usePromptCachingPreference = true,
                        ttlSeconds = 176400, // 49 hours initial TTL for robust background persistence
                        examType = examType,
                        evaluationModelId = runProfile.evaluationModel
                    )
                } catch (e: Exception) {
                    return@withContext Result.failure(e)
                }
            }

            // V20.26: true incremental Batch production. Never retain all base64 student
            // request bodies in RAM. At most one bounded chunk plus the current request is live.
            val maxChunkSizeBytes = 15L * 1024 * 1024
            var currentChunk = mutableListOf<Pair<Long, String>>()
            var currentChunkSizeBytes = 0L
            var preparedRequestCount = 0
            var submittedChunkCount = 0

            suspend fun submitCurrentChunk() {
                if (currentChunk.isEmpty()) return
                val chunk = currentChunk
                currentChunk = mutableListOf()
                currentChunkSizeBytes = 0L
                submittedChunkCount += 1
                onProgress?.invoke(
                    "Batch paketi gönderiliyor ($submittedChunkCount. paket, $preparedRequestCount/${eligiblePapers.size} öğrenci hazırlandı)..."
                )
                val meta = batchJobManager.createBatchJob(
                    draftId = examDraftId,
                    requests = chunk,
                    apiKey = apiKey,
                    evaluationModelId = runProfile.evaluationModel
                )
                if (meta == null) {
                    chunk.forEach { (paperId, _) ->
                        evaluationDao.insertOrUpdateStudentEvaluation(
                            ExamStudentEvaluationEntity(
                                studentPaperId = paperId,
                                examDraftId = examDraftId,
                                status = "ERROR",
                                needsReview = true,
                                errorMessage = "Batch işi oluşturulamadı.",
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                    batchCreationFailures += 1
                } else {
                    createdBatchJobs += 1
                    // Mark as EVALUATING only after the remote/local recoverable Batch job exists.
                    chunk.forEach { (paperId, _) ->
                        evaluationDao.insertOrUpdateStudentEvaluation(
                            ExamStudentEvaluationEntity(
                                studentPaperId = paperId,
                                examDraftId = examDraftId,
                                status = "EVALUATING",
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
                // `chunk` goes out of scope here; request/base64 strings become GC-eligible before
                // the next chunk is produced.
            }

            for (paper in eligiblePapers) {
                try {
                    val pages = paperUploadDao.getPagesForPaperOnce(paper.id)
                    val input = ExamStudentEvaluationInput(
                        studentPaperId = paper.id,
                        studentPages = pages,
                        questions = questions,
                        rubrics = rubrics,
                        preferences = preferences,
                        examType = examType,
                        gradeLevel = draftDao?.getDraftByIdOnce(examDraftId)?.gradeLevel,
                        pageLayouts = pageLayouts,
                        evaluationModelId = runProfile.evaluationModel,
                        supportsHighMediaResolution = runProfile.supportsHighMediaResolution,
                        supportsThinkingLevel = runProfile.supportsThinkingLevel,
                        supportsPromptCaching = runProfile.supportsPromptCaching,
                        allowLegacyPrivacyCrop = runProfile.legacyPrivacyApprovedAt != null,
                        privacyMasksByPageId = privacyMasksFor(pages)
                    )
                    val reqBody = httpEvaluator.buildStudentRequestBody(input, cachedContentResourceName)
                    val reqBytes = reqBody.toByteArray(Charsets.UTF_8).size.toLong()

                    if (currentChunk.isNotEmpty() && currentChunkSizeBytes + reqBytes > maxChunkSizeBytes) {
                        submitCurrentChunk()
                    }
                    currentChunk.add(paper.id to reqBody)
                    currentChunkSizeBytes += reqBytes
                    preparedRequestCount += 1

                    // A single exceptionally large request is isolated immediately;
                    // GeminiBatchJobManager will route it through the Files API.
                    if (currentChunkSizeBytes >= maxChunkSizeBytes || reqBytes > 2L * 1024 * 1024) {
                        submitCurrentChunk()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Privacy/alignment or request preparation failure is isolated to this paper.
                    evaluationDao.insertOrUpdateStudentEvaluation(
                        ExamStudentEvaluationEntity(
                            studentPaperId = paper.id,
                            examDraftId = examDraftId,
                            status = "ERROR",
                            needsReview = true,
                            errorMessage = e.message ?: "Öğrenci kâğıdı güvenli Batch isteğine hazırlanamadı.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            }
            submitCurrentChunk()

            if (preparedRequestCount == 0) {
                onProgress?.invoke("Güvenli Batch isteğine hazırlanabilen öğrenci kâğıdı bulunamadı.")
                return@withContext Result.success(Unit)
            }
        }

        if (batchCreationFailures > 0 && createdBatchJobs == 0 && batchJobManager.getUnprocessedJobsForDraft(examDraftId).isEmpty()) {
            return@withContext Result.failure(Exception("Gemini Batch işleri oluşturulamadı; ilgili öğrenciler ERROR durumuna alındı."))
        }

        // 2. Poll all active/unprocessed batch jobs for this draft until completed
        var pollDelayMs = 15_000L
        while (true) {
            runCatching { requireAiEvaluationWorkflowStage(examDraftId) }.getOrElse { stageError ->
                pauseEvaluationAndCancelRemote(examDraftId)
                return@withContext Result.failure(stageError)
            }
            currentCoroutineContext().ensureActive()
            val jobsToPoll = batchJobManager.getUnprocessedJobsForDraft(examDraftId)
            if (jobsToPoll.isEmpty()) {
                break
            }

            // Dynamically maintain the prompt cache validity during the active batch
            val cacheMgr = httpEvaluator.getCacheManager()
            val preferences = preferencesDao.getPreferencesOnce(examDraftId)
            if (cacheMgr != null && preferences != null && preferences.usePromptCaching && runProfile.supportsPromptCaching && apiKey.isNotBlank()) {
                val remainingTime = cacheMgr.getRemainingTimeForDraft(examDraftId)
                if (remainingTime in 1..900_000L) { // If cache exists and has less than 15 minutes remaining
                    val questions = questionDao.getByExamDraftIdOnce(examDraftId)
                    val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
                    val examType = resolveExamType(examDraftId)
                    val systemInstructionText = EvaluationPromptPolicy.build(
                        examType = examType,
                        rubricAdherenceLevel = preferences.rubricAdherenceLevel,
                        feedbackDetailLevel = preferences.feedbackDetailLevel,
                        provideWritingAndPunctuationFeedback = preferences.provideWritingAndPunctuationFeedback
                    ).systemInstruction

                    onProgress?.invoke("Prompt Caching süresi uzatılıyor...")
                    cacheMgr.getOrCreateCache(
                        draftId = examDraftId,
                        questions = questions,
                        rubrics = rubrics,
                        systemInstructionText = systemInstructionText,
                        apiKey = apiKey,
                        ttlSeconds = 176400, // Extend for another 49 hours
                        examType = examType,
                        evaluationModelId = runProfile.evaluationModel
                    )
                }
            }

            var hasAnyRunning = false

            for (job in jobsToPoll) {
                onProgress?.invoke("Batch işi durumu kontrol ediliyor: ${job.jobId} (${job.status})...")
                val (meta, results) = batchJobManager.checkJobStatus(job.jobId, apiKey)
                currentCoroutineContext().ensureActive()
                runCatching { requireAiEvaluationWorkflowStage(examDraftId) }.getOrElse { stageError ->
                    pauseEvaluationAndCancelRemote(examDraftId)
                    return@withContext Result.failure(stageError)
                }

                if (meta.status == "JOB_STATE_SUCCEEDED") {
                    if (results != null) {
                        val questions = questionDao.getByExamDraftIdOnce(examDraftId)
                        val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
                        val preferences = preferencesDao.getPreferencesOnce(examDraftId)!!
                        val resultExamType = resolveExamType(examDraftId)
                        val resultPageLayouts = buildAnswerSheetLayouts(examDraftId, questions, rubrics, resultExamType)

                        val returnedPaperIds = results.map { it.studentPaperId }.toSet()
                        val missingPaperIds = meta.studentPaperIds.filterNot { returnedPaperIds.contains(it) }

                        // Mark missing student papers as error
                        for (missingId in missingPaperIds) {
                            val errEval = ExamStudentEvaluationEntity(
                                studentPaperId = missingId,
                                examDraftId = examDraftId,
                                status = "ERROR",
                                needsReview = true,
                                errorMessage = "Batch sonucunda öğrenci değerlendirmesi eksik.",
                                updatedAt = System.currentTimeMillis()
                            )
                            evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                        }

                        for (res in results) {
                            val paperId = res.studentPaperId
                            if (res.isSuccess && !res.responseJson.isNullOrBlank()) {
                                val pages = paperUploadDao.getPagesForPaperOnce(paperId)
                                val input = ExamStudentEvaluationInput(
                                    studentPaperId = paperId,
                                    studentPages = pages,
                                    questions = questions,
                                    rubrics = rubrics,
                                    preferences = preferences,
                                    examType = resultExamType,
                                    gradeLevel = draftDao?.getDraftByIdOnce(examDraftId)?.gradeLevel,
                                    pageLayouts = resultPageLayouts,
                                    evaluationModelId = runProfile.evaluationModel,
                                    supportsHighMediaResolution = runProfile.supportsHighMediaResolution,
                                    supportsThinkingLevel = runProfile.supportsThinkingLevel,
                        supportsPromptCaching = runProfile.supportsPromptCaching,
                        allowLegacyPrivacyCrop = runProfile.legacyPrivacyApprovedAt != null,
                        privacyMasksByPageId = privacyMasksFor(pages)
                                )
                                val parsedOutput = httpEvaluator.parseGeminiResponse(res.responseJson, input)
                                val refinedOutput = if (parsedOutput.isSuccess) {
                                    httpEvaluator.finalizeInitialEvaluation(input, parsedOutput)
                                } else parsedOutput
                                val output = if (input.examType == ExamType.MULTIPLE_CHOICE && refinedOutput.isSuccess) {
                                    MultipleChoiceScoringPolicy.normalize(questions, rubrics, refinedOutput)
                                } else refinedOutput
                                recordUsage(examDraftId, paperId, "BATCH_FIRST_PASS", runProfile.evaluationModel, output.usage, runProfile, batch = true)
                                recordUsage(examDraftId, paperId, "SECOND_CHECK", runProfile.evaluationModel, output.secondaryUsage, runProfile, batch = false)

                                if (output.isSuccess) {
                                    val questionEntities = output.questionEvaluations.map { q ->
                                        ExamQuestionEvaluationEntity(
                                            studentPaperId = paperId,
                                            examDraftId = examDraftId,
                                            questionNumber = q.questionNumber,
                                            questionOrderIndex = q.questionOrderIndex,
                                            readAnswerText = q.readAnswerText,
                                            score = q.score,
                                            maxScore = q.maxScore,
                                            feedback = q.feedback,
                                            interpretedMeaning = q.interpretedMeaning,
                                            gradingEvidence = q.gradingEvidence,
                                            readingConfidence = q.readingConfidence,
                                            evaluationConfidence = q.evaluationConfidence,
                                            answerType = q.answerType,
                                            needsReview = q.needsReview,
                                            reviewReason = q.reviewReason,
                                            originalScore = q.score,
                                            isTeacherModified = false,
                                            isResolved = !q.needsReview,
                                            strengths = q.strengths,
                                            missingElements = q.missingElements,
                                            misconceptions = q.misconceptions,
                                            nextSteps = q.nextSteps
                                        )
                                    }

                                    val finalStatus = if (output.needsReview) "NEEDS_REVIEW" else "COMPLETED"
                                    val completedEval = ExamStudentEvaluationEntity(
                                        studentPaperId = paperId,
                                        examDraftId = examDraftId,
                                        status = finalStatus,
                                        totalScore = output.totalScore,
                                        totalMaxScore = output.totalMaxScore,
                                        spellingPunctuationFeedback = null,
                                        writingStrengths = output.writingStrengths,
                                        writingIssues = output.writingIssues,
                                        writingNextSteps = output.writingNextSteps,
                                        spellingPunctuationDeduction = output.spellingPunctuationDeduction,
                                        overallConfidence = output.overallConfidence,
                                        needsReview = output.needsReview,
                                        errorMessage = null,
                                        updatedAt = System.currentTimeMillis()
                                    )

                                    requireAiEvaluationWorkflowStage(examDraftId)
                                    currentCoroutineContext().ensureActive()
                                    evaluationDao.saveCompleteEvaluationTransaction(completedEval, questionEntities)
                                } else {
                                    val errEval = ExamStudentEvaluationEntity(
                                        studentPaperId = paperId,
                                        examDraftId = examDraftId,
                                        status = "ERROR",
                                        needsReview = true,
                                        errorMessage = output.errorMessage ?: "Ayrıştırma hatası.",
                                        updatedAt = System.currentTimeMillis()
                                    )
                                    evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                                }
                            } else {
                                val errEval = ExamStudentEvaluationEntity(
                                    studentPaperId = paperId,
                                    examDraftId = examDraftId,
                                    status = "ERROR",
                                    needsReview = true,
                                    errorMessage = res.errorMessage ?: "Batch öğrenci değerlendirmesi başarısız.",
                                    updatedAt = System.currentTimeMillis()
                                )
                                evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                            }
                        }
                    }
                    // Local results are committed. Remote cleanup is performed once every
                    // Batch in this draft is locally terminal so running siblings are never deleted.
                    batchJobManager.updateJobStatusInStore(job.jobId, "COMPLETED_PROCESSED")
                } else if (meta.status == "JOB_STATE_FAILED" || meta.status == "JOB_STATE_CANCELLED" || meta.status == "JOB_STATE_EXPIRED") {
                    meta.studentPaperIds.forEach { paperId ->
                        val errEval = ExamStudentEvaluationEntity(
                            studentPaperId = paperId,
                            examDraftId = examDraftId,
                            status = "ERROR",
                            needsReview = true,
                            errorMessage = "Batch işi ${meta.status} durumunda sonlandı.",
                            updatedAt = System.currentTimeMillis()
                        )
                        evaluationDao.insertOrUpdateStudentEvaluation(errEval)
                    }
                    // Mark terminal work processed. Remote cleanup runs after all sibling jobs
                    // are terminal, preserving active Batch jobs in the same draft.
                    batchJobManager.updateJobStatusInStore(job.jobId, "FAILED_PROCESSED")
                } else if (meta.status == "SUBMISSION_STARTED" || meta.status == "SUBMISSION_UNCERTAIN") {
                    val uncertaintyAgeMs = System.currentTimeMillis() - meta.createdAt
                    if (uncertaintyAgeMs >= 10 * 60_000L) {
                        val message = "Batch gönderiminin sonucu 10 dakika içinde güvenli biçimde doğrulanamadı. Otomatik yeniden gönderim yapılmadı; öğretmen müdahalesi gerekiyor."
                        persistEvaluationRunState(examDraftId, "BATCH", "ERROR", message)
                        synchronized(this@ExamEvaluationRepository) { evaluationErrors[examDraftId] = message }
                        return@withContext Result.failure(IllegalStateException(message))
                    }
                    if (meta.status == "SUBMISSION_STARTED") {
                        meta.studentPaperIds.forEach { paperId ->
                            val existing = evaluationDao.getStudentEvaluationOnce(paperId)
                            if (existing?.errorMessage != "Batch gönderiminin sonucu belirsiz. Aynı öğrenciler yeniden gönderilmedi.") {
                                evaluationDao.insertOrUpdateStudentEvaluation(
                                    ExamStudentEvaluationEntity(
                                        studentPaperId = paperId, examDraftId = examDraftId, status = "ERROR",
                                        needsReview = true,
                                        errorMessage = "Batch gönderiminin sonucu belirsiz. Aynı öğrenciler yeniden gönderilmedi.",
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        }
                        batchJobManager.updateJobStatusInStore(job.jobId, "SUBMISSION_UNCERTAIN")
                    }
                    hasAnyRunning = true
                } else {
                    hasAnyRunning = true
                }
            }

            if (hasAnyRunning) {
                delay(pollDelayMs)
                pollDelayMs = (pollDelayMs * 2).coerceAtMost(120_000L)
            }
        }

        // 3. Clean up cache if all batch jobs are processed
        val remainingJobs = batchJobManager.getUnprocessedJobsForDraft(examDraftId)
        if (remainingJobs.isEmpty()) {
            val cleanup = batchJobManager.cleanupDraft(examDraftId, apiKey)
            remoteCleanupPendingCounts[examDraftId] = cleanup.pendingRemoteDeletion
        }
        val cacheMgr = httpEvaluator.getCacheManager()
        if (remainingJobs.isEmpty() && cacheMgr != null && apiKey.isNotBlank()) {
            onProgress?.invoke("Prompt Caching temizleniyor...")
            cacheMgr.deleteCacheForDraft(examDraftId, apiKey)
        }

        Result.success(Unit)
    }

    suspend fun updateQuestionEvaluationScore(questionEvalId: Long, score: Double, isTeacherModified: Boolean, isResolved: Boolean) = withContext(Dispatchers.IO) {
        evaluationDao.updateQuestionScoreAndResolution(questionEvalId, score, isTeacherModified, isResolved)
    }

    suspend fun applyTeacherScoreChange(questionEvalId: Long, score: Double): Double = withContext(Dispatchers.IO) {
        evaluationDao.applyTeacherScoreChangeTransaction(questionEvalId, score, isResolved = true)
    }

    suspend fun resolveLocalMultipleChoiceAnswer(
        questionEvaluation: ExamQuestionEvaluationEntity,
        selectedChoice: String?,
        expectedChoice: String
    ) = withContext(Dispatchers.IO) {
        val resolution = MultipleChoiceManualReviewPolicy.resolve(
            selectedChoice = selectedChoice,
            expectedChoice = expectedChoice,
            maxScore = questionEvaluation.maxScore
        ) ?: throw IllegalArgumentException("Cevap anahtarındaki doğru seçenek geçersiz.")
        evaluationDao.resolveMultipleChoiceAnswer(
            questionEvalId = questionEvaluation.id,
            readAnswerText = resolution.selectedChoice.orEmpty(),
            score = resolution.score,
            feedback = resolution.feedback,
            answerType = resolution.answerType
        )
        val updated = evaluationDao.getQuestionEvaluationsForPaperOnce(questionEvaluation.studentPaperId)
        val newTotal = updated.sumOf { it.score }
        val student = evaluationDao.getStudentEvaluationOnce(questionEvaluation.studentPaperId)
        if (student != null) {
            val stillNeedsReview = updated.any { it.needsReview && !it.isResolved }
            evaluationDao.insertOrUpdateStudentEvaluation(
                student.copy(
                    totalScore = newTotal,
                    status = if (stillNeedsReview) "NEEDS_REVIEW" else "COMPLETED",
                    needsReview = stillNeedsReview,
                    errorMessage = null,
                    isTeacherApproved = false,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun updateTeacherNote(studentPaperId: Long, note: String?) = withContext(Dispatchers.IO) {
        val clean = note?.trim()?.takeIf { it.isNotEmpty() }
        require((clean?.length ?: 0) <= 500) { "Öğretmen notu en fazla 500 karakter olabilir." }
        require(evaluationDao.getStudentEvaluationOnce(studentPaperId) != null) { "Öğrenci değerlendirmesi bulunamadı." }
        evaluationDao.updateTeacherNote(studentPaperId, clean)
    }

    suspend fun updateStudentApproval(studentPaperId: Long, totalScore: Double, isTeacherApproved: Boolean) = withContext(Dispatchers.IO) {
        evaluationDao.updateStudentApprovalAndScore(studentPaperId, totalScore, isTeacherApproved)
    }

    suspend fun invalidateApprovalAndFinalFeedback(studentPaperId: Long, totalScore: Double) = withContext(Dispatchers.IO) {
        evaluationDao.invalidateFinalFeedbackTransaction(studentPaperId, totalScore)
    }


    suspend fun isHomeworkExam(examDraftId: Long): Boolean = withContext(Dispatchers.IO) {
        resolveExamType(examDraftId) == ExamType.HOMEWORK
    }
    suspend fun getStudentEvaluationOnce(studentPaperId: Long): ExamStudentEvaluationEntity? = withContext(Dispatchers.IO) {
        evaluationDao.getStudentEvaluationOnce(studentPaperId)
    }

    private suspend fun requireCurrentMultipleChoiceAnswerKey(
        examDraftId: Long,
        lockedQuestions: List<ExamQuestionEntity>
    ): Map<Int, String> {
        val questionMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            ?: throw IllegalStateException("Test soru seti meta verisi bulunamadı.")
        if (!questionMetadata.isLocked) {
            throw IllegalStateException("Test soru seti kilitli değil.")
        }
        val answerKeyMetadata = rubricDao.getMetadataByExamDraftIdOnce(examDraftId)
            ?: throw IllegalStateException("Test cevap anahtarı bulunamadı.")
        if (!answerKeyMetadata.isLocked || answerKeyMetadata.questionSetRevision != questionMetadata.revision) {
            throw IllegalStateException("Test cevap anahtarı kilitli değil veya güncel soru setiyle uyuşmuyor.")
        }
        val rowsByOrder = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId).groupBy { it.questionOrderIndex }
        val answerKey = linkedMapOf<Int, String>()
        for (question in lockedQuestions.sortedBy { it.orderIndex }) {
            val rows = rowsByOrder[question.orderIndex].orEmpty()
            if (rows.size != 1) {
                throw IllegalStateException("Test cevap anahtarında ${question.questionNumber}. soru için tam olarak bir doğru seçenek bulunmalıdır.")
            }
            val row = rows.single()
            val expected = MultipleChoiceScoringPolicy.normalizeChoice(
                row.expectedAnswer.ifBlank { row.originalAnswerKey.orEmpty() }
            ) ?: throw IllegalStateException("Test cevap anahtarında ${question.questionNumber}. sorunun doğru seçeneği geçersiz.")
            if (kotlin.math.abs(row.maxPoints.toDouble() - question.points.toDouble()) > 0.0001) {
                throw IllegalStateException("Test cevap anahtarında ${question.questionNumber}. sorunun puanı güncel soru yapısıyla uyuşmuyor.")
            }
            answerKey[question.orderIndex] = expected
        }
        val unknownRows = rowsByOrder.keys - lockedQuestions.map { it.orderIndex }.toSet()
        if (unknownRows.isNotEmpty()) {
            throw IllegalStateException("Test cevap anahtarında güncel soru setinde olmayan kayıtlar var.")
        }
        return answerKey
    }

    private fun validateMultipleChoiceFinalScore(
        qEval: ExamQuestionEvaluationEntity,
        expectedChoice: String
    ): String? {
        val normalizedRead = MultipleChoiceScoringPolicy.normalizeChoice(qEval.readAnswerText)
        if (qEval.readAnswerText.isNotBlank() && normalizedRead == null) {
            return "${qEval.questionNumber}. soruda geçersiz işaretleme kaydı var. Yerel Optik Okuma'yı yeniden çalıştırın veya öğretmen incelemesinde düzeltin."
        }
        val expectedScore = if (normalizedRead == expectedChoice) qEval.maxScore else 0.0
        if (kotlin.math.abs(qEval.score - expectedScore) > 0.0001) {
            return "${qEval.questionNumber}. sorunun puanı güncel cevap anahtarıyla uyuşmuyor. Cevap anahtarı değiştiyse Yerel Optik Okuma'yı yeniden çalıştırın veya işaretlemeyi öğretmen incelemesinde yeniden doğrulayın."
        }
        return null
    }

    suspend fun checkFinalResultsIntegrity(examDraftId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val examType = resolveExamType(examDraftId)
        val submission = submissionLabel(examType)
        val item = itemLabel(examType)
        val itemSet = itemSetLabel(examType)
        val openReviewRequests = evaluationDao.getReviewRequestsForExam(examDraftId).filter { it.status == "OPEN" }
        if (openReviewRequests.isNotEmpty()) {
            return@withContext Result.failure(Exception("${openReviewRequests.size} açık öğrenci/veli yeniden inceleme talebi var. Tüm talepleri sonuçlandırmadan rapor kesinleştirilemez."))
        }
        val studentPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
        val studentEvals = evaluationDao.getStudentEvaluationsForExamOnce(examDraftId)
        val evalMap = studentEvals.associateBy { it.studentPaperId }
        val allQuestionEvals = evaluationDao.getQuestionEvaluationsForExamOnce(examDraftId)
        val questionEvalMap = allQuestionEvals.groupBy { it.studentPaperId }
        val lockedQuestions = questionDao.getByExamDraftIdOnce(examDraftId)
        val testAnswerKey = if (examType == ExamType.MULTIPLE_CHOICE) {
            try {
                requireCurrentMultipleChoiceAnswerKey(examDraftId, lockedQuestions)
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        } else emptyMap()

        if (studentPapers.isEmpty()) return@withContext Result.failure(Exception("Beklenen $submission yok."))
        if (studentPapers.size != studentEvals.size) return@withContext Result.failure(Exception("Eksik öğrenci değerlendirme kaydı var."))
        if (lockedQuestions.isEmpty()) return@withContext Result.failure(Exception("Kilitli $itemSet yok."))

        for (paper in studentPapers) {
            val eval = evalMap[paper.id] ?: return@withContext Result.failure(Exception("Öğrenci kaydı bulunamadı."))
            if (!eval.isTeacherApproved) return@withContext Result.failure(Exception("Tüm sonuçlar onaylanmamış."))
            if (eval.status != "COMPLETED" && eval.status != "NEEDS_REVIEW") return@withContext Result.failure(Exception("Tamamlanmamış değerlendirmeler var."))
            
            val qEvals = questionEvalMap[paper.id].orEmpty()
            if (qEvals.size != lockedQuestions.size) return@withContext Result.failure(Exception("$item değerlendirme sayıları uyuşmuyor."))
            
            val processedOrders = mutableSetOf<Int>()
            var calculatedScore = 0.0

            for (qEval in qEvals) {
                val lockedQ = lockedQuestions.find { it.orderIndex == qEval.questionOrderIndex }
                    ?: return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.id} için bulunamayan ${item.lowercase()} sırası: ${qEval.questionOrderIndex}."))

                if (processedOrders.contains(qEval.questionOrderIndex)) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.id} için mükerrer ${item.lowercase()} değerlendirmesi bulundu: $item ${qEval.questionOrderIndex}."))
                }
                processedOrders.add(qEval.questionOrderIndex)

                if (lockedQ.questionNumber != qEval.questionNumber) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.id} için ${item.lowercase()} kimliği uyuşmazlığı: ${qEval.questionNumber} vs ${lockedQ.questionNumber}."))
                }

                if (lockedQ.points.toDouble() != qEval.maxScore) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.id} için maxScore uyuşmazlığı ($item ${qEval.questionOrderIndex})."))
                }

                if (qEval.score < 0 || qEval.score > qEval.maxScore) {
                    return@withContext Result.failure(Exception("Geçersiz puan aralığı bulundu."))
                }
                if (examType == ExamType.MULTIPLE_CHOICE &&
                    qEval.score != 0.0 && kotlin.math.abs(qEval.score - qEval.maxScore) > 0.0001
                ) {
                    return@withContext Result.failure(Exception("Test sorularında kısmi puan bulunamaz."))
                }
                if (examType == ExamType.MULTIPLE_CHOICE) {
                    val expectedChoice = testAnswerKey[qEval.questionOrderIndex]
                        ?: return@withContext Result.failure(Exception("Test cevap anahtarında ${qEval.questionNumber}. soru bulunamadı."))
                    validateMultipleChoiceFinalScore(qEval, expectedChoice)?.let { reason ->
                        return@withContext Result.failure(Exception(reason))
                    }
                }
                
                calculatedScore += qEval.score
            }

            if (processedOrders.size != lockedQuestions.size) {
                return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.id} için bazı ${item.lowercase()} değerlendirmeleri eksik."))
            }
            
            val unresolved = qEvals.filter { it.needsReview && !it.isResolved }
            if (unresolved.isNotEmpty()) return@withContext Result.failure(Exception("Çözülmemiş NEEDS_REVIEW ${item.lowercase()} kayıtları var."))

            if (Math.abs((eval.totalScore ?: 0.0) - calculatedScore) > 0.01) {
                return@withContext Result.failure(Exception("Toplam puan uyuşmazlığı var."))
            }
        }
        Result.success(Unit)
    }

    data class AiUsageSummary(
        val evaluationModel: String?,
        val feedbackModel: String?,
        val authoringModels: List<String>,
        val stages: List<String>,
        val inputTokens: Long,
        val cachedInputTokens: Long,
        val outputTokens: Long,
        val thinkingTokens: Long,
        val providerCallCostUsd: Double,
        val cacheStorageCostUsd: Double,
        val estimatedCostUsd: Double,
        val callCount: Int,
        val actualModelVersions: List<String>,
        val providerResponseIds: List<String>,
        val modelStatusStages: List<String>,
        val modelRetirementTimes: List<String>,
        val modelStatusMessages: List<String>
    )

    suspend fun getAiUsageSummary(examDraftId: Long): AiUsageSummary = withContext(Dispatchers.IO) {
        val profile = evaluationDao.getAiRunProfile(examDraftId)
        val rows = evaluationDao.getAiUsageForExam(examDraftId)
        val callCost = rows.sumOf { it.estimatedCostUsd }
        val cacheCost = if (profile != null) {
            httpEvaluator.getCacheManager()?.storageCostUsdForDraft(examDraftId, profile.cacheStoragePerMillionTokenHourUsd) ?: 0.0
        } else 0.0
        AiUsageSummary(
            evaluationModel = profile?.evaluationModel,
            feedbackModel = profile?.feedbackModel,
            authoringModels = rows.filter { it.stage.startsWith("AUTHORING_") }.map { it.modelId }.distinct(),
            stages = rows.map { it.stage }.distinct(),
            inputTokens = rows.sumOf { it.inputTokens },
            cachedInputTokens = rows.sumOf { it.cachedInputTokens },
            outputTokens = rows.sumOf { it.outputTokens },
            thinkingTokens = rows.sumOf { it.thinkingTokens },
            providerCallCostUsd = callCost,
            cacheStorageCostUsd = cacheCost,
            estimatedCostUsd = callCost + cacheCost,
            callCount = rows.size,
            actualModelVersions = rows.mapNotNull { it.actualModelVersion }.flatMap { it.split(" | ") }.distinct(),
            providerResponseIds = rows.mapNotNull { it.responseId }.flatMap { it.split(" | ") }.distinct(),
            modelStatusStages = rows.mapNotNull { it.modelStatusStage }.flatMap { it.split(" | ") }.distinct(),
            modelRetirementTimes = rows.mapNotNull { it.modelRetirementTime }.flatMap { it.split(" | ") }.distinct(),
            modelStatusMessages = rows.mapNotNull { it.modelStatusMessage }.flatMap { it.split(" | ") }.distinct()
        )
    }

    data class FeedbackGenerationSummary(
        val totalRequested: Int,
        val generated: Int,
        val failed: Int
    )

    suspend fun countMissingFinalFeedback(examDraftId: Long): Int = withContext(Dispatchers.IO) {
        val mode = processingMode(examDraftId)
        if (mode.feedbackSource != "AI") return@withContext 0
        val examType = resolveExamType(examDraftId)
        if (examType == ExamType.MULTIPLE_CHOICE) return@withContext 0
        val preferences = preferencesDao.getPreferencesOnce(examDraftId) ?: return@withContext 0
        if (preferences.feedbackDetailLevel == com.example.core.model.FeedbackDetailLevel.SCORE_ONLY) return@withContext 0
        evaluationDao.getStudentEvaluationsForExamOnce(examDraftId).count { it.isTeacherApproved && it.feedbackGeneratedAt == null }
    }

    suspend fun generateMissingFinalFeedback(
        examDraftId: Long,
        maxItems: Int = 25,
        onProgress: ((completed: Int, total: Int) -> Unit)? = null
    ): Result<FeedbackGenerationSummary> = withContext(Dispatchers.IO) {
        require(maxItems in 1..25) { "Bir dönüt turunda en fazla 25 öğrenci işlenebilir." }
        val mode = processingMode(examDraftId)
        if (mode.feedbackSource != "AI") {
            return@withContext Result.success(FeedbackGenerationSummary(0, 0, 0))
        }
        runCatching { requireStudentAiCompliance(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        val runProfile = runCatching { ensureAiRunProfile(examDraftId) }.getOrElse { return@withContext Result.failure(it) }
        val writer = feedbackWriter ?: return@withContext Result.failure(Exception("Dönüt yazarı kullanılamıyor."))
        val examType = resolveExamType(examDraftId)
        if (examType == ExamType.MULTIPLE_CHOICE) return@withContext Result.success(FeedbackGenerationSummary(0,0,0))
        val preferences = preferencesDao.getPreferencesOnce(examDraftId)
            ?: return@withContext Result.failure(Exception("Değerlendirme tercihleri bulunamadı."))
        if (preferences.feedbackDetailLevel == com.example.core.model.FeedbackDetailLevel.SCORE_ONLY) {
            return@withContext Result.success(FeedbackGenerationSummary(0,0,0))
        }
        val feedbackDraft = draftDao?.getDraftByIdOnce(examDraftId)
        if (draftDao != null && feedbackDraft?.currentWorkflowStage != WorkflowStage.REPORTS) {
            return@withContext Result.failure(IllegalStateException("Ayrıntılı dönüt yalnız Raporlar aşamasında üretilebilir."))
        }
        val gradeLevel = feedbackDraft?.gradeLevel
        val pending = evaluationDao.getStudentEvaluationsForExamOnce(examDraftId)
            .asSequence()
            .filter { it.isTeacherApproved && it.feedbackGeneratedAt == null }
            .take(maxItems)
            .toList()
        var generatedCount = 0
        var failedCount = 0
        pending.forEachIndexed { index, student ->
            currentCoroutineContext().ensureActive()
            if (draftDao != null && draftDao.getDraftByIdOnce(examDraftId)?.currentWorkflowStage != WorkflowStage.REPORTS) {
                return@withContext Result.failure(IllegalStateException("Raporlar aşamasından çıkıldığı için kalan dönütler üretilmedi."))
            }
            val rows = evaluationDao.getQuestionEvaluationsForPaperOnce(student.studentPaperId).sortedBy { it.questionOrderIndex }
            val request = ApprovedFeedbackRequest(
                studentPaperId = student.studentPaperId,
                gradeLevel = gradeLevel,
                detailLevel = preferences.feedbackDetailLevel,
                questions = rows.map { row ->
                    ApprovedFeedbackQuestionEvidence(
                        questionOrderIndex = row.questionOrderIndex,
                        questionNumber = row.questionNumber,
                        finalTeacherScore = row.score,
                        originalAiScore = row.originalScore,
                        maxScore = row.maxScore,
                        teacherModified = row.isTeacherModified,
                        answerType = row.answerType,
                        strengths = row.strengths,
                        missingElements = row.missingElements,
                        misconceptions = row.misconceptions,
                        nextSteps = row.nextSteps
                    )
                },
                writingStrengths = student.writingStrengths,
                writingIssues = student.writingIssues,
                writingNextSteps = student.writingNextSteps,
                feedbackModelId = runProfile.feedbackModel
            )
            try {
                val result = writer.generateApproved(request)
                recordUsage(examDraftId, student.studentPaperId, "FINAL_FEEDBACK", runProfile.feedbackModel, result.usage, runProfile, feedback = true, batch = false)
                val byOrder = rows.associateBy { it.questionOrderIndex }
                val feedbackById = result.questionFeedback.mapNotNull { (order, feedback) ->
                    byOrder[order]?.id?.let { it to feedback }
                }.toMap()
                if (feedbackById.size != rows.size) throw IllegalStateException("Bazı soru dönütleri eksik üretildi.")
                val committed = evaluationDao.saveFinalFeedbackIfSnapshotMatches(
                    examDraftId = examDraftId,
                    expectedStudent = student,
                    expectedQuestionEvaluations = rows,
                    questionFeedback = feedbackById,
                    overallFeedback = result.overallFeedback,
                    writingFeedback = result.writingFeedback,
                    generatedAt = System.currentTimeMillis()
                )
                if (!committed) {
                    throw IllegalStateException("Dönüt üretilirken workflow veya öğretmen onaylı puanlar değişti; eski dönüt kaydedilmedi.")
                }
                generatedCount++
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (_: Exception) {
                failedCount++
            }
            onProgress?.invoke(index + 1, pending.size)
        }
        Result.success(FeedbackGenerationSummary(pending.size, generatedCount, failedCount))
    }

    suspend fun validateAndConfirmAllResults(examDraftId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val examType = resolveExamType(examDraftId)
        val submission = submissionLabel(examType)
        val item = itemLabel(examType)
        val itemSet = itemSetLabel(examType)
        val openReviewRequests = evaluationDao.getReviewRequestsForExam(examDraftId).filter { it.status == "OPEN" }
        if (openReviewRequests.isNotEmpty()) {
            return@withContext Result.failure(Exception("${openReviewRequests.size} açık öğrenci/veli yeniden inceleme talebi var. Tüm talepleri sonuçlandırmadan sonuçlar nihai olarak onaylanamaz."))
        }
        val studentPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
        val studentEvals = evaluationDao.getStudentEvaluationsForExamOnce(examDraftId)
        val evalMap = studentEvals.associateBy { it.studentPaperId }
        val allQuestionEvals = evaluationDao.getQuestionEvaluationsForExamOnce(examDraftId)
        val questionEvalMap = allQuestionEvals.groupBy { it.studentPaperId }
        val lockedQuestions = questionDao.getByExamDraftIdOnce(examDraftId)
        val testAnswerKey = if (examType == ExamType.MULTIPLE_CHOICE) {
            try {
                requireCurrentMultipleChoiceAnswerKey(examDraftId, lockedQuestions)
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        } else emptyMap()

        if (studentPapers.isEmpty()) {
            return@withContext Result.failure(Exception("Değerlendirilecek $submission bulunamadı."))
        }

        if (lockedQuestions.isEmpty()) {
            return@withContext Result.failure(Exception("Kilitli $itemSet bulunamadı."))
        }

        val updates = mutableListOf<ExamStudentEvaluationEntity>()

        for (paper in studentPapers) {
            val eval = evalMap[paper.id]
            if (eval == null || (eval.status != "COMPLETED" && eval.status != "NEEDS_REVIEW")) {
                return@withContext Result.failure(Exception("Tüm öğrencilerin değerlendirmesi tamamlanmamış."))
            }
            if (eval.status == "ERROR" || eval.status == "EVALUATING" || eval.status == "WAITING") {
                return@withContext Result.failure(Exception("Hatalı veya devam eden durumda olan $submission kayıtları var."))
            }

            val qEvals = questionEvalMap[paper.id].orEmpty()
            if (qEvals.size != lockedQuestions.size) {
                return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için ${item.lowercase()} değerlendirme sayısı eksik veya uyuşmuyor."))
            }

            val processedOrders = mutableSetOf<Int>()

            for (qEval in qEvals) {
                val lockedQ = lockedQuestions.find { it.orderIndex == qEval.questionOrderIndex }
                if (lockedQ == null) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için bulunamayan ${item.lowercase()} sırası: ${qEval.questionOrderIndex}."))
                }
                if (processedOrders.contains(qEval.questionOrderIndex)) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için mükerrer ${item.lowercase()} değerlendirmesi bulundu: $item ${qEval.questionOrderIndex}."))
                }
                processedOrders.add(qEval.questionOrderIndex)

                if (lockedQ.questionNumber != qEval.questionNumber) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için ${item.lowercase()} kimliği uyuşmazlığı: ${qEval.questionNumber} vs ${lockedQ.questionNumber}."))
                }
                
                if (lockedQ.points.toDouble() != qEval.maxScore) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için maxScore uyuşmazlığı ($item ${qEval.questionOrderIndex})."))
                }

                if (qEval.score < 0.0 || qEval.score > qEval.maxScore) {
                    return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için ${item.lowercase()} ${qEval.questionOrderIndex} puanı 0 ile ${qEval.maxScore} arasında olmalıdır."))
                }
                if (examType == ExamType.MULTIPLE_CHOICE &&
                    qEval.score != 0.0 && kotlin.math.abs(qEval.score - qEval.maxScore) > 0.0001
                ) {
                    return@withContext Result.failure(Exception("Test sorularında kısmi puan bulunamaz; her soru yalnız 0 veya tam puan olabilir."))
                }
                if (examType == ExamType.MULTIPLE_CHOICE) {
                    val expectedChoice = testAnswerKey[qEval.questionOrderIndex]
                        ?: return@withContext Result.failure(Exception("Test cevap anahtarında ${qEval.questionNumber}. soru bulunamadı."))
                    validateMultipleChoiceFinalScore(qEval, expectedChoice)?.let { reason ->
                        return@withContext Result.failure(Exception(reason))
                    }
                }
            }

            if (processedOrders.size != lockedQuestions.size) {
                return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için bazı ${item.lowercase()} değerlendirmeleri eksik."))
            }

            val unresolved = qEvals.filter { it.needsReview && !it.isResolved }
            if (unresolved.isNotEmpty()) {
                return@withContext Result.failure(Exception("Öğrenci ${paper.studentName ?: paper.schoolNumber ?: paper.id} için çözülmemiş (NEEDS_REVIEW) ${item.lowercase()} kayıtları var."))
            }

            val recalculatedTotal = qEvals.sumOf { it.score }
            updates.add(eval.copy(totalScore = recalculatedTotal, isTeacherApproved = true))
        }

        val committed = evaluationDao.confirmAllStudentResultsIfSnapshotMatches(
            examDraftId = examDraftId,
            expectedStudents = studentEvals,
            expectedQuestionEvaluations = allQuestionEvals,
            updates = updates
        )
        if (!committed) {
            return@withContext Result.failure(
                Exception("Sonuçlar onaylanırken workflow, puanlar veya inceleme kayıtları değişti; eski snapshot onaylanmadı. Lütfen sonuçları yeniden kontrol edin.")
            )
        }

        // Academic approval ends here. Long prose feedback is prepared separately in Reports,
        // so a network/prose failure can never block or delay teacher approval.
        Result.success(Unit)
    }
}
