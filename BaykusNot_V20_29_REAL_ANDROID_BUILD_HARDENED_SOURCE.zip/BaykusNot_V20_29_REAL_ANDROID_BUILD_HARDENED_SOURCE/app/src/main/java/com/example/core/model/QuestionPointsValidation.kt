package com.example.core.model

enum class QuestionPointsValidationCode {
    INVALID_TARGET_DRAFT_ID,
    INVALID_EXPECTED_TOTAL_POINTS,
    EMPTY_QUESTION_LIST,
    QUESTION_DRAFT_MISMATCH,
    INVALID_ORDER_INDEX,
    BLANK_QUESTION_NUMBER,
    BLANK_QUESTION_TEXT,
    NON_POSITIVE_POINTS,
    DUPLICATE_ORDER_INDEX,
    DUPLICATE_QUESTION_NUMBER,
    TOTAL_POINTS_MISMATCH
}

data class QuestionPointsValidationIssue(
    val code: QuestionPointsValidationCode,
    val questionId: Long? = null,
    val orderIndex: Int? = null,
    val questionNumber: String? = null,
    val value: String? = null
)

data class QuestionPointsValidationResult(
    val expectedTotalPoints: Int,
    val calculatedTotalPoints: Long,
    val issues: List<QuestionPointsValidationIssue>
) {
    val canLock: Boolean
        get() = issues.isEmpty()
}

object QuestionPointsValidator {

    fun validate(
        examDraftId: Long,
        expectedTotalPoints: Int,
        questions: List<ExamQuestion>
    ): QuestionPointsValidationResult {
        val issues = mutableListOf<QuestionPointsValidationIssue>()

        if (examDraftId <= 0L) {
            issues.add(QuestionPointsValidationIssue(code = QuestionPointsValidationCode.INVALID_TARGET_DRAFT_ID))
        }

        if (expectedTotalPoints <= 0) {
            issues.add(QuestionPointsValidationIssue(code = QuestionPointsValidationCode.INVALID_EXPECTED_TOTAL_POINTS))
        }

        if (questions.isEmpty()) {
            issues.add(QuestionPointsValidationIssue(code = QuestionPointsValidationCode.EMPTY_QUESTION_LIST))
        }

        val seenOrderIndexes = mutableSetOf<Int>()
        val reportedDuplicateOrderIndexes = mutableSetOf<Int>()
        val seenQuestionNumbers = mutableSetOf<String>()
        val reportedDuplicateQuestionNumbers = mutableSetOf<String>()

        val calculatedTotalPoints = questions.sumOf { it.points.toLong() }

        for (question in questions) {
            if (question.examDraftId <= 0L || question.examDraftId != examDraftId) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.QUESTION_DRAFT_MISMATCH,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber
                    )
                )
            }

            if (question.orderIndex < 1) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.INVALID_ORDER_INDEX,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber
                    )
                )
            }

            if (!seenOrderIndexes.add(question.orderIndex) && reportedDuplicateOrderIndexes.add(question.orderIndex)) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.DUPLICATE_ORDER_INDEX,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber,
                        value = question.orderIndex.toString()
                    )
                )
            }

            if (question.questionNumber.trim().isEmpty()) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.BLANK_QUESTION_NUMBER,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber
                    )
                )
            } else {
                val normalizedNumber = normalizeQuestionNumber(question.questionNumber)
                if (!seenQuestionNumbers.add(normalizedNumber) && reportedDuplicateQuestionNumbers.add(normalizedNumber)) {
                    issues.add(
                        QuestionPointsValidationIssue(
                            code = QuestionPointsValidationCode.DUPLICATE_QUESTION_NUMBER,
                            questionId = question.id,
                            orderIndex = question.orderIndex,
                            questionNumber = question.questionNumber,
                            value = normalizedNumber
                        )
                    )
                }
            }

            if (question.questionText.trim().isEmpty()) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.BLANK_QUESTION_TEXT,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber
                    )
                )
            }

            if (question.points <= 0) {
                issues.add(
                    QuestionPointsValidationIssue(
                        code = QuestionPointsValidationCode.NON_POSITIVE_POINTS,
                        questionId = question.id,
                        orderIndex = question.orderIndex,
                        questionNumber = question.questionNumber
                    )
                )
            }
        }

        if (expectedTotalPoints > 0 && calculatedTotalPoints != expectedTotalPoints.toLong()) {
            issues.add(
                QuestionPointsValidationIssue(
                    code = QuestionPointsValidationCode.TOTAL_POINTS_MISMATCH,
                    value = "expected=$expectedTotalPoints,actual=$calculatedTotalPoints"
                )
            )
        }

        return QuestionPointsValidationResult(
            expectedTotalPoints = expectedTotalPoints,
            calculatedTotalPoints = calculatedTotalPoints,
            issues = issues
        )
    }
}
