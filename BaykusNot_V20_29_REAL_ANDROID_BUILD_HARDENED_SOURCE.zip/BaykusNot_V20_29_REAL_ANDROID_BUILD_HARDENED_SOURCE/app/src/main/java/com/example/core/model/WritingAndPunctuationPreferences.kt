package com.example.core.model

data class WritingAndPunctuationPreferences(
    val deductPoints: Boolean = false,
    val hasExplicitPreference: Boolean = false,
    val provideFeedback: Boolean = false
)
