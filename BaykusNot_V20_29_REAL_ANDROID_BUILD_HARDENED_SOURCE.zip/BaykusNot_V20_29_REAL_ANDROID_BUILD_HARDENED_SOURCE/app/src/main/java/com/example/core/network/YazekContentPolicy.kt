package com.example.core.network

import java.util.Locale

/**
 * Student-facing content guard aligned with the YAZEK principles used by BaykuşNot.
 * This is deliberately narrow: it protects feedback without rewriting academic source material.
 */
object YazekContentPolicy {
    val promptRules: String = """
        YAZEK ETİK İÇERİK KURALLARI:
        - Öğrenciyi yalnız görünür akademik çalışması üzerinden değerlendir; kimlik, cinsiyet, inanç,
          etnik/kültürel köken, engellilik, aile veya sosyoekonomik durum hakkında çıkarım yapma.
        - Ayrıştırıcı, aşağılayıcı, nefret/şiddet teşvik eden veya öğrenciyi ideolojik/siyasi bir görüşe
          yönlendiren öğrenci dönütü üretme.
        - Türk Millî Eğitiminin genel amaçları ve temel ilkeleriyle bağdaşmayan, insan onurunu zedeleyen
          ya da millî/manevi/kültürel değerlere karşı küçümseyici öğrenci yönlendirmesi üretme.
        - Farklı düşünce, yorum veya ifade biçimlerini yalnız kilitli soru/rubrik akademik olarak
          gerektiriyorsa değerlendir; rubrikte olmayan değer yargısını puan ölçütüne dönüştürme.
    """.trimIndent()

    fun validateStudentFacingFeedback(texts: List<String>) {
        val joined = texts.joinToString(" ").lowercase(Locale.forLanguageTag("tr-TR"))
        val identityBasedAttacks = listOf(
            "ırkın nedeniyle", "etnik kökenin nedeniyle", "dinin nedeniyle", "inancın nedeniyle",
            "cinsiyetin nedeniyle", "engelin nedeniyle", "ailen yüzünden", "ailenin durumu nedeniyle",
            "fakir olduğun için", "zengin olduğun için"
        )
        require(identityBasedAttacks.none(joined::contains)) {
            "Dönüt YAZEK kimlik-temelli ayrımcılık kontrolünden geçmedi."
        }
    }
}
