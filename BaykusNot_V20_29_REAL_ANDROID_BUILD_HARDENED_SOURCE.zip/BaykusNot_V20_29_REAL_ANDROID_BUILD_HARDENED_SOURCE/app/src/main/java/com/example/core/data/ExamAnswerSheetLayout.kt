package com.example.core.data

import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.model.ExamType
import com.example.core.model.formatExamSequenceForDocument
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

enum class AnswerSheetDensity(val code: String, val label: String, val description: String) {
    AUTOMATIC("AUTOMATIC", "Otomatik (Önerilen)", "Akıllı yerleşim ve dengeli satır aralığı"),
    COMPACT("COMPACT", "Kompakt", "Daha sıkı satırlar, maksimum kâğıt tasarrufu"),
    SPACIOUS("SPACIOUS", "Geniş", "Rahat el yazısı için genişletilmiş satır aralığı");

    companion object {
        fun fromCode(code: String?): AnswerSheetDensity {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) || it.name.equals(code, ignoreCase = true) }
                ?: AUTOMATIC
        }
    }
}

enum class AnswerLengthCategory(val label: String, val minLines: Int, val defaultLines: Int, val maxLines: Int) {
    VERY_SHORT("Çok Kısa", 2, 3, 3),
    SHORT("Kısa", 4, 4, 5),
    MEDIUM("Orta", 6, 6, 8),
    LONG("Uzun", 9, 9, 12),
    VERY_LONG("Çok Uzun", 13, 14, 16)
}

data class QuestionBoxSpec(
    val questionNumber: String,
    val displayTitle: String,
    val orderIndex: Int,
    val points: Int,
    val questionText: String,
    val lineCount: Int,
    val lineHeightPt: Float = 18f,
    val headerHeightPt: Float = 18f,
    val heightPt: Float,
    val isContinuation: Boolean = false,
    val topYPt: Float = 0f,
    val pageIndex: Int = 1
)

data class AnswerSheetPageLayout(
    val pageIndex: Int,
    val totalPages: Int,
    val questions: List<QuestionBoxSpec>
)

/**
 * First-page guidance shown only for Listening Exams.
 * Kept as a pure Kotlin value so PDF generation, preview and crop calculations
 * all use the exact same first-page header budget.
 */
data class ListeningAnswerSheetGuidance(
    val playbackCount: Int,
    val instructions: String
) {
    val normalizedPlaybackCount: Int get() = playbackCount.coerceIn(1, 3)

    val pdfLines: List<String>
        get() {
            val lines = mutableListOf("Dinletme sayısı: $normalizedPlaybackCount kez.")
            val cleanInstructions = instructions.trim()
            if (cleanInstructions.isNotEmpty()) {
                lines += wrapForAnswerSheetPdf(cleanInstructions, maxChars = 86, maxLines = 6)
            }
            return lines
        }

    val boxHeightPt: Float get() = 22f + (pdfLines.size * 10f)
    val extraFirstPageHeaderHeightPt: Float get() = boxHeightPt + 8f

    fun fingerprintHash(): Int =
        "$normalizedPlaybackCount|${instructions.trim()}".hashCode()
}

private fun wrapForAnswerSheetPdf(text: String, maxChars: Int, maxLines: Int): List<String> {
    if (text.isBlank()) return emptyList()
    val result = mutableListOf<String>()
    val paragraphs = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')

    fun appendParagraph(paragraph: String) {
        if (result.size >= maxLines) return
        val words = paragraph.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return
        var current = StringBuilder()
        for (word0 in words) {
            var word = word0
            while (word.length > maxChars && result.size < maxLines) {
                if (current.isNotEmpty()) {
                    result += current.toString()
                    current = StringBuilder()
                    if (result.size >= maxLines) return
                }
                result += word.take(maxChars)
                word = word.drop(maxChars)
            }
            if (result.size >= maxLines) return
            if (word.isEmpty()) continue
            val candidateLength = if (current.isEmpty()) word.length else current.length + 1 + word.length
            if (candidateLength <= maxChars) {
                if (current.isNotEmpty()) current.append(' ')
                current.append(word)
            } else {
                if (current.isNotEmpty()) result += current.toString()
                current = StringBuilder(word)
                if (result.size >= maxLines) return
            }
        }
        if (current.isNotEmpty() && result.size < maxLines) result += current.toString()
    }

    for (paragraph in paragraphs) {
        if (result.size >= maxLines) break
        appendParagraph(paragraph)
    }

    // If the original text did not fit, make truncation explicit instead of silently clipping.
    val reconstructed = result.joinToString(" ").replace("…", "").trim()
    val normalizedSource = text.replace(Regex("\\s+"), " ").trim()
    if (result.isNotEmpty() && reconstructed.length < normalizedSource.length && result.size >= maxLines) {
        val last = result.last()
        result[result.lastIndex] = if (last.length >= maxChars - 1) {
            last.take(maxChars - 1) + "…"
        } else {
            "$last…"
        }
    }
    return result
}

data class QuestionCropSegment(
    val pageIndex: Int,
    val topYPt: Float,
    val bottomYPt: Float,
    val heightPt: Float,
    val isContinuation: Boolean = false,
    val displayTitle: String = ""
)

data class QuestionCropBounds(
    val segments: List<QuestionCropSegment>,
    val totalPages: Int
) {
    val primarySegment: QuestionCropSegment? get() = segments.firstOrNull()
    val pageIndex: Int get() = primarySegment?.pageIndex ?: 1
    val topYPt: Float get() = primarySegment?.topYPt ?: 0f
    val bottomYPt: Float get() = primarySegment?.bottomYPt ?: 842f
    val heightPt: Float get() = primarySegment?.heightPt ?: 842f
}

object ExamAnswerSheetLayoutCalculator {

    fun buildAnswerSheetTitle(draft: ExamDraftEntity): String {
        val rawYear = draft.academicYear.trim()
        val yearStr = if (rawYear.contains("EĞİTİM", ignoreCase = true)) {
            rawYear.uppercase()
        } else if (rawYear.isNotEmpty()) {
            "$rawYear EĞİTİM-ÖĞRETİM YILI".uppercase()
        } else {
            "EĞİTİM-ÖĞRETİM YILI"
        }

        val rawInst = draft.institutionName.trim()
        val instStr = if (rawInst.isNotEmpty()) rawInst.uppercase() else "OKUL ADI"

        val rawCourse = draft.courseName.trim()
        val courseStr = if (rawCourse.contains("DERSİ", ignoreCase = true) || rawCourse.contains("DERS", ignoreCase = true)) {
            rawCourse.uppercase()
        } else if (rawCourse.isNotEmpty()) {
            "${rawCourse.uppercase()} DERSİ"
        } else {
            "DERSİ"
        }

        val rawTerm = draft.term.trim()
        val termStr = if (rawTerm.contains("DÖNEM", ignoreCase = true)) {
            rawTerm.uppercase()
        } else if (rawTerm.isNotEmpty()) {
            "$rawTerm. DÖNEM".uppercase()
        } else {
            "1. DÖNEM"
        }

        val seqStr = draft.examType.formatExamSequenceForDocument(draft.examSequenceNumber)

        return "$yearStr $instStr $courseStr $termStr $seqStr — ÖĞRENCİ CEVAP KÂĞIDI".trim()
    }

    fun buildIndividualReportTitle(draft: ExamDraftEntity): String {
        val rawYear = draft.academicYear.trim()
        val yearStr = if (rawYear.contains("EĞİTİM", ignoreCase = true)) {
            rawYear.uppercase()
        } else if (rawYear.isNotEmpty()) {
            "$rawYear EĞİTİM-ÖĞRETİM YILI".uppercase()
        } else {
            "EĞİTİM-ÖĞRETİM YILI"
        }

        val rawInst = draft.institutionName.trim()
        val instStr = if (rawInst.isNotEmpty()) rawInst.uppercase() else "OKUL ADI"

        val rawCourse = draft.courseName.trim()
        val courseStr = if (rawCourse.contains("DERSİ", ignoreCase = true) || rawCourse.contains("DERS", ignoreCase = true)) {
            rawCourse.uppercase()
        } else if (rawCourse.isNotEmpty()) {
            "${rawCourse.uppercase()} DERSİ"
        } else {
            "DERSİ"
        }

        val rawTerm = draft.term.trim()
        val termStr = if (rawTerm.contains("DÖNEM", ignoreCase = true)) {
            rawTerm.uppercase()
        } else if (rawTerm.isNotEmpty()) {
            "$rawTerm. DÖNEM".uppercase()
        } else {
            "1. DÖNEM"
        }

        val seqStr = draft.examType.formatExamSequenceForDocument(draft.examSequenceNumber)

        return "$yearStr $instStr $courseStr $termStr $seqStr — BİREYSEL ÖĞRENCİ RAPORU".trim()
    }

    fun formatExamDate(examDateMillis: Long): String {
        return if (examDateMillis > 0L) {
            val sdf = SimpleDateFormat("dd.MM.yyyy", Locale("tr", "TR"))
            sdf.format(Date(examDateMillis))
        } else {
            "____/____/________"
        }
    }

    /**
     * Determine expected answer category & line count from teacher-approved rubric criteria
     * without assuming points = lines.
     */
    fun determineCategoryAndLines(
        question: ExamQuestionEntity,
        rubricCriteria: List<ExamRubricCriterionEntity> = emptyList(),
        density: AnswerSheetDensity = AnswerSheetDensity.AUTOMATIC
    ): Pair<AnswerLengthCategory, Int> {
        val criteriaForQuestion = rubricCriteria.filter {
            it.questionOrderIndex == question.orderIndex ||
            it.questionNumberSnapshot.trim().equals(question.questionNumber.trim(), ignoreCase = true)
        }

        val expectedLen = criteriaForQuestion.sumOf {
            if (it.expectedAnswer.isNotBlank()) it.expectedAnswer.trim().length else (it.originalAnswerKey?.trim()?.length ?: 0)
        }
        val criteriaCount = criteriaForQuestion.size

        val category: AnswerLengthCategory = when {
            criteriaCount <= 1 && expectedLen in 1..35 -> AnswerLengthCategory.VERY_SHORT
            criteriaCount <= 1 && expectedLen in 36..110 -> AnswerLengthCategory.SHORT
            criteriaCount in 2..3 || (expectedLen in 111..260) -> AnswerLengthCategory.MEDIUM
            criteriaCount in 4..5 || (expectedLen in 261..480) -> AnswerLengthCategory.LONG
            criteriaCount > 5 || expectedLen > 480 -> AnswerLengthCategory.VERY_LONG
            else -> {
                val textLen = question.questionText.trim().length
                if (textLen < 60) AnswerLengthCategory.SHORT
                else AnswerLengthCategory.MEDIUM
            }
        }

        var lines = category.defaultLines

        when (density) {
            AnswerSheetDensity.COMPACT -> lines = maxOf(category.minLines, lines - 1)
            AnswerSheetDensity.SPACIOUS -> lines = minOf(category.maxLines, lines + 1)
            AnswerSheetDensity.AUTOMATIC -> { /* default */ }
        }

        return Pair(category, lines)
    }

    fun calculateQuestionBoxSpec(
        question: ExamQuestionEntity,
        rubricCriteria: List<ExamRubricCriterionEntity> = emptyList(),
        density: AnswerSheetDensity = AnswerSheetDensity.AUTOMATIC,
        lineOverrides: Map<Int, Int> = emptyMap(),
        examType: ExamType = ExamType.WRITTEN
    ): QuestionBoxSpec {
        if (examType == ExamType.MULTIPLE_CHOICE) {
            // Test formu ayrı cevap satırı istemez: tek kompakt optik satır yeterlidir.
            val headerHeightPt = 0f
            val bodyHeightPt = 25f
            return QuestionBoxSpec(
                questionNumber = question.questionNumber,
                displayTitle = "Soru ${question.questionNumber} (${question.points} Puan)",
                orderIndex = question.orderIndex,
                points = question.points,
                questionText = question.questionText,
                lineCount = 1,
                lineHeightPt = bodyHeightPt,
                headerHeightPt = headerHeightPt,
                heightPt = headerHeightPt + bodyHeightPt
            )
        }

        val lines = if (lineOverrides.containsKey(question.orderIndex)) {
            lineOverrides[question.orderIndex]!!.coerceIn(3, 25)
        } else {
            val (_, autoLines) = determineCategoryAndLines(question, rubricCriteria, density)
            autoLines
        }

        val lineHeightPt = when (density) {
            AnswerSheetDensity.COMPACT -> 16.5f
            AnswerSheetDensity.SPACIOUS -> 19.5f
            AnswerSheetDensity.AUTOMATIC -> 18f
        }

        val headerHeightPt = 18f
        val heightPt = headerHeightPt + (lines * lineHeightPt)

        return QuestionBoxSpec(
            questionNumber = question.questionNumber,
            displayTitle = "Cevap ${question.questionNumber} (${question.points} Puan)",
            orderIndex = question.orderIndex,
            points = question.points,
            questionText = question.questionText,
            lineCount = lines,
            lineHeightPt = lineHeightPt,
            headerHeightPt = headerHeightPt,
            heightPt = heightPt
        )
    }

    /**
     * Canonical packing engine. Fits questions onto A4 pages (targeting 2 pages = 1 sheet front/back).
     */
    fun paginateQuestions(
        questions: List<ExamQuestionEntity>,
        rubricCriteria: List<ExamRubricCriterionEntity> = emptyList(),
        densitySetting: String = "AUTOMATIC",
        lineOverrides: Map<Int, Int> = emptyMap(),
        listeningGuidance: ListeningAnswerSheetGuidance? = null,
        examType: ExamType = ExamType.WRITTEN,
        pageHeightPt: Float = 842f,
        page1HeaderHeightPt: Float = 175f, // Updated layout page 1 header
        subsequentHeaderHeightPt: Float = 118f, // Updated layout page 2+ header
        footerHeightPt: Float = 35f,
        marginVerticalPt: Float = 36f
    ): List<AnswerSheetPageLayout> {
        val density = AnswerSheetDensity.fromCode(densitySetting)
        val sortedQuestions = questions.sortedBy { it.orderIndex }
        if (sortedQuestions.isEmpty()) return emptyList()

        val initialBoxSpecs = sortedQuestions.map { calculateQuestionBoxSpec(it, rubricCriteria, density, lineOverrides, examType) }

        // Available heights. Listening guidance is rendered on page 1 only, so the same
        // extra budget must be used by preview/PDF/crop calculations.
        val effectivePage1HeaderHeightPt = (if (examType == ExamType.MULTIPLE_CHOICE) 102f else page1HeaderHeightPt) +
            (listeningGuidance?.extraFirstPageHeaderHeightPt ?: 0f)
        val effectiveSubsequentHeaderHeightPt = if (examType == ExamType.MULTIPLE_CHOICE) 72f else subsequentHeaderHeightPt
        val page1Available = pageHeightPt - marginVerticalPt * 2 - effectivePage1HeaderHeightPt - footerHeightPt
        val pageSubsequentAvailable = pageHeightPt - marginVerticalPt * 2 - effectiveSubsequentHeaderHeightPt - footerHeightPt // ~ 675 pt
        val twoPageTotalCapacity = page1Available + pageSubsequentAvailable // ~ 1258 pt

        // Inter-box spacing
        val interBoxSpacing = if (examType == ExamType.MULTIPLE_CHOICE) 3f else when (density) {
            AnswerSheetDensity.COMPACT -> 6f
            AnswerSheetDensity.SPACIOUS -> 12f
            AnswerSheetDensity.AUTOMATIC -> 8f
        }

        val totalInitialHeight = initialBoxSpecs.sumOf { (it.heightPt + interBoxSpacing).toDouble() }.toFloat()

        // 2-Page Budget Optimization: If initial height slightly exceeds 2 pages, optimize line counts safely within bounds
        // Respect teacher overrides: Do NOT auto-shrink questions that have teacher line overrides!
        val finalBoxSpecs = if (examType != ExamType.MULTIPLE_CHOICE && totalInitialHeight > twoPageTotalCapacity && density == AnswerSheetDensity.AUTOMATIC) {
            initialBoxSpecs.map { box ->
                if (lineOverrides.containsKey(box.orderIndex)) {
                    box // Teacher override takes precedence
                } else {
                    val q = sortedQuestions.first { it.orderIndex == box.orderIndex }
                    val (cat, _) = determineCategoryAndLines(q, rubricCriteria, density)
                    val optimizedLines = maxOf(cat.minLines, box.lineCount - 1)
                    val heightPt = box.headerHeightPt + (optimizedLines * box.lineHeightPt)
                    box.copy(lineCount = optimizedLines, heightPt = heightPt)
                }
            }
        } else {
            initialBoxSpecs
        }

        // Packing Engine
        val pages = mutableListOf<AnswerSheetPageLayout>()
        var currentPageQuestions = mutableListOf<QuestionBoxSpec>()

        var currentPageIndex = 1
        var currentY = marginVerticalPt + effectivePage1HeaderHeightPt
        var currentAvailable = page1Available

        for (box in finalBoxSpecs) {
            val reqHeight = box.heightPt + interBoxSpacing

            if (reqHeight <= currentAvailable || currentPageQuestions.isEmpty()) {
                val positionedBox = box.copy(
                    topYPt = currentY,
                    pageIndex = currentPageIndex
                )
                currentPageQuestions.add(positionedBox)
                currentY += reqHeight
                currentAvailable -= reqHeight
            } else {
                // Check if moving to next page works
                val nextAvailable = pageSubsequentAvailable
                if (reqHeight <= nextAvailable) {
                    pages.add(
                        AnswerSheetPageLayout(
                            pageIndex = currentPageIndex,
                            totalPages = 0,
                            questions = currentPageQuestions
                        )
                    )
                    currentPageIndex++
                    currentPageQuestions = mutableListOf()
                    currentY = marginVerticalPt + effectiveSubsequentHeaderHeightPt
                    currentAvailable = nextAvailable

                    val positionedBox = box.copy(
                        topYPt = currentY,
                        pageIndex = currentPageIndex
                    )
                    currentPageQuestions.add(positionedBox)
                    currentY += reqHeight
                    currentAvailable -= reqHeight
                } else {
                    // Box is larger than an entire empty page! Safely split box across pages
                    var remainingLines = box.lineCount
                    var partIndex = 1

                    while (remainingLines > 0) {
                        val availLineSpace = maxOf(0f, currentAvailable - box.headerHeightPt - interBoxSpacing)
                        var partLines = (availLineSpace / box.lineHeightPt).toInt().coerceAtLeast(3)

                        if (partLines >= remainingLines) {
                            partLines = remainingLines
                        }

                        val partHeight = box.headerHeightPt + (partLines * box.lineHeightPt)
                        val isCont = partIndex > 1
                        val displayTitle = if (isCont) {
                            "Cevap ${box.questionNumber} — Devam"
                        } else {
                            "Cevap ${box.questionNumber} (${box.points} Puan)"
                        }

                        val partBox = box.copy(
                            displayTitle = displayTitle,
                            lineCount = partLines,
                            heightPt = partHeight,
                            isContinuation = isCont,
                            topYPt = currentY,
                            pageIndex = currentPageIndex
                        )
                        currentPageQuestions.add(partBox)

                        remainingLines -= partLines
                        partIndex++

                        if (remainingLines > 0) {
                            pages.add(
                                AnswerSheetPageLayout(
                                    pageIndex = currentPageIndex,
                                    totalPages = 0,
                                    questions = currentPageQuestions
                                )
                            )
                            currentPageIndex++
                            currentPageQuestions = mutableListOf()
                            currentY = marginVerticalPt + effectiveSubsequentHeaderHeightPt
                            currentAvailable = pageSubsequentAvailable
                        } else {
                            currentY += partHeight + interBoxSpacing
                            currentAvailable -= (partHeight + interBoxSpacing)
                        }
                    }
                }
            }
        }

        if (currentPageQuestions.isNotEmpty()) {
            pages.add(
                AnswerSheetPageLayout(
                    pageIndex = currentPageIndex,
                    totalPages = 0,
                    questions = currentPageQuestions
                )
            )
        }

        val totalPages = max(1, pages.size)
        return pages.map { page ->
            page.copy(totalPages = totalPages)
        }
    }

    /**
     * Canonical lookup for crop coordinates matching PDF layout 1:1.
     */
    fun getQuestionCropBounds(
        pageLayouts: List<AnswerSheetPageLayout>,
        orderIndex: Int
    ): QuestionCropBounds? {
        val segments = mutableListOf<QuestionCropSegment>()
        var totalPages = 1
        for (page in pageLayouts) {
            totalPages = page.totalPages
            for (qBox in page.questions) {
                if (qBox.orderIndex == orderIndex) {
                    segments.add(
                        QuestionCropSegment(
                            pageIndex = page.pageIndex,
                            topYPt = qBox.topYPt,
                            bottomYPt = qBox.topYPt + qBox.heightPt,
                            heightPt = qBox.heightPt,
                            isContinuation = qBox.isContinuation,
                            displayTitle = qBox.displayTitle
                        )
                    )
                }
            }
        }
        if (segments.isEmpty()) return null
        return QuestionCropBounds(segments = segments, totalPages = totalPages)
    }

    fun getSummaryText(pageLayouts: List<AnswerSheetPageLayout>, questionCount: Int): String {
        val pageCount = pageLayouts.size
        val sheetStr = if (pageCount <= 2) "1 yaprak ön/arka" else "${(pageCount + 1) / 2} yaprak"
        return "Akıllı yerleşim hazır • $questionCount soru • $pageCount sayfa • $sheetStr"
    }
}
