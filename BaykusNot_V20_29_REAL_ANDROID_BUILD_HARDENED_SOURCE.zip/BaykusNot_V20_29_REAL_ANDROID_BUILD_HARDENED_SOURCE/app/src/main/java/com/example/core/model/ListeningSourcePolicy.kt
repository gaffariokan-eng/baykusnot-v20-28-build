package com.example.core.model

/**
 * Single product rule for Listening Exam source readiness.
 * A teacher may provide either a usable audio file OR a non-blank listening text.
 * The two sources are alternatives; neither one is mandatory when the other is valid.
 */
object ListeningSourcePolicy {
    fun isReady(hasUsableAudio: Boolean, listeningText: String): Boolean =
        hasUsableAudio || listeningText.isNotBlank()
}
