package com.example.feature.workflow

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.ExamAnswerSheetRepository

@Composable
fun AnswerSheetRoute(
    draftId: Long,
    repository: ExamAnswerSheetRepository,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: AnswerSheetViewModel = viewModel(
        key = "answer_sheet_$draftId",
        factory = AnswerSheetViewModel.Factory(
            repository = repository,
            examDraftId = draftId
        )
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val savePdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) viewModel.savePdfToUri(context, uri)
    }


    AnswerSheetScreen(
        uiState = uiState,
        onStudentCountChange = viewModel::updateStudentCount,
        onLayoutDensityChange = viewModel::updateLayoutDensity,
        onLineOverrideChange = viewModel::updateLineOverride,
        onResetLineOverrides = viewModel::resetLineOverrides,
        onSelectPreviewPage = viewModel::selectPreviewPage,
        onGeneratePdf = { context -> viewModel.generateBatchPdf(context) },
        onSavePdf = {
            val file = uiState.generatedPdfFile
            if (file != null && file.exists()) savePdfLauncher.launch(file.name)
        },
        onClearSaveMessage = viewModel::clearSaveSuccessMessage,
        onContinue = { if (!uiState.isSavingSettings && uiState.isPdfUpToDate) onContinue() },
        modifier = modifier
    )
}

