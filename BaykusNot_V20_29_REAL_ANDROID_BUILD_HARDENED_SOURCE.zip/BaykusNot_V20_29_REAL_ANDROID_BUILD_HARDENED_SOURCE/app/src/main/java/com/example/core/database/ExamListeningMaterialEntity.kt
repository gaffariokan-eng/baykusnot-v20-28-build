package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Listening-exam specific source data.
 *
 * The audio file is copied into app-private storage; [originalUri] is retained only as
 * provenance. Transcript/settings are intentionally stored independently from the media so
 * teachers can prepare or correct the transcript before/after choosing a file.
 */
@Entity(
    tableName = "exam_listening_material",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamListeningMaterialEntity(
    @PrimaryKey
    val examDraftId: Long,
    val localRelativePath: String? = null,
    val originalUri: String? = null,
    val displayName: String? = null,
    val mimeType: String? = null,
    val sizeBytes: Long? = null,
    val sha256: String? = null,
    val transcript: String = "",
    val playbackCount: Int = 2,
    val instructions: String = "",
    // Legacy schema field kept for database compatibility. A separate transcript approval
    // gate is no longer part of the Listening Exam product flow.
    val isTranscriptApproved: Boolean = false,
    val importedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

fun ExamListeningMaterialEntity.hasAudio(): Boolean =
    !localRelativePath.isNullOrBlank() &&
        !displayName.isNullOrBlank() &&
        !mimeType.isNullOrBlank() &&
        (sizeBytes ?: 0L) > 0L &&
        sha256?.length == 64
