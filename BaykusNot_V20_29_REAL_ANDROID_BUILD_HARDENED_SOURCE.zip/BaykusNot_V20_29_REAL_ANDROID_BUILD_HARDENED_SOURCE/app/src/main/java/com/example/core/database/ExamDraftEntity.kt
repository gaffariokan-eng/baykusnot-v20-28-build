package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.core.model.ExamType
import com.example.core.model.WorkflowStage
import com.example.core.model.WorkflowState

@Entity(tableName = "exam_draft")
data class ExamDraftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examType: ExamType,
    val academicYear: String,
    val institutionName: String,
    val courseName: String,
    val teachers: List<String>,
    val gradeLevel: String,
    val term: String,
    val examSequenceNumber: String,
    val examDate: Long,
    val totalPoints: Int,
    val draftName: String,
    val currentWorkflowStage: WorkflowStage = WorkflowStage.EXAM_INFO,
    val draftState: WorkflowState = WorkflowState.NOT_STARTED,
    val hasScenario: Boolean = false,
    val isScenarioApproved: Boolean = false,
    val isObjectiveMappingApproved: Boolean = false,
    val isMismatchAccepted: Boolean = false,
    val stagingCourseName: String? = null,
    val stagingGradeLevel: String? = null,
    val stagingTerm: String? = null,
    val stagingExamSequenceNumber: String? = null,
    val approvedCourseName: String? = null,
    val approvedGradeLevel: String? = null,
    val approvedTerm: String? = null,
    val approvedExamSequenceNumber: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
