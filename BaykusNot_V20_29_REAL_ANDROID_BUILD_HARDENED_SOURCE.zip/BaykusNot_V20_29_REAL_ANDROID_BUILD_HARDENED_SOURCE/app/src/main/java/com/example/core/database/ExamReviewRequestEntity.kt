package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Local audit record for a student/parent request to have an AI-assisted assessment reviewed.
 * The official YAZEK ethical-violation process remains external to BaykuşNot; this table covers
 * the assessment-level objection/re-review mechanism required by the ethics guide.
 */
@Entity(
    tableName = "exam_review_request",
    foreignKeys = [
        ForeignKey(
            entity = ExamStudentPaperEntity::class,
            parentColumns = ["id"],
            childColumns = ["studentPaperId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["examDraftId"]), Index(value = ["studentPaperId"])]
)
data class ExamReviewRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examDraftId: Long,
    val studentPaperId: Long,
    val requestedBy: String = "STUDENT_OR_PARENT",
    val reason: String,
    val status: String = "OPEN", // OPEN | RESOLVED
    val scoreBefore: Double?,
    val scoreAfter: Double? = null,
    val requestedAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val resolutionNote: String? = null
)
