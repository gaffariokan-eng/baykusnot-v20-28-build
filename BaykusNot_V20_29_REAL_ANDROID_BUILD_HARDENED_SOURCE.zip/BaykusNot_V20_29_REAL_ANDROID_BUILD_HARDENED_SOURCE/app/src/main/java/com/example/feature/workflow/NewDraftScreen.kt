package com.example.feature.workflow

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.ExamType
import com.example.core.ui.BaykusPrimaryButton
import com.example.core.ui.BaykusTopAppBar
import kotlinx.coroutines.launch

internal object ExamInfoTestTags {
    const val CONTENT = "exam_info_content"
    const val DRAFT_NAME = "exam_info_draft_name"
    const val ACADEMIC_YEAR = "exam_info_academic_year"
    const val INSTITUTION_NAME = "exam_info_institution_name"
    const val COURSE_NAME = "exam_info_course_name"
    const val GRADE_LEVEL = "exam_info_grade_level"
    const val TERM = "exam_info_term"
    const val EXAM_SEQUENCE = "exam_info_exam_sequence"
    const val TOTAL_POINTS = "exam_info_total_points"
    const val SAVE_BUTTON = "exam_info_save_button"
    const val DELETE_BUTTON = "exam_info_delete_button"

    fun teacher(teacherName: String): String = "exam_info_teacher_$teacherName"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewDraftScreen(
    viewModel: NewDraftViewModel,
    isEditMode: Boolean,
    onNavigateBack: () -> Unit,
    onNavigateToWorkflow: (Long) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var pendingDeletionNotice by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            val examTypeName = stringResource(uiState.examType.displayNameRes)
            BaykusTopAppBar(
                title = if (isEditMode) "$examTypeName Taslağını Düzenle" else "Yeni $examTypeName",
                subtitle = when (uiState.examType) {
                    ExamType.HOMEWORK -> "Ödev Temel Bilgileri"
                    ExamType.READINESS -> "Hazırbulunuşluk Temel Bilgileri"
                    ExamType.MULTIPLE_CHOICE -> "Test Sınavı Temel Bilgileri"
                    else -> "Sınav Temel Bilgileri"
                },
                onNavigateBack = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        if (!uiState.isLoaded) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (uiState.loadError != null) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(uiState.loadError, style = MaterialTheme.typography.bodyLarge)
                    OutlinedButton(onClick = onNavigateBack) { Text("Geri Dön") }
                }
            }
            return@Scaffold
        }

        ExamInfoContent(
            uiState = uiState,
            isEditMode = isEditMode,
            onFieldChange = viewModel::updateField,
            onToggleTeacher = viewModel::toggleTeacher,
            onSave = {
                viewModel.saveDraft(
                    onSuccess = { id -> onNavigateToWorkflow(id) },
                    onError = { msg ->
                        scope.launch { snackbarHostState.showSnackbar(msg) }
                    }
                )
            },
            onDeleteRequest = { showDeleteConfirm = true },
            modifier = Modifier.padding(padding)
        )

        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Taslağı Sil", style = MaterialTheme.typography.titleMedium) },
                text = {
                    Text(
                        when (uiState.examType) {
                            ExamType.HOMEWORK -> "Bu ödev kontrolü taslağını ve bağlı uygulama verilerini silmek istediğinize emin misiniz? Daha önce dışa aktarıp cihazda seçtiğiniz konuma kaydettiğiniz PDF kopyaları otomatik silinmez. Bu işlem geri alınamaz."
                            ExamType.READINESS -> "Bu hazırbulunuşluk sınavı taslağını ve bağlı uygulama verilerini silmek istediğinize emin misiniz? Daha önce dışa aktarıp cihazda seçtiğiniz konuma kaydettiğiniz PDF kopyaları otomatik silinmez. Bu işlem geri alınamaz."
                            else -> "Bu sınav taslağını ve bağlı uygulama verilerini silmek istediğinize emin misiniz? Daha önce dışa aktarıp cihazda seçtiğiniz konuma kaydettiğiniz PDF kopyaları otomatik silinmez. Bu işlem geri alınamaz."
                        }
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirm = false
                            viewModel.deleteDraft(
                                onDeleted = { notice ->
                                    if (notice == null) onNavigateBack()
                                    else pendingDeletionNotice = notice
                                },
                                onError = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                            )
                        }
                    ) { Text("Sil", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) { Text("Vazgeç") }
                }
            )
        }

        if (pendingDeletionNotice != null) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Silme işlemi izleniyor") },
                text = { Text(pendingDeletionNotice.orEmpty()) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            pendingDeletionNotice = null
                            onNavigateBack()
                        }
                    ) { Text("Tamam") }
                }
            )
        }
    }
}

@Composable
internal fun ExamInfoContent(
    uiState: NewDraftUiState,
    isEditMode: Boolean,
    onFieldChange: (DraftField, String) -> Unit,
    onToggleTeacher: (String) -> Unit,
    onSave: () -> Unit,
    onDeleteRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHomework = uiState.examType == ExamType.HOMEWORK
    val isReadiness = uiState.examType == ExamType.READINESS
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag(ExamInfoTestTags.CONTENT)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = when {
                        isHomework -> "Ödev Kimlik Bilgileri"
                        isReadiness -> "Hazırbulunuşluk Kimlik Bilgileri"
                        else -> "Sınav Kimlik Bilgileri"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = uiState.draftName,
                    onValueChange = { onFieldChange(DraftField.DRAFT_NAME, it) },
                    label = {
                        Text(
                            when {
                                isHomework -> "Taslak / Ödev Adı"
                                isReadiness -> "Taslak / Hazırbulunuşluk Adı"
                                else -> "Taslak / Sınav Adı"
                            }
                        )
                    },
                    placeholder = {
                        Text(
                            when (uiState.examType) {
                                ExamType.LISTENING -> "Örn: 7. Sınıf Türkçe Dinleme Sınavı"
                                ExamType.HOMEWORK -> "Örn: 6. Sınıf Türkçe 2. Ödev Kontrolü"
                                ExamType.READINESS -> "Örn: 7. Sınıf Matematik Kesirler Hazırbulunuşluk"
                                ExamType.MULTIPLE_CHOICE -> "Örn: 8. Sınıf Türkçe 1. Test Sınavı"
                                else -> "Örn: 9. Sınıf Matematik 1. Yazılı"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(ExamInfoTestTags.DRAFT_NAME),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                val context = androidx.compose.ui.platform.LocalContext.current
                val dateFormatter = remember { java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()) }
                val formattedDate = dateFormatter.format(java.util.Date(uiState.examDate))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val calendar = java.util.Calendar.getInstance().apply { timeInMillis = uiState.examDate }
                            android.app.DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val selectedCal = java.util.Calendar.getInstance().apply {
                                        set(java.util.Calendar.YEAR, year)
                                        set(java.util.Calendar.MONTH, month)
                                        set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                                    }
                                    onFieldChange(DraftField.EXAM_DATE, selectedCal.timeInMillis.toString())
                                },
                                calendar.get(java.util.Calendar.YEAR),
                                calendar.get(java.util.Calendar.MONTH),
                                calendar.get(java.util.Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                ) {
                    OutlinedTextField(
                        value = formattedDate,
                        onValueChange = { },
                        readOnly = true,
                        label = { Text(if (isHomework) "Kontrol / Teslim Tarihi" else "Sınav Tarihi") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("exam_info_exam_date"),
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Tarih Seç")
                        },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledBorderColor = MaterialTheme.colorScheme.outline,
                            disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                OutlinedTextField(
                    value = uiState.academicYear,
                    onValueChange = { onFieldChange(DraftField.ACADEMIC_YEAR, it) },
                    label = { Text("Eğitim Öğretim Yılı") },
                    placeholder = { Text("Örn: 2025-2026") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(ExamInfoTestTags.ACADEMIC_YEAR),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = uiState.institutionName,
                    onValueChange = { onFieldChange(DraftField.INSTITUTION_NAME, it) },
                    label = { Text("Kurum / Okul Adı") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(ExamInfoTestTags.INSTITUTION_NAME),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Ders ve Sınıf Detayları",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = uiState.courseName,
                        onValueChange = { onFieldChange(DraftField.COURSE_NAME, it) },
                        label = { Text("Ders Adı") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag(ExamInfoTestTags.COURSE_NAME),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = uiState.gradeLevel,
                        onValueChange = { onFieldChange(DraftField.GRADE_LEVEL, it) },
                        label = { Text("Sınıf (Örn: 9)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag(ExamInfoTestTags.GRADE_LEVEL),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = uiState.term,
                        onValueChange = { onFieldChange(DraftField.TERM, it) },
                        label = { Text("Dönem (Örn: 1)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag(ExamInfoTestTags.TERM),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = uiState.examSequenceNumber,
                        onValueChange = { onFieldChange(DraftField.EXAM_SEQUENCE, it) },
                        label = { Text(if (isHomework) "Ödev No (Örn: 1)" else "Sınav No (Örn: 1)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag(ExamInfoTestTags.EXAM_SEQUENCE),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                OutlinedTextField(
                    value = uiState.totalPoints,
                    onValueChange = { onFieldChange(DraftField.TOTAL_POINTS, it) },
                    label = { Text(if (isHomework) "Toplam Ödev Puanı" else "Toplam Sınav Puanı") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(ExamInfoTestTags.TOTAL_POINTS),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = if (isHomework) "Ödevi Değerlendiren Öğretmenler" else "Sınavı Yapan Öğretmenler",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                if (uiState.availableTeachers.isEmpty()) {
                    Text(
                        text = "Profilinizde henüz kayıtlı öğretmen yok.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    uiState.availableTeachers.forEach { teacher ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 44.dp)
                        ) {
                            Checkbox(
                                checked = uiState.selectedTeachers.contains(teacher),
                                onCheckedChange = { onToggleTeacher(teacher) },
                                modifier = Modifier.testTag(ExamInfoTestTags.teacher(teacher))
                            )
                            Text(
                                text = teacher,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        BaykusPrimaryButton(
            text = if (uiState.isSaving) "Kaydediliyor…" else if (isEditMode) "Değişiklikleri Kaydet" else "İş Akışına Başla",
            onClick = { if (!uiState.isSaving && !uiState.isDeleting) onSave() },
            modifier = Modifier.testTag(ExamInfoTestTags.SAVE_BUTTON)
        )

        if (isEditMode) {
            OutlinedButton(
                onClick = onDeleteRequest,
                enabled = !uiState.isSaving && !uiState.isDeleting,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag(ExamInfoTestTags.DELETE_BUTTON),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Bu Taslağı Sil", fontWeight = FontWeight.Bold)
            }
        }
    }
}
