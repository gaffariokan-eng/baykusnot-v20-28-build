package com.example.feature.workflow

import com.example.core.security.StudentImageCrypto
import com.example.core.network.ExamImagePrivacyProcessor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.data.ListeningAnswerSheetGuidance
import com.example.core.database.ExamQuestionEvaluationEntity
import com.example.core.database.ExamStudentEvaluationEntity
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.network.GeminiModelRegistry
import java.io.File

@Composable
fun AiEvaluationScreen(
    viewModel: AiEvaluationViewModel,
    examType: ExamType = ExamType.WRITTEN,
    onAdvanceToTeacherReview: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val copy = submissionCopy(examType)
    val clipboardManager = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current

    val totalStudents = state.studentPapers.size
    val completedCount = state.studentEvaluations.values.count { it.status == "COMPLETED" }
    val needsReviewCount = state.studentEvaluations.values.count { it.status == "NEEDS_REVIEW" }
    val errorCount = state.studentEvaluations.values.count { it.status == "ERROR" }
    val evaluatingCount = state.studentEvaluations.values.count { it.status == "EVALUATING" }

    val isAllDone = totalStudents > 0 && (completedCount + needsReviewCount == totalStudents)

    if (state.showYazekGate) {
        var yazekReferenceNote by remember(state.yazekScopeSummary) { mutableStateOf("") }
        var officialYazekApplied by remember(state.yazekScopeSummary) { mutableStateOf(false) }
        var noticeAndConsentCompleted by remember(state.yazekScopeSummary) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = viewModel::dismissYazekGate,
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            title = { Text("YAZEK / Veri Güvenliği") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Gerçek öğrenci verisi AI hizmetine gönderilmeden önce aşağıdaki iki koşul ayrı ayrı doğrulanmalıdır. " +
                            "Önceki beyan yalnız kapsam, eğitsel amaç, AI aracı ve hedef kitle değişmediyse yeniden kullanılabilir. " +
                            "Yapay zekâ çıktıları hata/halüsinasyon içerebilir; her puan ve dönüt öğretmen denetiminden geçmelidir."
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { officialYazekApplied = !officialYazekApplied }
                    ) {
                        Checkbox(
                            checked = officialYazekApplied,
                            onCheckedChange = { officialYazekApplied = it }
                        )
                        Text(
                            "Bu kapsam için gereken tüm resmî YAZEK Etik Beyan Formlarını tamamladım ve YAZEK'te uygulamaya aldım (Uygulamaya Al/Uygula adımı tamamlandı).",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { noticeAndConsentCompleted = !noticeAndConsentCompleted }
                    ) {
                        Checkbox(
                            checked = noticeAndConsentCompleted,
                            onCheckedChange = { noticeAndConsentCompleted = it }
                        )
                        Text(
                            "Öğrenci/veli veri bilgilendirmesini ve cevap kâğıdı görüntüsü, fotoğraf, ses, video veya benzeri kişisel veri işleniyorsa gerekli açık rıza/aydınlatılmış onam sürecini tamamladım.",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        state.yazekScopeSummary,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedButton(
                        onClick = { clipboardManager.setText(AnnotatedString(state.yazekScopeSummary)) },
                        enabled = state.yazekScopeSummary.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("YAZEK Beyan Bilgilerini Kopyala") }
                    OutlinedButton(
                        onClick = { uriHandler.openUri("https://yazek.meb.gov.tr/") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Resmî YAZEK'i Aç") }
                    Text(
                        "Resmî formdaki 8 etik ilkeyi ayrıca değerlendirin: insan merkezlilik, eşitlik/kapsayıcılık, şeffaflık, mahremiyet, güvenilirlik, insan denetimi, eğitsel değer ve millî/manevi değerlere uyum. " +
                            "BaykuşNot bu etik beyan kutularını sizin adınıza otomatik olarak onaylamaz.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = { clipboardManager.setText(AnnotatedString(state.yazekStudentParentNotice)) },
                        enabled = state.yazekStudentParentNotice.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Öğrenci/Veli Veri Bilgilendirmesini Kopyala") }
                    Text(
                        "Bu kayıt resmî YAZEK beyanının yerine geçmez; yalnız BaykuşNot'un öğrenci verisini kapsam dışı bir beyanla göndermesini engeller. " +
                            "YAZEK'te uygulamaya alınmış form ilk 3 gün düzenlenebilir; bu süre geçtikten sonra kapsam, eğitsel amaç, YZ aracı veya hedef kitle değiştiyse yeni beyan oluşturun.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = yazekReferenceNote,
                        onValueChange = { yazekReferenceNote = it },
                        label = { Text("YAZEK beyan referansı/notu (önerilir)") },
                        supportingText = { Text("Varsa resmî beyan numarasını kaydedin; birden fazla şube/form varsa numaraları virgülle ayırabilirsiniz.") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.confirmYazekAndStart(
                            referenceNote = yazekReferenceNote.trim().ifBlank { null },
                            officialDeclarationApplied = officialYazekApplied,
                            noticeAndConsentCompleted = noticeAndConsentCompleted
                        )
                    },
                    enabled = officialYazekApplied && noticeAndConsentCompleted
                ) {
                    Text("YAZEK ve Veri Sürecini Doğruladım")
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissYazekGate) { Text("Vazgeç") }
            }
        )
    }



    if (state.showLegacyPrivacyGate) {
        var legacyPageIndex by remember(state.legacyPrivacyPages) { mutableIntStateOf(0) }
        Dialog(onDismissRequest = viewModel::dismissLegacyPrivacyGate) {
            Surface(shape = RoundedCornerShape(20.dp), tonalElevation = 6.dp) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Eski Cevap Kâğıdı — Gizlilik Önizlemesi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "Eski formda dört hizalama işareti yok. Her sayfada AI'a gönderilecek kırpımı kontrol edin. Kişisel bilgi görünüyorsa devam etmeyin; yeni V3 cevap formuyla yeniden çekin.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    val pages = state.legacyPrivacyPages
                    if (pages.isEmpty()) {
                        Text("Önizlenecek eski sayfa bulunamadı.", color = MaterialTheme.colorScheme.error)
                    } else {
                        val safeLegacyIndex = legacyPageIndex.coerceIn(0, pages.lastIndex)
                        val page = pages[safeLegacyIndex]
                        val preview = remember(page.id, page.imagePath) {
                            ExamImagePrivacyProcessor.prepareLegacyPrivacyPreview(page.imagePath, page.pageIndex)
                        }
                        Text("Sayfa ${safeLegacyIndex + 1}/${pages.size}", fontWeight = FontWeight.SemiBold)
                        LaunchedEffect(page.id, preview != null) {
                            viewModel.markLegacyPrivacyPageViewed(page.id, preview != null)
                        }
                        if (preview != null) {
                            Image(
                                bitmap = preview.asImageBitmap(),
                                contentDescription = "AI gizlilik önizlemesi",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 440.dp).border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Text("Önizleme oluşturulamadı. Bu sayfayla AI değerlendirmesine devam etmeyin.", color = MaterialTheme.colorScheme.error)
                        }
                        Text(
                            "Görüntülenen: ${state.legacyPrivacyViewedPageIds.size}/${pages.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(onClick = { legacyPageIndex = (safeLegacyIndex - 1).coerceAtLeast(0) }, enabled = safeLegacyIndex > 0) { Text("Önceki") }
                            TextButton(onClick = { legacyPageIndex = (safeLegacyIndex + 1).coerceAtMost(pages.lastIndex) }, enabled = safeLegacyIndex < pages.lastIndex) { Text("Sonraki") }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = viewModel::dismissLegacyPrivacyGate) { Text("Vazgeç") }
                        Spacer(Modifier.width(8.dp))
                        val allLegacyPagesViewed = state.legacyPrivacyPages.isNotEmpty() &&
                            state.legacyPrivacyPages.all { it.id in state.legacyPrivacyViewedPageIds }
                        Button(onClick = viewModel::confirmLegacyPrivacyAndContinue, enabled = allLegacyPagesViewed) {
                            Text("Tüm Sayfaları Kontrol Ettim — Devam")
                        }
                    }
                }
            }
        }
    }

    if (state.showHomeworkPrivacyGate) {
        var homeworkPageIndex by remember(state.homeworkPrivacyPages) { mutableIntStateOf(0) }
        Dialog(onDismissRequest = viewModel::dismissHomeworkPrivacyGate) {
            Surface(shape = RoundedCornerShape(20.dp), tonalElevation = 6.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Ödev Gizlilik Kontrolü", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "Sayfaları kontrol edin. Gövdede ad-soyad, okul no veya başka kişisel bilgi varsa doğrudan bilginin üzerine dokunun; BaykuşNot AI kopyasında o alanı yerel olarak gizler. Birden fazla alan için tekrar dokunabilirsiniz.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    val pages = state.homeworkPrivacyPages
                    if (pages.isEmpty()) {
                        Text("Ödev sayfası bulunamadı.", color = MaterialTheme.colorScheme.error)
                    } else {
                        val safeHomeworkPageIndex = homeworkPageIndex.coerceIn(0, pages.lastIndex)
                        val page = pages[safeHomeworkPageIndex]
                        val bitmap = remember(page.id, page.imagePath) { StudentImageCrypto.decodeBitmap(page.imagePath) }
                        Text("Sayfa ${safeHomeworkPageIndex + 1}/${pages.size}", fontWeight = FontWeight.SemiBold)
                        LaunchedEffect(page.id, bitmap != null) {
                            viewModel.markHomeworkPrivacyPageViewed(page.id, bitmap != null)
                        }
                        if (bitmap != null) {
                            val aspect = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(aspect)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    .pointerInput(page.id) {
                                        detectTapGestures { offset ->
                                            val nx = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                            val ny = (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                                            viewModel.addHomeworkPrivacyMask(page.id, nx, ny)
                                        }
                                    }
                            ) {
                                Image(bitmap.asImageBitmap(), "Ödev gizlilik önizlemesi", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                                Canvas(Modifier.fillMaxSize()) {
                                    state.homeworkPrivacyMasks[page.id].orEmpty().forEach { mask ->
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(mask.left * size.width, mask.top * size.height),
                                            size = Size((mask.right - mask.left) * size.width, (mask.bottom - mask.top) * size.height)
                                        )
                                    }
                                }
                            }
                        } else {
                            Text("Bu sayfanın önizlemesi açılamadı. AI değerlendirmesine devam etmeyin.", color = MaterialTheme.colorScheme.error)
                        }
                        Text(
                            "Görüntülenen: ${state.homeworkPrivacyViewedPageIds.size}/${pages.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(onClick = { homeworkPageIndex = (safeHomeworkPageIndex - 1).coerceAtLeast(0) }, enabled = safeHomeworkPageIndex > 0) { Text("Önceki") }
                            Row {
                                TextButton(onClick = { viewModel.undoHomeworkPrivacyMask(page.id) }, enabled = state.homeworkPrivacyMasks[page.id].orEmpty().isNotEmpty()) { Text("Son Maskeyi Geri Al") }
                                TextButton(onClick = { viewModel.clearHomeworkPrivacyMasks(page.id) }, enabled = state.homeworkPrivacyMasks[page.id].orEmpty().isNotEmpty()) { Text("Temizle") }
                            }
                            TextButton(onClick = { homeworkPageIndex = (safeHomeworkPageIndex + 1).coerceAtMost(pages.lastIndex) }, enabled = safeHomeworkPageIndex < pages.lastIndex) { Text("Sonraki") }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = viewModel::dismissHomeworkPrivacyGate) { Text("Vazgeç") }
                        Spacer(Modifier.width(8.dp))
                        val allHomeworkPagesViewed = state.homeworkPrivacyPages.isNotEmpty() &&
                            state.homeworkPrivacyPages.all { it.id in state.homeworkPrivacyViewedPageIds }
                        Button(onClick = viewModel::confirmHomeworkPrivacyAndStart, enabled = allHomeworkPagesViewed) { Text("Kontrol Tamam — Başlat") }
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Title & Engine Badge
            Text(
                text = "Yapay Zekâ Değerlendirmesi",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = copy.evaluationIntro,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            
            Text(
                text = "Motor: ${state.activeEvaluationModel ?: GeminiModelRegistry.evaluationModel} • anonim tam-kâğıt okuma + gerektiğinde hedefli ikinci kontrol",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Status Progress Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Değerlendirme Durumu",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$totalStudents öğrenciden ${completedCount + needsReviewCount} tamamlandı",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (state.isEvaluating) {
                                OutlinedButton(
                                    onClick = { viewModel.pauseEvaluationProcess() },
                                    modifier = Modifier.testTag("pause_evaluation_button")
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = "Durdur")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Durdur")
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.startEvaluationProcess() },
                                    enabled = totalStudents > 0 && !isAllDone,
                                    modifier = Modifier.testTag("start_evaluation_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Başlat")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (completedCount + needsReviewCount > 0) "Devam Et" else "Başlat")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { if (totalStudents > 0) (completedCount + needsReviewCount).toFloat() / totalStudents else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.outlineVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                    androidx.compose.foundation.layout.FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Toplam: $totalStudents", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text("Tamamlandı: $completedCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                        Text("İnceleme: $needsReviewCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                        if (errorCount > 0) {
                            Text("Hata: $errorCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        } else {
                            Text("Hata: 0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (state.errorMessage != null) {
                if (state.errorMessage!!.contains("PROMPT_CACHE_FAILED")) {
                    val rawMsg = state.errorMessage ?: ""
                    val displayMsg = rawMsg.replace("PROMPT_CACHE_FAILED:", "").trim()
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissError() },
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Prompt Cache Hatası")
                            }
                        },
                        text = {
                            Text(displayMsg)
                        },
                        confirmButton = {
                            Button(
                                onClick = { viewModel.allowBypassCacheAndRetry() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier.testTag("bypass_cache_button")
                            ) {
                                Text("Önbellek Olmadan Devam Et")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = { viewModel.dismissError() },
                                modifier = Modifier.testTag("dismiss_cache_error_button")
                            ) {
                                Text("Vazgeç")
                            }
                        }
                    )
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = state.errorMessage ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = { viewModel.dismissError() },
                                modifier = Modifier.testTag("dismiss_error_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Kapat",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // Live Table Header Info
            Text(
                text = copy.matrixTitle,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Matrix Table
            val horizontalScrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(horizontalScrollState)
                ) {
                    // Table Header Row
                    Row(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableCell("Sıra", width = 50.dp, isHeader = true)
                        TableCell("Öğrenci / Kimlik", width = 140.dp, isHeader = true)
                        TableCell("Durum", width = 110.dp, isHeader = true)

                        state.questions.sortedBy { it.orderIndex }.forEach { q ->
                            TableCell("${copy.itemShortLabel}${q.orderIndex}\n(${q.points}p)", width = 70.dp, isHeader = true)
                        }

                        TableCell("Toplam", width = 80.dp, isHeader = true)
                    }

                    // Table Body Rows
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(state.studentPapers.sortedBy { it.studentSequenceIndex }) { paper ->
                            val sEval = state.studentEvaluations[paper.id]
                            val qEvals = state.questionEvaluations[paper.id] ?: emptyList()

                            StudentEvaluationRow(
                                paper = paper,
                                sEval = sEval,
                                qEvals = qEvals,
                                questions = state.questions,
                                isCurrentlyEvaluating = state.currentEvaluatingPaperId == paper.id,
                                onCellClick = { qOrder -> viewModel.selectCell(paper.id, qOrder) },
                                onRetryClick = { viewModel.retryStudentPaper(paper.id) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer Action
            if (isAllDone) {
                Button(
                    onClick = onAdvanceToTeacherReview,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("advance_to_review_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = "Öğretmen İncelemesine Geç",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                }
            } else {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedButton(
                        onClick = { },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = false
                    ) {
                        Text("Öğretmen İncelemesine Geç")
                    }
                    Text(
                        text = "Tüm öğrenci değerlendirmeleri tamamlandığında açılır.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(
                        onClick = viewModel::switchToManualTeacherReview,
                        enabled = totalStudents > 0
                    ) {
                        Text("AI Olmadan Manuel Değerlendirmeye Geç")
                    }
                    if (state.processingEvaluationSource == "MANUAL") {
                        OutlinedButton(
                            onClick = viewModel::reenableAiEvaluation,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("AI Değerlendirmesini Açıkça Yeniden Etkinleştir") }
                    }
                    Text(
                        text = "İnternet/AI hizmeti kullanılamıyorsa öğrenci kâğıtlarını BaykuşNot içinde öğretmen manuel puanlayabilir. Manuel moda geçildiğinde AI değerlendirme, ikinci okuma ve otomatik AI dönütü kapalı kalır.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Detail Dialog
        if (state.selectedDetailItem != null) {
            QuestionEvaluationDetailDialog(
                item = state.selectedDetailItem!!,
                questions = state.questions,
                rubrics = state.rubrics,
                layoutDensity = state.layoutDensity,
                lineOverrides = state.lineOverrides,
                listeningGuidance = state.listeningGuidance,
                examType = examType,
                onDismiss = { viewModel.dismissDetail() }
            )
        }
    }
}

@Composable
fun StudentEvaluationRow(
    paper: ExamStudentPaperEntity,
    sEval: ExamStudentEvaluationEntity?,
    qEvals: List<ExamQuestionEvaluationEntity>,
    questions: List<ExamQuestion>,
    isCurrentlyEvaluating: Boolean,
    onCellClick: (Int) -> Unit,
    onRetryClick: () -> Unit
) {
    val qEvalMap = remember(qEvals) { qEvals.associateBy { it.questionOrderIndex } }
    val status = sEval?.status ?: if (isCurrentlyEvaluating) "EVALUATING" else "WAITING"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            .background(
                if (isCurrentlyEvaluating) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surface
            )
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Sequence
        TableCell("#${paper.studentSequenceIndex}", width = 50.dp)

        // Identity
        val identityStr = buildString {
            append(paper.studentName ?: "Öğrenci ${paper.studentSequenceIndex}")
            if (!paper.schoolNumber.isNullOrBlank()) {
                append("\nNo: ${paper.schoolNumber}")
            }
        }
        TableCell(identityStr, width = 140.dp, isBold = true)

        // Status Chip
        Box(
            modifier = Modifier
                .width(110.dp)
                .padding(horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            when (status) {
                "EVALUATING" -> StatusChip("İşleniyor", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer, showSpinner = true)
                "COMPLETED" -> StatusChip("Tamamlandı", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer, icon = Icons.Default.CheckCircle)
                "NEEDS_REVIEW" -> StatusChip("İnceleme", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer, icon = Icons.Default.Warning)
                "ERROR" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusChip("Hata", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer, icon = Icons.Default.Error)
                        IconButton(onClick = onRetryClick, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Tekrar Dene", modifier = Modifier.size(16.dp))
                        }
                    }
                }
                else -> StatusChip("Bekliyor", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Question Score Cells
        questions.sortedBy { it.orderIndex }.forEach { q ->
            val qEval = qEvalMap[q.orderIndex]
            val cellText: String
            val bgColor: Color
            val textColor: Color

            if (qEval != null) {
                cellText = "${qEval.score.toInt()}/${q.points}"
                if (qEval.needsReview || qEval.answerType == "UNREADABLE") {
                    bgColor = MaterialTheme.colorScheme.secondaryContainer
                    textColor = MaterialTheme.colorScheme.onSecondaryContainer
                } else if (qEval.answerType == "UNANSWERED") {
                    bgColor = MaterialTheme.colorScheme.surfaceVariant
                    textColor = MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    bgColor = MaterialTheme.colorScheme.tertiaryContainer
                    textColor = MaterialTheme.colorScheme.onTertiaryContainer
                }
            } else if (isCurrentlyEvaluating) {
                cellText = "..."
                bgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                textColor = MaterialTheme.colorScheme.primary
            } else {
                cellText = "—"
                bgColor = Color.Transparent
                textColor = MaterialTheme.colorScheme.onSurfaceVariant
            }

            Box(
                modifier = Modifier
                    .width(70.dp)
                    .padding(horizontal = 2.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(bgColor)
                    .clickable { onCellClick(q.orderIndex) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = cellText,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
            }
        }

        // Total Score Cell
        val totalText = if (sEval != null) {
            "${sEval.totalScore.toInt()} / ${sEval.totalMaxScore.toInt()}"
        } else "—"

        TableCell(totalText, width = 80.dp, isBold = true)
    }
}

@Composable
fun StatusChip(
    label: String,
    containerColor: Color,
    contentColor: Color,
    showSpinner: Boolean = false,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Surface(
        color = containerColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showSpinner) {
                CircularProgressIndicator(
                    modifier = Modifier.size(12.dp),
                    strokeWidth = 1.5.dp,
                    color = contentColor
                )
                Spacer(modifier = Modifier.width(4.dp))
            } else if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(12.dp), tint = contentColor)
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    isBold: Boolean = false
) {
    Text(
        text = text,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp),
        style = if (isHeader) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodySmall,
        fontWeight = if (isHeader || isBold) FontWeight.Bold else FontWeight.Normal,
        textAlign = TextAlign.Center,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        color = if (isHeader) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
    )
}

@Composable
fun QuestionEvaluationDetailDialog(
    item: SelectedDetailItem,
    questions: List<com.example.core.model.ExamQuestion>,
    rubrics: List<com.example.core.database.ExamRubricCriterionEntity>,
    layoutDensity: String = "AUTOMATIC",
    lineOverrides: Map<Int, Int> = emptyMap(),
    listeningGuidance: ListeningAnswerSheetGuidance? = null,
    examType: ExamType = ExamType.WRITTEN,
    onDismiss: () -> Unit
) {
    val copy = submissionCopy(examType)
    val clipboardManager = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${copy.itemLabel} ${item.question.orderIndex} Değerlendirme Detayı",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                Text(
                    text = "${item.studentPaper.studentName ?: "Öğrenci"} (No: ${item.studentPaper.schoolNumber ?: "—"}, Sınıf: ${item.studentPaper.classLevel ?: "—"}/${item.studentPaper.branch ?: "—"})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Question Box
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "${copy.itemLabel} Metni (${item.question.points} Puan):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.question.questionText,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Crop coordinates calculation using canonical layout density and lineOverrides
                val cropBounds = remember(item, questions, rubrics, layoutDensity, lineOverrides, listeningGuidance) {
                    try {
                        val dbQuestions = questions.map { q ->
                            com.example.core.database.ExamQuestionEntity(
                                id = q.id,
                                examDraftId = q.examDraftId,
                                orderIndex = q.orderIndex,
                                questionNumber = q.questionNumber,
                                normalizedQuestionNumber = q.questionNumber.trim().uppercase(),
                                questionText = q.questionText,
                                points = q.points,
                                createdAt = 0L,
                                updatedAt = 0L
                            )
                        }
                        val pageLayouts = com.example.core.data.ExamAnswerSheetLayoutCalculator.paginateQuestions(
                            dbQuestions,
                            rubrics,
                            densitySetting = layoutDensity,
                            lineOverrides = lineOverrides,
                            listeningGuidance = listeningGuidance,
                            examType = examType
                        )
                        com.example.core.data.ExamAnswerSheetLayoutCalculator.getQuestionCropBounds(pageLayouts, item.question.orderIndex)
                    } catch (_: Exception) {
                        null
                    }
                }

                val cropSegments = cropBounds?.segments ?: emptyList()
                val sortedPages = remember(item.pages) { item.pages.sortedBy { it.pageIndex } }
                
                // Mode switcher: 0 = Cropped answer area (all segments), 1..N = full page N
                var selectedViewMode by remember(item) { mutableIntStateOf(0) }

                val croppedBitmaps = remember(cropSegments, sortedPages) {
                    cropSegments.mapNotNull { segment ->
                        val page = sortedPages.find { it.pageIndex == segment.pageIndex } ?: return@mapNotNull null
                        val file = File(page.imagePath)
                        if (!file.exists()) return@mapNotNull null
                        val cropped = ExamImagePrivacyProcessor.prepareQuestionPreview(
                            imagePath = file.absolutePath,
                            topPt = segment.topYPt,
                            bottomPt = segment.bottomYPt
                        ) ?: return@mapNotNull null
                        Triple(segment, page, cropped)
                    }
                }

                val selectedFullPage = if (selectedViewMode > 0) sortedPages.find { it.pageIndex == selectedViewMode } else null
                val fullPageBitmap = remember(selectedFullPage) {
                    selectedFullPage?.imagePath?.let { path ->
                        val f = File(path)
                        if (f.exists()) ExamImagePrivacyProcessor.prepareFullPagePreview(f.absolutePath) else null
                    }
                }

                if (sortedPages.isNotEmpty()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (selectedViewMode == 0) "${copy.itemLabel} ${item.question.orderIndex} ${copy.answerAreaLabel} (${croppedBitmaps.size} Parça):" else "${copy.fullDocumentLabel} (Sayfa $selectedViewMode / ${sortedPages.size}):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }

                        if (sortedPages.size > 1 || croppedBitmaps.size > 1) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { selectedViewMode = 0 },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = if (selectedViewMode == 0) ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else ButtonDefaults.outlinedButtonColors(),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text(
                                        text = copy.answerAreaLabel,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }

                                sortedPages.forEach { p ->
                                    val isSelected = selectedViewMode == p.pageIndex
                                    OutlinedButton(
                                        onClick = { selectedViewMode = p.pageIndex },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = if (isSelected) ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else ButtonDefaults.outlinedButtonColors(),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text(
                                            text = "Tüm Sayfa ${p.pageIndex}",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                        }

                        if (selectedViewMode == 0) {
                            if (croppedBitmaps.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    croppedBitmaps.forEach { (segment, _, bitmap) ->
                                        Column {
                                            if (croppedBitmaps.size > 1) {
                                                Text(
                                                    text = "Sayfa ${segment.pageIndex} — ${if (examType == ExamType.HOMEWORK) {
                                                        if (segment.isContinuation) "Görev/Madde ${item.question.orderIndex} (Devam)" else "Görev/Madde ${item.question.orderIndex}"
                                                    } else {
                                                        if (segment.isContinuation) "Cevap ${item.question.orderIndex} (Devam)" else "Cevap ${item.question.orderIndex}"
                                                    }}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(bottom = 2.dp)
                                                )
                                            }
                                            Image(
                                                bitmap = bitmap.asImageBitmap(),
                                                contentDescription = "${copy.answerAreaLabel} görseli",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(max = 220.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                                                contentScale = ContentScale.Fit
                                            )
                                        }
                                    }
                                }
                            }
                        } else if (fullPageBitmap != null) {
                            Image(
                                bitmap = fullPageBitmap.asImageBitmap(),
                                contentDescription = "${copy.fullDocumentContentDescription} $selectedViewMode",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(240.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Extracted Answer & Score
                val qEval = item.questionEvaluation
                if (qEval != null) {
                    Surface(
                        color = if (qEval.needsReview) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = if (qEval.needsReview) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (examType == ExamType.HOMEWORK) "Teslim/Yanıt Türü: ${qEval.answerType}" else "Okunan Cevap Türü: ${qEval.answerType}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Verilen Puan: ${qEval.score} / ${qEval.maxScore}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = when (examType) {
                                    ExamType.HOMEWORK -> "Teslimden Okunan / Algılanan İçerik:"
                                    ExamType.MULTIPLE_CHOICE -> "İşaretlenen Seçenek:"
                                    else -> "El Yazısından Okunan Metin (HTR):"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (qEval.readAnswerText.isBlank()) {
                                    when (examType) {
                                        ExamType.HOMEWORK -> "[İlgili görev için içerik bulunamadı veya güvenilir biçimde okunamadı]"
                                        ExamType.MULTIPLE_CHOICE -> "[Seçenek belirlenemedi / boş]"
                                        else -> "[Cevap Okunamadı / Boş]"
                                    }
                                } else qEval.readAnswerText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )

                            if (!qEval.interpretedMeaning.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "AI'ın Cevaptan Çıkardığı Anlam:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = qEval.interpretedMeaning,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (!qEval.gradingEvidence.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Puanlama Kanıtı / Rubrik Dayanağı:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = qEval.gradingEvidence,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (!qEval.feedback.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Rubrik Değerlendirme Dönütü:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = qEval.feedback,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(text = "Okuma Güveni: %${(qEval.readingConfidence * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                                LinearProgressIndicator(
                                    progress = { qEval.readingConfidence.toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(4.dp).padding(vertical = 2.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.primaryContainer
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "Değerlendirme Güveni: %${(qEval.evaluationConfidence * 100).toInt()}", style = MaterialTheme.typography.labelSmall)
                                LinearProgressIndicator(
                                    progress = { qEval.evaluationConfidence.toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(4.dp).padding(vertical = 2.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            }

                            if (qEval.needsReview) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "İnceleme Nedeni: ${qEval.reviewReason ?: "Düşük Güven"}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        text = if (examType == ExamType.HOMEWORK) "Bu görev/madde henüz değerlendirilmedi." else "Bu soru henüz değerlendirilmedi.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Kapat")
                }
            }
        }
    }
}
