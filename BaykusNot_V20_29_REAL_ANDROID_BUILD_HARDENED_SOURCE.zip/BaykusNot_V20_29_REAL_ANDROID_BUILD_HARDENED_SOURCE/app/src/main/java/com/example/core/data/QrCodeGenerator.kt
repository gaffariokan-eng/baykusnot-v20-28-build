package com.example.core.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter

object QrCodeGenerator {
    fun generateQrBitmap(content: String, sizePx: Int = 200): Bitmap {
        return try {
            val bitMatrix = MultiFormatWriter().encode(
                content,
                BarcodeFormat.QR_CODE,
                sizePx,
                sizePx
            )
            val width = bitMatrix.width
            val height = bitMatrix.height
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            for (x in 0 until width) {
                for (y in 0 until height) {
                    bmp.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            bmp
        } catch (e: Exception) {
            throw IllegalStateException("Karekod oluşturulamadı.", e)
        }
    }

    fun drawQrCode(canvas: Canvas, content: String, rect: RectF, blackPaint: Paint, whitePaint: Paint) {
        try {
            val bitMatrix = MultiFormatWriter().encode(
                content,
                BarcodeFormat.QR_CODE,
                20,
                20
            )
            val matrixWidth = bitMatrix.width
            val matrixHeight = bitMatrix.height
            if (matrixWidth <= 0 || matrixHeight <= 0) return

            canvas.drawRect(rect, whitePaint)

            val moduleW = rect.width() / matrixWidth.toFloat()
            val moduleH = rect.height() / matrixHeight.toFloat()

            for (x in 0 until matrixWidth) {
                for (y in 0 until matrixHeight) {
                    if (bitMatrix.get(x, y)) {
                        val left = rect.left + x * moduleW
                        val top = rect.top + y * moduleH
                        val right = if (x == matrixWidth - 1) rect.right else left + moduleW
                        val bottom = if (y == matrixHeight - 1) rect.bottom else top + moduleH
                        canvas.drawRect(left, top, right, bottom, blackPaint)
                    }
                }
            }
        } catch (e: Exception) {
            throw IllegalStateException("Karekod çizilemedi.", e)
        }
    }
}

