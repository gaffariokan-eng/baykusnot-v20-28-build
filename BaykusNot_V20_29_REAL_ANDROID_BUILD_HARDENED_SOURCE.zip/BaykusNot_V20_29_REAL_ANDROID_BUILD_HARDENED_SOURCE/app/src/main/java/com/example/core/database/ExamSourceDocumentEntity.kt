package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_source_document",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamSourceDocumentEntity(
    @PrimaryKey
    val examDraftId: Long,
    val localRelativePath: String,
    val originalUri: String?,
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val sha256: String,
    val pageCount: Int,
    val importedAt: Long
)
