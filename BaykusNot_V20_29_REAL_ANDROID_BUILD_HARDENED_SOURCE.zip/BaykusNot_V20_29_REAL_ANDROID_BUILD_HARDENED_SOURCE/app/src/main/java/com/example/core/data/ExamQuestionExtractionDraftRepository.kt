package com.example.core.data

import com.example.core.database.ExamQuestionExtractionDraftDao
import com.example.core.database.ExamQuestionExtractionDraftEntity
import kotlinx.coroutines.flow.Flow

class ExamQuestionExtractionDraftRepository(
    private val extractionDraftDao: ExamQuestionExtractionDraftDao
) {

    fun observeStaging(examDraftId: Long): Flow<List<ExamQuestionExtractionDraftEntity>> {
        return extractionDraftDao.observeByExamDraftId(examDraftId)
    }

    suspend fun getStagingOnce(examDraftId: Long): List<ExamQuestionExtractionDraftEntity> {
        return extractionDraftDao.getByExamDraftIdOnce(examDraftId)
    }

    suspend fun replaceStaging(
        examDraftId: Long,
        rows: List<ExamQuestionExtractionDraftEntity>
    ) {
        require(rows.isNotEmpty()) { "Cannot replace staging with empty list" }
        
        rows.forEachIndexed { index, row ->
            require(row.examDraftId == examDraftId) { "Mismatched examDraftId in row" }
            require(row.orderIndex == index + 1) { "orderIndex must be exactly contiguous and 1-based" }
            require(row.sourceFingerprint.isNotBlank()) { "sourceFingerprint must not be blank" }
            
            if (index > 0) {
                require(row.sourceFingerprint == rows[0].sourceFingerprint) { "All rows must have exact same sourceFingerprint" }
            }
        }

        extractionDraftDao.replaceForDraft(
            examDraftId = examDraftId,
            questions = rows
        )
    }

    suspend fun clearStaging(examDraftId: Long) {
        extractionDraftDao.deleteByExamDraftId(examDraftId)
    }
}
