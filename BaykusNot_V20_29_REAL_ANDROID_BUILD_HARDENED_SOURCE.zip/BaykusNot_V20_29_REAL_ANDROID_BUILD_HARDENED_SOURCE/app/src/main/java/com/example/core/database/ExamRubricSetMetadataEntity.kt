package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_rubric_set_metadata",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamRubricSetMetadataEntity(
    @PrimaryKey
    val examDraftId: Long,
    val questionSetRevision: Int,
    val isLocked: Boolean,
    val lockedAt: Long?,
    val revision: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val evaluationSourceType: String = "AI_GENERATED_RUBRIC",
    val originalTeacherAnswerKey: String? = null,
    val originalTeacherRubric: String? = null,
    val elaboratedAnswerKey: String? = null,
    val elaboratedRubric: String? = null,
    val isAsIs: Boolean = false
)
