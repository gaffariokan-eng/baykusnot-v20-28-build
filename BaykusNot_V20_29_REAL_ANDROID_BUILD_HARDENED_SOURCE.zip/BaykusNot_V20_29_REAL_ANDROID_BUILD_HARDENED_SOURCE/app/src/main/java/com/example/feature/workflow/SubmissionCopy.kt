package com.example.feature.workflow

import com.example.core.model.ExamType

/**
 * Teacher-facing copy for the shared student-submission pipeline.
 * Domain/storage stays on the existing ExamStudentPaper / ExamPaperPage model;
 * only wording changes for homework submissions.
 */
data class SubmissionCopy(
    val isHomework: Boolean,
    val isReadiness: Boolean,
    val isMultipleChoice: Boolean,
    val stageLabel: String,
    val uploadTitle: String,
    val uploadDescription: String,
    val dashboardTitle: String,
    val setUnitLabel: String,
    val emptyStateText: String,
    val filteredEmptyText: String,
    val unmatchedDescription: String,
    val deleteSubmissionText: String,
    val reassignPrompt: String,
    val targetSetLabel: String,
    val evaluationIntro: String,
    val matrixTitle: String,
    val itemLabel: String,
    val itemShortLabel: String,
    val answerAreaLabel: String,
    val fullDocumentLabel: String,
    val fullDocumentContentDescription: String,
    val reviewEmptyText: String,
    val reviewTitle: String,
    val unresolvedItemLabel: String,
    val reviewDescription: String
)

fun submissionCopy(examType: ExamType): SubmissionCopy = when (examType) {
    ExamType.HOMEWORK -> SubmissionCopy(
        isHomework = true,
        isReadiness = false,
        isMultipleChoice = false,
        stageLabel = "Ödev Teslimleri",
        uploadTitle = "Öğrenci Ödev Teslimleri",
        uploadDescription = "Öğrencilerin teslim ettiği ödevleri toplu PDF, fotoğraf veya kamera ile yükleyin; sayfaları öğrenci bazında kontrol edip değerlendirmeye hazırlayın.",
        dashboardTitle = "Ödev Teslimi Durum Özeti",
        setUnitLabel = "Teslim",
        emptyStateText = "Henüz öğrenci ödev teslimi yüklenmedi.\nYukarıdaki butonları veya kamerayı kullanarak teslimleri çekin/yükleyin.",
        filteredEmptyText = "Seçili filtreye uygun ödev teslimi bulunamadı.",
        unmatchedDescription = "Henüz bir öğrenci teslimine bağlanmamış veya okunabilirlik sorunu olan ödev sayfaları aşağıdadır. İlerleyebilmek için sayfaları doğru öğrenciye bağlayın ya da sorunlu sayfaları silin.",
        deleteSubmissionText = "Teslimi Sil",
        reassignPrompt = "Bu ödev sayfasını hangi öğrenci teslimine ve kaçıncı sayfa olarak bağlamak istiyorsunuz?",
        targetSetLabel = "Hedef Öğrenci Teslimi:",
        evaluationIntro = "Ödev teslimleri okunuyor, rubriğe göre puanlanıyor ve öğrenci dönütleri hazırlanıyor.",
        matrixTitle = "Öğrenci x Görev/Madde Canlı Değerlendirme Matrisi",
        itemLabel = "Görev/Madde",
        itemShortLabel = "M",
        answerAreaLabel = "Teslim / Yanıt Alanı",
        fullDocumentLabel = "Ödev Teslimi",
        fullDocumentContentDescription = "Ödev teslimi sayfası",
        reviewEmptyText = "Değerlendirilmiş öğrenci ödev teslimi bulunamadı.",
        reviewTitle = "Ödev Teslimi Öğretmen İncelemesi",
        unresolvedItemLabel = "Çözülmemiş Görev/Madde",
        reviewDescription = "Sorunlu veya düşük güvenli görev/yanıtları kontrol edin, puanları düzenleyin ve sonuçları onaylayın."
    )


    ExamType.MULTIPLE_CHOICE -> SubmissionCopy(
        isHomework = false,
        isReadiness = false,
        isMultipleChoice = true,
        stageLabel = "Test Cevap Formları",
        uploadTitle = "Öğrenci Test Cevap Formları",
        uploadDescription = "BaykuşNot'un oluşturduğu test cevap formlarını toplu PDF, fotoğraf veya kamera ile yükleyin. QR ve öğrenci bilgilerini kontrol ettikten sonra formlar cihaz içinde optik olarak okunur.",
        dashboardTitle = "Test Cevap Formları Durum Özeti",
        setUnitLabel = "Form",
        emptyStateText = "Henüz test cevap formu yüklenmedi.\nBaykuşNot cevap formlarını PDF, fotoğraf veya kamera ile yükleyin.",
        filteredEmptyText = "Seçili filtreye uygun test cevap formu bulunamadı.",
        unmatchedDescription = "QR okunamayan, yanlış teste ait veya bağ kurulmamış test cevap formu sayfaları aşağıdadır. Optik okumaya geçmeden önce düzeltin.",
        deleteSubmissionText = "Formu Sil",
        reassignPrompt = "Bu sayfayı hangi öğrenci test cevap formuna ve kaçıncı sayfa olarak bağlamak istiyorsunuz?",
        targetSetLabel = "Hedef Öğrenci Formu:",
        evaluationIntro = "Test cevap formları cihaz içinde yerel optik okuma ile okunuyor ve kilitli cevap anahtarıyla karşılaştırılıyor.",
        matrixTitle = "Öğrenci x Test Sorusu Optik Okuma Matrisi",
        itemLabel = "Soru",
        itemShortLabel = "S",
        answerAreaLabel = "İşaretleme Alanı",
        fullDocumentLabel = "Test Cevap Formu",
        fullDocumentContentDescription = "Test cevap formu sayfası",
        reviewEmptyText = "Optik olarak okunmuş test cevap formu bulunamadı.",
        reviewTitle = "Test Optik Okuma İncelemesi",
        unresolvedItemLabel = "Belirsiz İşaretleme",
        reviewDescription = "Çift, silik veya belirsiz işaretleri kontrol edin. Testte puanlama yalnız 0 veya soru tam puanı olarak uygulanır."
    )

    ExamType.READINESS -> SubmissionCopy(
        isHomework = false,
        isReadiness = true,
        isMultipleChoice = false,
        stageLabel = "Hazırbulunuşluk Cevap Kâğıtları",
        uploadTitle = "Hazırbulunuşluk Öğrenci Kâğıtları",
        uploadDescription = "Öğrencilerin hazırbulunuşluk cevap kâğıtlarını toplu PDF, fotoğraf veya kamera ile yükleyin; sayfaları kontrol edip tanılayıcı değerlendirmeye hazırlayın.",
        dashboardTitle = "Hazırbulunuşluk Kâğıtları Durum Özeti",
        setUnitLabel = "Set",
        emptyStateText = "Henüz hazırbulunuşluk öğrenci kâğıdı yüklenmedi.\nYukarıdaki butonları veya kamerayı kullanarak kâğıtları çekin/yükleyin.",
        filteredEmptyText = "Seçili filtreye uygun hazırbulunuşluk öğrenci kâğıdı bulunamadı.",
        unmatchedDescription = "Karekod okunamayan, yanlış çalışmaya ait veya bağ kurulmamış sayfalar aşağıdadır. İlerleyebilmek için sayfaları silin veya doğru öğrenciye manuel bağlayın.",
        deleteSubmissionText = "Kâğıdı Sil",
        reassignPrompt = "Bu sayfayı hangi hazırbulunuşluk öğrenci kâğıdı setine ve kaçıncı sayfa olarak bağlamak istiyorsunuz?",
        targetSetLabel = "Hedef Öğrenci Seti:",
        evaluationIntro = "Hazırbulunuşluk cevapları okunuyor, tanılayıcı rubriğe göre puanlanıyor ve öğrencilerin mevcut ön koşul bilgi/beceri durumunu yansıtan dönütler hazırlanıyor.",
        matrixTitle = "Öğrenci x Hazırbulunuşluk Sorusu Canlı Değerlendirme Matrisi",
        itemLabel = "Soru",
        itemShortLabel = "S",
        answerAreaLabel = "Cevap Alanı",
        fullDocumentLabel = "Hazırbulunuşluk Cevap Kâğıdı",
        fullDocumentContentDescription = "Hazırbulunuşluk cevap kâğıdı sayfası",
        reviewEmptyText = "Değerlendirilmiş hazırbulunuşluk öğrenci kâğıdı bulunamadı.",
        reviewTitle = "Hazırbulunuşluk Öğretmen İncelemesi",
        unresolvedItemLabel = "Çözülmemiş Soru",
        reviewDescription = "Düşük güvenli veya sorunlu cevapları kontrol edin. Puanları yalnız kilitli rubriğe göre düzeltin; öğrencinin mevcut bilgi/beceri durumuna ilişkin nihai yorumlar öğretmen onayından sonra rapora yansısın."
    )

    else -> SubmissionCopy(
        isHomework = false,
        isReadiness = false,
        isMultipleChoice = false,
        stageLabel = "Öğrenci Kâğıtları",
        uploadTitle = "Öğrenci Kâğıtları",
        uploadDescription = "Öğrencilerin cevap kâğıtlarını toplu PDF, fotoğraf veya kamera ile yükleyin ve değerlendirmeye hazırlayın.",
        dashboardTitle = "Yükleme Durum Özeti",
        setUnitLabel = "Set",
        emptyStateText = "Henüz öğrenci kâğıdı yüklenmedi.\nYukarıdaki butonları veya kamerayı kullanarak kâğıtları çekin/yükleyin.",
        filteredEmptyText = "Seçili filtreye uygun öğrenci kâğıdı bulunamadı.",
        unmatchedDescription = "Karekod okunamayan, yanlış sınava ait veya bağ kurulmamış sayfalar aşağıdadır. İlerleyebilmek için lütfen silin veya bir öğrenciye manuel bağlayın.",
        deleteSubmissionText = "Kâğıdı Sil",
        reassignPrompt = "Bu sayfayı hangi öğrenci kâğıdı setine ve kaçıncı sayfa olarak bağlamak istiyorsunuz?",
        targetSetLabel = "Hedef Öğrenci Seti:",
        evaluationIntro = "Cevaplar okunuyor, rubriğe göre puanlanıyor ve öğrenci dönütleri hazırlanıyor.",
        matrixTitle = "Öğrenci x Soru Canlı Değerlendirme Matrisi",
        itemLabel = "Soru",
        itemShortLabel = "S",
        answerAreaLabel = "Cevap Alanı",
        fullDocumentLabel = "Cevap Kâğıdı",
        fullDocumentContentDescription = "Cevap kâğıdı sayfası",
        reviewEmptyText = "Değerlendirilmiş öğrenci kâğıdı bulunamadı.",
        reviewTitle = "Öğretmen İncelemesi",
        unresolvedItemLabel = "Çözülmemiş Soru",
        reviewDescription = "Sorunlu veya düşük güvenli cevapları kontrol edin, puanları düzenleyin ve onaylayın."
    )
}


fun SubmissionCopy.localizeUploadMessage(message: String?): String? {
    if (message == null) return null
    if (isHomework) {
        return message
            .replace("öğrenci cevap kâğıtlarını", "öğrenci ödev teslimlerini", ignoreCase = true)
            .replace("öğrenci kâğıdı seti", "ödev teslimi", ignoreCase = true)
            .replace("öğrenci kâğıdı", "ödev teslimi", ignoreCase = true)
            .replace("kâğıt setinde", "ödev tesliminde", ignoreCase = true)
            .replace("Öğrenci seti", "Öğrenci teslimi", ignoreCase = true)
            .replace("başka sınava ait", "başka çalışmaya ait", ignoreCase = true)
            .replace("QR kodu okunamayan", "öğrenciye bağlanmamış", ignoreCase = true)
    }
    if (isReadiness) {
        return message
            .replace("öğrenci cevap kâğıtlarını", "hazırbulunuşluk cevap kâğıtlarını", ignoreCase = true)
            .replace("öğrenci kâğıdı seti", "hazırbulunuşluk öğrenci kâğıdı seti", ignoreCase = true)
            .replace("öğrenci kâğıdı", "hazırbulunuşluk öğrenci kâğıdı", ignoreCase = true)
            .replace("başka sınava ait", "başka hazırbulunuşluk çalışmasına ait", ignoreCase = true)
            .replace("başka çalışmaya ait", "başka hazırbulunuşluk çalışmasına ait", ignoreCase = true)
    }
    if (isMultipleChoice) {
        return message
            .replace("öğrenci cevap kâğıtlarını", "test cevap formlarını", ignoreCase = true)
            .replace("öğrenci kâğıdı seti", "test cevap formu", ignoreCase = true)
            .replace("öğrenci kâğıdı", "test cevap formu", ignoreCase = true)
            .replace("başka sınava ait", "başka test sınavına ait", ignoreCase = true)
            .replace("kâğıt setinde", "test cevap formunda", ignoreCase = true)
    }
    return message
}
