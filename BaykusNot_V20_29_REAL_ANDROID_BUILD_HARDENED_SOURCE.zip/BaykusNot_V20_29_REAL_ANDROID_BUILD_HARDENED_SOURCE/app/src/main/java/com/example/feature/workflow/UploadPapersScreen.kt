package com.example.feature.workflow

import com.example.core.security.StudentImageCrypto
import android.content.Context
import android.net.Uri
import com.example.core.data.validateStudentIdentity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.ExamAnswerSheetRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.database.ExamPaperPageEntity
import com.example.core.data.CameraCaptureJournal
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.model.ExamType
import java.io.File

object UploadPapersTestTags {
    const val SCREEN = "upload_papers_screen"
    const val DASHBOARD = "upload_papers_dashboard"
    const val BTN_BATCH_PDF = "upload_papers_btn_pdf"
    const val BTN_CAMERA = "upload_papers_btn_camera"
    const val BTN_CONTINUE = "upload_papers_btn_continue"
    const val FILTER_ALL = "upload_papers_filter_all"
    const val FILTER_READY = "upload_papers_filter_ready"
    const val FILTER_ISSUES = "upload_papers_filter_issues"
}

@Composable
fun UploadPapersRoute(
    examDraftId: Long,
    examType: ExamType = ExamType.WRITTEN,
    uploadRepository: ExamPaperUploadRepository,
    answerSheetRepository: ExamAnswerSheetRepository,
    onContinue: (Boolean, String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: UploadPapersViewModel = viewModel(
        factory = UploadPapersViewModel.Factory(
            examPaperUploadRepository = uploadRepository,
            examAnswerSheetRepository = answerSheetRepository,
            examDraftId = examDraftId,
            examType = examType
        )
    )
    val uiState by viewModel.uiState.collectAsState()
    val copy = submissionCopy(examType)

    UploadPapersScreen(
        uiState = uiState,
        copy = copy,
        onFilterSelected = viewModel::setFilter,
        onBatchPdfSelected = { uri, context -> viewModel.processBatchPdf(context, uri) },
        onPhotosSelected = { uris, context -> viewModel.processImages(context, uris) },
        onCameraCaptured = { file -> viewModel.processCameraCapture(file) },
        onPreviewPage = viewModel::openPagePreview,
        onClosePreview = viewModel::closePagePreview,
        onDeletePage = viewModel::deletePage,
        onEditPaper = viewModel::openEditPaper,
        onCloseEditPaper = viewModel::closeEditPaper,
        onSavePaperDetails = viewModel::savePaperDetails,
        onReassignPage = viewModel::openReassignPage,
        onCloseReassignPage = viewModel::closeReassignPage,
        onConfirmReassignPage = viewModel::reassignPageToPaper,
        onDeleteStudentPaper = viewModel::deleteStudentPaperSet,
        onClearAll = viewModel::clearAll,
        onClearMessages = viewModel::clearMessages,
        onContinue = { onContinue(uiState.canProceed, copy.localizeUploadMessage(uiState.proceedBlockReason)) },
        modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun UploadPapersScreen(
    uiState: UploadPapersUiState,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    onFilterSelected: (UploadPapersFilter) -> Unit,
    onBatchPdfSelected: (Uri, Context) -> Unit,
    onPhotosSelected: (List<Uri>, Context) -> Unit,
    onCameraCaptured: (File) -> Unit,
    onPreviewPage: (ExamPaperPageEntity) -> Unit,
    onClosePreview: () -> Unit,
    onDeletePage: (Long) -> Unit,
    onEditPaper: (ExamStudentPaperEntity) -> Unit,
    onCloseEditPaper: () -> Unit,
    onSavePaperDetails: (Long, String?, String?, String?, String?) -> Unit,
    onReassignPage: (ExamPaperPageEntity) -> Unit,
    onCloseReassignPage: () -> Unit,
    onConfirmReassignPage: (Long, Int, Int) -> Unit,
    onDeleteStudentPaper: (Long) -> Unit,
    onClearAll: () -> Unit,
    onClearMessages: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var tempCameraFile by remember { mutableStateOf<File?>(null) }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onBatchPdfSelected(uri, context)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            onPhotosSelected(uris, context)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        // remember{} state may be lost if Android kills the process while the external camera is
        // open. Recover the exact pending file from the atomic capture journal.
        val file = tempCameraFile ?: CameraCaptureJournal.currentCapture(context)
        if (success && file != null && file.exists()) {
            onCameraCaptured(file)
        } else if (file != null) {
            CameraCaptureJournal.scrubPlaintext(file)
            CameraCaptureJournal.clearIfMatches(context, file)
        } else {
            CameraCaptureJournal.clear(context)
        }
        tempCameraFile = null
        tempCameraUri = null
    }

    fun launchCamera() {
        val prepared = CameraCaptureJournal.prepareCapture(context)
        val file = prepared.getOrElse { return }
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            tempCameraFile = file
            tempCameraUri = uri
            cameraLauncher.launch(uri)
        } catch (_: Exception) {
            CameraCaptureJournal.scrubPlaintext(file)
            CameraCaptureJournal.clearIfMatches(context, file)
            tempCameraFile = null
            tempCameraUri = null
        }
    }

    Box(modifier = modifier.fillMaxSize().testTag(UploadPapersTestTags.SCREEN)) {
        if (uiState.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = copy.uploadTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = copy.uploadDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                if (copy.isMultipleChoice) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Daha güvenilir optik okuma için", fontWeight = FontWeight.Bold)
                            Text("• Formun dört köşe işaretinin tamamı fotoğrafta görünsün.", style = MaterialTheme.typography.bodySmall)
                            Text("• Kâğıdı düz zeminde, gölgesiz ve mümkün olduğunca tepeden çekin.", style = MaterialTheme.typography.bodySmall)
                            Text("• Çok sayıda form için toplu PDF/fotoğraf; tek düzeltme için Kamera kullanın.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Status Dashboard
                DashboardCard(uiState = uiState, copy = copy)

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons for importing papers - Responsive 2-Row Grid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { pdfLauncher.launch("application/pdf") },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag(UploadPapersTestTags.BTN_BATCH_PDF),
                            enabled = !uiState.isProcessing
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Toplu PDF", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }

                        Button(
                            onClick = { launchCamera() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag(UploadPapersTestTags.BTN_CAMERA),
                            enabled = !uiState.isProcessing,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kamera Çek", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                    }

                    OutlinedButton(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        enabled = !uiState.isProcessing
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Galeri'den Seç", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Filter Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = uiState.selectedFilter == UploadPapersFilter.ALL,
                        onClick = { onFilterSelected(UploadPapersFilter.ALL) },
                        label = { Text("Tümü (${uiState.totalUploadedSets})") },
                        modifier = Modifier.testTag(UploadPapersTestTags.FILTER_ALL)
                    )
                    FilterChip(
                        selected = uiState.selectedFilter == UploadPapersFilter.READY,
                        onClick = { onFilterSelected(UploadPapersFilter.READY) },
                        label = { Text("Hazır (${uiState.readySetsCount})") },
                        modifier = Modifier.testTag(UploadPapersTestTags.FILTER_READY)
                    )
                    FilterChip(
                        selected = uiState.selectedFilter == UploadPapersFilter.ISSUES,
                        onClick = { onFilterSelected(UploadPapersFilter.ISSUES) },
                        label = { Text("Sorunlu (${uiState.missingPagesCount + uiState.issueSetsCount})") },
                        modifier = Modifier.testTag(UploadPapersTestTags.FILTER_ISSUES)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (uiState.isProcessing) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = uiState.processingMessage ?: "İşlem yapılıyor...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (uiState.errorMessage != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = copy.localizeUploadMessage(uiState.errorMessage) ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onClearMessages) {
                                Icon(Icons.Default.Delete, contentDescription = "Kapat")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Main Content Area
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Unmatched / Problematic Pages Section
                    if (uiState.unmatchedPages.isNotEmpty()) {
                        item {
                            UnmatchedPagesSection(
                                unmatchedPages = uiState.unmatchedPages,
                                copy = copy,
                                onPreviewPage = onPreviewPage,
                                onDeletePage = onDeletePage,
                                onReassignPage = onReassignPage
                            )
                        }
                    }

                    if (uiState.filteredPapers.isEmpty() && uiState.unmatchedPages.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.Info,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (uiState.studentPapers.isEmpty())
                                            copy.emptyStateText
                                        else
                                            copy.filteredEmptyText,
                                        textAlign = TextAlign.Center,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        items(uiState.filteredPapers, key = { it.id }) { paper ->
                            val paperPages = uiState.pages.filter { it.studentPaperId == paper.id }
                            StudentPaperCard(
                                paper = paper,
                                copy = copy,
                                pages = paperPages,
                                onPreviewPage = onPreviewPage,
                                onDeletePage = onDeletePage,
                                onEditPaper = { onEditPaper(paper) },
                                onReassignPage = onReassignPage,
                                onDeleteStudentPaper = { onDeleteStudentPaper(paper.id) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Action Bar
                if (uiState.proceedBlockReason != null) {
                    Text(
                        text = copy.localizeUploadMessage(uiState.proceedBlockReason) ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                Button(
                    onClick = onContinue,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(UploadPapersTestTags.BTN_CONTINUE),
                    enabled = uiState.canProceed && !uiState.isProcessing
                ) {
                    Text("Devam Et")
                }

                if (uiState.canProceed) {
                    Text(
                        text = when {
                            uiState.isHomework -> "Sonraki adım: Değerlendirme"
                            copy.stageLabel.contains("Test", ignoreCase = true) -> "Sonraki adım: Yerel Optik Okuma"
                            else -> "Sonraki adım: Değerlendirme Tercihleri"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 4.dp)
                    )
                }
            }
        }

        // Preview Dialog
        uiState.previewingPage?.let { page ->
            PagePreviewDialog(
                page = page,
                copy = copy,
                onClose = onClosePreview,
                onDelete = {
                    onDeletePage(page.id)
                    onClosePreview()
                }
            )
        }

        // Edit Paper Dialog
        uiState.editingPaper?.let { paper ->
            EditStudentPaperDialog(
                paper = paper,
                copy = copy,
                onDismiss = onCloseEditPaper,
                onSave = { name, cLevel, br, sNo ->
                    onSavePaperDetails(paper.id, name, cLevel, br, sNo)
                }
            )
        }

        // Reassign Page Dialog
        uiState.reassigningPage?.let { page ->
            ReassignPageDialog(
                page = page,
                copy = copy,
                expectedStudentCount = uiState.studentAssignmentCapacity,
                expectedTotalPages = uiState.expectedTotalPages,
                papers = uiState.studentPapers,
                onDismiss = onCloseReassignPage,
                onConfirm = { targetStudentSeq, targetPageIndex ->
                    onConfirmReassignPage(page.id, targetStudentSeq, targetPageIndex)
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardCard(
    uiState: UploadPapersUiState,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN)
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(UploadPapersTestTags.DASHBOARD),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = copy.dashboardTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                val countComplete = !uiState.hasFixedExpectedStudentCount || uiState.totalUploadedSets == uiState.expectedStudentCount
                Surface(
                    color = if (countComplete) {
                        MaterialTheme.colorScheme.tertiaryContainer
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (uiState.hasFixedExpectedStudentCount) {
                            "${uiState.totalUploadedSets}/${uiState.expectedStudentCount} ${copy.setUnitLabel}"
                        } else {
                            "${uiState.totalUploadedSets} ${copy.setUnitLabel}"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (countComplete) {
                            MaterialTheme.colorScheme.onTertiaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                maxItemsInEachRow = 3
            ) {
                MetricItem(
                    title = if (uiState.hasFixedExpectedStudentCount) "Beklenen" else "Kapasite",
                    value = if (uiState.hasFixedExpectedStudentCount) "${uiState.expectedStudentCount}" else "500'e kadar",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                MetricItem(
                    title = "Yüklenen",
                    value = "${uiState.totalUploadedSets}",
                    color = if (!uiState.hasFixedExpectedStudentCount || uiState.totalUploadedSets == uiState.expectedStudentCount) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                )
                MetricItem(
                    title = "Hazır",
                    value = "${uiState.readySetsCount}",
                    color = MaterialTheme.colorScheme.tertiary
                )
                MetricItem(
                    title = "Eşleşmemiş",
                    value = "${uiState.unmatchedPages.size}",
                    color = if (uiState.unmatchedPages.isEmpty()) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.secondary
                    }
                )
                MetricItem(
                    title = "Hatalı",
                    value = "${uiState.issueSetsCount}",
                    color = if (uiState.issueSetsCount == 0) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.error
                    }
                )
            }
        }
    }
}

@Composable
fun MetricItem(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UnmatchedPagesSection(
    unmatchedPages: List<ExamPaperPageEntity>,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    onPreviewPage: (ExamPaperPageEntity) -> Unit,
    onDeletePage: (Long) -> Unit,
    onReassignPage: (ExamPaperPageEntity) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.15f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Eşleşmemiş / Sorunlu Sayfalar (${unmatchedPages.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = copy.unmatchedDescription,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = unmatchedPages,
                    key = { it.id }
                ) { page ->
                    PageThumbnailItem(
                        page = page,
                        onPreview = { onPreviewPage(page) },
                        onDelete = { onDeletePage(page.id) },
                        onReassign = { onReassignPage(page) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudentPaperCard(
    paper: ExamStudentPaperEntity,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    pages: List<ExamPaperPageEntity>,
    onPreviewPage: (ExamPaperPageEntity) -> Unit,
    onDeletePage: (Long) -> Unit,
    onEditPaper: () -> Unit,
    onReassignPage: (ExamPaperPageEntity) -> Unit,
    onDeleteStudentPaper: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = paper.studentName ?: "Öğrenci #${paper.studentSequenceIndex}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (paper.isManuallyCorrected) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "Elle Düzenlendi",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    val detailsStr = listOfNotNull(
                        paper.classLevel?.let { "Sınıf: $it" },
                        paper.branch?.let { "Şube: $it" },
                        paper.schoolNumber?.let { "No: $it" }
                    ).joinToString(" | ")

                    if (detailsStr.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = detailsStr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
                StatusBadge(status = paper.status, reason = paper.statusReason)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Page Thumbnails Grid
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pages.sortedBy { it.pageIndex }.forEach { page ->
                    PageThumbnailItem(
                        page = page,
                        onPreview = { onPreviewPage(page) },
                        onDelete = { onDeletePage(page.id) },
                        onReassign = { onReassignPage(page) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
            ) {
                TextButton(
                    onClick = onEditPaper,
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Bilgileri Düzenle", style = MaterialTheme.typography.labelLarge)
                }
                TextButton(
                    onClick = onDeleteStudentPaper,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(copy.deleteSubmissionText, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun PageThumbnailItem(
    page: ExamPaperPageEntity,
    onPreview: () -> Unit,
    onDelete: () -> Unit,
    onReassign: () -> Unit
) {
    val bitmap = remember(page.imagePath) {
        try {
            StudentImageCrypto.decodeThumbnail(page.imagePath)
        } catch (_: Exception) {
            null
        }
    }
    DisposableEffect(bitmap) {
        onDispose {
            if (bitmap != null && !bitmap.isRecycled) bitmap.recycle()
        }
    }

    Box(
        modifier = Modifier
            .width(90.dp)
            .border(
                width = 1.dp,
                color = when (page.status) {
                    "VALID" -> MaterialTheme.colorScheme.outlineVariant
                    else -> MaterialTheme.colorScheme.error
                },
                shape = RoundedCornerShape(8.dp)
            )
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onPreview)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Sayfa ${page.pageIndex}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Görsel Yok",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "S.${page.pageIndex}/${page.totalPages}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onReassign,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "Taşı",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Sil",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String, reason: String?) {
    val (bgColor, textColor, label, icon) = when (status) {
        "READY" -> Quadruple(
            MaterialTheme.colorScheme.tertiaryContainer,
            MaterialTheme.colorScheme.onTertiaryContainer,
            "HAZIR",
            Icons.Default.CheckCircle
        )
        "MISSING_PAGES" -> Quadruple(
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer,
            reason ?: "EKSİK SAYFA",
            Icons.Default.Warning
        )
        "DUPLICATE_PAGES" -> Quadruple(
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.onErrorContainer,
            "TEKRAR SAYFA",
            Icons.Default.Error
        )
        "UNMATCHED_IDENTITY" -> Quadruple(
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer,
            "KİMLİK BELİRSİZ",
            Icons.Default.Warning
        )
        else -> Quadruple(
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.onErrorContainer,
            reason ?: "HATA",
            Icons.Default.Error
        )
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = textColor, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = textColor, fontWeight = FontWeight.Bold)
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun PagePreviewDialog(
    page: ExamPaperPageEntity,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    onClose: () -> Unit,
    onDelete: () -> Unit
) {
    val bitmap = remember(page.imagePath) {
        try { StudentImageCrypto.decodeBitmap(page.imagePath) } catch (_: Exception) { null }
    }

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sayfa Önizleme (Sayfa ${page.pageIndex}/${page.totalPages})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onClose) {
                        Text("✕", modifier = Modifier.semantics { contentDescription = "Kapat" })
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Önizleme",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text("Görsel yüklenemedi", color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (!copy.isHomework) {
                    Text(
                        text = "QR İçeriği: ${page.qrRawContent ?: "Okunamadı"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = if (page.studentPaperId > 0L) "Ödev sayfası öğrenci teslimine bağlandı." else "Ödev sayfası henüz bir öğrenci teslimine bağlanmadı.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (page.statusReason != null) {
                    Text(
                        text = "Durum: ${page.statusReason}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Sayfayı Sil")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = onClose) {
                        Text("Kapat")
                    }
                }
            }
        }
    }
}

@Composable
fun EditStudentPaperDialog(
    paper: ExamStudentPaperEntity,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    onDismiss: () -> Unit,
    onSave: (String?, String?, String?, String?) -> Unit
) {
    var name by remember { mutableStateOf(paper.studentName ?: "") }
    var classLevel by remember { mutableStateOf(paper.classLevel ?: "") }
    var branch by remember { mutableStateOf(paper.branch ?: "") }
    var schoolNumber by remember { mutableStateOf(paper.schoolNumber ?: "") }

    val validation = remember(classLevel, branch, schoolNumber) {
        validateStudentIdentity(classLevel, branch, schoolNumber)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (copy.isHomework) "Ödev Teslimi — Öğrenci Bilgileri" else "Öğrenci Bilgilerini Düzenle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (copy.isHomework) {
                    Text(
                        text = "Ödev tesliminin raporlarda doğru öğrenciyle eşleşmesi için sınıf, şube ve okul numarasını doğrulayın.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Ad Soyad") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = classLevel,
                        onValueChange = { classLevel = it },
                        label = { Text("Sınıf (5-12)") },
                        isError = !validation.isValid && classLevel.isNotBlank(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = branch,
                        onValueChange = { branch = it },
                        label = { Text("Şube (A-Z)") },
                        isError = !validation.isValid && branch.isNotBlank(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Quick A-Z Branch Selection Chips
                Text(
                    text = "Hızlı Şube Seçimi:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val quickBranches = com.example.core.data.BranchConstants.CANONICAL_BRANCHES
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickBranches.forEach { letter ->
                        FilterChip(
                            selected = branch.equals(letter, ignoreCase = true),
                            onClick = { branch = letter },
                            label = { Text(letter, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
                OutlinedTextField(
                    value = schoolNumber,
                    onValueChange = { schoolNumber = it },
                    label = { Text("Okul Numarası (Rakam)") },
                    isError = !validation.isValid && schoolNumber.isNotBlank(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (!validation.isValid) {
                    Text(
                        text = validation.reason ?: "Geçersiz kimlik bilgisi",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = validation.isValid,
                onClick = {
                    onSave(
                        name.ifBlank { null },
                        validation.normalizedClass ?: classLevel.ifBlank { null },
                        validation.normalizedBranch ?: branch.ifBlank { null },
                        validation.normalizedSchoolNo ?: schoolNumber.ifBlank { null }
                    )
                }
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}

@Composable
fun ReassignPageDialog(
    page: ExamPaperPageEntity,
    copy: SubmissionCopy = submissionCopy(ExamType.WRITTEN),
    expectedStudentCount: Int,
    expectedTotalPages: Int,
    papers: List<ExamStudentPaperEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit
) {
    val papersBySeq = remember(papers) { papers.associateBy { it.studentSequenceIndex } }
    var selectedSeq by remember { mutableStateOf(1) }
    var selectedPageIndex by remember { mutableStateOf(page.pageIndex.coerceAtLeast(1)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sayfayı Manuel Eşleştir / Taşı") },
        text = {
            Column {
                Text(
                    text = copy.reassignPrompt,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text(copy.targetSetLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                val studentList = (1..maxOf(expectedStudentCount, papers.size)).toList()

                LazyColumn(modifier = Modifier.height(180.dp)) {
                    items(studentList) { seq ->
                        val existingPaper = papersBySeq[seq]
                        val isSelected = seq == selectedSeq
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { selectedSeq = seq },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected)
                                    MaterialTheme.colorScheme.primaryContainer
                                else
                                    MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${existingPaper?.studentName ?: "Öğrenci #$seq"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                if (existingPaper != null) {
                                    val details = listOfNotNull(existingPaper.classLevel, existingPaper.branch, existingPaper.schoolNumber).joinToString("/")
                                    if (details.isNotBlank()) {
                                        Text(text = details, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Hedef Sayfa Numarası:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val maxPages = if (copy.isHomework) {
                        maxOf(page.totalPages, expectedTotalPages + 1, 1)
                    } else {
                        maxOf(page.totalPages, expectedTotalPages, 1)
                    }
                    (1..maxPages).forEach { pIdx ->
                        FilterChip(
                            selected = pIdx == selectedPageIndex,
                            onClick = { selectedPageIndex = pIdx },
                            label = { Text("Sayfa $pIdx") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(selectedSeq, selectedPageIndex) }) {
                Text("Eşleştir ve Kaydet")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal")
            }
        }
    )
}
