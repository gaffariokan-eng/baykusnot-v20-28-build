package com.example.feature.workflow

import com.example.core.model.ExamType

/**
 * Presentation copy for the shared question/task review stage.
 * The underlying domain remains ExamQuestion for every exam type; only teacher-facing wording changes.
 */
internal data class QuestionPointsCopy(
    val loadingText: String,
    val missingDraftText: String,
    val title: String,
    val description: String,
    val countLabel: String,
    val itemCardPrefix: String,
    val itemNumberLabel: String,
    val itemTextLabel: String,
    val emptyStateText: String,
    val addButtonText: String,
    val moveUpDescription: String,
    val moveDownDescription: String,
    val removeDescription: String,
    val objectiveSectionTitle: String,
    val objectiveDescription: String,
    val objectiveMissingText: String,
    val objectiveCompleteText: String,
    val objectiveSelectionTitle: String,
    val objectiveFallbackLabel: String,
    val objectiveMismatchAcceptText: String,
    val objectiveApprovalRequiredText: String
)

internal fun questionPointsCopy(examType: ExamType): QuestionPointsCopy = when (examType) {
    ExamType.LISTENING -> QuestionPointsCopy(
        loadingText = "Dinleme soruları ve puanları yükleniyor…",
        missingDraftText = "Dinleme sınavı taslağı bulunamadı.",
        title = "Dinleme Soruları ve Puanlar",
        description = "Yüklenen soruları kontrol edin; sıra numaralarını ve puan dağılımını doğrulayın. Sonraki adımlar Yazılı Sınav ile aynı şekilde ilerler.",
        countLabel = "Soru Sayısı",
        itemCardPrefix = "Dinleme Sorusu",
        itemNumberLabel = "Soru No",
        itemTextLabel = "Soru Metni",
        emptyStateText = "Henüz dinleme sorusu eklenmedi.",
        addButtonText = "Dinleme sorusu ekle",
        moveUpDescription = "Soruyu yukarı taşı",
        moveDownDescription = "Soruyu aşağı taşı",
        removeDescription = "Soruyu sil",
        objectiveSectionTitle = "Kazanım Eşleştirme",
        objectiveDescription = "Sınav senaryosuna göre dinleme sorularını kazanımlarla eşleştirin.",
        objectiveMissingText = "Henüz kazanım seçilmemiş sorular var.",
        objectiveCompleteText = "Bütün sorular en az bir kazanımla eşleştirildi.",
        objectiveSelectionTitle = "Kazanım Seçimi",
        objectiveFallbackLabel = "Kazanım",
        objectiveMismatchAcceptText = "Senaryodaki soru sayısı farkını gördüm ve bu eşleştirmeyi kabul ediyorum.",
        objectiveApprovalRequiredText = "Soru setini kilitleyebilmek için kazanım eşleştirmesini onaylamalısınız."
    )

    ExamType.READINESS -> QuestionPointsCopy(
        loadingText = "Hazırbulunuşluk soruları ve puanları yükleniyor…",
        missingDraftText = "Hazırbulunuşluk sınavı taslağı bulunamadı.",
        title = "Hazırbulunuşluk Soruları ve Puanlar",
        description = "Konu/ünite öncesi ölçmek istediğiniz bilgi ve becerileri temsil eden soruları, sıra numaralarını ve puan dağılımını kontrol edin.",
        countLabel = "Soru Sayısı",
        itemCardPrefix = "Hazırbulunuşluk Sorusu",
        itemNumberLabel = "Soru No",
        itemTextLabel = "Soru Metni",
        emptyStateText = "Henüz hazırbulunuşluk sorusu eklenmedi.",
        addButtonText = "Hazırbulunuşluk sorusu ekle",
        moveUpDescription = "Soruyu yukarı taşı",
        moveDownDescription = "Soruyu aşağı taşı",
        removeDescription = "Soruyu sil",
        objectiveSectionTitle = "Ön Koşul Bilgi/Beceri Eşleştirmesi",
        objectiveDescription = "Her hazırbulunuşluk sorusunu, konu/ünite öncesi gerçekten ölçtüğü ön koşul bilgi ve beceri hedefleriyle eşleştirin.",
        objectiveMissingText = "Henüz ön koşul bilgi/beceri hedefi seçilmemiş sorular var.",
        objectiveCompleteText = "Bütün sorular en az bir ön koşul bilgi/beceri hedefiyle eşleştirildi.",
        objectiveSelectionTitle = "Ön Koşul Bilgi/Beceri Seçimi",
        objectiveFallbackLabel = "Ön Koşul/Beceri",
        objectiveMismatchAcceptText = "Hazırbulunuşluk senaryosundaki soru sayısı farkını gördüm ve bu tanılayıcı eşleştirmeyi kabul ediyorum.",
        objectiveApprovalRequiredText = "Soru setini kilitleyebilmek için ön koşul bilgi/beceri eşleştirmesini onaylamalısınız."
    )

    ExamType.HOMEWORK -> QuestionPointsCopy(
        loadingText = "Ödev görevleri ve puanları yükleniyor…",
        missingDraftText = "Ödev kontrolü taslağı bulunamadı.",
        title = "Ödev Görevleri ve Puanlar",
        description = "Ödev kaynağından çıkarılan görev/maddeleri kontrol edin; sıralamayı, metinleri ve puan dağılımını doğrulayın. Gerekirse görevleri düzenleyebilir veya elle yeni görev ekleyebilirsiniz.",
        countLabel = "Görev/Madde Sayısı",
        itemCardPrefix = "Görev/Madde",
        itemNumberLabel = "Madde No",
        itemTextLabel = "Görev / Madde Metni",
        emptyStateText = "Henüz görev/madde eklenmedi.",
        addButtonText = "Görev / madde ekle",
        moveUpDescription = "Görevi yukarı taşı",
        moveDownDescription = "Görevi aşağı taşı",
        removeDescription = "Görevi sil",
        objectiveSectionTitle = "Kazanım Eşleştirme",
        objectiveDescription = "Ödev görev/maddelerini ilgili kazanımlarla eşleştirin.",
        objectiveMissingText = "Henüz kazanım seçilmemiş görev/maddeler var.",
        objectiveCompleteText = "Bütün görev/maddeler en az bir kazanımla eşleştirildi.",
        objectiveSelectionTitle = "Kazanım Seçimi",
        objectiveFallbackLabel = "Kazanım",
        objectiveMismatchAcceptText = "Senaryodaki görev/madde sayısı farkını gördüm ve bu eşleştirmeyi kabul ediyorum.",
        objectiveApprovalRequiredText = "Görev setini kilitleyebilmek için kazanım eşleştirmesini onaylamalısınız."
    )

    else -> QuestionPointsCopy(
        loadingText = "Soru ve puanlar yükleniyor…",
        missingDraftText = "Sınav taslağı bulunamadı.",
        title = "Soru ve Puan Kontrolü",
        description = "Soruları, sıra numaralarını ve puan dağılımını kontrol edin.",
        countLabel = "Soru Sayısı",
        itemCardPrefix = "Soru",
        itemNumberLabel = "Soru No",
        itemTextLabel = "Soru Metni",
        emptyStateText = "Henüz soru eklenmedi.",
        addButtonText = "Soru ekle",
        moveUpDescription = "Soruyu yukarı taşı",
        moveDownDescription = "Soruyu aşağı taşı",
        removeDescription = "Soruyu sil",
        objectiveSectionTitle = "Kazanım Eşleştirme",
        objectiveDescription = "Sınav senaryosuna göre soruları kazanımlarla eşleştirmelisiniz.",
        objectiveMissingText = "Henüz kazanım seçilmemiş sorular var.",
        objectiveCompleteText = "Bütün sorular en az bir kazanımla eşleştirildi.",
        objectiveSelectionTitle = "Kazanım Seçimi",
        objectiveFallbackLabel = "Kazanım",
        objectiveMismatchAcceptText = "Senaryodaki soru sayısı farkını gördüm ve bu eşleştirmeyi kabul ediyorum.",
        objectiveApprovalRequiredText = "Soru setini kilitleyebilmek için kazanım eşleştirmesini onaylamalısınız."
    )
}
