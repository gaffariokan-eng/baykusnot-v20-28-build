package com.example.core.database

import android.content.Context
import com.example.core.security.DatabasePassphraseStore
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TeacherProfileEntity::class,
        ExamDraftEntity::class,
        ExamEvaluationPreferencesEntity::class,
        ExamSourceDocumentEntity::class,
        ExamQuestionEntity::class,
        ExamQuestionSetMetadataEntity::class,
        ExamRubricSetMetadataEntity::class,
        ExamRubricCriterionEntity::class,
        ExamQuestionExtractionDraftEntity::class,
        ExamAnswerSheetConfigEntity::class,
        ExamStudentPaperEntity::class,
        ExamPaperPageEntity::class,
        ExamStudentEvaluationEntity::class,
        ExamQuestionEvaluationEntity::class,
        ExamObjectiveEntity::class,
        QuestionObjectiveCrossRef::class,
        ExamListeningMaterialEntity::class,
        ExamAiRunProfileEntity::class,
        ExamAiUsageEntity::class,
        ExamReviewRequestEntity::class,
        ExamYazekDeclarationEntity::class,
        ExamProcessingModeEntity::class,
        ExamEvaluationRunStateEntity::class
    ],
    version = 30,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun teacherProfileDao(): TeacherProfileDao
    abstract fun examDraftDao(): ExamDraftDao
    abstract fun examEvaluationPreferencesDao(): ExamEvaluationPreferencesDao
    abstract fun examSourceDocumentDao(): ExamSourceDocumentDao
    abstract fun examQuestionDao(): ExamQuestionDao
    abstract fun examQuestionExtractionDraftDao(): ExamQuestionExtractionDraftDao
    abstract fun examRubricDao(): ExamRubricDao
    abstract fun examAnswerSheetConfigDao(): ExamAnswerSheetConfigDao
    abstract fun examPaperUploadDao(): ExamPaperUploadDao
    abstract fun examEvaluationDao(): ExamEvaluationDao
    abstract fun examObjectiveDao(): ExamObjectiveDao
    abstract fun examListeningMaterialDao(): ExamListeningMaterialDao


    companion object {






        val MIGRATION_29_30 = object : Migration(29, 30) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Canonical Teacher Mode: preserve explicit teacher writing/punctuation and feedback
                // choices, but normalize technical controls that are no longer exposed in V20.21.
                db.execSQL(
                    """
                    UPDATE `exam_evaluation_preferences`
                    SET `evaluationMode` = 'PAPER_BY_PAPER',
                        `rubricAdherenceLevel` = 'BALANCED',
                        `modelQualityTier` = 'STANDARD',
                        `reportClass` = 1,
                        `reportIndividual` = 1,
                        `reportQuestion` = 1,
                        `useBatchApi` = 0,
                        `usePromptCaching` = 1,
                        `revision` = `revision` + 1,
                        `updatedAt` = CAST(strftime('%s','now') AS INTEGER) * 1000
                    WHERE `evaluationMode` != 'PAPER_BY_PAPER'
                       OR `rubricAdherenceLevel` != 'BALANCED'
                       OR `modelQualityTier` != 'STANDARD'
                       OR `reportClass` != 1
                       OR `reportIndividual` != 1
                       OR `reportQuestion` != 1
                       OR `useBatchApi` != 0
                       OR `usePromptCaching` != 1
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exam_evaluation_run_state` (
                        `examDraftId` INTEGER NOT NULL,
                        `requestedMode` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `completedCount` INTEGER NOT NULL,
                        `totalCount` INTEGER NOT NULL,
                        `lastError` TEXT,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_28_29 = object : Migration(28, 29) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `teacherNote` TEXT")
            }
        }

        val MIGRATION_27_28 = object : Migration(27, 28) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_processing_mode` (
                        `examDraftId` INTEGER NOT NULL,
                        `evaluationSource` TEXT NOT NULL,
                        `feedbackSource` TEXT NOT NULL,
                        `changedAt` INTEGER NOT NULL,
                        `reason` TEXT,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_26_27 = object : Migration(26, 27) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_review_request` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `studentPaperId` INTEGER NOT NULL,
                        `requestedBy` TEXT NOT NULL,
                        `reason` TEXT NOT NULL,
                        `status` TEXT NOT NULL,
                        `scoreBefore` REAL,
                        `scoreAfter` REAL,
                        `requestedAt` INTEGER NOT NULL,
                        `resolvedAt` INTEGER,
                        `resolutionNote` TEXT,
                        FOREIGN KEY(`studentPaperId`) REFERENCES `exam_student_paper`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_review_request_examDraftId` ON `exam_review_request` (`examDraftId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_review_request_studentPaperId` ON `exam_review_request` (`studentPaperId`)")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_yazek_declaration` (
                        `examDraftId` INTEGER NOT NULL,
                        `scopeFingerprint` TEXT NOT NULL,
                        `scopeSummary` TEXT NOT NULL,
                        `academicYear` TEXT NOT NULL,
                        `confirmedAt` INTEGER NOT NULL,
                        `referenceNote` TEXT,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_25_26 = object : Migration(25, 26) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringInputPerMillionUsd` REAL NOT NULL DEFAULT 0.75")
                db.execSQL("ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringOutputPerMillionUsd` REAL NOT NULL DEFAULT 3.75")
                db.execSQL("ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringCachedInputPerMillionUsd` REAL NOT NULL DEFAULT 0.075")
            }
        }

        val MIGRATION_24_25 = object : Migration(24, 25) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_ai_usage` ADD COLUMN `actualModelVersion` TEXT")
                db.execSQL("ALTER TABLE `exam_ai_usage` ADD COLUMN `responseId` TEXT")
                db.execSQL("ALTER TABLE `exam_ai_usage` ADD COLUMN `modelStatusStage` TEXT")
                db.execSQL("ALTER TABLE `exam_ai_usage` ADD COLUMN `modelRetirementTime` TEXT")
                db.execSQL("ALTER TABLE `exam_ai_usage` ADD COLUMN `modelStatusMessage` TEXT")
            }
        }

        val MIGRATION_23_24 = object : Migration(23, 24) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_ai_run_profile` (
                        `examDraftId` INTEGER NOT NULL,
                        `evaluationModel` TEXT NOT NULL,
                        `feedbackModel` TEXT NOT NULL,
                        `authoringModel` TEXT NOT NULL,
                        `evaluationInputPerMillionUsd` REAL NOT NULL,
                        `evaluationOutputPerMillionUsd` REAL NOT NULL,
                        `evaluationCachedInputPerMillionUsd` REAL NOT NULL,
                        `cacheStoragePerMillionTokenHourUsd` REAL NOT NULL,
                        `feedbackInputPerMillionUsd` REAL NOT NULL,
                        `feedbackOutputPerMillionUsd` REAL NOT NULL,
                        `batchPriceFactor` REAL NOT NULL,
                        `highImageTokens` INTEGER NOT NULL,
                        `supportsHighMediaResolution` INTEGER NOT NULL,
                        `supportsBatch` INTEGER NOT NULL,
                        `supportsPromptCaching` INTEGER NOT NULL,
                        `supportsThinkingLevel` INTEGER NOT NULL,
                        `preferBatchEvaluation` INTEGER NOT NULL,
                        `promptPolicyVersion` TEXT NOT NULL,
                        `legacyPrivacyApprovedAt` INTEGER,
                        `homeworkPrivacyApprovedAt` INTEGER,
                        `profileUpdatedAt` INTEGER NOT NULL,
                        `lockedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_ai_usage` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `studentPaperId` INTEGER,
                        `stage` TEXT NOT NULL,
                        `modelId` TEXT NOT NULL,
                        `useBatchPricing` INTEGER NOT NULL,
                        `inputTokens` INTEGER NOT NULL,
                        `cachedInputTokens` INTEGER NOT NULL,
                        `outputTokens` INTEGER NOT NULL,
                        `thinkingTokens` INTEGER NOT NULL,
                        `estimatedCostUsd` REAL NOT NULL,
                        `recordedAt` INTEGER NOT NULL,
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_ai_usage_examDraftId` ON `exam_ai_usage` (`examDraftId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_ai_usage_studentPaperId` ON `exam_ai_usage` (`studentPaperId`)")
            }
        }

        val MIGRATION_22_23 = object : Migration(22, 23) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingStrengths` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingIssues` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingNextSteps` TEXT NOT NULL DEFAULT '[]'")
            }
        }

        val MIGRATION_21_22 = object : Migration(21, 22) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `interpretedMeaning` TEXT")
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `gradingEvidence` TEXT")
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `strengths` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `missingElements` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `misconceptions` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_question_evaluation` ADD COLUMN `nextSteps` TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `overallFeedback` TEXT")
                db.execSQL("ALTER TABLE `exam_student_evaluation` ADD COLUMN `feedbackGeneratedAt` INTEGER")
            }
        }

        val MIGRATION_20_21 = object : Migration(20, 21) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exam_listening_material` (
                        `examDraftId` INTEGER NOT NULL,
                        `localRelativePath` TEXT,
                        `originalUri` TEXT,
                        `displayName` TEXT,
                        `mimeType` TEXT,
                        `sizeBytes` INTEGER,
                        `sha256` TEXT,
                        `transcript` TEXT NOT NULL DEFAULT '',
                        `playbackCount` INTEGER NOT NULL DEFAULT 2,
                        `instructions` TEXT NOT NULL DEFAULT '',
                        `isTranscriptApproved` INTEGER NOT NULL DEFAULT 0,
                        `importedAt` INTEGER,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`)
                            ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_19_20 = object : Migration(19, 20) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_answer_sheet_config` ADD COLUMN `layoutDensity` TEXT NOT NULL DEFAULT 'AUTOMATIC'")
                db.execSQL("ALTER TABLE `exam_answer_sheet_config` ADD COLUMN `layoutVersion` INTEGER NOT NULL DEFAULT 2")
            }
        }
        
        val MIGRATION_18_19 = object : Migration(18, 19) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `evaluationSourceType` TEXT NOT NULL DEFAULT 'AI_GENERATED_RUBRIC'")
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `originalTeacherAnswerKey` TEXT")
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `originalTeacherRubric` TEXT")
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `elaboratedAnswerKey` TEXT")
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `elaboratedRubric` TEXT")
                db.execSQL("ALTER TABLE `exam_rubric_set_metadata` ADD COLUMN `isAsIs` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exam_rubric_criterion` ADD COLUMN `originalAnswerKey` TEXT")
                db.execSQL("ALTER TABLE `exam_rubric_criterion` ADD COLUMN `originalRubric` TEXT")
            }
        }

        val MIGRATION_17_18 = object : Migration(17, 18) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `stagingCourseName` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `stagingGradeLevel` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `stagingTerm` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `stagingExamSequenceNumber` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `approvedCourseName` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `approvedGradeLevel` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `approvedTerm` TEXT")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `approvedExamSequenceNumber` TEXT")
            }
        }

        val MIGRATION_16_17 = object : Migration(16, 17) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `isMismatchAccepted` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_15_16 = object : Migration(15, 16) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `hasScenario` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `isScenarioApproved` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exam_draft` ADD COLUMN `isObjectiveMappingApproved` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exam_objective` ADD COLUMN `isStaging` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_14_15 =
            object : Migration(14, 15) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `exam_objective` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `examDraftId` INTEGER NOT NULL, `learningArea` TEXT, `objectiveCode` TEXT, `objectiveText` TEXT NOT NULL, `notes` TEXT, `expectedQuestionCount` INTEGER, FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                    )
                    db.execSQL(
                        "CREATE INDEX IF NOT EXISTS `index_exam_objective_examDraftId` ON `exam_objective` (`examDraftId`)"
                    )
                    db.execSQL(
                        "CREATE TABLE IF NOT EXISTS `question_objective_cross_ref` (`questionId` INTEGER NOT NULL, `objectiveId` INTEGER NOT NULL, PRIMARY KEY(`questionId`, `objectiveId`), FOREIGN KEY(`questionId`) REFERENCES `exam_question`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`objectiveId`) REFERENCES `exam_objective`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                    )
                    db.execSQL(
                        "CREATE INDEX IF NOT EXISTS `index_question_objective_cross_ref_objectiveId` ON `question_objective_cross_ref` (`objectiveId`)"
                    )
                    db.execSQL(
                        "CREATE INDEX IF NOT EXISTS `index_question_objective_cross_ref_questionId` ON `question_objective_cross_ref` (`questionId`)"
                    )
                }
            }

        val MIGRATION_1_2 =
            object : Migration(1, 2) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS
                        `exam_evaluation_preferences` (
                            `examDraftId` INTEGER NOT NULL,
                            `evaluationMode` TEXT NOT NULL,
                            `rubricAdherenceLevel` TEXT NOT NULL,
                            `feedbackDetailLevel` TEXT NOT NULL,
                            `deductWritingAndPunctuationPoints`
                                INTEGER NOT NULL,
                            `provideWritingAndPunctuationFeedback`
                                INTEGER NOT NULL,
                            `modelQualityTier` TEXT NOT NULL,
                            `isLocked` INTEGER NOT NULL,
                            `lockedAt` INTEGER,
                            `revision` INTEGER NOT NULL,
                            `createdAt` INTEGER NOT NULL,
                            `updatedAt` INTEGER NOT NULL,
                            PRIMARY KEY(`examDraftId`),
                            FOREIGN KEY(`examDraftId`)
                                REFERENCES `exam_draft`(`id`)
                                ON UPDATE NO ACTION
                                ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                }
            }


        val MIGRATION_2_3 =
            object : Migration(2, 3) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `exam_source_document` (
                            `examDraftId` INTEGER NOT NULL,
                            `localRelativePath` TEXT NOT NULL,
                            `originalUri` TEXT,
                            `displayName` TEXT NOT NULL,
                            `mimeType` TEXT NOT NULL,
                            `sizeBytes` INTEGER NOT NULL,
                            `sha256` TEXT NOT NULL,
                            `pageCount` INTEGER NOT NULL,
                            `importedAt` INTEGER NOT NULL,
                            PRIMARY KEY(`examDraftId`),
                            FOREIGN KEY(`examDraftId`)
                                REFERENCES `exam_draft`(`id`)
                                ON UPDATE NO ACTION
                                ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                }
            }

        val MIGRATION_3_4 =
            object : Migration(3, 4) {

                override fun migrate(
                    db:
                        SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `exam_question` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `examDraftId` INTEGER NOT NULL,
                            `orderIndex` INTEGER NOT NULL,
                            `questionNumber` TEXT NOT NULL,
                            `normalizedQuestionNumber` TEXT NOT NULL,
                            `questionText` TEXT NOT NULL,
                            `points` INTEGER NOT NULL,
                            `createdAt` INTEGER NOT NULL,
                            `updatedAt` INTEGER NOT NULL,
                            FOREIGN KEY(`examDraftId`)
                                REFERENCES `exam_draft`(`id`)
                                ON UPDATE NO ACTION
                                ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )

                    db.execSQL(
                        """
                        CREATE INDEX IF NOT EXISTS
                        `index_exam_question_examDraftId`
                        ON `exam_question`
                        (`examDraftId`)
                        """.trimIndent()
                    )

                    db.execSQL(
                        """
                        CREATE UNIQUE INDEX IF NOT EXISTS
                        `index_exam_question_examDraftId_orderIndex`
                        ON `exam_question`
                        (`examDraftId`, `orderIndex`)
                        """.trimIndent()
                    )

                    db.execSQL(
                        """
                        CREATE UNIQUE INDEX IF NOT EXISTS
                        `index_exam_question_examDraftId_normalizedQuestionNumber`
                        ON `exam_question`
                        (`examDraftId`, `normalizedQuestionNumber`)
                        """.trimIndent()
                    )
                }
            }

        val MIGRATION_4_5 =
            object : Migration(4, 5) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS
                        `exam_question_set_metadata` (
                            `examDraftId` INTEGER NOT NULL,
                            `isLocked` INTEGER NOT NULL,
                            `lockedAt` INTEGER,
                            `revision` INTEGER NOT NULL,
                            `createdAt` INTEGER NOT NULL,
                            `updatedAt` INTEGER NOT NULL,
                            PRIMARY KEY(`examDraftId`),
                            FOREIGN KEY(`examDraftId`)
                                REFERENCES `exam_draft`(`id`)
                                ON UPDATE NO ACTION
                                ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                }
            }

        val MIGRATION_5_6 =
            object : Migration(5, 6) {
                override fun migrate(db: SupportSQLiteDatabase) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `exam_rubric_set_metadata` (
                            `examDraftId` INTEGER NOT NULL,
                            `questionSetRevision` INTEGER NOT NULL,
                            `isLocked` INTEGER NOT NULL,
                            `lockedAt` INTEGER,
                            `revision` INTEGER NOT NULL,
                            `createdAt` INTEGER NOT NULL,
                            `updatedAt` INTEGER NOT NULL,
                            PRIMARY KEY(`examDraftId`),
                            FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `exam_rubric_criterion` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `examDraftId` INTEGER NOT NULL,
                            `questionOrderIndex` INTEGER NOT NULL,
                            `questionNumberSnapshot` TEXT NOT NULL,
                            `criterionOrderIndex` INTEGER NOT NULL,
                            `title` TEXT NOT NULL,
                            `description` TEXT NOT NULL,
                            `maxPoints` INTEGER NOT NULL,
                            `expectedAnswer` TEXT NOT NULL,
                            `partialCreditGuidance` TEXT NOT NULL,
                            `commonMistakes` TEXT NOT NULL,
                            `createdAt` INTEGER NOT NULL,
                            `updatedAt` INTEGER NOT NULL,
                            FOREIGN KEY(`examDraftId`) REFERENCES `exam_rubric_set_metadata`(`examDraftId`) ON UPDATE NO ACTION ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_rubric_criterion_examDraftId` ON `exam_rubric_criterion` (`examDraftId`)")
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_exam_rubric_criterion_examDraftId_questionOrderIndex_criterionOrderIndex` ON `exam_rubric_criterion` (`examDraftId`, `questionOrderIndex`, `criterionOrderIndex`)")
                }
            }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `hasExplicitWritingPunctuationPreference` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_6_7 =
            object : Migration(6, 7) {
                override fun migrate(db: SupportSQLiteDatabase) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `exam_question_extraction_draft` (
                            `examDraftId` INTEGER NOT NULL,
                            `sourceFingerprint` TEXT NOT NULL,
                            `orderIndex` INTEGER NOT NULL,
                            `rawQuestionNumber` TEXT NOT NULL,
                            `rawQuestionText` TEXT NOT NULL,
                            `rawPoints` INTEGER,
                            PRIMARY KEY(`examDraftId`, `orderIndex`),
                            FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                        )
                        """.trimIndent()
                    )
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_question_extraction_draft_examDraftId` ON `exam_question_extraction_draft` (`examDraftId`)")
                }
            }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exam_answer_sheet_config` (
                        `examDraftId` INTEGER NOT NULL,
                        `studentCount` INTEGER NOT NULL,
                        `isGenerated` INTEGER NOT NULL,
                        `pdfPath` TEXT,
                        `generatedAt` INTEGER,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`examDraftId`),
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exam_student_paper` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `studentSequenceIndex` INTEGER NOT NULL,
                        `studentName` TEXT,
                        `classLevel` TEXT,
                        `branch` TEXT,
                        `schoolNumber` TEXT,
                        `status` TEXT NOT NULL,
                        `statusReason` TEXT,
                        `isManuallyCorrected` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_student_paper_examDraftId` ON `exam_student_paper` (`examDraftId`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `exam_paper_page` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `studentPaperId` INTEGER NOT NULL,
                        `pageIndex` INTEGER NOT NULL,
                        `totalPages` INTEGER NOT NULL,
                        `qrStudentSeq` INTEGER,
                        `imagePath` TEXT NOT NULL,
                        `qrRawContent` TEXT,
                        `isReadabilityOk` INTEGER NOT NULL,
                        `status` TEXT NOT NULL,
                        `statusReason` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_paper_page_examDraftId` ON `exam_paper_page` (`examDraftId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_paper_page_studentPaperId` ON `exam_paper_page` (`studentPaperId`)")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_paper_page` ADD COLUMN `isManuallyAssigned` INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `reportClass` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `reportIndividual` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `reportQuestion` INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `useBatchApi` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `exam_evaluation_preferences` ADD COLUMN `usePromptCaching` INTEGER NOT NULL DEFAULT 1")
            }
        }

        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_student_evaluation` (
                        `studentPaperId` INTEGER NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `status` TEXT NOT NULL,
                        `totalScore` REAL NOT NULL,
                        `totalMaxScore` REAL NOT NULL,
                        `spellingPunctuationFeedback` TEXT,
                        `spellingPunctuationDeduction` REAL NOT NULL,
                        `overallConfidence` REAL NOT NULL,
                        `needsReview` INTEGER NOT NULL,
                        `errorMessage` TEXT,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`studentPaperId`),
                        FOREIGN KEY(`studentPaperId`) REFERENCES `exam_student_paper`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_student_evaluation_examDraftId` ON `exam_student_evaluation` (`examDraftId`)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exam_question_evaluation` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `studentPaperId` INTEGER NOT NULL,
                        `examDraftId` INTEGER NOT NULL,
                        `questionNumber` TEXT NOT NULL,
                        `questionOrderIndex` INTEGER NOT NULL,
                        `readAnswerText` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `maxScore` REAL NOT NULL,
                        `feedback` TEXT,
                        `readingConfidence` REAL NOT NULL,
                        `evaluationConfidence` REAL NOT NULL,
                        `answerType` TEXT NOT NULL,
                        `needsReview` INTEGER NOT NULL,
                        `reviewReason` TEXT,
                        FOREIGN KEY(`studentPaperId`) REFERENCES `exam_student_paper`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_question_evaluation_studentPaperId` ON `exam_question_evaluation` (`studentPaperId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exam_question_evaluation_examDraftId` ON `exam_question_evaluation` (`examDraftId`)")
            }
        }

        val MIGRATION_13_14 = object : Migration(13, 14) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE exam_question_evaluation ADD COLUMN originalScore REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE exam_question_evaluation ADD COLUMN isTeacherModified INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE exam_question_evaluation ADD COLUMN isResolved INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE exam_student_evaluation ADD COLUMN isTeacherApproved INTEGER NOT NULL DEFAULT 0")
                
                db.execSQL("UPDATE exam_question_evaluation SET originalScore = score")
                db.execSQL("UPDATE exam_question_evaluation SET isResolved = 0 WHERE needsReview = 1")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val appContext = context.applicationContext
                val databaseName = "evaluator_database"
                val passphrase = DatabasePassphraseStore(appContext).getOrCreatePassphrase()
                DatabaseEncryptionManager.ensureEncrypted(appContext.getDatabasePath(databaseName), passphrase)
                System.loadLibrary("sqlcipher")
                val instance = Room.databaseBuilder(
                    appContext,
                    AppDatabase::class.java,
                    databaseName
                )
                    .openHelperFactory(SupportOpenHelperFactory(passphrase.toByteArray(Charsets.UTF_8)))
                    .addMigrations(MIGRATION_1_2)
                    .addMigrations(MIGRATION_2_3)
                    .addMigrations(MIGRATION_3_4)
                    .addMigrations(MIGRATION_4_5)
                    .addMigrations(MIGRATION_5_6)
                    .addMigrations(MIGRATION_6_7)
                    .addMigrations(MIGRATION_7_8)
                    .addMigrations(MIGRATION_8_9)
                    .addMigrations(MIGRATION_9_10)
                    .addMigrations(MIGRATION_10_11)
                    .addMigrations(MIGRATION_11_12)
                    .addMigrations(MIGRATION_12_13)
                    .addMigrations(MIGRATION_13_14)
                    .addMigrations(MIGRATION_14_15)
                    .addMigrations(MIGRATION_15_16)
                    .addMigrations(MIGRATION_16_17)
                    .addMigrations(MIGRATION_17_18)
                    .addMigrations(MIGRATION_18_19)
                    .addMigrations(MIGRATION_19_20)
                    .addMigrations(MIGRATION_20_21)
                    .addMigrations(MIGRATION_21_22)
                    .addMigrations(MIGRATION_22_23)
                    .addMigrations(MIGRATION_23_24)
                    .addMigrations(MIGRATION_24_25)
                    .addMigrations(MIGRATION_25_26)
                    .addMigrations(MIGRATION_26_27)
                    .addMigrations(MIGRATION_27_28)
                    .addMigrations(MIGRATION_28_29)
                    .addMigrations(MIGRATION_29_30)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
