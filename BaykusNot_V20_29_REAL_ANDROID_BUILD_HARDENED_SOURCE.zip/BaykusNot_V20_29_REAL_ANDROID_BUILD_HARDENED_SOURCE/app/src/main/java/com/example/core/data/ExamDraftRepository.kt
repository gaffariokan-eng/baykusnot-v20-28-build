package com.example.core.data

import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamDraftEntity
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ExamDraftRepository(
    private val dao: ExamDraftDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    val allDrafts: Flow<List<ExamDraftEntity>> = dao.getAllDrafts()

    fun getDraftById(id: Long): Flow<ExamDraftEntity?> = dao.getDraftById(id)

    suspend fun getDraftByIdOnce(id: Long): ExamDraftEntity? = withContext(ioDispatcher) {
        dao.getDraftByIdOnce(id)
    }

    suspend fun insertDraft(draft: ExamDraftEntity): Long = withContext(ioDispatcher) {
        dao.insertDraft(draft.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
    }

    suspend fun updateDraft(draft: ExamDraftEntity) = withContext(ioDispatcher) {
        dao.updateDraft(draft.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteDraftById(id: Long) = withContext(ioDispatcher) {
        dao.deleteDraftById(id)
    }

    suspend fun getEvaluationPreferencesCopySourceDrafts(
        targetExamDraftId: Long
    ): List<ExamDraftEntity> =
        withContext(ioDispatcher) {
            dao.getEvaluationPreferencesCopySourceDrafts(
                targetExamDraftId
            )
        }
}
