package com.example.feature.workflow

import android.content.Context
import java.io.File
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.model.WorkflowStage
import com.example.core.model.ExamType
import com.example.core.ui.BaykusBanner
import com.example.core.ui.BaykusCard
import com.example.core.ui.BaykusPrimaryButton
import com.example.core.ui.BaykusSecondaryButton
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.BaykusTopAppBar
import com.example.core.ui.BaykusWorkflowStepper
import com.example.core.ui.StatusType
import com.example.ui.theme.WiseAmberSecondary
import com.example.ui.theme.WiseNavyPrimary

object RubricTestTags {
    const val LOADING = "rubric_loading"
    const val NOT_FOUND = "rubric_not_found"
    const val SHELL = "rubric_shell"
    const val TITLE = "rubric_title"
    const val QUESTIONS = "rubric_questions"
    const val EMPTY_QUESTIONS = "rubric_empty_questions"

    fun question(orderIndex: Int): String =
        "rubric_question_$orderIndex"

    fun criteria(questionOrderIndex: Int): String =
        "rubric_criteria_$questionOrderIndex"

    fun emptyCriteria(questionOrderIndex: Int): String =
        "rubric_empty_criteria_$questionOrderIndex"

    fun criterion(localId: Long): String =
        "rubric_criterion_$localId"

    fun criterionTitleInput(localId: Long): String =
        "rubric_criterion_title_input_$localId"

    fun criterionDescriptionInput(localId: Long): String =
        "rubric_criterion_description_input_$localId"

    fun criterionMaxPointsInput(localId: Long): String =
        "rubric_criterion_max_points_input_$localId"

    fun expectedAnswer(localId: Long): String =
        "rubric_expected_answer_$localId"

    fun partialCreditGuidance(localId: Long): String =
        "rubric_partial_credit_guidance_$localId"

    fun commonMistakes(localId: Long): String =
        "rubric_common_mistakes_$localId"

    const val SAVE_BUTTON = "rubric_save_button"
    const val LOCK_BUTTON = "rubric_lock_button"
    const val UNLOCK_BUTTON = "rubric_unlock_button"
    const val CONTINUE_BUTTON = "rubric_continue_button"
}

@Composable
fun RubricSectionHeader(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(18.dp)
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        if (subtitle != null) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.padding(start = 12.dp, top = 2.dp)
            )
        }
    }
}

@Composable
fun RubricScreen(
    uiState: RubricUiState,
    modifier: Modifier = Modifier,
    onCriterionTitleChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onCriterionDescriptionChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onCriterionMaxPointsChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onCriterionExpectedAnswerChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onCriterionPartialCreditGuidanceChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onCriterionCommonMistakesChange: (localId: Long, value: String) -> Unit = { _, _ -> },
    onSaveWritingPunctuationPreference: (Boolean) -> Unit = {},
    onGenerateRubric: () -> Unit = {},
    onSaveClick: () -> Unit = {},
    onLockClick: () -> Unit = {},
    onUnlockClick: () -> Unit = {},
    onContinueClick: () -> Unit = {},
    onEvaluationSourceTypeChange: (String) -> Unit = {},
    onOriginalAnswerKeyChange: (String) -> Unit = {},
    onOriginalRubricChange: (String) -> Unit = {},
    onIsAsIsChange: (Boolean) -> Unit = {},
    onMatchWithQuestionsClick: () -> Unit = {},
    onUploadDocumentClick: (targetType: String) -> Unit = {},
    onRemoveDocumentClick: (targetType: String) -> Unit = {},
    onGeneratePdf: (Context) -> Unit = {},
    onSavePdf: (Context) -> Unit = {},
    onSharePdf: (File) -> Unit = {},
    onSelectPage: (Int) -> Unit = {}
) {
    if (uiState.isLoading) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .testTag(RubricTestTags.LOADING),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(12.dp))
                Text("Rubrik bilgileri yükleniyor...", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    } else if (!uiState.draftExists) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .testTag(RubricTestTags.NOT_FOUND),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = when (uiState.examType) {
                    ExamType.HOMEWORK -> "Ödev kontrolü taslağı bulunamadı."
                    ExamType.READINESS -> "Hazırbulunuşluk sınavı taslağı bulunamadı."
                    else -> "Sınav taslağı bulunamadı."
                },
                style = MaterialTheme.typography.bodyLarge
            )
        }
    } else {
        val controlsEnabled = !uiState.isLocked && !uiState.isSaving && !uiState.isLocking && !uiState.isUnlocking && !uiState.isMatching

        val listState = rememberLazyListState()
        var previousGenerating by remember { mutableStateOf(false) }

        LaunchedEffect(uiState.isGenerating, uiState.editableCriteria, uiState.evaluationSourceType) {
            if (previousGenerating && !uiState.isGenerating && uiState.editableCriteria.isNotEmpty() && uiState.evaluationSourceType == "AI_GENERATED_RUBRIC") {
                listState.animateScrollToItem(4)
            }
            previousGenerating = uiState.isGenerating
        }

        LazyColumn(
            state = listState,
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag(RubricTestTags.SHELL),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                RubricSectionHeader("Rubrik Durumu", "Değerlendirme sürecinizin güncel durumu")
                Spacer(modifier = Modifier.height(8.dp))
                BaykusBanner(
                    message = if (uiState.isLocked) 
                        "Rubrik kilitlendi. Değerlendirme tercihlerine geçebilirsiniz." 
                    else 
                        when (uiState.examType) {
                            ExamType.READINESS -> "Kendi cevap anahtarınızı/rubriğinizi yükleyin veya yapay zekanın konu/ünite öncesi mevcut bilgi ve beceriyi ayırt edecek tanılayıcı rubrik üretmesini sağlayın."
                            ExamType.HOMEWORK -> "Kendi beklenen yanıt/çıktı anahtarınızı veya rubriğinizi yükleyin ya da yapay zekanın ayrıntılı ödev değerlendirme rehberi üretmesini sağlayın."
                            else -> "Kendi cevap anahtarınızı/rubriğinizi yükleyin veya yapay zekanın ayrıntılı rehber üretmesini sağlayın."
                        },
                    type = if (uiState.isLocked) StatusType.SUCCESS else StatusType.INFO
                )
            }

            // 2. Rubrik Durumu & Mesaj
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kriter Listesi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag(RubricTestTags.TITLE)
                        )

                        BaykusStatusChip(
                            text = if (uiState.isLocked) "Kilitli" else "Düzenlenebilir",
                            type = if (uiState.isLocked) StatusType.SUCCESS else StatusType.WARNING
                        )
                    }

                    uiState.message?.let { message ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            // 4. Rubrik Oluşturma ve Değerlendirme Kaynağı
            if (uiState.questions.isNotEmpty() && !uiState.isLocked) {
                item {
                    RubricSectionHeader("Değerlendirme Kaynağı", "Rubriğin neye göre oluşturulacağını seçin")
                    Spacer(modifier = Modifier.height(4.dp))
                    RubricGenerationControls(
                        uiState = uiState,
                        onSaveWritingPunctuationPreference = onSaveWritingPunctuationPreference,
                        onGenerateRubric = onGenerateRubric,
                        onEvaluationSourceTypeChange = onEvaluationSourceTypeChange,
                        onOriginalAnswerKeyChange = onOriginalAnswerKeyChange,
                        onOriginalRubricChange = onOriginalRubricChange,
                        onIsAsIsChange = onIsAsIsChange,
                        onMatchWithQuestionsClick = onMatchWithQuestionsClick,
                        onUploadDocumentClick = onUploadDocumentClick,
                        onRemoveDocumentClick = onRemoveDocumentClick
                    )
                }
            }

            // 5. Kriterler (Soru ve Kriter Listesi)
            item {
                when (uiState.examType) {
                    ExamType.HOMEWORK -> RubricSectionHeader("Görev/Madde Kriterleri", "Her görev/madde için ayrıntılı değerlendirme anahtarını belirleyin")
                    ExamType.READINESS -> RubricSectionHeader("Hazırbulunuşluk Soru Kriterleri", "Her soruda konu/ünite öncesi mevcut ön koşul bilgi ve beceriyi hangi kanıtlarla ölçeceğinizi belirleyin")
                    else -> RubricSectionHeader("Soru Kriterleri", "Her soru için ayrıntılı değerlendirme anahtarını belirleyin")
                }
            }

            if (uiState.questions.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp)
                            .testTag(RubricTestTags.EMPTY_QUESTIONS)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = if (uiState.examType == ExamType.HOMEWORK) "Henüz görev/madde bulunmuyor." else "Henüz soru bulunmuyor.",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (uiState.examType == ExamType.HOMEWORK) "Önce görev/maddeleri ekleyip puanlarını belirlemelisiniz." else "Önce soruları ekleyip puanlarını belirlemelisiniz.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            } else {
                items(
                    items = uiState.questions.sortedBy { it.orderIndex },
                    key = { question -> question.orderIndex }
                ) { question ->
                    BaykusCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag(RubricTestTags.question(question.orderIndex)),
                        elevation = 1.dp
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (uiState.examType == ExamType.HOMEWORK) "Görev/Madde ${question.questionNumber}" else "Soru ${question.questionNumber}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = WiseAmberSecondary.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "${question.points} Puan",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = question.questionText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            val criteriaForQuestion = uiState.editableCriteria
                                .filter { it.questionOrderIndex == question.orderIndex }

                            if (criteriaForQuestion.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                        .padding(12.dp)
                                        .testTag(RubricTestTags.emptyCriteria(question.orderIndex))
                                ) {
                                    Text(
                                        text = when (uiState.examType) {
                                            ExamType.HOMEWORK -> "Bu görev/madde için henüz kriter eklenmedi."
                                            ExamType.READINESS -> "Bu hazırbulunuşluk sorusu için henüz kriter eklenmedi."
                                            else -> "Bu soru için henüz kriter eklenmedi."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            } else {
                                Column(
                                    modifier = Modifier.testTag(RubricTestTags.criteria(question.orderIndex)),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    criteriaForQuestion
                                        .sortedWith(compareBy({ it.criterionOrderIndex }, { it.localId }))
                                        .forEach { criterion ->
                                            Card(
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag(RubricTestTags.criterion(criterion.localId))
                                            ) {
                                                Column(modifier = Modifier.padding(14.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        OutlinedTextField(
                                                            value = criterion.title,
                                                            onValueChange = { onCriterionTitleChange(criterion.localId, it) },
                                                            label = { Text("Kriter Başlığı") },
                                                            singleLine = true,
                                                            enabled = controlsEnabled,
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .testTag(RubricTestTags.criterionTitleInput(criterion.localId))
                                                        )
                                                        OutlinedTextField(
                                                            value = criterion.maxPointsText,
                                                            onValueChange = { onCriterionMaxPointsChange(criterion.localId, it) },
                                                            label = { Text("Puan") },
                                                            singleLine = true,
                                                            enabled = controlsEnabled,
                                                            modifier = Modifier
                                                                .weight(0.4f)
                                                                .testTag(RubricTestTags.criterionMaxPointsInput(criterion.localId))
                                                        )
                                                    }

                                                    Spacer(modifier = Modifier.height(16.dp))

                                                    Text(
                                                        text = "Ayrıntılar",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = MaterialTheme.colorScheme.primary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    OutlinedTextField(
                                                        value = criterion.description,
                                                        onValueChange = { onCriterionDescriptionChange(criterion.localId, it) },
                                                        label = { Text("Açıklama") },
                                                        singleLine = false,
                                                        minLines = 2,
                                                        enabled = controlsEnabled,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag(RubricTestTags.criterionDescriptionInput(criterion.localId))
                                                    )

                                                    Spacer(modifier = Modifier.height(16.dp))

                                                    Text(
                                                        text = "Değerlendirme Rehberi",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = MaterialTheme.colorScheme.primary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    OutlinedTextField(
                                                        value = criterion.expectedAnswer,
                                                        onValueChange = { onCriterionExpectedAnswerChange(criterion.localId, it) },
                                                        label = { Text("İdeal Yanıt / Beklenen Doğru") },
                                                        singleLine = false,
                                                        minLines = 2,
                                                        enabled = controlsEnabled,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag(RubricTestTags.expectedAnswer(criterion.localId))
                                                    )

                                                    Spacer(modifier = Modifier.height(10.dp))

                                                    OutlinedTextField(
                                                        value = criterion.partialCreditGuidance,
                                                        onValueChange = { onCriterionPartialCreditGuidanceChange(criterion.localId, it) },
                                                        label = { Text("Kısmi Puanlama") },
                                                        singleLine = false,
                                                        minLines = 2,
                                                        enabled = controlsEnabled,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag(RubricTestTags.partialCreditGuidance(criterion.localId))
                                                    )

                                                    Spacer(modifier = Modifier.height(10.dp))

                                                    OutlinedTextField(
                                                        value = criterion.commonMistakes,
                                                        onValueChange = { onCriterionCommonMistakesChange(criterion.localId, it) },
                                                        label = { Text("Yaygın Öğrenci Hataları") },
                                                        singleLine = false,
                                                        minLines = 2,
                                                        enabled = controlsEnabled,
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .testTag(RubricTestTags.commonMistakes(criterion.localId))
                                                    )
                                                }
                                            }
                                        }
                                }
                            }
                        }
                    }
                }
            }

            // 5b. Tek işlem: doğrula -> kaydet -> onayla/kilitle -> ilerle
            item {
                RubricSectionHeader("Onay", "Tüm düzenlemeleri bitirdikten sonra tek adımda kaydedip ilerleyin")
                Spacer(modifier = Modifier.height(4.dp))
                if (!uiState.isLocked) {
                    Button(
                        onClick = if (uiState.hasUnsavedChanges) onSaveClick else onLockClick,
                        enabled = !uiState.isSaving && !uiState.isLocking && (uiState.canSave || uiState.canLock),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                            .testTag(RubricTestTags.LOCK_BUTTON)
                    ) {
                        Text(
                            text = when {
                                uiState.isSaving -> "Kaydediliyor..."
                                uiState.isLocking -> "Onaylanıyor..."
                                else -> "Kaydet ve İlerle"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    val unlockEnabled = uiState.draftExists &&
                        !uiState.isLoading &&
                        !uiState.isSaving &&
                        !uiState.isLocking &&
                        !uiState.isUnlocking &&
                        uiState.isLocked
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onUnlockClick,
                            enabled = unlockEnabled,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 46.dp)
                                .testTag(RubricTestTags.UNLOCK_BUTTON)
                        ) {
                            Text("Düzenlemeye Aç", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onContinueClick,
                            enabled = uiState.canContinue,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 46.dp)
                                .testTag(RubricTestTags.CONTINUE_BUTTON)
                        ) {
                            Text("İlerle", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // 6. Öğretmen Değerlendirme Rubriği PDF işlemleri
            item {
                RubricSectionHeader("Değerlendirme Rubriği PDF", "Çıktı alma, önizleme ve paylaşma işlemleri")
                Spacer(modifier = Modifier.height(4.dp))
                TeacherRubricPdfSection(
                    uiState = uiState,
                    onGeneratePdf = onGeneratePdf,
                    onSavePdf = onSavePdf,
                    onSharePdf = onSharePdf,
                    onSelectPage = onSelectPage
                )
            }
        }
    }
}

@Composable
internal fun TeacherRubricPdfSection(
    uiState: RubricUiState,
    onGeneratePdf: (Context) -> Unit,
    onSavePdf: (Context) -> Unit,
    onSharePdf: (File) -> Unit,
    onSelectPage: (Int) -> Unit
) {
    val context = LocalContext.current
    val file = uiState.generatedPdfFile
    val isLocked = uiState.isLocked

    BaykusCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Öğretmen Değerlendirme Rubriği (PDF)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                val statusText = if (!isLocked) "Kilitli Değil" else if (uiState.isPdfUpToDate) "Güncel" else if (file != null) "Güncellenmeli" else "Oluşturulmadı"
                val statusType = if (!isLocked) StatusType.INFO else if (uiState.isPdfUpToDate) StatusType.SUCCESS else StatusType.WARNING
                BaykusStatusChip(text = statusText, type = statusType)
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!isLocked) {
                Text(
                    text = "PDF oluşturmak ve önizlemek için rubriği kilitleyin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                if (!uiState.isPdfUpToDate && uiState.pdfStaleTitle != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WiseAmberSecondary.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = uiState.pdfStaleTitle!!, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            if (uiState.pdfStaleSubtitle != null) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = uiState.pdfStaleSubtitle!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BaykusPrimaryButton(
                        text = if (file == null) "PDF Oluştur" else if (uiState.isPdfUpToDate) "PDF'yi Yenile" else "PDF'yi Güncelle",
                        onClick = { onGeneratePdf(context) },
                        isLoading = uiState.isGeneratingPdf,
                        modifier = Modifier.weight(1f)
                    )
                    if (file != null && file.exists()) {
                        BaykusSecondaryButton(
                            text = "Kaydet",
                            onClick = { onSavePdf(context) },
                            modifier = Modifier.weight(0.8f)
                        )
                        BaykusSecondaryButton(
                            text = "Paylaş",
                            onClick = { onSharePdf(file) },
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }

                if (uiState.isGeneratingPdf && uiState.pdfGenerationProgress != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = uiState.pdfGenerationProgress!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }

                if (file != null && file.exists()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    ZoomableTeacherRubricPreview(
                        file = file,
                        selectedPageIndex = uiState.selectedPreviewPageIndex,
                        pageCount = uiState.pdfPageCount,
                        onSelectPage = onSelectPage
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomableTeacherRubricPreview(
    file: File,
    selectedPageIndex: Int,
    pageCount: Int,
    onSelectPage: (Int) -> Unit
) {
    var isFullscreenOpen by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (pageCount > 1) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (selectedPageIndex > 1) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPage(selectedPageIndex - 1)
                            }
                        },
                        enabled = selectedPageIndex > 1,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Önceki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "Sayfa $selectedPageIndex / $pageCount",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedButton(
                        onClick = {
                            if (selectedPageIndex < pageCount) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPage(selectedPageIndex + 1)
                            }
                        },
                        enabled = selectedPageIndex < pageCount,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Sonraki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = scale <= 1.05f,
                    onClick = {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                    },
                    label = { Text("Sığdır", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = scale in 1.8f..2.4f,
                    onClick = {
                        scale = 2.1f
                        offsetX = 0f
                        offsetY = 0f
                    },
                    label = { Text("Genişliğe Sığdır", fontSize = 11.sp) }
                )
            }

            OutlinedButton(
                onClick = { isFullscreenOpen = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tam Ekran İncele", fontSize = 11.sp)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f / 1.414f)
                .clip(RoundedCornerShape(6.dp))
                .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                .background(Color(0xFFE2E8F0))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1.2f) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            } else {
                                scale = 2.2f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        },
                        onTap = {
                            isFullscreenOpen = true
                        }
                    )
                }
                .pointerInput(selectedPageIndex, pageCount, scale) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        if (scale <= 1.05f && pageCount > 1) {
                            if (dragAmount < -50f && selectedPageIndex < pageCount) {
                                change.consume()
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPage(selectedPageIndex + 1)
                            } else if (dragAmount > 50f && selectedPageIndex > 1) {
                                change.consume()
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPage(selectedPageIndex - 1)
                            }
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 4f)
                        scale = newScale
                        if (newScale > 1f) {
                            offsetX += pan.x
                            offsetY += pan.y
                        } else {
                            offsetX = 0f
                            offsetY = 0f
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val bitmap = remember(file, selectedPageIndex) {
                renderPdfPageToBitmap(file, selectedPageIndex)
            }
            if (bitmap != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Öğretmen Rubriği PDF Önizleme",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Text("Önizleme yüklenemedi.", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }

    if (isFullscreenOpen) {
        Dialog(
            onDismissRequest = { isFullscreenOpen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            var fsScale by remember { mutableFloatStateOf(1f) }
            var fsOffsetX by remember { mutableFloatStateOf(0f) }
            var fsOffsetY by remember { mutableFloatStateOf(0f) }

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF1E293B)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Surface(
                        color = Color(0xFF0F172A),
                        tonalElevation = 4.dp
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .statusBarsPadding()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(onClick = { isFullscreenOpen = false }) {
                                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                                    }
                                    Text(
                                        text = "Öğretmen Rubriği İnceleme (Sayfa $selectedPageIndex / $pageCount)",
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            fsScale = 1f
                                            fsOffsetX = 0f
                                            fsOffsetY = 0f
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, Color.Gray),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("Sığdır", fontSize = 11.sp)
                                    }
                                    IconButton(
                                        onClick = { fsScale = (fsScale + 0.5f).coerceAtMost(4f) }
                                    ) {
                                        Icon(Icons.Default.ZoomIn, contentDescription = "Yakınlaştır", tint = Color.White)
                                    }
                                    IconButton(
                                        onClick = {
                                            fsScale = (fsScale - 0.5f).coerceAtLeast(1f)
                                            if (fsScale == 1f) {
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.ZoomOut, contentDescription = "Uzaklaştır", tint = Color.White)
                                    }
                                }
                            }

                            if (pageCount > 1) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = {
                                            if (selectedPageIndex > 1) {
                                                fsScale = 1f
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                                onSelectPage(selectedPageIndex - 1)
                                            }
                                        },
                                        enabled = selectedPageIndex > 1
                                    ) {
                                        Text("Önceki Sayfa", color = if (selectedPageIndex > 1) Color.White else Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Sayfa $selectedPageIndex / $pageCount", color = Color.White, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    TextButton(
                                        onClick = {
                                            if (selectedPageIndex < pageCount) {
                                                fsScale = 1f
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                                onSelectPage(selectedPageIndex + 1)
                                            }
                                        },
                                        enabled = selectedPageIndex < pageCount
                                    ) {
                                        Text("Sonraki Sayfa", color = if (selectedPageIndex < pageCount) Color.White else Color.Gray)
                                    }
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F172A))
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (fsScale * zoom).coerceIn(1f, 4f)
                                    fsScale = newScale
                                    if (newScale > 1f) {
                                        fsOffsetX += pan.x
                                        fsOffsetY += pan.y
                                    } else {
                                        fsOffsetX = 0f
                                        fsOffsetY = 0f
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        val fsBitmap = remember(file, selectedPageIndex) {
                            renderPdfPageToBitmap(file, selectedPageIndex)
                        }
                        if (fsBitmap != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer(
                                        scaleX = fsScale,
                                        scaleY = fsScale,
                                        translationX = fsOffsetX,
                                        translationY = fsOffsetY
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                androidx.compose.foundation.Image(
                                    bitmap = fsBitmap.asImageBitmap(),
                                    contentDescription = "Öğretmen Rubriği Tam Ekran Önizleme",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun renderPdfPageToBitmap(pdfFile: File, pageIndex1Based: Int): android.graphics.Bitmap? {
    try {
        if (!pdfFile.exists()) return null
        android.os.ParcelFileDescriptor.open(pdfFile, android.os.ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            android.graphics.pdf.PdfRenderer(pfd).use { renderer ->
                if (renderer.pageCount <= 0) return null
                val safeIdx = (pageIndex1Based - 1).coerceIn(0, renderer.pageCount - 1)
                renderer.openPage(safeIdx).use { page ->
                    val width = (page.width * 2.0).toInt()
                    val height = (page.height * 2.0).toInt()
                    val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                }
            }
        }
    } catch (e: Exception) {
        return null
    }
}
