package com.example.core.data

import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.QuestionPointsValidationResult

sealed interface SaveExamQuestionsResult {

    data class Success(
        val metadata: ExamQuestionSetMetadata,
        val validation: QuestionPointsValidationResult
    ) : SaveExamQuestionsResult

    data object DraftNotFound : SaveExamQuestionsResult

    data class ValidationFailed(
        val validation: QuestionPointsValidationResult
    ) : SaveExamQuestionsResult

    data class Locked(
        val currentRevision: Int
    ) : SaveExamQuestionsResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : SaveExamQuestionsResult

    data class Failure(
        val cause: Throwable
    ) : SaveExamQuestionsResult
}

sealed interface LockExamQuestionSetResult {

    data class Success(
        val metadata: ExamQuestionSetMetadata
    ) : LockExamQuestionSetResult

    data object DraftNotFound : LockExamQuestionSetResult

    data object MetadataMissing : LockExamQuestionSetResult

    data class ValidationFailed(
        val validation: QuestionPointsValidationResult
    ) : LockExamQuestionSetResult

    data class AlreadyLocked(
        val currentRevision: Int
    ) : LockExamQuestionSetResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : LockExamQuestionSetResult

    data class Failure(
        val cause: Throwable
    ) : LockExamQuestionSetResult
}

sealed interface UnlockExamQuestionSetResult {

    data class Success(
        val metadata: ExamQuestionSetMetadata
    ) : UnlockExamQuestionSetResult

    data object MetadataMissing : UnlockExamQuestionSetResult

    data class AlreadyUnlocked(
        val currentRevision: Int
    ) : UnlockExamQuestionSetResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : UnlockExamQuestionSetResult

    data class Failure(
        val cause: Throwable
    ) : UnlockExamQuestionSetResult
}
