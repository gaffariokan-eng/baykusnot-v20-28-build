package com.example.core.model

/** Shared, deterministic rules for Test Sınavı option parsing and answer-key locking. */
object MultipleChoiceOptionPolicy {
    fun normalizeChoice(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val trimmed = text.trim().uppercase()
        if (trimmed.matches(Regex("^[A-H]$"))) return trimmed
        // Java/Kotlin \b can treat Turkish letters such as Ç/Ğ/İ inconsistently
        // around ASCII option letters. Match only truly standalone A-H tokens.
        val choices = Regex("""(?<![\p{L}\p{N}])([A-H])(?![\p{L}\p{N}])""")
            .findAll(trimmed)
            .mapNotNull { it.groupValues.getOrNull(1) }
            .distinct()
            .toList()
        return choices.singleOrNull()
    }

    fun detectLabels(questionText: String): List<String> {
        val regex = Regex(
            """(?:^|\n|\s)\(?([A-H])\)?[\)\.\:\-]\s+""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
        )
        val labels = regex.findAll(questionText)
            .map { it.groupValues[1].uppercase() }
            .distinct()
            .take(8)
            .toList()
        return if (labels.size >= 2) labels else listOf("A", "B", "C", "D", "E")
    }

}


object MultipleChoiceTestStructurePolicy {
    const val MAX_QUESTION_COUNT = 200

    fun optionLabels(optionCount: Int): List<String> =
        (0 until optionCount.coerceIn(2, 8)).map { ('A'.code + it).toChar().toString() }

    /** Returns positive integer points whose sum is exactly [totalPoints], or empty if impossible. */
    fun distributePoints(questionCount: Int, totalPoints: Int): List<Int> {
        if (questionCount !in 1..MAX_QUESTION_COUNT || totalPoints < questionCount) return emptyList()
        val base = totalPoints / questionCount
        val remainder = totalPoints % questionCount
        return (1..questionCount).map { order -> base + if (order <= remainder) 1 else 0 }
    }
}

object MultipleChoiceAnswerKeyPolicy {
    fun validate(
        questions: List<ExamQuestion>,
        criteria: List<ExamRubricCriterion>
    ): List<ExamRubricValidationIssue> {
        val issues = mutableListOf<ExamRubricValidationIssue>()
        for (question in questions.sortedBy { it.orderIndex }) {
            val questionCriteria = criteria.filter { it.questionOrderIndex == question.orderIndex }
            if (questionCriteria.size != 1) {
                issues += ExamRubricValidationIssue(
                    code = ExamRubricValidationCode.MULTIPLE_CHOICE_CRITERION_COUNT_MISMATCH,
                    questionOrderIndex = question.orderIndex,
                    value = "expected=1,actual=${questionCriteria.size}"
                )
                continue
            }

            val criterion = questionCriteria.single()
            val answerSource = criterion.expectedAnswer.ifBlank { criterion.originalAnswerKey.orEmpty() }
            val normalized = MultipleChoiceOptionPolicy.normalizeChoice(answerSource)
            if (normalized == null) {
                issues += ExamRubricValidationIssue(
                    code = ExamRubricValidationCode.INVALID_MULTIPLE_CHOICE_EXPECTED_ANSWER,
                    questionOrderIndex = question.orderIndex,
                    criterionOrderIndex = criterion.criterionOrderIndex,
                    value = answerSource
                )
            }
        }
        return issues
    }
}


data class MultipleChoiceAnswerKeyParseResult(
    val answersByQuestionNumber: Map<String, String>,
    val unparsedTokens: List<String>
)

object MultipleChoiceAnswerKeyTextParser {
    /** Accepts forms such as `1-A 2:C 3D`, comma/newline/semicolon separated. */
    fun parse(raw: String): MultipleChoiceAnswerKeyParseResult {
        if (raw.isBlank()) return MultipleChoiceAnswerKeyParseResult(emptyMap(), emptyList())
        val normalized = raw.uppercase()
        val pattern = Regex("""(?<!\d)(\d{1,3})\s*[-:=.),;]?\s*([A-H])(?![A-Z])""")
        val answers = linkedMapOf<String, String>()
        pattern.findAll(normalized).forEach { match ->
            answers[match.groupValues[1]] = match.groupValues[2]
        }

        // A teacher may also paste a compact sequential key such as "ACDBE".
        // Only use this fallback when there are no explicit question numbers.
        if (answers.isEmpty() && normalized.none { it.isDigit() }) {
            val compact = normalized.filter { it in 'A'..'H' }
            val nonChoice = normalized.filter { it !in 'A'..'H' && !it.isWhitespace() && it !in ",;|/-" }
            if (compact.length >= 2 && nonChoice.isEmpty()) {
                compact.forEachIndexed { index, choice -> answers[(index + 1).toString()] = choice.toString() }
                return MultipleChoiceAnswerKeyParseResult(answers, emptyList())
            }
        }

        val leftovers = normalized
            .replace(pattern, " ")
            .split(Regex("""[\s,;|/]+"""))
            .map { it.trim() }
            .filter { it.isNotBlank() }
        return MultipleChoiceAnswerKeyParseResult(answers, leftovers)
    }
}


data class MultipleChoiceManualResolution(
    val selectedChoice: String?,
    val expectedChoice: String,
    val score: Double,
    val answerType: String,
    val feedback: String
)

object MultipleChoiceManualReviewPolicy {
    fun resolve(selectedChoice: String?, expectedChoice: String?, maxScore: Double): MultipleChoiceManualResolution? {
        val expected = MultipleChoiceOptionPolicy.normalizeChoice(expectedChoice) ?: return null
        val selected = MultipleChoiceOptionPolicy.normalizeChoice(selectedChoice)
        val score = if (selected != null && selected == expected) maxScore.coerceAtLeast(0.0) else 0.0
        return MultipleChoiceManualResolution(
            selectedChoice = selected,
            expectedChoice = expected,
            score = score,
            answerType = if (selected == null) "UNANSWERED" else "MULTIPLE_CHOICE",
            feedback = when {
                selected == null -> "Boş"
                selected == expected -> "Doğru"
                else -> "Yanlış — doğru cevap: $expected"
            }
        )
    }
}


data class MultipleChoiceReportAnswer(
    val score: Double,
    val maxScore: Double,
    val answerType: String,
    val readAnswerText: String = ""
)

data class MultipleChoiceReportTally(
    val correct: Int,
    val wrong: Int,
    val blank: Int
)

object MultipleChoiceReportPolicy {
    fun tally(answers: List<MultipleChoiceReportAnswer>): MultipleChoiceReportTally {
        val blank = answers.count { it.answerType == "UNANSWERED" }
        val correct = answers.count { it.maxScore > 0.0 && kotlin.math.abs(it.score - it.maxScore) < 0.0001 }
        val wrong = answers.size - correct - blank
        return MultipleChoiceReportTally(correct = correct, wrong = wrong.coerceAtLeast(0), blank = blank)
    }

    fun choiceDistribution(answers: List<MultipleChoiceReportAnswer>): Map<String, Int> =
        answers.asSequence()
            .mapNotNull { MultipleChoiceOptionPolicy.normalizeChoice(it.readAnswerText) }
            .groupingBy { it }
            .eachCount()
            .toSortedMap()
}

enum class OpticalChoiceStatus { MARKED, BLANK, MULTIPLE, AMBIGUOUS }

data class OpticalChoiceClassification(
    val status: OpticalChoiceStatus,
    val choice: String? = null,
    val confidence: Double = 0.0,
    val reason: String? = null
)

object MultipleChoiceOpticalClassifier {
    /**
     * Classifies fill ratios sampled from the *interior* of empty answer bubbles.
     * No network/AI is involved. Thresholds are deliberately conservative so
     * uncertain marks are sent to teacher review rather than guessed.
     */
    fun classify(
        fillsByChoice: Map<String, Double>,
        markedThreshold: Double = 0.18,
        ambiguityMargin: Double = 0.07
    ): OpticalChoiceClassification {
        if (fillsByChoice.isEmpty()) {
            return OpticalChoiceClassification(OpticalChoiceStatus.AMBIGUOUS, reason = "Seçenek alanı bulunamadı.")
        }
        val ranked = fillsByChoice.entries.sortedByDescending { it.value }
        val first = ranked.first()
        val secondValue = ranked.getOrNull(1)?.value ?: 0.0
        val above = ranked.filter { it.value >= markedThreshold }
        if (above.isEmpty()) {
            val confidence = (1.0 - (first.value / markedThreshold).coerceIn(0.0, 1.0)).coerceIn(0.0, 1.0)
            return OpticalChoiceClassification(OpticalChoiceStatus.BLANK, confidence = confidence)
        }
        if (above.size >= 2) {
            return OpticalChoiceClassification(
                OpticalChoiceStatus.MULTIPLE,
                confidence = 0.0,
                reason = "Birden fazla seçenek işaretli görünüyor."
            )
        }
        val margin = first.value - secondValue
        if (margin < ambiguityMargin) {
            return OpticalChoiceClassification(
                OpticalChoiceStatus.AMBIGUOUS,
                confidence = (margin / ambiguityMargin).coerceIn(0.0, 1.0),
                reason = "İşaret yeterince belirgin değil."
            )
        }
        return OpticalChoiceClassification(
            OpticalChoiceStatus.MARKED,
            choice = first.key,
            confidence = ((first.value - markedThreshold) / (1.0 - markedThreshold)).coerceIn(0.0, 1.0)
                .coerceAtLeast((margin / 0.30).coerceIn(0.0, 1.0))
        )
    }
}
