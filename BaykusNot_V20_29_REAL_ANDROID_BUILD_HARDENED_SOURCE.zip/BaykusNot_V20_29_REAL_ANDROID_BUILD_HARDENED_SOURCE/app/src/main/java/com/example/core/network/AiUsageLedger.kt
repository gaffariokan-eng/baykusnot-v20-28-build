package com.example.core.network

import com.example.core.database.ExamAiUsageEntity
import com.example.core.database.ExamEvaluationDao

/** Shared audit/cost ledger for AI work outside the student-evaluation pipeline. */
class AiUsageLedger(private val dao: ExamEvaluationDao) {
    suspend fun recordAuthoring(
        examDraftId: Long,
        stage: String,
        requestedModelId: String,
        profileSnapshot: GeminiModelProfile,
        usage: AiUsageMetadata
    ) {
        if (examDraftId <= 0L) return
        val cached = usage.cachedInputTokens.coerceIn(0L, usage.inputTokens.coerceAtLeast(0L))
        val uncached = (usage.inputTokens - cached).coerceAtLeast(0L)
        val output = (usage.outputTokens + usage.thinkingTokens).coerceAtLeast(0L)
        val cost = (
            uncached * profileSnapshot.authoringInputPerMillionUsd +
                cached * profileSnapshot.authoringCachedInputPerMillionUsd +
                output * profileSnapshot.authoringOutputPerMillionUsd
            ) / 1_000_000.0
        dao.insertAiUsage(
            ExamAiUsageEntity(
                examDraftId = examDraftId,
                stage = stage,
                modelId = requestedModelId,
                useBatchPricing = false,
                inputTokens = usage.inputTokens,
                cachedInputTokens = usage.cachedInputTokens,
                outputTokens = usage.outputTokens,
                thinkingTokens = usage.thinkingTokens,
                estimatedCostUsd = cost,
                actualModelVersion = usage.actualModelVersion,
                responseId = usage.responseId,
                modelStatusStage = usage.modelStatusStage,
                modelRetirementTime = usage.modelRetirementTime,
                modelStatusMessage = usage.modelStatusMessage
            )
        )
    }
}
