package com.example.feature.workflow

import com.example.core.model.ExamQuestion

data class QuestionPointsEditableMapping(
    val editableQuestions: List<EditableExamQuestion>,
    val nextLocalId: Long
)

object QuestionPointsEditableMapper {

    fun map(
        questions: List<ExamQuestion>,
        firstLocalId: Long
    ): QuestionPointsEditableMapping {
        require(firstLocalId > 0L) { "firstLocalId must be positive" }
        if (Long.MAX_VALUE - firstLocalId < questions.size) {
            throw IllegalArgumentException("Local ID overflow")
        }

        val editableQuestions = questions.mapIndexed { index, q ->
            EditableExamQuestion(
                localId = firstLocalId + index,
                persistedId = q.id,
                orderIndex = q.orderIndex,
                questionNumber = q.questionNumber,
                questionText = q.questionText,
                pointsText = q.points.toString()
            )
        }

        val nextLocalId = firstLocalId + questions.size

        return QuestionPointsEditableMapping(
            editableQuestions = editableQuestions,
            nextLocalId = nextLocalId
        )
    }
}
