package com.example.core.data

import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.network.ExamStudentEvaluationOutput
import com.example.core.network.QuestionEvaluationOutput
import com.example.core.model.MultipleChoiceOptionPolicy

/**
 * Deterministic scoring guard for multiple-choice tests.
 * Current Test Sınavı flow reads BaykuşNot optical forms locally; this object also
 * remains as a defensive normalizer for any legacy evaluation rows created by
 * earlier builds. The locked teacher answer key is always authoritative and a
 * test item can only receive zero or its full question score.
 */
object MultipleChoiceScoringPolicy {

    fun normalize(
        questions: List<ExamQuestionEntity>,
        rubrics: List<ExamRubricCriterionEntity>,
        output: ExamStudentEvaluationOutput
    ): ExamStudentEvaluationOutput {
        val rawByOrder = output.questionEvaluations.groupBy { it.questionOrderIndex }
        val lockedOrders = questions.map { it.orderIndex }.toSet()
        val hasUnknownOutputs = output.questionEvaluations.any { it.questionOrderIndex !in lockedOrders }
        val hasDuplicateOutputs = rawByOrder.values.any { it.size > 1 }

        val normalizedQuestions = questions.sortedBy { it.orderIndex }.map { question ->
            val candidates = rawByOrder[question.orderIndex].orEmpty()
            val raw = candidates.firstOrNull() ?: QuestionEvaluationOutput(
                questionNumber = question.questionNumber,
                questionOrderIndex = question.orderIndex,
                readAnswerText = "",
                score = 0.0,
                maxScore = question.points.toDouble(),
                feedback = null,
                readingConfidence = 0.0,
                evaluationConfidence = 0.0,
                answerType = "UNREADABLE",
                needsReview = true,
                reviewReason = "Bu test sorusu için değerlendirme çıktısı alınamadı."
            )
            val normalized = normalizeQuestion(question, rubrics, raw)
            if (candidates.size > 1) {
                normalized.copy(
                    needsReview = true,
                    reviewReason = appendReason(normalized.reviewReason, "Aynı test sorusu için birden fazla değerlendirme çıktısı geldi.")
                )
            } else normalized
        }.toMutableList()

        if (hasUnknownOutputs && normalizedQuestions.isNotEmpty()) {
            val first = normalizedQuestions.first()
            normalizedQuestions[0] = first.copy(
                needsReview = true,
                reviewReason = appendReason(first.reviewReason, "Kilitli soru setinde bulunmayan test değerlendirme çıktısı geldi.")
            )
        }

        val totalScore = normalizedQuestions.sumOf { it.score }
        val totalMaxScore = questions.sumOf { it.points.toDouble().coerceAtLeast(0.0) }
        val overallConfidence = if (normalizedQuestions.isEmpty()) 1.0 else normalizedQuestions
            .map { (it.readingConfidence + it.evaluationConfidence) / 2.0 }
            .average()
        val needsReview = normalizedQuestions.any { it.needsReview } ||
            hasUnknownOutputs || hasDuplicateOutputs || overallConfidence < 0.70

        return output.copy(
            questionEvaluations = normalizedQuestions,
            spellingPunctuationFeedback = null,
            spellingPunctuationDeduction = 0.0,
            totalScore = totalScore,
            totalMaxScore = totalMaxScore,
            overallConfidence = overallConfidence,
            needsReview = needsReview
        )
    }

    fun normalizeChoice(text: String?): String? = MultipleChoiceOptionPolicy.normalizeChoice(text)

    private fun normalizeQuestion(
        question: ExamQuestionEntity,
        rubrics: List<ExamRubricCriterionEntity>,
        raw: QuestionEvaluationOutput
    ): QuestionEvaluationOutput {
        val maxScore = question.points.toDouble().coerceAtLeast(0.0)
        val relevantRubrics = rubrics.filter {
            it.questionOrderIndex == question.orderIndex ||
                it.questionNumberSnapshot.trim().equals(question.questionNumber.trim(), ignoreCase = true)
        }
        val expectedChoice = relevantRubrics.asSequence()
            .mapNotNull { normalizeChoice(it.expectedAnswer.ifBlank { it.originalAnswerKey.orEmpty() }) }
            .firstOrNull()

        val authoritativeRaw = raw.copy(
            questionNumber = question.questionNumber,
            questionOrderIndex = question.orderIndex
        )
        val answerType = authoritativeRaw.answerType.uppercase()
        if (answerType == "UNANSWERED") {
            return authoritativeRaw.copy(score = 0.0, maxScore = maxScore)
        }
        if (answerType == "UNREADABLE" || answerType == "LOW_CONFIDENCE") {
            return authoritativeRaw.copy(
                score = 0.0,
                maxScore = maxScore,
                needsReview = true,
                reviewReason = appendReason(authoritativeRaw.reviewReason, "İşaretlenen seçenek güvenilir biçimde belirlenemedi.")
            )
        }

        if (expectedChoice == null) {
            return authoritativeRaw.copy(
                score = 0.0,
                maxScore = maxScore,
                needsReview = true,
                reviewReason = appendReason(authoritativeRaw.reviewReason, "Kilitli cevap anahtarında doğru seçenek belirlenemedi.")
            )
        }

        val markedChoice = normalizeChoice(authoritativeRaw.readAnswerText)
        if (markedChoice == null) {
            return authoritativeRaw.copy(
                score = 0.0,
                maxScore = maxScore,
                needsReview = true,
                reviewReason = appendReason(authoritativeRaw.reviewReason, "Öğrencinin işaretlediği seçenek belirlenemedi.")
            )
        }

        return authoritativeRaw.copy(
            readAnswerText = markedChoice,
            score = if (markedChoice == expectedChoice) maxScore else 0.0,
            maxScore = maxScore
        )
    }

    private fun appendReason(existing: String?, newReason: String): String =
        if (existing.isNullOrBlank()) newReason else "$existing $newReason"
}
