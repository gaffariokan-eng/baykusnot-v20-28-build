package com.example.core.data

import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamListeningMaterialDao
import com.example.core.database.ExamListeningMaterialEntity
import com.example.core.database.ExamQuestionDao
import com.example.core.database.hasAudio
import com.example.core.model.ExamType
import com.example.core.model.ListeningSourcePolicy
import com.example.core.network.RubricGenerationSourceContext
import java.io.File
import java.io.InputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

enum class ListeningMaterialFailure {
    DRAFT_NOT_FOUND,
    WRONG_EXAM_TYPE,
    UNSUPPORTED_AUDIO_TYPE,
    EMPTY_FILE,
    FILE_TOO_LARGE,
    SOURCE_UNAVAILABLE,
    STORAGE_ERROR,
    INVALID_PLAYBACK_COUNT,
    SOURCE_LOCKED
}

sealed interface ListeningAudioImportResult {
    data class Success(
        val material: ExamListeningMaterialEntity,
        val replacedExisting: Boolean
    ) : ListeningAudioImportResult

    data class Failure(val reason: ListeningMaterialFailure) : ListeningAudioImportResult
}

class ExamListeningMaterialRepository(
    private val filesRoot: File,
    private val materialDao: ExamListeningMaterialDao,
    private val examDraftDao: ExamDraftDao,
    private val questionDao: ExamQuestionDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val nowProvider: () -> Long = System::currentTimeMillis
) {
    fun observe(examDraftId: Long): Flow<ExamListeningMaterialEntity?> =
        materialDao.observeByExamDraftId(examDraftId)

    suspend fun getOnce(examDraftId: Long): ExamListeningMaterialEntity? =
        withContext(ioDispatcher) { materialDao.getByExamDraftIdOnce(examDraftId) }

    suspend fun importAudio(
        examDraftId: Long,
        originalUri: String?,
        displayName: String,
        mimeType: String,
        declaredSizeBytes: Long?,
        openInputStream: () -> InputStream?
    ): ListeningAudioImportResult = withContext(ioDispatcher) {
        val draft = examDraftDao.getDraftByIdOnce(examDraftId)
            ?: return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.DRAFT_NOT_FOUND)
        if (draft.examType != ExamType.LISTENING) {
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.WRONG_EXAM_TYPE)
        }
        if (questionDao.getMetadataByExamDraftIdOnce(examDraftId)?.isLocked == true) {
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.SOURCE_LOCKED)
        }
        if (!isSupportedAudio(mimeType, displayName)) {
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.UNSUPPORTED_AUDIO_TYPE)
        }
        if (declaredSizeBytes == 0L) {
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.EMPTY_FILE)
        }
        if (declaredSizeBytes != null && declaredSizeBytes > MAX_AUDIO_SIZE_BYTES) {
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.FILE_TOO_LARGE)
        }

        val input = try {
            openInputStream()
        } catch (_: Exception) {
            null
        } ?: return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.SOURCE_UNAVAILABLE)

        val directory = resolveManagedFile("exams/$examDraftId/listening")
        if (directory == null || (!directory.exists() && !directory.mkdirs())) {
            input.close()
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.STORAGE_ERROR)
        }

        val tempFile = File(directory, ".audio_${System.nanoTime()}.tmp")
        var actualSize = 0L
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            input.use { source ->
                tempFile.outputStream().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        actualSize += count
                        if (actualSize > MAX_AUDIO_SIZE_BYTES) {
                            tempFile.delete()
                            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.FILE_TOO_LARGE)
                        }
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                    }
                }
            }
        } catch (e: CancellationException) {
            tempFile.delete()
            throw e
        } catch (_: Exception) {
            tempFile.delete()
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.STORAGE_ERROR)
        }

        if (actualSize <= 0L) {
            tempFile.delete()
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.EMPTY_FILE)
        }

        val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
        val extension = extensionFor(mimeType, displayName)
        val importedAt = nowProvider()
        val finalFile = File(directory, "audio_${importedAt}_${sha256.take(12)}$extension")

        try {
            try {
                Files.move(
                    tempFile.toPath(),
                    finalFile.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(
                    tempFile.toPath(),
                    finalFile.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
                )
            }
        } catch (_: Exception) {
            tempFile.delete()
            finalFile.delete()
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.STORAGE_ERROR)
        }

        val existing = materialDao.getByExamDraftIdOnce(examDraftId)
        val relativePath = "exams/$examDraftId/listening/${finalFile.name}"
        val updated = (existing ?: ExamListeningMaterialEntity(examDraftId = examDraftId)).copy(
            localRelativePath = relativePath,
            originalUri = originalUri,
            displayName = displayName.ifBlank { "Dinleme sesi$extension" },
            mimeType = mimeType.ifBlank { mimeFromExtension(extension) },
            sizeBytes = actualSize,
            sha256 = sha256,
            importedAt = importedAt,
            updatedAt = importedAt
        )

        try {
            materialDao.upsert(updated)
        } catch (_: Exception) {
            finalFile.delete()
            return@withContext ListeningAudioImportResult.Failure(ListeningMaterialFailure.STORAGE_ERROR)
        }

        val oldPath = existing?.localRelativePath
        if (!oldPath.isNullOrBlank() && oldPath != relativePath) {
            resolveManagedFile(oldPath)?.delete()
        }

        ListeningAudioImportResult.Success(
            material = updated,
            replacedExisting = existing?.hasAudio() == true
        )
    }

    suspend fun saveDetails(
        examDraftId: Long,
        transcript: String,
        playbackCount: Int,
        instructions: String
    ): Result<ExamListeningMaterialEntity> = withContext(ioDispatcher) {
        if (playbackCount !in 1..3) {
            return@withContext Result.failure(IllegalArgumentException("INVALID_PLAYBACK_COUNT"))
        }
        val draft = examDraftDao.getDraftByIdOnce(examDraftId)
            ?: return@withContext Result.failure(IllegalStateException("DRAFT_NOT_FOUND"))
        if (draft.examType != ExamType.LISTENING) {
            return@withContext Result.failure(IllegalStateException("WRONG_EXAM_TYPE"))
        }
        if (questionDao.getMetadataByExamDraftIdOnce(examDraftId)?.isLocked == true) {
            return@withContext Result.failure(IllegalStateException("SOURCE_LOCKED"))
        }

        val existing = materialDao.getByExamDraftIdOnce(examDraftId)
            ?: ExamListeningMaterialEntity(examDraftId = examDraftId)
        val normalizedTranscript = transcript.trim()
        val updated = existing.copy(
            transcript = normalizedTranscript,
            playbackCount = playbackCount,
            instructions = instructions.trim(),
            // Legacy schema column only; there is no separate transcript approval gate.
            isTranscriptApproved = false,
            updatedAt = nowProvider()
        )
        try {
            materialDao.upsert(updated)
            Result.success(updated)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun removeAudio(examDraftId: Long): Boolean = withContext(ioDispatcher) {
        if (questionDao.getMetadataByExamDraftIdOnce(examDraftId)?.isLocked == true) {
            return@withContext false
        }
        val existing = materialDao.getByExamDraftIdOnce(examDraftId) ?: return@withContext true
        val oldFile = existing.localRelativePath?.let(::resolveManagedFile)
        val updated = existing.copy(
            localRelativePath = null,
            originalUri = null,
            displayName = null,
            mimeType = null,
            sizeBytes = null,
            sha256 = null,
            importedAt = null,
            updatedAt = nowProvider()
        )
        return@withContext try {
            materialDao.upsert(updated)
            oldFile?.delete()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun isAudioUsable(material: ExamListeningMaterialEntity): Boolean = withContext(ioDispatcher) {
        resolveUsableAudioFile(material) != null
    }

    suspend fun isReadyForQuestions(examDraftId: Long): Boolean = withContext(ioDispatcher) {
        val material = materialDao.getByExamDraftIdOnce(examDraftId) ?: return@withContext false
        // Product rule: a listening exam may use either the original audio OR the listening text.
        ListeningSourcePolicy.isReady(
            hasUsableAudio = resolveUsableAudioFile(material) != null,
            listeningText = material.transcript
        )
    }

    /**
     * Returns the single source context that should be sent to rubric generation.
     * Text is preferred when the teacher supplied it because it avoids re-uploading audio
     * and reduces both latency and multimodal token cost. Audio is used only when no text
     * was provided.
     */
    suspend fun getRubricSourceContext(examDraftId: Long): RubricGenerationSourceContext? =
        withContext(ioDispatcher) {
            val material = materialDao.getByExamDraftIdOnce(examDraftId)
                ?: return@withContext null

            val listeningText = material.transcript.trim()
            if (listeningText.isNotBlank()) {
                return@withContext RubricGenerationSourceContext.ListeningText(listeningText)
            }

            val audioFile = resolveUsableAudioFile(material) ?: return@withContext null
            RubricGenerationSourceContext.ListeningAudio(
                file = audioFile,
                mimeType = material.mimeType.orEmpty(),
                displayName = material.displayName ?: audioFile.name,
                sizeBytes = audioFile.length()
            )
        }

    private fun resolveUsableAudioFile(material: ExamListeningMaterialEntity): File? {
        if (!material.hasAudio()) return null
        val path = material.localRelativePath ?: return null
        val file = resolveManagedFile(path) ?: return null
        val expectedSize = material.sizeBytes ?: return null
        return file.takeIf {
            it.exists() && it.isFile && it.canRead() && it.length() == expectedSize
        }
    }

    private fun resolveManagedFile(relativePath: String): File? {
        if (relativePath.isBlank() || relativePath.startsWith("/") || relativePath.contains("..")) return null
        return try {
            val root = filesRoot.canonicalFile
            val candidate = File(root, relativePath).canonicalFile
            val prefix = root.path + File.separator
            candidate.takeIf { it.path.startsWith(prefix) && it.path != root.path }
        } catch (_: Exception) {
            null
        }
    }

    private fun isSupportedAudio(mimeType: String, displayName: String): Boolean {
        if (mimeType.lowercase().startsWith("audio/")) return true
        return displayName.substringAfterLast('.', "").lowercase() in SUPPORTED_EXTENSIONS
    }

    private fun extensionFor(mimeType: String, displayName: String): String {
        val nameExtension = displayName.substringAfterLast('.', "").lowercase()
        if (nameExtension in SUPPORTED_EXTENSIONS) return ".$nameExtension"
        return when (mimeType.lowercase()) {
            "audio/mpeg", "audio/mp3" -> ".mp3"
            "audio/wav", "audio/x-wav", "audio/wave" -> ".wav"
            "audio/mp4", "audio/x-m4a", "audio/m4a" -> ".m4a"
            "audio/aac" -> ".aac"
            "audio/ogg" -> ".ogg"
            "audio/flac", "audio/x-flac" -> ".flac"
            else -> ".audio"
        }
    }

    private fun mimeFromExtension(extension: String): String = when (extension.lowercase()) {
        ".mp3" -> "audio/mpeg"
        ".wav" -> "audio/wav"
        ".m4a" -> "audio/mp4"
        ".aac" -> "audio/aac"
        ".ogg" -> "audio/ogg"
        ".flac" -> "audio/flac"
        else -> "audio/*"
    }

    companion object {
        const val MAX_AUDIO_SIZE_BYTES: Long = 200L * 1024L * 1024L
        private val SUPPORTED_EXTENSIONS = setOf("mp3", "wav", "m4a", "aac", "ogg", "flac")
    }
}
