package com.example.feature.homework

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.LockEvaluationPreferencesResult
import com.example.core.data.LockExamQuestionSetResult
import com.example.core.data.LockExamRubricSetResult
import com.example.core.data.SaveEvaluationPreferencesResult
import com.example.core.data.SaveExamQuestionsResult
import com.example.core.data.SaveExamRubricResult
import com.example.core.model.EvaluationMode
import com.example.core.model.EvaluationPreferences
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.RubricAdherenceLevel
import com.example.core.model.WritingAndPunctuationPreferences
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

private const val HOMEWORK_PREFIX = "ÖDEV TANIMI:\n"

@Composable
fun HomeworkAssignmentScreen(
    draftId: Long,
    draftRepository: ExamDraftRepository,
    questionRepository: ExamQuestionRepository,
    rubricRepository: ExamRubricRepository,
    preferencesRepository: ExamEvaluationPreferencesRepository,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var assignment by remember(draftId) { mutableStateOf("") }
    var isLoading by remember(draftId) { mutableStateOf(true) }
    var isBusy by remember(draftId) { mutableStateOf(false) }
    var isLocked by remember(draftId) { mutableStateOf(false) }
    var message by remember(draftId) { mutableStateOf<String?>(null) }

    suspend fun unlockPartialHomeworkContract(): Boolean {
        val prefs = preferencesRepository.observePreferences(draftId).first()
        if (prefs?.isLocked == true && !preferencesRepository.unlockPreferences(draftId)) return false

        val rubricMeta = rubricRepository.getMetadataOnce(draftId)
        if (rubricMeta?.isLocked == true) {
            val result = rubricRepository.unlockRubricSet(draftId, rubricMeta.revision)
            if (result !is com.example.core.data.UnlockExamRubricSetResult.Success &&
                result !is com.example.core.data.UnlockExamRubricSetResult.AlreadyUnlocked) return false
        }

        val questionMeta = questionRepository.getMetadataOnce(draftId)
        if (questionMeta?.isLocked == true) {
            val result = questionRepository.unlockQuestionSet(draftId, questionMeta.revision)
            if (result !is com.example.core.data.UnlockExamQuestionSetResult.Success &&
                result !is com.example.core.data.UnlockExamQuestionSetResult.AlreadyUnlocked) return false
        }
        return true
    }

    suspend fun reload() {
        try {
            val questions = questionRepository.getQuestionsOnce(draftId)
            val qMeta = questionRepository.getMetadataOnce(draftId)
            val rMeta = rubricRepository.getMetadataOnce(draftId)
            val prefs = preferencesRepository.observePreferences(draftId).first()
            assignment = questions.firstOrNull()?.questionText
                ?.removePrefix(HOMEWORK_PREFIX)
                ?.substringBefore("\n\nDEĞERLENDİRME TALİMATI:")
                ?.trim()
                .orEmpty()

            val fullyLocked = qMeta?.isLocked == true &&
                rMeta?.isLocked == true &&
                rMeta.questionSetRevision == qMeta.revision &&
                prefs?.isLocked == true
            val anyLocked = qMeta?.isLocked == true || rMeta?.isLocked == true || prefs?.isLocked == true

            if (!fullyLocked && anyLocked) {
                if (!unlockPartialHomeworkContract()) {
                    isLocked = false
                    message = "Ödevin yarım kilitli eski durumu güvenli biçimde açılamadı. Uygulamayı yeniden açıp tekrar deneyin."
                } else {
                    isLocked = false
                    message = "Ödevin yarım kalan onayı düzenlemeye açıldı. Kaydedip yeniden onaylayın."
                }
            } else {
                isLocked = fullyLocked
            }
        } catch (t: Throwable) {
            isLocked = false
            message = "Ödev tanımı yüklenemedi: ${t.message ?: "Bilinmeyen hata"}"
        } finally {
            isLoading = false
        }
    }

    LaunchedEffect(draftId) { reload() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Ödev neydi?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Öğrenciye verdiğiniz ödevi birkaç cümleyle yazın. BaykuşNot öğrencinin yüklediği çalışmayı bu tanıma göre 100 üzerinden puanlayacak ve ayrıntılı dönüt verecek.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (isLocked) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Text("Ödev tanımı kaydedildi", fontWeight = FontWeight.Bold)
                    Text(assignment.ifBlank { "—" })
                }
            }
        } else {
            OutlinedTextField(
                value = assignment,
                onValueChange = { assignment = it; message = null },
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth(),
                minLines = 5,
                label = { Text("Ödev tanımı") },
                placeholder = { Text("Örn: Öğrenciler yaşadıkları bölgedeki bir çevre sorununu araştırıp nedenlerini, sonuçlarını ve iki çözüm önerisini açıklayacak.") }
            )
        }

        message?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(8.dp))

        if (isLocked) {
            OutlinedButton(
                onClick = {
                    if (isBusy) return@OutlinedButton
                    scope.launch {
                        isBusy = true
                        message = null
                        try {
                            if (!unlockPartialHomeworkContract()) {
                                message = "Ödev tanımı düzenlemeye açılamadı."
                            } else {
                                reload()
                            }
                        } catch (_: Throwable) {
                            message = "Ödev tanımı düzenlemeye açılamadı."
                        } finally { isBusy = false }
                    }
                },
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Düzenlemeye Aç") }

            Button(onClick = onContinue, enabled = !isBusy, modifier = Modifier.fillMaxWidth()) {
                Text("İlerle")
            }
        } else {
            Button(
                onClick = {
                    val clean = assignment.trim()
                    if (clean.isBlank()) { message = "Ödevin ne olduğunu yazın."; return@Button }
                    if (isBusy) return@Button
                    scope.launch {
                        isBusy = true
                        message = null
                        try {
                            val draft = draftRepository.getDraftByIdOnce(draftId)
                                ?: error("Ödev kaydı bulunamadı.")
                            if (draft.totalPoints != 100) {
                                draftRepository.updateDraft(draft.copy(totalPoints = 100))
                            }

                            val qMeta0 = questionRepository.getMetadataOnce(draftId)
                            val saveQ = questionRepository.saveQuestions(
                                examDraftId = draftId,
                                expectedRevision = qMeta0?.revision ?: 0,
                                questions = listOf(
                                    ExamQuestion(
                                        examDraftId = draftId,
                                        orderIndex = 1,
                                        questionNumber = "Ödev",
                                        questionText = HOMEWORK_PREFIX + clean +
                                            "\n\nDEĞERLENDİRME TALİMATI:\nÖğrencinin yüklediği çalışmanın bu ödevi ne ölçüde, ne doğrulukta ve ne eksiksizlikte yerine getirdiğini değerlendir. 100 üzerinden puan ver ve öğrenciye güçlü yanlarını, eksiklerini ve geliştirme önerilerini açıklayan ayrıntılı dönüt üret.",
                                        points = 100
                                    )
                                )
                            )
                            val savedQMeta = (saveQ as? SaveExamQuestionsResult.Success)?.metadata
                                ?: error("Ödev tanımı kaydedilemedi.")
                            val lockQ = questionRepository.lockQuestionSet(draftId, savedQMeta.revision)
                            if (lockQ !is LockExamQuestionSetResult.Success && lockQ !is LockExamQuestionSetResult.AlreadyLocked) {
                                error("Ödev tanımı onaylanamadı.")
                            }

                            val criterion = ExamRubricCriterion(
                                examDraftId = draftId,
                                questionOrderIndex = 1,
                                questionNumberSnapshot = "Ödev",
                                criterionOrderIndex = 1,
                                title = "Ödevin yerine getirilme düzeyi",
                                description = "Verilen ödev tanımındaki gerekliliklerin doğruluk, tamlık ve uygunluk açısından ne ölçüde yerine getirildiğini değerlendir.",
                                maxPoints = 100,
                                expectedAnswer = "Öğrenci çalışması, verilen ödev tanımındaki görev ve beklentileri yerine getirmelidir.",
                                partialCreditGuidance = "Kısmen tamamlanan veya kısmen doğru çalışmalar için karşılanan gereklilikler oranında kısmi puan ver.",
                                commonMistakes = "Eksik bölüm, yönergeden sapma, içerik hatası, yüzeysel veya kanıtsız açıklama."
                            )
                            val rMeta0 = rubricRepository.getMetadataOnce(draftId)
                            val saveR = rubricRepository.saveRubric(draftId, rMeta0?.revision ?: 0, listOf(criterion))
                            val savedRMeta = (saveR as? SaveExamRubricResult.Success)?.metadata
                                ?: error("Ödev değerlendirme ölçütü hazırlanamadı.")
                            val lockR = rubricRepository.lockRubricSet(draftId, savedRMeta.revision)
                            if (lockR !is LockExamRubricSetResult.Success && lockR !is LockExamRubricSetResult.AlreadyLocked) {
                                error("Ödev değerlendirme ölçütü onaylanamadı.")
                            }

                            val prefs = EvaluationPreferences(
                                evaluationMode = EvaluationMode.PAPER_BY_PAPER,
                                rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
                                feedbackDetailLevel = FeedbackDetailLevel.BRIEF,
                                writingAndPunctuation = WritingAndPunctuationPreferences(
                                    deductPoints = false,
                                    hasExplicitPreference = true,
                                    provideFeedback = false
                                ),
                                reportClass = true,
                                reportIndividual = true,
                                reportQuestion = false,
                                useBatchApi = false,
                                usePromptCaching = true
                            )
                            val saveP = preferencesRepository.savePreferences(draftId, prefs)
                            if (saveP !is SaveEvaluationPreferencesResult.Created && saveP !is SaveEvaluationPreferencesResult.Updated && saveP !is SaveEvaluationPreferencesResult.Locked) {
                                error("Ödev değerlendirme ayarları hazırlanamadı.")
                            }
                            val lockP = preferencesRepository.lockPreferences(draftId)
                            if (lockP !is LockEvaluationPreferencesResult.Success && lockP !is LockEvaluationPreferencesResult.AlreadyLocked) {
                                error("Ödev değerlendirme ayarları onaylanamadı.")
                            }

                            isLocked = true
                            onContinue()
                        } catch (t: Throwable) {
                            runCatching { unlockPartialHomeworkContract() }
                            isLocked = false
                            message = t.message ?: "Ödev tanımı kaydedilemedi."
                        } finally { isBusy = false }
                    }
                },
                enabled = !isBusy && assignment.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isBusy) CircularProgressIndicator(modifier = Modifier.height(18.dp))
                else Text("Kaydet ve İlerle")
            }
        }
    }
}
