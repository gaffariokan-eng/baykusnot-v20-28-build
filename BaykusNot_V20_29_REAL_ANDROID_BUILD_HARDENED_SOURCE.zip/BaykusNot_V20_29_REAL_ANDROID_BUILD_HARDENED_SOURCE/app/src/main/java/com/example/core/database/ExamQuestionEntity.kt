package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_question",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(
            value = ["examDraftId"]
        ),
        Index(
            value = [
                "examDraftId",
                "orderIndex"
            ],
            unique = true
        ),
        Index(
            value = [
                "examDraftId",
                "normalizedQuestionNumber"
            ],
            unique = true
        )
    ]
)
data class ExamQuestionEntity(
    @PrimaryKey(
        autoGenerate = true
    )
    val id: Long = 0L,
    val examDraftId: Long,
    val orderIndex: Int,
    val questionNumber: String,
    val normalizedQuestionNumber: String,
    val questionText: String,
    val points: Int,
    val createdAt: Long,
    val updatedAt: Long
)
