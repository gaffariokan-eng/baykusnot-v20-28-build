package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_paper_page",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["examDraftId"]),
        Index(value = ["studentPaperId"])
    ]
)
data class ExamPaperPageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val examDraftId: Long,
    val studentPaperId: Long = 0,
    val pageIndex: Int = 1,
    val totalPages: Int = 1,
    val qrStudentSeq: Int? = null,
    val imagePath: String,
    val qrRawContent: String? = null,
    val isReadabilityOk: Boolean = true,
    val isManuallyAssigned: Boolean = false,
    val status: String = "VALID", // "VALID", "WRONG_EXAM", "UNREADABLE_QR", "MISMATCHED"
    val statusReason: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
