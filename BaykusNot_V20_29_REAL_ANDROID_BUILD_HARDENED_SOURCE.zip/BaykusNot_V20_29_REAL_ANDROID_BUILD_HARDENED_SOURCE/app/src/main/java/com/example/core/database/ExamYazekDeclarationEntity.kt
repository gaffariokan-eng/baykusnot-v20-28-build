package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey

/** Immutable audit snapshot of the YAZEK declaration scope bound to actual AI use for an exam. */
@Entity(
    tableName = "exam_yazek_declaration",
    primaryKeys = ["examDraftId"],
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamYazekDeclarationEntity(
    val examDraftId: Long,
    val scopeFingerprint: String,
    val scopeSummary: String,
    val academicYear: String,
    val confirmedAt: Long,
    val referenceNote: String? = null
)
