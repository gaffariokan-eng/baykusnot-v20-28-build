package com.example.core.data

/**
 * Fiducial geometry shared by PDF rendering and on-device photo rectification.
 * Marks live outside the normal answer content, so they do not change the teacher/student flow.
 */
object AnswerSheetRegistrationGeometry {
    const val pageWidthPt = 595f
    const val pageHeightPt = 842f
    const val markSizePt = 14f

    /** Clockwise: top-left, top-right, bottom-right, bottom-left. */
    val registrationCentersPt: List<Pair<Float, Float>> = listOf(
        22f to 22f,
        573f to 22f,
        573f to 820f,
        22f to 820f
    )
}
