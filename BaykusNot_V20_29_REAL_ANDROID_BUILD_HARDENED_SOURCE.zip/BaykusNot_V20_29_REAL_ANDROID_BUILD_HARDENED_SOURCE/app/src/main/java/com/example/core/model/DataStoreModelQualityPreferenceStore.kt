package com.example.core.model

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DataStoreModelQualityPreferenceStore(
    private val dataStore: DataStore<Preferences>
) : ModelQualityPreferenceStore {

    override val selectedTier: Flow<ModelQualityTier> =
        dataStore.data.map { preferences ->
            val storedValue = preferences[SELECTED_TIER_KEY]

            storedValue
                ?.let { value ->
                    ModelQualityTier.entries.firstOrNull { tier ->
                        tier.name == value
                    }
                }
                ?: ModelQualityTier.STANDARD
        }

    override suspend fun setSelectedTier(tier: ModelQualityTier) {
        dataStore.edit { preferences ->
            preferences[SELECTED_TIER_KEY] = tier.name
        }
    }

    private companion object {
        val SELECTED_TIER_KEY =
            stringPreferencesKey("selected_model_quality_tier")
    }
}
