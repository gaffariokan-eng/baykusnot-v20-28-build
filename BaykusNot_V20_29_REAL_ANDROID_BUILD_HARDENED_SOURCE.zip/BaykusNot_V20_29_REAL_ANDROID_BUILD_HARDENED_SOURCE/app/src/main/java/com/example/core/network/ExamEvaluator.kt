package com.example.core.network

import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.data.AnswerSheetPageLayout
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.model.ExamType
import com.example.core.security.PrivacyMaskRect

data class AiUsageMetadata(
    val inputTokens: Long = 0,
    val cachedInputTokens: Long = 0,
    val outputTokens: Long = 0,
    val thinkingTokens: Long = 0,
    /** Provider-returned audit metadata; never inferred from the requested model id. */
    val actualModelVersion: String? = null,
    val responseId: String? = null,
    val modelStatusStage: String? = null,
    val modelRetirementTime: String? = null,
    val modelStatusMessage: String? = null
) {
    private fun mergeAudit(a: String?, b: String?): String? = listOfNotNull(a?.takeIf { it.isNotBlank() }, b?.takeIf { it.isNotBlank() }).distinct().joinToString(" | ").takeIf { it.isNotBlank() }
    operator fun plus(other: AiUsageMetadata): AiUsageMetadata = AiUsageMetadata(
        inputTokens = inputTokens + other.inputTokens,
        cachedInputTokens = cachedInputTokens + other.cachedInputTokens,
        outputTokens = outputTokens + other.outputTokens,
        thinkingTokens = thinkingTokens + other.thinkingTokens,
        actualModelVersion = mergeAudit(actualModelVersion, other.actualModelVersion),
        responseId = mergeAudit(responseId, other.responseId),
        modelStatusStage = mergeAudit(modelStatusStage, other.modelStatusStage),
        modelRetirementTime = mergeAudit(modelRetirementTime, other.modelRetirementTime),
        modelStatusMessage = mergeAudit(modelStatusMessage, other.modelStatusMessage)
    )
}

data class ExamStudentEvaluationInput(
    val studentPaperId: Long,
    val studentPages: List<ExamPaperPageEntity>,
    val questions: List<ExamQuestionEntity>,
    val rubrics: List<ExamRubricCriterionEntity>,
    val preferences: ExamEvaluationPreferencesEntity,
    val examType: ExamType = ExamType.WRITTEN,
    /** Grade level is used only to calibrate age-appropriate expectations and feedback language. */
    val gradeLevel: String? = null,
    /** When set, the evaluator must return only this locked question/task. */
    val targetQuestionOrderIndex: Int? = null,
    /** Shared cache created from the full locked question/task set, if available. */
    val cachedContentResourceName: String? = null,
    /** Canonical BaykuşNot answer-sheet geometry used for privacy cropping and targeted re-reads. */
    val pageLayouts: List<AnswerSheetPageLayout> = emptyList(),
    /** Locked per-exam model snapshot. Prevents a settings change from changing a running exam. */
    val evaluationModelId: String? = null,
    val supportsHighMediaResolution: Boolean = true,
    val supportsThinkingLevel: Boolean = true,
    val supportsPromptCaching: Boolean = true,
    val allowLegacyPrivacyCrop: Boolean = false,
    /** Local-only normalized redaction rectangles for arbitrary homework pages. */
    val privacyMasksByPageId: Map<Long, List<PrivacyMaskRect>> = emptyMap()
)

data class QuestionEvaluationOutput(
    val questionNumber: String,
    val questionOrderIndex: Int,
    val readAnswerText: String,
    val score: Double,
    val maxScore: Double,
    val feedback: String?,
    val readingConfidence: Double,
    val evaluationConfidence: Double,
    val answerType: String, // "NORMAL", "UNANSWERED", "UNREADABLE", "LOW_CONFIDENCE"
    val needsReview: Boolean,
    val reviewReason: String?,
    /** Exact transcription and semantic interpretation are deliberately separate. */
    val interpretedMeaning: String? = null,
    /** Short rubric-grounded evidence supporting the assigned score. */
    val gradingEvidence: String? = null,
    val strengths: List<String> = emptyList(),
    val missingElements: List<String> = emptyList(),
    val misconceptions: List<String> = emptyList(),
    val nextSteps: List<String> = emptyList(),
    /** Populated only when rebuilding final feedback from teacher-reviewed database state. */
    val isTeacherModified: Boolean = false
)

data class ExamStudentEvaluationOutput(
    val studentPaperId: Long,
    val questionEvaluations: List<QuestionEvaluationOutput>,
    val spellingPunctuationFeedback: String?,
    val writingStrengths: List<String> = emptyList(),
    val writingIssues: List<String> = emptyList(),
    val writingNextSteps: List<String> = emptyList(),
    val spellingPunctuationDeduction: Double,
    val totalScore: Double,
    val totalMaxScore: Double,
    val overallConfidence: Double,
    val needsReview: Boolean,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null,
    /** Student-facing whole-exam feedback, generated only after teacher approval. */
    val overallFeedback: String? = null,
    /** Usage of the first/main provider call. */
    val usage: AiUsageMetadata = AiUsageMetadata(),
    /** Usage of targeted independent second-check calls, always standard synchronous calls. */
    val secondaryUsage: AiUsageMetadata = AiUsageMetadata()
)

interface ExamEvaluator {
    suspend fun evaluateStudent(input: ExamStudentEvaluationInput): ExamStudentEvaluationOutput
}
