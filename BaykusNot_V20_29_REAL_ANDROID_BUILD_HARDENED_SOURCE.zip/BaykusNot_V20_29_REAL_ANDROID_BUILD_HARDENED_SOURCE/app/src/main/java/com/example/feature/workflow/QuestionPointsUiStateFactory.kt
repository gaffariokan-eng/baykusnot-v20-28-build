package com.example.feature.workflow

import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.ExamType

object QuestionPointsUiStateFactory {

    fun create(
        draftId: Long,
        draftExists: Boolean,
        editableQuestions: List<EditableExamQuestion>,
        expectedTotalPoints: Int,
        metadata: ExamQuestionSetMetadata?,
        hasUnsavedChanges: Boolean,
        isLoading: Boolean,
        isSaving: Boolean,
        isLocking: Boolean,
        isUnlocking: Boolean,
        isSuggestingObjectives: Boolean = false,
        message: String? = null,
        objectives: List<com.example.core.database.ExamObjectiveEntity>? = null,
        isObjectivesMappingValid: Boolean = true,
        isObjectiveMappingApproved: Boolean = false,
        isMismatchAccepted: Boolean = false,
        hasScenario: Boolean = false,
        hasObjectiveMismatch: Boolean = false,
        examType: ExamType = ExamType.WRITTEN,
        listeningTranscript: String = "",
        hasListeningAudio: Boolean = false,
        listeningPlaybackCount: Int = 2,
        listeningInstructions: String = "",
        isListeningMaterialReady: Boolean = true
    ): QuestionPointsUiState {
        val evaluation = QuestionPointsFormEvaluator.evaluate(
            examDraftId = draftId,
            expectedTotalPoints = expectedTotalPoints,
            editableQuestions = editableQuestions
        )

        val operationInProgress = isSaving || isLocking || isUnlocking

        val isLocked = metadata?.isLocked ?: false
        val lockedAt = metadata?.lockedAt
        val revision = metadata?.revision ?: 0

        val sourceReady = examType != ExamType.LISTENING || isListeningMaterialReady

        val canSave = draftExists &&
                sourceReady &&
                !isLoading &&
                !operationInProgress &&
                metadata?.isLocked != true &&
                evaluation.canSave

        val scenarioValid = if (hasScenario) {
            objectives != null &&
                    objectives.isNotEmpty() &&
                    isObjectivesMappingValid &&
                    isObjectiveMappingApproved &&
                    (!hasObjectiveMismatch || isMismatchAccepted)
        } else {
            true
        }
        val canLock = draftExists &&
                sourceReady &&
                !isLoading &&
                !operationInProgress &&
                metadata != null &&
                !metadata.isLocked &&
                !hasUnsavedChanges &&
                evaluation.canLock &&
                scenarioValid

        val canContinue = draftExists &&
                sourceReady &&
                !isLoading &&
                !operationInProgress &&
                metadata?.isLocked == true &&
                !hasUnsavedChanges &&
                evaluation.canLock

        return QuestionPointsUiState(
            draftId = draftId,
            draftExists = draftExists,
            examType = examType,
            listeningTranscript = listeningTranscript,
            hasListeningAudio = hasListeningAudio,
            listeningPlaybackCount = listeningPlaybackCount,
            listeningInstructions = listeningInstructions,
            isListeningMaterialReady = isListeningMaterialReady,
            editableQuestions = editableQuestions,
            expectedTotalPoints = expectedTotalPoints,
            calculatedTotalPoints = evaluation.calculatedTotalPoints,
            remainingPoints = evaluation.remainingPoints,
            validationIssues = evaluation.validation?.issues ?: emptyList(),
            inputIssues = evaluation.inputIssues,
            canSave = canSave,
            canLock = canLock,
            canContinue = canContinue,
            isLocked = isLocked,
            lockedAt = lockedAt,
            revision = revision,
            isLoading = isLoading,
            isSaving = isSaving,
            isLocking = isLocking,
            isUnlocking = isUnlocking,
            isSuggestingObjectives = isSuggestingObjectives,
            message = message,
            hasUnsavedChanges = hasUnsavedChanges,
            objectives = objectives,
            isObjectivesMappingValid = isObjectivesMappingValid,
            isObjectiveMappingApproved = isObjectiveMappingApproved,
            isMismatchAccepted = isMismatchAccepted,
            hasScenario = hasScenario,
            hasObjectiveMismatch = hasObjectiveMismatch
        )
    }
}
