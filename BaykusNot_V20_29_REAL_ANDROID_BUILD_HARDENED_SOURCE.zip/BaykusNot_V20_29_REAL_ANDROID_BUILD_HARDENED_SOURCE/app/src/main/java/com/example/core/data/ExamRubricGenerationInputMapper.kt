package com.example.core.data

import com.example.core.network.ExamRubricGenerationInput
import com.example.core.network.RubricGenerationQuestion

object ExamRubricGenerationInputMapper {
    fun map(
        ready: ExamRubricGenerationPreflightResult.Ready
    ): ExamRubricGenerationInput {
        return ExamRubricGenerationInput(
            examDraftId = ready.examDraftId,
            questions = ready.questions.map { question ->
                RubricGenerationQuestion(
                    questionOrderIndex = question.orderIndex,
                    questionNumber = question.questionNumber,
                    questionText = question.questionText,
                    points = question.points
                )
            },
            deductWritingPunctuationPoints = ready.deductWritingPunctuationPoints,
            sourceContext = ready.sourceContext,
            examType = ready.examType
        )
    }
}
