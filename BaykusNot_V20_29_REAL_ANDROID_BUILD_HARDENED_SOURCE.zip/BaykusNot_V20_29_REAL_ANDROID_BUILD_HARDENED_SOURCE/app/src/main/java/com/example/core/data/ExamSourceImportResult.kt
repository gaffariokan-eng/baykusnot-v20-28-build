package com.example.core.data

import com.example.core.database.ExamSourceDocumentEntity

sealed interface ExamSourceImportResult {

    data class Success(
        val document:
            ExamSourceDocumentEntity,
        val replacedExisting:
            Boolean,
        val reusedExisting:
            Boolean
    ) : ExamSourceImportResult

    data class Failure(
        val reason:
            ExamSourceImportFailure
    ) : ExamSourceImportResult
}

enum class ExamSourceImportFailure {
    DRAFT_NOT_FOUND,
    UNSUPPORTED_MIME_TYPE,
    SOURCE_UNAVAILABLE,
    EMPTY_FILE,
    FILE_TOO_LARGE,
    INVALID_PDF,
    STORAGE_ERROR,
    DATABASE_ERROR
}
