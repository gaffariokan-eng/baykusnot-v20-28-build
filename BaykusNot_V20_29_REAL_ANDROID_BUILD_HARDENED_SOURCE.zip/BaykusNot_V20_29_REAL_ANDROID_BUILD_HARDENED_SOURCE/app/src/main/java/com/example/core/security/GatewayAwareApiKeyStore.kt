package com.example.core.security

import com.example.BuildConfig
import com.example.core.network.GatewaySessionManager

/**
 * Prevents production release from depending on a Gemini secret stored on-device.
 * In gateway-managed release builds, every AI call first ensures a short-lived authenticated
 * gateway session, then legacy request builders receive only a non-secret placeholder.
 */
class GatewayAwareApiKeyStore(
    private val directStore: SecureApiKeyStore,
    private val gatewaySessionManager: GatewaySessionManager? = null
) : SecureApiKeyStore {

    val isGatewayManaged: Boolean
        get() = BuildConfig.AI_GATEWAY_BASE_URL.isNotBlank()

    val isProductionBlocked: Boolean
        get() = !BuildConfig.ALLOW_DIRECT_GEMINI && !isGatewayManaged

    override suspend fun saveApiKey(apiKey: String) {
        if (!BuildConfig.ALLOW_DIRECT_GEMINI) {
            throw IllegalStateException("Release sürümünde mobil Gemini anahtarı kaydedilemez.")
        }
        directStore.saveApiKey(apiKey)
    }

    override suspend fun hasApiKey(): Boolean = when {
        isGatewayManaged -> gatewaySessionManager?.isEnrolled() == true
        isProductionBlocked -> false
        else -> directStore.hasApiKey()
    }

    override suspend fun deleteApiKey() {
        if (BuildConfig.ALLOW_DIRECT_GEMINI) directStore.deleteApiKey()
    }

    override suspend fun <T> useApiKey(block: suspend (String) -> T): T? = when {
        isGatewayManaged -> {
            val manager = gatewaySessionManager
                ?: throw IllegalStateException("Gateway oturum yöneticisi yapılandırılmamış.")
            manager.ensureValidSession()
            block(GATEWAY_PLACEHOLDER)
        }
        isProductionBlocked -> null
        else -> directStore.useApiKey(block)
    }

    companion object {
        private const val GATEWAY_PLACEHOLDER = "GATEWAY_MANAGED_NO_CLIENT_SECRET"
    }
}
