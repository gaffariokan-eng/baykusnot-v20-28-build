package com.example.feature.workflow

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.ExamQuestionExtractionDraftRepository
import com.example.core.data.ExamObjectiveRepository

@Composable
internal fun QuestionPointsRoute(
    draftId: Long,
    examQuestionRepository: ExamQuestionRepository,
    examDraftRepository: ExamDraftRepository,
    examQuestionExtractionDraftRepository: ExamQuestionExtractionDraftRepository,
    objectiveRepository: ExamObjectiveRepository,
    matcher: com.example.core.network.ExamQuestionObjectiveMatcher,
    examRubricRepository: ExamRubricRepository,
    examListeningMaterialRepository: ExamListeningMaterialRepository? = null,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: QuestionPointsViewModel = viewModel(
        key = "question_points_$draftId",
        factory = QuestionPointsViewModel.Factory(
            draftId = draftId,
            examQuestionRepository = examQuestionRepository,
            examDraftRepository = examDraftRepository,
            examQuestionExtractionDraftRepository = examQuestionExtractionDraftRepository,
            objectiveRepository = objectiveRepository,
            matcher = matcher,
            examRubricRepository = examRubricRepository,
            examListeningMaterialRepository = examListeningMaterialRepository
        )
    )

    QuestionPointsRoute(
        viewModel = viewModel,
        onContinue = onContinue,
        modifier = modifier
    )
}

@Composable
internal fun QuestionPointsRoute(
    viewModel: QuestionPointsViewModel,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    DisposableEffect(viewModel) {
        onDispose { viewModel.cancelActiveAuthoringWork() }
    }
    var saveAndAdvanceRequested by remember { mutableStateOf(false) }

    LaunchedEffect(saveAndAdvanceRequested, uiState.isSaving, uiState.isLocking, uiState.isLocked, uiState.hasUnsavedChanges, uiState.canLock) {
        if (!saveAndAdvanceRequested || uiState.isSaving || uiState.isLocking) return@LaunchedEffect
        when {
            uiState.isLocked -> { saveAndAdvanceRequested = false; onContinue() }
            uiState.hasUnsavedChanges && uiState.canSave -> viewModel.saveQuestions()
            uiState.canLock -> viewModel.lockQuestionSet()
        }
    }

    QuestionPointsContent(
        uiState = uiState,
        onAddQuestion = viewModel::addQuestion,
        onRemoveQuestion = viewModel::removeQuestion,
        onMoveQuestionUp = viewModel::moveQuestionUp,
        onMoveQuestionDown = viewModel::moveQuestionDown,
        onQuestionNumberChange = viewModel::updateQuestionNumber,
        onQuestionTextChange = viewModel::updateQuestionText,
        onQuestionPointsChange = viewModel::updateQuestionPoints,
        onSave = { saveAndAdvanceRequested = true },
        onLock = { saveAndAdvanceRequested = true },
        onUnlock = viewModel::unlockQuestionSet,
        onContinue = onContinue,
        onDismissMessage = viewModel::dismissMessage,
        onSuggestObjectives = viewModel::suggestObjectives,
        onApproveObjectivesMapping = viewModel::approveObjectivesMapping,
        onToggleObjective = viewModel::toggleObjective,
        onAcceptMismatch = viewModel::acceptMismatch,
        modifier = modifier
    )
}
