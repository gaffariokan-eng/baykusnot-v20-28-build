package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamQuestionExtractionDraftDao {
    @Query("""
        SELECT *
        FROM exam_question_extraction_draft
        WHERE examDraftId = :examDraftId
        ORDER BY orderIndex ASC
    """)
    fun observeByExamDraftId(
        examDraftId: Long
    ): Flow<List<ExamQuestionExtractionDraftEntity>>

    @Query("""
        SELECT *
        FROM exam_question_extraction_draft
        WHERE examDraftId = :examDraftId
        ORDER BY orderIndex ASC
    """)
    suspend fun getByExamDraftIdOnce(
        examDraftId: Long
    ): List<ExamQuestionExtractionDraftEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(
        questions: List<ExamQuestionExtractionDraftEntity>
    )

    @Query("""
        DELETE FROM exam_question_extraction_draft
        WHERE examDraftId = :examDraftId
    """)
    suspend fun deleteByExamDraftId(
        examDraftId: Long
    ): Int

    @Transaction
    suspend fun replaceForDraft(
        examDraftId: Long,
        questions: List<ExamQuestionExtractionDraftEntity>
    ) {
        deleteByExamDraftId(examDraftId)
        if (questions.isNotEmpty()) {
            insertAll(questions)
        }
    }
}
