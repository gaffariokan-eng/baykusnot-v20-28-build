package com.example.core.data

import com.example.core.network.ExamRubricGenerationValidationResult

class ExamRubricGenerationPersistenceStage(
    private val repository: ExamRubricRepository
) {
    suspend fun save(
        examDraftId: Long,
        ready: ExamRubricGenerationPreflightResult.Ready,
        validation: ExamRubricGenerationValidationResult
    ): SaveExamRubricResult {
        val criteria = ExamRubricGenerationPersistenceMapper.map(
            examDraftId = examDraftId,
            validation = validation
        )

        return repository.saveRubric(
            examDraftId = examDraftId,
            expectedRevision = 0,
            expectedQuestionSetRevision = ready.questionSetRevision,
            criteria = criteria
        )
    }
}
