package com.example.feature.workflow

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.AnswerSheetDensity
import com.example.core.data.ExamAnswerSheetLayoutCalculator
import com.example.core.data.ExamAnswerSheetPreflightResult
import com.example.core.data.ExamAnswerSheetRepository
import com.example.core.data.PdfStatus
import com.example.core.data.PdfSafWriter
import com.example.core.database.ExamAnswerSheetConfigEntity
import com.example.core.model.ExamType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

private data class PdfStatusDetails(
    val file: File?,
    val count: Int?,
    val isUpToDate: Boolean,
    val title: String?,
    val subtitle: String?
)

class AnswerSheetViewModel(
    private val repository: ExamAnswerSheetRepository,
    private val examDraftId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(AnswerSheetUiState())
    val uiState: StateFlow<AnswerSheetUiState> = _uiState.asStateFlow()

    // Settings are edited optimistically in the UI, but persistence is asynchronous.
    // Keep only the newest write in each storage domain and block PDF/advance until it settles.
    private var configSaveJob: Job? = null
    private var lineOverrideSaveJob: Job? = null
    private var configSaveRevision: Long = 0L
    private var lineOverrideSaveRevision: Long = 0L
    private var configSaveActive: Boolean = false
    private var lineOverrideSaveActive: Boolean = false

    private fun publishSettingsSavingState(markPdfStale: Boolean = false) {
        val current = _uiState.value
        _uiState.value = current.copy(
            isSavingSettings = configSaveActive || lineOverrideSaveActive,
            isPdfUpToDate = if (markPdfStale) false else current.isPdfUpToDate
        )
    }

    private fun scheduleConfigSave(previousState: AnswerSheetUiState) {
        val previousJob = configSaveJob
        val revision = ++configSaveRevision
        configSaveActive = true
        publishSettingsSavingState(markPdfStale = true)
        configSaveJob = viewModelScope.launch {
            previousJob?.cancelAndJoin()
            try {
                if (revision != configSaveRevision) return@launch
                val desired = _uiState.value
                val current = repository.getConfig(examDraftId) ?: ExamAnswerSheetConfigEntity(examDraftId = examDraftId)
                val saved = repository.saveConfigIfNoUploadedPapers(
                    current.copy(
                        studentCount = desired.studentCount,
                        layoutDensity = desired.layoutDensity,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                if (!saved) {
                    val persisted = repository.getConfig(examDraftId) ?: current
                    if (revision == configSaveRevision) {
                        _uiState.value = _uiState.value.copy(
                            studentCount = persisted.studentCount,
                            layoutDensity = persisted.layoutDensity,
                            hasUploadedPapers = true,
                            isPdfUpToDate = false,
                            errorMessage = "Öğrenci kâğıtları yüklenmiş olduğu için cevap kâğıdı ayarları değiştirilemedi."
                        )
                    }
                    return@launch
                }
                if (revision == configSaveRevision) {
                    val latest = _uiState.value
                    recalculateLayout(latest.layoutDensity, latest.lineOverrides)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                if (revision == configSaveRevision) {
                    val persisted = runCatching { repository.getConfig(examDraftId) }.getOrNull()
                    _uiState.value = _uiState.value.copy(
                        studentCount = persisted?.studentCount ?: previousState.studentCount,
                        layoutDensity = persisted?.layoutDensity ?: previousState.layoutDensity,
                        isPdfUpToDate = false,
                        errorMessage = "Cevap kâğıdı ayarları kaydedilemedi. Lütfen tekrar deneyin."
                    )
                }
            } finally {
                if (revision == configSaveRevision) {
                    configSaveActive = false
                    publishSettingsSavingState()
                }
            }
        }
    }

    private fun scheduleLineOverrideSave(previousOverrides: Map<Int, Int>) {
        val previousJob = lineOverrideSaveJob
        val revision = ++lineOverrideSaveRevision
        lineOverrideSaveActive = true
        publishSettingsSavingState(markPdfStale = true)
        lineOverrideSaveJob = viewModelScope.launch {
            previousJob?.cancelAndJoin()
            try {
                if (revision != lineOverrideSaveRevision) return@launch
                if (repository.hasUploadedPapers(examDraftId)) {
                    if (revision == lineOverrideSaveRevision) {
                        _uiState.value = _uiState.value.copy(
                            lineOverrides = repository.getLineOverrides(examDraftId),
                            hasUploadedPapers = true,
                            isPdfUpToDate = false,
                            errorMessage = "Öğrenci kâğıtları yüklenmiş olduğu için cevap alanı satırları değiştirilemedi."
                        )
                    }
                    return@launch
                }
                val desired = _uiState.value.lineOverrides
                check(repository.saveLineOverrides(examDraftId, desired)) {
                    "Cevap alanı satır ayarı kalıcı olarak kaydedilemedi."
                }
                if (revision == lineOverrideSaveRevision) {
                    val latest = _uiState.value
                    recalculateLayout(latest.layoutDensity, latest.lineOverrides)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                if (revision == lineOverrideSaveRevision) {
                    val persisted = repository.getLineOverrides(examDraftId)
                    _uiState.value = _uiState.value.copy(
                        lineOverrides = if (persisted.isNotEmpty() || previousOverrides.isNotEmpty()) persisted else previousOverrides,
                        isPdfUpToDate = false,
                        errorMessage = "Cevap alanı satır ayarı kaydedilemedi. Lütfen tekrar deneyin."
                    )
                }
            } finally {
                if (revision == lineOverrideSaveRevision) {
                    lineOverrideSaveActive = false
                    publishSettingsSavingState()
                }
            }
        }
    }

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null, saveSuccessMessage = null)
            try {
                val preflight = repository.validatePreflight(examDraftId)
                if (preflight is ExamAnswerSheetPreflightResult.Failure) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = preflight.reason,
                        isPreflightValid = false
                    )
                    return@launch
                }

                val success = preflight as ExamAnswerSheetPreflightResult.Success
                val config = repository.getConfig(examDraftId)
                val studentCount = config?.studentCount ?: 20
                val density = config?.layoutDensity ?: "AUTOMATIC"
                val lineOverrides = repository.getLineOverrides(examDraftId)
                val hasUploadedPapers = repository.hasUploadedPapers(examDraftId)
                val titleHeader = ExamAnswerSheetLayoutCalculator.buildAnswerSheetTitle(success.draft)
                val layouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
                    questions = success.questions,
                    rubricCriteria = success.rubricCriteria,
                    densitySetting = density,
                    lineOverrides = lineOverrides,
                    listeningGuidance = success.listeningGuidance,
                    examType = success.draft.examType
                )
                val summaryText = ExamAnswerSheetLayoutCalculator.getSummaryText(layouts, success.questions.size)

                val pdfStatus = repository.getPdfStatus(examDraftId, studentCount)
                val statusDetails = when (pdfStatus) {
                    is PdfStatus.UpToDate -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, true, null, null)
                    is PdfStatus.Stale -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, false, pdfStatus.title, pdfStatus.subtitle)
                    is PdfStatus.NotGenerated -> PdfStatusDetails(null, null, false, null, null)
                }

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = null,
                    draft = success.draft,
                    questions = success.questions,
                    rubricCriteria = success.rubricCriteria,
                    studentCount = studentCount,
                    layoutDensity = density,
                    lineOverrides = lineOverrides,
                    hasUploadedPapers = hasUploadedPapers,
                    layoutSummaryText = summaryText,
                    titleHeader = titleHeader,
                    listeningGuidance = success.listeningGuidance,
                    pageLayouts = layouts,
                    selectedPreviewPageIndex = 1,
                    generatedPdfFile = statusDetails.file,
                    generatedPdfStudentCount = statusDetails.count,
                    isPdfUpToDate = statusDetails.isUpToDate,
                    pdfStaleTitle = statusDetails.title,
                    pdfStaleSubtitle = statusDetails.subtitle,
                    isPreflightValid = true
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Cevap kâğıdı verileri yüklenirken bir hata oluştu. Lütfen tekrar deneyin.",
                    isPreflightValid = false
                )
            }
        }
    }

    fun updateStudentCount(count: Int) {
        if (_uiState.value.hasUploadedPapers) {
            _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci kâğıtları yüklendikten sonra öğrenci sayısı değiştirilemez. Değişiklik için yüklenen kâğıtları temizleyin.")
            return
        }
        val clampedCount: Int
        val validationError: String?
        if (count > 500) {
            clampedCount = 500
            validationError = if (_uiState.value.draft?.examType == com.example.core.model.ExamType.READINESS) {
                "Bir hazırbulunuşluk sınavı için en fazla 500 öğrenci oluşturabilirsiniz."
            } else {
                "Bir sınav için en fazla 500 öğrenci oluşturabilirsiniz."
            }
        } else if (count < 1) {
            clampedCount = 1
            validationError = null
        } else {
            clampedCount = count
            validationError = null
        }
        val previousState = _uiState.value
        _uiState.value = previousState.copy(
            studentCount = clampedCount,
            errorMessage = validationError,
            isPdfUpToDate = false
        )
        scheduleConfigSave(previousState)
    }

    fun updateLayoutDensity(densityCode: String) {
        if (_uiState.value.hasUploadedPapers) {
            _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci kâğıtları yüklendikten sonra yerleşim değiştirilemez.")
            return
        }
        val previousState = _uiState.value
        _uiState.value = previousState.copy(
            layoutDensity = densityCode,
            errorMessage = null,
            isPdfUpToDate = false
        )
        scheduleConfigSave(previousState)
    }

    fun updateLineOverride(questionOrderIndex: Int, delta: Int) {
        if (_uiState.value.hasUploadedPapers) {
            _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci kâğıtları yüklendikten sonra cevap alanı satırları değiştirilemez.")
            return
        }
        val currentState = _uiState.value
        val question = currentState.questions.firstOrNull { it.orderIndex == questionOrderIndex } ?: return
        val density = AnswerSheetDensity.fromCode(currentState.layoutDensity)
        val currentBox = ExamAnswerSheetLayoutCalculator.calculateQuestionBoxSpec(
            question = question,
            rubricCriteria = currentState.rubricCriteria,
            density = density,
            lineOverrides = currentState.lineOverrides,
            examType = currentState.draft?.examType ?: ExamType.WRITTEN
        )
        val newLines = (currentBox.lineCount + delta).coerceIn(3, 25)
        val updatedOverrides = currentState.lineOverrides.toMutableMap().apply { this[questionOrderIndex] = newLines }
        _uiState.value = currentState.copy(
            lineOverrides = updatedOverrides,
            errorMessage = null,
            isPdfUpToDate = false
        )
        scheduleLineOverrideSave(currentState.lineOverrides)
    }

    fun resetLineOverrides() {
        if (_uiState.value.hasUploadedPapers) {
            _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci kâğıtları yüklendikten sonra cevap alanı satırları değiştirilemez.")
            return
        }
        val currentState = _uiState.value
        _uiState.value = currentState.copy(
            lineOverrides = emptyMap(),
            errorMessage = null,
            isPdfUpToDate = false
        )
        scheduleLineOverrideSave(currentState.lineOverrides)
    }

    private suspend fun recalculateLayout(densityCode: String, lineOverrides: Map<Int, Int>) {
        val currentState = _uiState.value
        val newLayouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = currentState.questions,
            rubricCriteria = currentState.rubricCriteria,
            densitySetting = densityCode,
            lineOverrides = lineOverrides,
            listeningGuidance = currentState.listeningGuidance,
            examType = currentState.draft?.examType ?: ExamType.WRITTEN
        )
        val summaryText = ExamAnswerSheetLayoutCalculator.getSummaryText(newLayouts, currentState.questions.size)
        val pdfStatus = repository.getPdfStatus(examDraftId, currentState.studentCount)
        val statusDetails = when (pdfStatus) {
            is PdfStatus.UpToDate -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, true, null, null)
            is PdfStatus.Stale -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, false, pdfStatus.title, pdfStatus.subtitle)
            is PdfStatus.NotGenerated -> PdfStatusDetails(null, null, false, null, null)
        }
        _uiState.value = _uiState.value.copy(pageLayouts = newLayouts, layoutSummaryText = summaryText, selectedPreviewPageIndex = 1, generatedPdfFile = statusDetails.file, generatedPdfStudentCount = statusDetails.count, isPdfUpToDate = statusDetails.isUpToDate, pdfStaleTitle = statusDetails.title, pdfStaleSubtitle = statusDetails.subtitle)
    }

    private suspend fun refreshPdfStatus(studentCount: Int) {
        val pdfStatus = repository.getPdfStatus(examDraftId, studentCount)
        val statusDetails = when (pdfStatus) {
            is PdfStatus.UpToDate -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, true, null, null)
            is PdfStatus.Stale -> PdfStatusDetails(pdfStatus.pdfFile, pdfStatus.generatedStudentCount, false, pdfStatus.title, pdfStatus.subtitle)
            is PdfStatus.NotGenerated -> PdfStatusDetails(null, null, false, null, null)
        }
        _uiState.value = _uiState.value.copy(generatedPdfFile = statusDetails.file, generatedPdfStudentCount = statusDetails.count, isPdfUpToDate = statusDetails.isUpToDate, pdfStaleTitle = statusDetails.title, pdfStaleSubtitle = statusDetails.subtitle)
    }

    fun selectPreviewPage(pageIndex: Int) {
        if (pageIndex in 1..(_uiState.value.pageLayouts.size.coerceAtLeast(1))) {
            _uiState.value = _uiState.value.copy(selectedPreviewPageIndex = pageIndex)
        }
    }

    fun generateBatchPdf(context: Context, onComplete: ((File?) -> Unit)? = null) {
        val currentState = _uiState.value
        if (!currentState.isPreflightValid || currentState.isGeneratingPdf || currentState.isSavingSettings) return

        val totalStudents = currentState.studentCount
        _uiState.value = currentState.copy(
            isGeneratingPdf = true,
            pdfGenerationProgress = "1 / $totalStudents öğrencinin cevap kâğıdı hazırlanıyor...",
            errorMessage = null,
            saveSuccessMessage = null
        )
        viewModelScope.launch {
            try {
                val pdfFile = repository.generateBatchPdf(
                    context = context,
                    examDraftId = examDraftId,
                    studentCount = totalStudents,
                    onProgress = { currentStudent, total ->
                        _uiState.value = _uiState.value.copy(
                            pdfGenerationProgress = "$currentStudent / $total öğrencinin cevap kâğıdı hazırlanıyor..."
                        )
                    }
                )
                _uiState.value = _uiState.value.copy(
                    isGeneratingPdf = false,
                    pdfGenerationProgress = null,
                    generatedPdfFile = pdfFile,
                    generatedPdfStudentCount = totalStudents,
                    isPdfUpToDate = true,
                    saveSuccessMessage = "Toplu PDF başarıyla oluşturuldu ($totalStudents Öğrenci)."
                )
                onComplete?.invoke(pdfFile)
            } catch (e: Exception) {
                Log.e("AnswerSheetViewModel", "Error generating PDF", e)
                _uiState.value = _uiState.value.copy(
                    isGeneratingPdf = false,
                    pdfGenerationProgress = null,
                    errorMessage = "Cevap kâğıdı PDF'si oluşturulamadı. Lütfen tekrar deneyin."
                )
                onComplete?.invoke(null)
            }
        }
    }

    fun savePdfToUri(context: Context, destination: Uri) {
        val file = _uiState.value.generatedPdfFile ?: return
        if (!file.exists()) return

        viewModelScope.launch(Dispatchers.IO) {
            PdfSafWriter.writeVerified(context, file, destination)
                .onSuccess {
                    _uiState.value = _uiState.value.copy(
                        saveSuccessMessage = "PDF seçtiğiniz konuma güvenli biçimde kaydedildi (${file.name}).",
                        errorMessage = null
                    )
                }
                .onFailure {
                    _uiState.value = _uiState.value.copy(
                        errorMessage = "PDF kaydedilemedi veya yazım doğrulanamadı. Lütfen başka bir konum seçip tekrar deneyin."
                    )
                }
        }
    }

    fun clearSaveSuccessMessage() {
        _uiState.value = _uiState.value.copy(saveSuccessMessage = null)
    }

    class Factory(
        private val repository: ExamAnswerSheetRepository,
        private val examDraftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AnswerSheetViewModel::class.java)) {
                return AnswerSheetViewModel(repository, examDraftId) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
