package com.example.core.data

import android.content.Context
import com.example.core.database.ExamPaperUploadDao
import com.example.core.network.GeminiBatchJobManager
import com.example.core.network.GeminiCacheManager
import com.example.core.security.HomeworkPrivacyMaskStore
import com.example.core.security.SecureApiKeyStore
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ExamDeletionSummary(
    val deletedLocalFiles: Int,
    val clearedPrivacyMasks: Int,
    val cleanedRemoteBatchRecords: Int,
    val pendingRemoteBatchRecords: Int,
    val remoteCleanupAttempted: Boolean,
    val cleanedRemoteCacheRecords: Int = 0,
    val pendingRemoteCacheRecords: Int = 0,
    val pendingLocalCleanup: Boolean = false
) {
    val isFullyCleaned: Boolean
        get() = !pendingLocalCleanup && pendingRemoteBatchRecords == 0 && pendingRemoteCacheRecords == 0

    fun userNoticeOrNull(): String? {
        if (isFullyCleaned) return null
        val pending = buildList {
            if (pendingLocalCleanup) add("yerel dosya temizliği")
            if (pendingRemoteBatchRecords > 0) add("$pendingRemoteBatchRecords uzak Batch kaynağı")
            if (pendingRemoteCacheRecords > 0) add("$pendingRemoteCacheRecords uzak AI önbelleği")
        }.joinToString(", ")
        return "Çalışmanın yerel veritabanı kaydı silindi; $pending için silme doğrulaması bekliyor. " +
            "BaykuşNot açıldıkça temizliği otomatik yeniden deneyecek. " +
            "Daha önce cihazda seçtiğiniz konuma dışa aktarılan PDF kopyaları ayrıca sizin yönetiminizdedir."
    }
}

/** Crash-safe deletion orchestrator. Logical deletion commits before destructive local cleanup. */
class ExamDeletionRepository(
    context: Context,
    private val draftRepository: ExamDraftRepository,
    private val paperUploadDao: ExamPaperUploadDao,
    private val homeworkPrivacyMaskStore: HomeworkPrivacyMaskStore,
    private val batchJobManager: GeminiBatchJobManager?,
    private val cacheManager: GeminiCacheManager?,
    private val apiKeyStore: SecureApiKeyStore?
) {
    private val appContext = context.applicationContext
    private val deletionJournal = ExamDeletionJournal(appContext)

    suspend fun deleteExamCompletely(examDraftId: Long): Result<ExamDeletionSummary> = withContext(Dispatchers.IO) {
        if (examDraftId <= 0L) return@withContext Result.failure(IllegalArgumentException("INVALID_EXAM_ID"))
        val draft = draftRepository.getDraftByIdOnce(examDraftId)
        val existingIntent = deletionJournal.read(examDraftId)
        if (draft == null && existingIntent == null) {
            return@withContext Result.success(ExamDeletionSummary(0, 0, 0, 0, false))
        }
        try {
            val pageIds = existingIntent?.pageIds ?: paperUploadDao.getPagesForExamOnce(examDraftId).map { it.id }
            var remoteCleanupAttempted = false
            var remoteCleaned = 0
            var remotePending = 0
            var cacheCleaned = 0
            var cachePending = 0

            if (existingIntent == null) {
                var usedCredential = false
                if (apiKeyStore != null) {
                    val credentialCleanup = runCatching {
                        apiKeyStore.useApiKey { key ->
                            usedCredential = true
                            remoteCleanupAttempted = true
                            batchJobManager?.cleanupDraft(examDraftId, key)?.let {
                                remoteCleaned = it.confirmedRemoteDeleted; remotePending = it.pendingRemoteDeletion
                            }
                            cacheManager?.deleteCacheForDraft(examDraftId, key)?.let {
                                cacheCleaned = it.confirmedRemoteDeleted; cachePending = it.pendingRemoteDeletion
                            }
                        }
                    }
                    if (usedCredential && credentialCleanup.isFailure) {
                        throw IllegalStateException("Uzak AI kaynaklarının silme takibi güvenceye alınamadı.", credentialCleanup.exceptionOrNull())
                    }
                }
                if (!usedCredential) {
                    batchJobManager?.cleanupDraft(examDraftId, null)?.let {
                        remoteCleaned = it.confirmedRemoteDeleted; remotePending = it.pendingRemoteDeletion
                    }
                    cacheManager?.markDraftCacheCleanupPending(
                        examDraftId,
                        "Sınav silindi; cached-content uzaktan silme doğrulaması bekliyor."
                    )?.let { cachePending = it.pendingRemoteDeletion }
                }
                // From this point onward deletion intent is durable and may be resumed after process death.
                deletionJournal.prepare(examDraftId, pageIds)
            }

            val intent = deletionJournal.read(examDraftId) ?: error("DELETE_JOURNAL_MISSING")
            if (intent.stage == ExamDeletionStage.PREPARED) {
                if (draftRepository.getDraftByIdOnce(examDraftId) != null) {
                    draftRepository.deleteDraftById(examDraftId)
                    check(draftRepository.getDraftByIdOnce(examDraftId) == null) { "DB_DELETE_NOT_COMMITTED" }
                }
                deletionJournal.markCommitted(examDraftId)
            }

            val local = cleanupCommittedDeletion(examDraftId, pageIds)
            Result.success(
                ExamDeletionSummary(
                    deletedLocalFiles = local.deletedFiles,
                    clearedPrivacyMasks = local.clearedMasks,
                    cleanedRemoteBatchRecords = remoteCleaned,
                    pendingRemoteBatchRecords = remotePending,
                    remoteCleanupAttempted = remoteCleanupAttempted,
                    cleanedRemoteCacheRecords = cacheCleaned,
                    pendingRemoteCacheRecords = cachePending,
                    pendingLocalCleanup = !local.complete
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Startup maintenance: finish deletion intents that survived process death or I/O interruption. */
    suspend fun retryPendingLocalDeletion(): Int = withContext(Dispatchers.IO) {
        var completed = 0
        deletionJournal.all().forEach { intent ->
            runCatching {
                if (intent.stage == ExamDeletionStage.PREPARED) {
                    if (draftRepository.getDraftByIdOnce(intent.examId) != null) {
                        draftRepository.deleteDraftById(intent.examId)
                        check(draftRepository.getDraftByIdOnce(intent.examId) == null)
                    }
                    deletionJournal.markCommitted(intent.examId)
                }
                if (cleanupCommittedDeletion(intent.examId, intent.pageIds).complete) completed++
            }
        }
        completed
    }

    private data class LocalCleanup(val deletedFiles: Int, val clearedMasks: Int, val complete: Boolean)

    private fun cleanupCommittedDeletion(examId: Long, pageIds: List<Long>): LocalCleanup {
        var deleted = 0
        var masks = 0
        var complete = true

        pageIds.forEach { pageId ->
            if (homeworkPrivacyMaskStore.clearDurably(pageId)) masks++ else complete = false
        }

        val reportPrefix = "BaykusNot_Exam_${examId}_"
        val targets = mutableListOf<File>()
        File(appContext.cacheDir, "reports").listFiles()
            ?.filter { it.isFile && it.name.startsWith(reportPrefix) }
            ?.let(targets::addAll)
        targets += listOf(
            File(appContext.filesDir, "paper_uploads/$examId"),
            File(appContext.filesDir, "paper_import_journal/exam_${examId}.paths"),
            File(appContext.filesDir, "exams/$examId"),
            File(appContext.filesDir, "exam_${examId}_teacher_rubric.pdf"),
            File(appContext.filesDir, "exam_${examId}_teacher_rubric.pdf.meta"),
            File(appContext.filesDir, "line_overrides_${examId}.json")
        )

        targets.forEach { target ->
            if (!target.exists()) return@forEach
            val count = if (target.isDirectory) target.walkBottomUp().count { it.isFile } else 1
            val ok = if (target.isDirectory) target.deleteRecursively() else target.delete()
            if (ok) deleted += count else complete = false
        }

        if (complete && !deletionJournal.clear(examId)) complete = false
        return LocalCleanup(deleted, masks, complete)
    }
}
