package com.example.core.network

import com.example.core.model.FeedbackDetailLevel
import com.example.core.security.SecureApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlin.math.abs

/** Compact, teacher-approved evidence. Deliberately contains NO raw answer, image, rubric or question text. */
data class ApprovedFeedbackQuestionEvidence(
    val questionOrderIndex: Int,
    val questionNumber: String,
    val finalTeacherScore: Double,
    val originalAiScore: Double,
    val maxScore: Double,
    val teacherModified: Boolean,
    val answerType: String,
    val strengths: List<String>,
    val missingElements: List<String>,
    val misconceptions: List<String>,
    val nextSteps: List<String>
)

data class ApprovedFeedbackRequest(
    val studentPaperId: Long,
    val gradeLevel: String?,
    val detailLevel: FeedbackDetailLevel,
    val questions: List<ApprovedFeedbackQuestionEvidence>,
    val writingStrengths: List<String> = emptyList(),
    val writingIssues: List<String> = emptyList(),
    val writingNextSteps: List<String> = emptyList(),
    val feedbackModelId: String? = null
)

data class ApprovedFeedbackResult(
    val questionFeedback: Map<Int, String>,
    val overallFeedback: String,
    val writingFeedback: String? = null,
    val usage: AiUsageMetadata = AiUsageMetadata()
)

/**
 * Final prose layer. It cannot see the student's raw work and therefore cannot re-grade it.
 * It receives only the teacher-approved final score plus compact pedagogy produced by the main evaluator.
 */
class HttpGeminiStudentFeedbackWriter(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore
) {
    private val parser = Json { ignoreUnknownKeys = true; isLenient = true }

    suspend fun generateApproved(request: ApprovedFeedbackRequest): ApprovedFeedbackResult {
        require(request.detailLevel != FeedbackDetailLevel.SCORE_ONLY) { "Puan-only modunda ayrıntılı dönüt üretilmez." }
        require(request.questions.isNotEmpty()) { "Dönüt üretilecek soru bulunamadı." }

        val local = request.questions.map { sanitizedEvidence(it) }.mapNotNull { q -> deterministicFeedback(q)?.let { q.questionOrderIndex to it } }.toMap()
        val needsAi = request.questions.filterNot { local.containsKey(it.questionOrderIndex) }
        val generated = generate(request, needsAi)
        val merged = request.questions.associate { q ->
            q.questionOrderIndex to (local[q.questionOrderIndex]
                ?: generated.questionFeedback[q.questionOrderIndex]
                ?: throw IllegalStateException("${q.questionNumber}. soru için ayrıntılı dönüt eksik döndü."))
        }
        val overall = generated.overallFeedback.trim()
        require(overall.isNotBlank()) { "Genel değerlendirme boş döndü." }
        return ApprovedFeedbackResult(merged, overall, generated.writingFeedback?.trim()?.takeIf { it.isNotBlank() }, generated.usage)
    }

    private data class GeneratedFeedback(
        val questionFeedback: Map<Int, String>,
        val overallFeedback: String,
        val writingFeedback: String?,
        val usage: AiUsageMetadata = AiUsageMetadata()
    )

    private fun sanitizedEvidence(q: ApprovedFeedbackQuestionEvidence): ApprovedFeedbackQuestionEvidence {
        if (!q.teacherModified || q.maxScore <= 0.0) return q
        val delta = q.finalTeacherScore - q.originalAiScore
        val material = kotlin.math.abs(delta) >= kotlin.math.max(1.0, q.maxScore * 0.15)
        if (!material) return q
        return if (delta > 0.0) {
            // Teacher judged the answer materially stronger: old AI deficit claims are no longer reliable.
            q.copy(missingElements = emptyList(), misconceptions = emptyList(), nextSteps = emptyList())
        } else {
            // Teacher judged the answer materially weaker: old AI praise may overstate achievement.
            q.copy(strengths = emptyList())
        }
    }

    private suspend fun generate(
        request: ApprovedFeedbackRequest,
        needsAi: List<ApprovedFeedbackQuestionEvidence>
    ): GeneratedFeedback = withContext(Dispatchers.IO) {
        var key = ""
        apiKeyStore.useApiKey { key = it }
        require(key.isNotBlank()) { "Dönüt için Gemini API anahtarı bulunamadı." }

        val needsAiOrders = needsAi.map { it.questionOrderIndex }.toSet()
        val evidenceArray = buildJsonArray {
            request.questions.sortedBy { it.questionOrderIndex }.forEach { rawQ ->
                val q = sanitizedEvidence(rawQ)
                add(buildJsonObject {
                    put("questionOrderIndex", q.questionOrderIndex)
                    put("questionNumber", q.questionNumber)
                    put("finalTeacherScore", q.finalTeacherScore)
                    put("maxScore", q.maxScore)
                    put("answerType", q.answerType)
                    put("strengths", buildJsonArray { q.strengths.take(5).forEach { add(it.take(360)) } })
                    put("missingElements", buildJsonArray { q.missingElements.take(5).forEach { add(it.take(360)) } })
                    put("misconceptions", buildJsonArray { q.misconceptions.take(4).forEach { add(it.take(360)) } })
                    put("nextSteps", buildJsonArray { q.nextSteps.take(4).forEach { add(it.take(360)) } })
                    put("writeQuestionFeedback", q.questionOrderIndex in needsAiOrders)
                })
            }
        }

        val writingDiagnostic = buildJsonObject {
            put("strengths", buildJsonArray { request.writingStrengths.take(4).forEach { add(it.take(320)) } })
            put("issues", buildJsonArray { request.writingIssues.take(5).forEach { add(it.take(320)) } })
            put("nextSteps", buildJsonArray { request.writingNextSteps.take(4).forEach { add(it.take(320)) } })
        }
        val shouldWriteWritingFeedback = request.writingStrengths.isNotEmpty() || request.writingIssues.isNotEmpty() || request.writingNextSteps.isNotEmpty()

        val lengthRule = when (request.detailLevel) {
            FeedbackDetailLevel.BRIEF -> "İstenen soru dönütü için 1 somut cümle; genel değerlendirme için 2-3 kısa cümle yaz."
            FeedbackDetailLevel.INSTRUCTIONAL -> "Kısmen doğru/yanlış cevapta 3-5 öğretici cümle; genel değerlendirmede 1-2 kısa paragraf yaz."
            FeedbackDetailLevel.DETAILED -> "Kısmen doğru/yanlış cevapta genellikle 4-7 cümle; genel değerlendirmede güçlü yön, gelişim alanı ve uygulanabilir çalışma yolunu içeren 2-3 doğal paragraf yaz."
            FeedbackDetailLevel.SCORE_ONLY -> error("Puan-only")
        }
        // Hard output ceiling prevents a malformed/over-verbose response from turning one
        // student's feedback into an unbounded output-cost event. The ceilings remain generous
        // enough for the requested teacher-like detailed feedback.
        val maxOutputTokens = when (request.detailLevel) {
            FeedbackDetailLevel.BRIEF -> (600 + needsAi.size * 100).coerceAtMost(2500)
            FeedbackDetailLevel.INSTRUCTIONAL -> (900 + needsAi.size * 180).coerceAtMost(4000)
            FeedbackDetailLevel.DETAILED -> (1200 + needsAi.size * 300).coerceAtMost(7000)
            FeedbackDetailLevel.SCORE_ONLY -> error("Puan-only")
        }

        val systemInstruction = """
            Sen BaykuşNot'un nihai öğrenci dönüt yazarı olan deneyimli bir öğretmensin.
            Ham öğrenci cevabını, soru metnini, rubriği veya görüntüyü GÖRMÜYORSUN. Yeniden değerlendirme yapamazsın.
            finalTeacherScore öğretmenin onayladığı tartışılmaz nihai puandır; puanı ASLA değiştirme veya yeni puan önerme.
            Yalnız strengths, missingElements, misconceptions ve nextSteps alanlarında verilen pedagojik teşhisi doğal Türkçeye dönüştür.
            BaykuşNot öğretmen değişiklikleriyle çelişen eski teşhisleri bu isteğe gelmeden yerelde bastırır; dış model öğretmen-AI uyuşmazlığını görmez ve yeni gerekçe uyduramaz.
            Dönütte sayısal puanı tekrar yazma; puan raporda ayrı gösterilir.
            writeQuestionFeedback=false olan soru için items üretme; BaykuşNot basit dönütü cihazda ücretsiz oluşturur.
            Kişilik etiketi, utandırma, başka öğrencilerle kıyaslama ve boş övgü kullanma.
            Genel değerlendirmede yalnız sağlanan teşhisler arasında örüntü kur; öğrencinin sınav dışındaki özellikleri hakkında çıkarım yapma.
            writingDiagnostic yalnız yazım/noktalama/anlatım için yapılandırılmış teşhistir. writeWritingFeedback=true ise bunu kısa, somut öğretmen Türkçesine dönüştür; false ise writingFeedback boş olsun.
            ${YazekContentPolicy.promptRules}
            $lengthRule
        """.trimIndent()

        val requestedFeedbackModel = request.feedbackModelId ?: GeminiModelRegistry.feedbackModel
        GeminiModelRegistry.requireFeedbackModelApproved(requestedFeedbackModel)

        val responseSchema = buildJsonObject {
            put("type", "OBJECT")
            put("properties", buildJsonObject {
                put("items", buildJsonObject {
                    put("type", "ARRAY")
                    put("items", buildJsonObject {
                        put("type", "OBJECT")
                        put("properties", buildJsonObject {
                            put("questionOrderIndex", buildJsonObject { put("type", "INTEGER") })
                            put("feedback", buildJsonObject { put("type", "STRING") })
                        })
                        put("required", buildJsonArray { add("questionOrderIndex"); add("feedback") })
                    })
                })
                put("overallFeedback", buildJsonObject { put("type", "STRING") })
                put("writingFeedback", buildJsonObject { put("type", "STRING") })
            })
            put("required", buildJsonArray { add("items"); add("overallFeedback"); add("writingFeedback") })
        }

        val body = buildJsonObject {
            put("systemInstruction", buildJsonObject { put("parts", buildJsonArray { add(buildJsonObject { put("text", systemInstruction) }) }) })
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", buildJsonArray {
                        add(buildJsonObject {
                            put("text", "Öğrenci düzeyi: ${request.gradeLevel.orEmpty()}\nÖğretmen onaylı kompakt pedagojik teşhis:\n$evidenceArray\nYazım/noktalama yapılandırılmış teşhisi:\n$writingDiagnostic\nwriteWritingFeedback=$shouldWriteWritingFeedback")
                        })
                    })
                })
            })
            put("generationConfig", buildJsonObject {
                put("responseMimeType", "application/json")
                put("responseSchema", responseSchema)
                put("maxOutputTokens", maxOutputTokens)
            })
            put("store", false)
        }

        val requestHttp = Request.Builder()
            .url(GeminiModelRegistry.generateContentUrl(requestedFeedbackModel))
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        okHttpClient.executeCancellable(requestHttp).use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Dönüt modeli HTTP ${response.code} hatası verdi.")
            val raw = response.body?.string().orEmpty()
            val root = parser.parseToJsonElement(raw).jsonObject
            val text = root["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("content")?.jsonObject?.get("parts")?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("text")?.jsonPrimitive?.content.orEmpty()
            if (text.isBlank()) throw IllegalStateException("Dönüt modeli boş yanıt verdi.")
            val data = parser.parseToJsonElement(text).jsonObject
            val itemMap = data["items"]?.jsonArray.orEmpty().mapNotNull { item ->
                val obj = item.jsonObject
                val idx = obj["questionOrderIndex"]?.jsonPrimitive?.content?.toIntOrNull() ?: return@mapNotNull null
                val feedback = obj["feedback"]?.jsonPrimitive?.content?.trim().orEmpty()
                if (feedback.isBlank()) null else idx to feedback
            }.toMap()
            val requiredOrders = needsAiOrders
            val missing = requiredOrders - itemMap.keys
            if (missing.isNotEmpty()) throw IllegalStateException("Dönüt modeli bazı soruları atladı: ${missing.sorted().joinToString()}")
            val overall = data["overallFeedback"]?.jsonPrimitive?.content?.trim().orEmpty()
            if (overall.isBlank()) throw IllegalStateException("Genel değerlendirme üretilmedi.")
            val writing = data["writingFeedback"]?.jsonPrimitive?.content?.trim().orEmpty()
            if (shouldWriteWritingFeedback && writing.isBlank()) throw IllegalStateException("Yazım/noktalama dönütü üretilmedi.")
            validateProviderSafety(root)
            validatePedagogicalOutput(itemMap.values.toList() + overall + listOfNotNull(writing.takeIf { it.isNotBlank() }))
            val usageObj = root["usageMetadata"]?.jsonObject
            val modelStatusObj = root["modelStatus"]?.jsonObject
            val usage = AiUsageMetadata(
                inputTokens = usageObj?.get("promptTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                cachedInputTokens = usageObj?.get("cachedContentTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                outputTokens = usageObj?.get("candidatesTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                thinkingTokens = usageObj?.get("thoughtsTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                actualModelVersion = root["modelVersion"]?.jsonPrimitive?.contentOrNull,
                responseId = root["responseId"]?.jsonPrimitive?.contentOrNull,
                modelStatusStage = modelStatusObj?.get("modelStage")?.jsonPrimitive?.contentOrNull,
                modelRetirementTime = modelStatusObj?.get("retirementTime")?.jsonPrimitive?.contentOrNull,
                modelStatusMessage = modelStatusObj?.get("message")?.jsonPrimitive?.contentOrNull
            )
            GeneratedFeedback(itemMap, overall, writing.takeIf { it.isNotBlank() }, usage)
        }
    }

    private fun validateProviderSafety(root: kotlinx.serialization.json.JsonObject) {
        val blockReason = root["promptFeedback"]?.jsonObject?.get("blockReason")?.jsonPrimitive?.contentOrNull
        require(blockReason.isNullOrBlank() || blockReason == "BLOCK_REASON_UNSPECIFIED") { "Dönüt isteği sağlayıcı güvenlik filtresinde engellendi: $blockReason" }
        val candidate = root["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
        val finishReason = candidate?.get("finishReason")?.jsonPrimitive?.contentOrNull
        require(finishReason.isNullOrBlank() || finishReason == "STOP") { "Dönüt güvenli/tam biçimde tamamlanmadı: $finishReason" }
        val blocked = candidate?.get("safetyRatings")?.jsonArray.orEmpty().any { rating ->
            rating.jsonObject["blocked"]?.jsonPrimitive?.content?.toBooleanStrictOrNull() == true
        }
        require(!blocked) { "Dönüt sağlayıcı güvenlik filtresinde engellendi." }
    }

    private fun validatePedagogicalOutput(texts: List<String>) {
        val joined = texts.joinToString(" ").lowercase(java.util.Locale.forLanguageTag("tr-TR"))
        val forbidden = listOf(
            "tembelsin", "başarısızsın", "zeki değilsin", "aptalsın", "beceriksizsin",
            "diğer öğrencilerden", "sınıf arkadaşlarından daha", "senden olmaz"
        )
        require(forbidden.none { joined.contains(it) }) { "Dönüt pedagojik güvenlik kontrolünden geçmedi." }
        YazekContentPolicy.validateStudentFacingFeedback(texts)
        val scorePattern = Regex("""\b\d+(?:[.,]\d+)?\s*/\s*\d+(?:[.,]\d+)?\b""")
        require(texts.none { scorePattern.containsMatchIn(it) }) { "Dönüt içinde yeniden üretilmiş sayısal puan bulundu." }
        require(texts.all { it.length <= 12000 }) { "Dönüt beklenmeyen uzunlukta üretildi." }
    }

    private fun deterministicFeedback(q: ApprovedFeedbackQuestionEvidence): String? {
        if (q.answerType == "UNANSWERED") {
            return "Bu soruyu cevaplamamışsın. İlgili konuyu kısa bir tekrar yaptıktan sonra benzer bir soruyu yeniden çözmen yararlı olacaktır."
        }
        if (q.maxScore <= 0.0) return null
        val ratio = q.finalTeacherScore / q.maxScore
        if (ratio >= 0.999 && q.missingElements.isEmpty() && q.misconceptions.isEmpty()) {
            val strength = q.strengths.firstOrNull()?.trim()?.takeIf { it.isNotBlank() }
            return if (strength == null) {
                "Cevabın doğru ve yeterli. Sorunun beklediği temel unsurların tamamını karşılamışsın."
            } else {
                "Cevabın doğru ve yeterli. Özellikle $strength yönünü doğru kullanmışsın."
            }
        }
        return null
    }
}
