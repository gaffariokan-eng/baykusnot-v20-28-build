package com.example.core.network

import com.example.core.model.ExamType
import java.io.File

data class RubricGenerationQuestion(
    val questionOrderIndex: Int,
    val questionNumber: String,
    val questionText: String,
    val points: Int
)

sealed interface RubricGenerationSourceContext {
    data class ListeningText(
        val text: String
    ) : RubricGenerationSourceContext

    data class ListeningAudio(
        val file: File,
        val mimeType: String,
        val displayName: String,
        val sizeBytes: Long
    ) : RubricGenerationSourceContext

    data class HomeworkText(
        val text: String
    ) : RubricGenerationSourceContext

    data class HomeworkDocument(
        val file: File,
        val mimeType: String,
        val displayName: String,
        val sizeBytes: Long
    ) : RubricGenerationSourceContext
}

data class ExamRubricGenerationInput(
    val questions: List<RubricGenerationQuestion>,
    val deductWritingPunctuationPoints: Boolean,
    val sourceContext: RubricGenerationSourceContext? = null,
    val examType: ExamType = ExamType.WRITTEN,
    val examDraftId: Long? = null
) {
    init {
        require(questions.isNotEmpty()) { "Generation input must contain at least one question." }
    }
}

data class GeneratedExamRubricCriterion(
    val questionOrderIndex: Int,
    val questionNumberSnapshot: String,
    val criterionOrderIndex: Int,
    val title: String,
    val description: String,
    val maxPoints: Int,
    val expectedAnswer: String,
    val partialCreditGuidance: String = "",
    val commonMistakes: String = ""
)

sealed interface ExamRubricGenerationResult {
    data class Generated(
        val criteria: List<GeneratedExamRubricCriterion>
    ) : ExamRubricGenerationResult

    data object MissingApiKey : ExamRubricGenerationResult
    data object InvalidInput : ExamRubricGenerationResult
    data object NetworkFailure : ExamRubricGenerationResult
    data object Unauthorized : ExamRubricGenerationResult
    data object RateLimited : ExamRubricGenerationResult
    data object ServiceUnavailable : ExamRubricGenerationResult
    data object MalformedResponse : ExamRubricGenerationResult
    data object UnexpectedFailure : ExamRubricGenerationResult
}

/**
 * Contract for generating exam rubrics from locked canonical questions.
 * Invariants:
 * - Canonical question text and points are authoritative.
 * - Generated criteria cannot mutate questions.
 * - Generated rubric is NOT automatically locked.
 * - Generation result is pure domain data, not persistence.
 * - Teacher remains final reviewer.
 */
interface ExamRubricGenerator {
    suspend fun generate(
        input: ExamRubricGenerationInput
    ): ExamRubricGenerationResult

    suspend fun generateWithSource(
        input: ExamRubricGenerationInput,
        evaluationSourceType: String,
        originalTeacherAnswerKey: String?,
        originalTeacherRubric: String?,
        isAsIs: Boolean
    ): ExamRubricGenerationResult

    suspend fun extractDocumentText(
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String>

    suspend fun extractDocumentTextForExam(
        examDraftId: Long,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Result<String> = extractDocumentText(fileName, mimeType, bytes)
}
