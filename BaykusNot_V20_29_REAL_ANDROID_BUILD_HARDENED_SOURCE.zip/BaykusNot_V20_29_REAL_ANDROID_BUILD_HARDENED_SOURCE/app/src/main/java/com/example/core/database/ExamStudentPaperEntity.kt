package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_student_paper",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["examDraftId"])]
)
data class ExamStudentPaperEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val examDraftId: Long,
    val studentSequenceIndex: Int,
    val studentName: String? = null,
    val classLevel: String? = null,
    val branch: String? = null,
    val schoolNumber: String? = null,
    val status: String, // "READY", "MISSING_PAGES", "DUPLICATE_PAGES", "UNMATCHED", "ERROR"
    val statusReason: String? = null,
    val isManuallyCorrected: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
