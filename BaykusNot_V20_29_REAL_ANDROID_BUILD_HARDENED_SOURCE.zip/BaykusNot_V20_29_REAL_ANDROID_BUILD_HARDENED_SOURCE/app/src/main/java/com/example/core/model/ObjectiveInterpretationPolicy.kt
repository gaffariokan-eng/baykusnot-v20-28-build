package com.example.core.model

/**
 * Human-facing interpretation for question-to-objective reporting.
 * READINESS is diagnostic: percentages describe current prerequisite evidence, not permanent achievement.
 */
object ObjectiveInterpretationPolicy {
    fun singular(examType: ExamType): String = when (examType) {
        ExamType.READINESS -> "ön koşul bilgi/beceri hedefi"
        else -> "kazanım"
    }

    fun plural(examType: ExamType): String = when (examType) {
        ExamType.READINESS -> "ön koşul bilgi/beceri hedefleri"
        else -> "kazanımlar"
    }

    fun level(examType: ExamType, percentage: Double): String = when (examType) {
        ExamType.READINESS -> when {
            percentage >= 85 -> "Ön koşul bilgi/beceri güçlü biçimde karşılanıyor."
            percentage >= 70 -> "Ön koşul bilgi/beceri büyük ölçüde karşılanıyor."
            percentage >= 50 -> "Ön koşul bilgi/beceri kısmen karşılanıyor."
            else -> "Bu ön koşul bilgi/beceri için destek gerekiyor."
        }
        else -> when {
            percentage >= 85 -> "Kazanım güçlü düzeyde."
            percentage >= 70 -> "Kazanım büyük ölçüde edinilmiş."
            percentage >= 50 -> "Kazanım kısmen edinilmiş."
            else -> "Kazanım üzerinde çalışılması gerekiyor."
        }
    }
}
