package com.example.core.network

import com.example.core.security.BoundedInputReader
import android.content.Context
import android.util.AtomicFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.put
import kotlinx.serialization.json.add
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import java.io.File
import java.security.MessageDigest

@Serializable
data class BatchJobMetadata(
    val jobId: String,
    val draftId: Long,
    val studentPaperIds: List<Long>,
    val createdAt: Long,
    var status: String,
    val isFileBased: Boolean = false,
    val fingerprint: String? = null,
    /** Remote Files API input resource; retained in the cleanup ledger until remote deletion is confirmed. */
    val inputFileResourceName: String? = null,
    val outputFileResourceName: String? = null,
    val modelId: String = "",
    /** Remote deletion must be confirmed before this local record can disappear. */
    val cleanupStatus: String = "NONE",
    val cleanupLastError: String? = null,
    val cleanupUpdatedAt: Long? = null
)

data class BatchCleanupResult(
    val matchedRecords: Int,
    val confirmedRemoteDeleted: Int,
    val pendingRemoteDeletion: Int,
    val localOnlyRemoved: Int
)

@Serializable
data class BatchJobStore(
    val jobs: List<BatchJobMetadata> = emptyList()
)

data class BatchStudentResult(
    val studentPaperId: Long,
    val responseJson: String?,
    val isSuccess: Boolean,
    val errorMessage: String?
)

data class RemoteOperationInfo(
    val name: String,
    val displayName: String,
    val rawState: String
)

/** Latest provider-side Batch state used by privacy cleanup. */
data class RemoteBatchSnapshot(
    val exists: Boolean,
    val state: String,
    val terminal: Boolean,
    val outputFileResourceName: String? = null,
    val errorCode: Int? = null
)

class GeminiBatchJobManager(
    private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta"
) {
    private val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true }
    private val file = File(context.filesDir, "gemini_batch_jobs.json")
    private val atomicFile = AtomicFile(file)
    private val maxLedgerBytes = 16L * 1024L * 1024L

    init {
        // Crash-safe local hygiene: JSONL payloads are temporary and must never survive app restarts.
        context.cacheDir.listFiles()?.filter { it.name.startsWith("batch_input_") && it.name.endsWith(".jsonl") }
            ?.forEach { runCatching { it.delete() } }
    }

    private fun loadJobs(): List<BatchJobMetadata> {
        val backup = File(file.path + ".bak")
        if (!file.exists() && !backup.exists()) return emptyList()
        return runCatching {
            atomicFile.openRead().use { input ->
                val bytes = BoundedInputReader.read(input, maxLedgerBytes, "Batch gizlilik/audit kaydı")
                jsonParser.decodeFromString<BatchJobStore>(String(bytes, Charsets.UTF_8)).jobs
            }
        }.getOrElse { error ->
            throw IllegalStateException(
                "Batch gizlilik/audit kayıt dosyası okunamadı; uzak kaynak kimlikleri kaybolmuş varsayılamaz.",
                error
            )
        }
    }

    private fun saveJobs(jobs: List<BatchJobMetadata>) {
        file.parentFile?.mkdirs()
        val encoded = jsonParser.encodeToString(BatchJobStore.serializer(), BatchJobStore(jobs))
        require(encoded.toByteArray(Charsets.UTF_8).size.toLong() <= maxLedgerBytes) {
            "Batch gizlilik/audit kaydı güvenli boyut sınırını aşıyor."
        }
        // Validate serialization before touching the authoritative ledger.
        jsonParser.decodeFromString<BatchJobStore>(encoded)

        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomicFile.startWrite()
            stream.write(encoded.toByteArray(Charsets.UTF_8))
            atomicFile.finishWrite(stream)
            stream = null

            // Read-back verification through AtomicFile also exercises .bak recovery semantics.
            val verified = atomicFile.openRead().use { input ->
                val bytes = BoundedInputReader.read(input, maxLedgerBytes, "Batch gizlilik/audit kaydı")
                jsonParser.decodeFromString<BatchJobStore>(String(bytes, Charsets.UTF_8))
            }
            check(verified.jobs == jobs) { "Batch audit kaydı yazma sonrası doğrulanamadı." }
        } catch (error: Throwable) {
            stream?.let { runCatching { atomicFile.failWrite(it) } }
            throw IllegalStateException("Batch gizlilik/audit kaydı crash-safe biçimde yazılamadı.", error)
        }
    }

    fun normalizeState(rawState: String): String {
        val upper = rawState.uppercase()
        return when {
            upper.contains("SUCCEEDED") -> "JOB_STATE_SUCCEEDED"
            upper.contains("FAILED") -> "JOB_STATE_FAILED"
            upper.contains("CANCELLED") || upper.contains("CANCELED") -> "JOB_STATE_CANCELLED"
            upper.contains("EXPIRED") -> "JOB_STATE_EXPIRED"
            upper.contains("RUNNING") || upper.contains("PROCESSING") -> "JOB_STATE_RUNNING"
            upper.contains("PENDING") -> "JOB_STATE_PENDING"
            else -> "JOB_STATE_PENDING"
        }
    }

    fun getActiveJobsForDraft(draftId: Long): List<BatchJobMetadata> {
        val jobs = loadJobs()
        return jobs.filter { it.draftId == draftId && (it.status == "JOB_STATE_PENDING" || it.status == "JOB_STATE_RUNNING") }
    }

    fun getUnprocessedJobsForDraft(draftId: Long): List<BatchJobMetadata> {
        val jobs = loadJobs()
        return jobs.filter { it.draftId == draftId && it.status != "COMPLETED_PROCESSED" && it.status != "FAILED_PROCESSED" }
    }

    fun updateJobStatusInStore(jobId: String, newStatus: String) {
        val jobs = loadJobs().toMutableList()
        val index = jobs.indexOfFirst { it.jobId == jobId }
        if (index >= 0) {
            jobs[index] = jobs[index].copy(status = newStatus)
            saveJobs(jobs)
        }
    }

    /**
     * Transactional privacy cleanup. A provider Batch operation is never treated as cancelled
     * merely because `batches.delete` succeeded: Google documents delete as "forget result", not
     * cancellation. Active operations must reach a terminal provider state before their operation
     * record is deleted. File-output resource IDs are discovered from `batches.get` before the
     * operation disappears, and every known input/output file must be deleted first.
     */
    suspend fun cleanupDraft(draftId: Long, apiKey: String? = null): BatchCleanupResult = withContext(Dispatchers.IO) {
        val all = loadJobs()
        val matching = all.filter { it.draftId == draftId }
        if (matching.isEmpty()) return@withContext BatchCleanupResult(0, 0, 0, 0)

        var confirmedRemote = 0
        var pendingRemote = 0
        var localOnly = 0
        val retained = all.filterNot { it.draftId == draftId }.toMutableList()

        for (originalMeta in matching) {
            val hasRemoteBatch = !originalMeta.jobId.startsWith("local_intent_") && originalMeta.jobId.isNotBlank()
            val hasRemoteInput = !originalMeta.inputFileResourceName.isNullOrBlank()
            val hasRemoteOutput = !originalMeta.outputFileResourceName.isNullOrBlank()
            if (!hasRemoteBatch && !hasRemoteInput && !hasRemoteOutput) {
                localOnly++
                continue
            }

            if (apiKey.isNullOrBlank()) {
                pendingRemote++
                retained += originalMeta.pendingCleanup("Uzak silme için kimlik bilgisi/gateway oturumu yok.")
                continue
            }

            val errors = mutableListOf<String>()
            var meta = originalMeta
            var batchTerminal = !hasRemoteBatch
            var batchAbsent = !hasRemoteBatch

            if (hasRemoteBatch) {
                var snapshot = remoteGetBatchSnapshot(meta.jobId, apiKey)
                if (snapshot == null) {
                    pendingRemote++
                    retained += meta.pendingCleanup("Batch durumu sağlayıcıdan doğrulanamadı; yerel takip kaydı korundu.")
                    continue
                }

                if (snapshot.exists && !snapshot.terminal) {
                    val cancelAccepted = remoteCancel(meta.jobId, apiKey)
                    if (!cancelAccepted) {
                        pendingRemote++
                        retained += meta.copy(
                            cleanupStatus = "REMOTE_CANCEL_PENDING",
                            cleanupLastError = "Aktif Batch için iptal isteği sağlayıcı tarafından doğrulanamadı.",
                            cleanupUpdatedAt = System.currentTimeMillis()
                        )
                        continue
                    }
                    // Cancellation is asynchronous/best-effort. Verify provider state; do not delete
                    // the operation while it can still be processing student data.
                    snapshot = remoteGetBatchSnapshot(meta.jobId, apiKey)
                    if (snapshot == null || (snapshot.exists && !snapshot.terminal)) {
                        pendingRemote++
                        retained += meta.copy(
                            status = snapshot?.state ?: meta.status,
                            cleanupStatus = "REMOTE_CANCEL_PENDING",
                            cleanupLastError = "Batch iptali başlatıldı; terminal durum doğrulaması bekleniyor.",
                            cleanupUpdatedAt = System.currentTimeMillis()
                        )
                        continue
                    }
                }

                if (!snapshot.exists) {
                    // For an old file-based record whose operation vanished before BaykuşNot ever
                    // learned the output file ID, privacy cleanup cannot honestly be certified.
                    if (meta.isFileBased && meta.outputFileResourceName.isNullOrBlank()) {
                        pendingRemote++
                        retained += meta.pendingCleanup(
                            "Batch işlemi artık bulunamıyor ancak dosya-tabanlı sonuç kaynağının kimliği bilinmiyor; otomatik tam silme doğrulanamadı."
                        )
                        continue
                    }
                    batchAbsent = true
                    batchTerminal = true
                } else {
                    batchTerminal = snapshot.terminal
                    meta = meta.copy(
                        status = snapshot.state,
                        outputFileResourceName = meta.outputFileResourceName ?: snapshot.outputFileResourceName
                    )
                    if (meta.isFileBased && snapshot.state == "JOB_STATE_SUCCEEDED" && meta.outputFileResourceName.isNullOrBlank()) {
                        pendingRemote++
                        retained += meta.pendingCleanup("Başarılı dosya-tabanlı Batch'in sonuç dosyası kimliği sağlayıcı yanıtından çözülemedi.")
                        continue
                    }
                }
            }

            if (!batchTerminal) {
                pendingRemote++
                retained += meta.pendingCleanup("Batch henüz terminal durumda değil.")
                continue
            }

            // Delete Files API resources before deleting the operation so output identifiers are
            // never lost while file cleanup is still pending.
            val inputDeleted = meta.inputFileResourceName.isNullOrBlank() ||
                remoteDeleteFileConfirmed(meta.inputFileResourceName!!, apiKey).also { ok ->
                    if (!ok) errors += "Batch giriş dosyası uzaktan silinemedi: ${meta.inputFileResourceName}"
                }
            val outputDeleted = meta.outputFileResourceName.isNullOrBlank() ||
                remoteDeleteFileConfirmed(meta.outputFileResourceName!!, apiKey).also { ok ->
                    if (!ok) errors += "Batch sonuç dosyası uzaktan silinemedi: ${meta.outputFileResourceName}"
                }

            if (!inputDeleted || !outputDeleted) {
                pendingRemote++
                retained += meta.pendingCleanup(errors.joinToString(" | ").ifBlank { "Uzak dosya silme doğrulanamadı." })
                continue
            }

            val operationDeleted = batchAbsent || !hasRemoteBatch || remoteDeleteBatch(meta.jobId, apiKey)
            if (!operationDeleted) {
                pendingRemote++
                retained += meta.pendingCleanup("Terminal Batch işlem kaydı sağlayıcıdan silinemedi: ${meta.jobId}")
                continue
            }

            confirmedRemote++
        }

        saveJobs(retained)
        BatchCleanupResult(matching.size, confirmedRemote, pendingRemote, localOnly)
    }

    suspend fun retryPendingRemoteCleanup(apiKey: String): BatchCleanupResult = withContext(Dispatchers.IO) {
        val pendingDrafts = loadJobs()
            .filter { it.cleanupStatus == "REMOTE_DELETE_PENDING" || it.cleanupStatus == "REMOTE_CANCEL_PENDING" }
            .map { it.draftId }
            .distinct()
        var matched = 0
        var confirmed = 0
        var pending = 0
        var localOnly = 0
        for (draftId in pendingDrafts) {
            val result = cleanupDraft(draftId, apiKey)
            matched += result.matchedRecords
            confirmed += result.confirmedRemoteDeleted
            pending += result.pendingRemoteDeletion
            localOnly += result.localOnlyRemoved
        }
        BatchCleanupResult(matched, confirmed, pending, localOnly)
    }

    private fun BatchJobMetadata.pendingCleanup(message: String): BatchJobMetadata = copy(
        cleanupStatus = "REMOTE_DELETE_PENDING",
        cleanupLastError = message,
        cleanupUpdatedAt = System.currentTimeMillis()
    )

    private suspend fun remoteCancel(jobId: String, apiKey: String): Boolean = try {
        val normalized = jobId.removePrefix("/")
        val request = Request.Builder()
            .url("$baseUrl/$normalized:cancel")
            .header("x-goog-api-key", apiKey)
            .post(ByteArray(0).toRequestBody(null))
            .build()
        okHttpClient.executeCancellable(request).use { it.isSuccessful || it.code == 404 }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        false
    }

    /** Returns null on transport/protocol failure; 404 is represented as an absent terminal resource. */
    private suspend fun remoteGetBatchSnapshot(jobId: String, apiKey: String): RemoteBatchSnapshot? = try {
        val normalized = jobId.removePrefix("/")
        val request = Request.Builder()
            .url("$baseUrl/$normalized")
            .header("x-goog-api-key", apiKey)
            .get()
            .build()
        okHttpClient.executeCancellable(request).use { response ->
            if (response.code == 404) {
                return@use RemoteBatchSnapshot(false, "REMOTE_ABSENT", true)
            }
            if (!response.isSuccessful) return@use null
            val root = jsonParser.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
            val done = root["done"]?.jsonPrimitive?.booleanOrNull ?: false
            val errorCode = (root["error"] as? JsonObject)?.get("code")?.jsonPrimitive?.intOrNull
            val rawState = findStringField(root, "state")
            val state = when {
                errorCode == 1 -> "JOB_STATE_CANCELLED"
                done && errorCode != null -> "JOB_STATE_FAILED"
                done && rawState.isNullOrBlank() -> "JOB_STATE_SUCCEEDED"
                else -> normalizeState(rawState.orEmpty())
            }
            val terminal = done || state in setOf(
                "JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"
            )
            RemoteBatchSnapshot(
                exists = true,
                state = state,
                terminal = terminal,
                outputFileResourceName = extractOutputFileResourceName(root),
                errorCode = errorCode
            )
        }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        null
    }

    private fun findStringField(element: JsonElement?, key: String): String? = when (element) {
        is JsonObject -> {
            val direct = (element[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
            direct ?: element.entries
                .asSequence()
                .filter { it.key != key }
                .mapNotNull { findStringField(it.value, key) }
                .firstOrNull()
        }
        is JsonArray -> element.firstNotNullOfOrNull { findStringField(it, key) }
        else -> null
    }

    /** Handles current `output.inlinedResponses.inlinedResponses[]` plus older flat variants. */
    private fun findInlineResponses(element: JsonElement?): JsonArray? = when (element) {
        is JsonObject -> {
            val direct = element["inlinedResponses"]
            when (direct) {
                is JsonArray -> direct
                is JsonObject -> (direct["inlinedResponses"] as? JsonArray)
                    ?: direct.values.firstNotNullOfOrNull { findInlineResponses(it) }
                else -> element.entries
                    .asSequence()
                    .filter { it.key != "inlinedResponses" }
                    .mapNotNull { findInlineResponses(it.value) }
                    .firstOrNull()
            }
        }
        is JsonArray -> element.firstNotNullOfOrNull { findInlineResponses(it) }
        else -> null
    }

    private fun findLegacyDestFileName(root: JsonObject): String? {
        fun fileNameFrom(value: JsonElement?): String? = (value as? JsonObject)
            ?.get("fileName")
            ?.jsonPrimitive
            ?.contentOrNull
            ?.takeIf { it.startsWith("files/") }
        val response = root["response"] as? JsonObject
        return fileNameFrom(root["dest"])
            ?: fileNameFrom(response?.get("dest"))
            ?: fileNameFrom((root["batch"] as? JsonObject)?.get("dest"))
            ?: fileNameFrom((response?.get("batch") as? JsonObject)?.get("dest"))
    }

    private fun extractOutputFileResourceName(root: JsonObject): String? =
        findStringField(root, "responsesFile") ?: findLegacyDestFileName(root)

    private suspend fun remoteDeleteBatch(jobId: String, apiKey: String): Boolean = try {
        val normalized = jobId.removePrefix("/")
        val request = Request.Builder()
            .url("$baseUrl/$normalized")
            .header("x-goog-api-key", apiKey)
            .delete()
            .build()
        okHttpClient.executeCancellable(request).use { it.isSuccessful || it.code == 404 }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        false
    }

    private suspend fun remoteDeleteFileConfirmed(resourceName: String, apiKey: String): Boolean = try {
        val normalized = resourceName.removePrefix("/")
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/$normalized")
            .header("x-goog-api-key", apiKey)
            .delete()
            .build()
        okHttpClient.executeCancellable(request).use { it.isSuccessful || it.code == 404 }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        false
    }

    fun calculateSubmissionFingerprint(draftId: Long, requests: List<Pair<Long, String>>): String {
        val sorted = requests.sortedBy { it.first }
        val papersPart = sorted.joinToString(",") { it.first.toString() }
        val payloadsPart = sorted.joinToString("|") { it.second }
        val combined = "draft_${draftId}_papers_${papersPart}_payloads_${payloadsPart}"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(combined.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    suspend fun listRemoteOperations(apiKey: String): List<RemoteOperationInfo> = withContext(Dispatchers.IO) {
        val resultList = mutableListOf<RemoteOperationInfo>()
        var pageToken: String? = null
        
        do {
            val url = if (pageToken == null) {
                "$baseUrl/batches"
            } else {
                "$baseUrl/batches?pageToken=$pageToken"
            }
            
            var hasMore = false
            try {
                val request = Request.Builder().url(url).header("x-goog-api-key", apiKey).get().build()
                val response = okHttpClient.executeCancellable(request)
                response.use { resp ->
                    if (resp.isSuccessful) {
                        val bodyStr = resp.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(bodyStr).jsonObject
                        val operations = root["operations"]?.jsonArray
                        
                        if (operations != null) {
                            for (opElement in operations) {
                                try {
                                    val opObj = opElement.jsonObject
                                    val name = opObj["name"]?.jsonPrimitive?.content ?: continue
                                    
                                    val metadata = opObj["metadata"]?.jsonObject
                                    val request = opObj["request"]?.jsonObject ?: metadata?.get("request")?.jsonObject
                                    
                                    val displayName = request?.get("displayName")?.jsonPrimitive?.contentOrNull
                                        ?: findStringField(opObj, "displayName")
                                        ?: ""

                                    val rawState = findStringField(opObj, "state")
                                        ?: "JOB_STATE_PENDING"
                                        
                                    resultList.add(RemoteOperationInfo(name, displayName, rawState))
                                } catch (_: Exception) {}
                            }
                        }
                        
                        pageToken = root["nextPageToken"]?.jsonPrimitive?.content
                        hasMore = !pageToken.isNullOrBlank()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                hasMore = false
            }
        } while (hasMore)
        
        resultList
    }

    suspend fun recoverUncertainJobs(draftId: Long, apiKey: String) = withContext(Dispatchers.IO) {
        val jobs = loadJobs()
        val uncertainJobs = jobs.filter { it.draftId == draftId && (it.status == "SUBMISSION_STARTED" || it.jobId.startsWith("local_intent_")) }
        if (uncertainJobs.isEmpty()) return@withContext

        val remoteOps = listRemoteOperations(apiKey)
        val updatedJobs = loadJobs().toMutableList()

        for (uncertainJob in uncertainJobs) {
            val fingerprint = uncertainJob.fingerprint
            if (fingerprint == null) {
                updatedJobs.removeAll { it.jobId == uncertainJob.jobId }
                continue
            }

            val matchingRemoteOp = remoteOps.find { op ->
                op.displayName.contains(fingerprint) || op.displayName == "exam_batch_${draftId}_$fingerprint"
            }

            if (matchingRemoteOp != null) {
                val remoteState = normalizeState(matchingRemoteOp.rawState)
                val index = updatedJobs.indexOfFirst { it.jobId == uncertainJob.jobId }
                if (index >= 0) {
                    updatedJobs[index] = uncertainJob.copy(
                        jobId = matchingRemoteOp.name,
                        status = remoteState
                    )
                }
            }
            // "Bulunamadı" diye silmeyin. Ağ hatası veya pagination eksiği olabilir.
            // else { updatedJobs.removeAll { it.jobId == uncertainJob.jobId } }
        }
        saveJobs(updatedJobs)
    }

    suspend fun createBatchJob(
        draftId: Long,
        requests: List<Pair<Long, String>>,
        apiKey: String,
        evaluationModelId: String = GeminiModelRegistry.evaluationModel
    ): BatchJobMetadata? = withContext(Dispatchers.IO) {
        GeminiModelRegistry.requireEvaluationModelApproved(evaluationModelId)
        val fingerprint = calculateSubmissionFingerprint(draftId, requests)

        // 1. Check local jobs first
        val localJobs = loadJobs()
        val existingLocal = localJobs.find { it.fingerprint == fingerprint && it.draftId == draftId }
        if (existingLocal != null) {
            if (existingLocal.status != "SUBMISSION_STARTED" && !existingLocal.jobId.startsWith("local_intent_")) {
                return@withContext existingLocal
            }
            
            // 2. Check remote operations second
            val remoteOps = listRemoteOperations(apiKey)
            val matchingRemote = remoteOps.find { op ->
                op.displayName.contains(fingerprint) || op.displayName == "exam_batch_${draftId}_$fingerprint"
            }
            if (matchingRemote != null) {
                val remoteState = normalizeState(matchingRemote.rawState)
                val recoveredMeta = BatchJobMetadata(
                    jobId = matchingRemote.name,
                    draftId = draftId,
                    studentPaperIds = requests.map { it.first },
                    createdAt = System.currentTimeMillis(),
                    status = remoteState,
                    isFileBased = requests.sumOf { it.second.length.toLong() } > 15 * 1024 * 1024 || requests.any { it.second.length > 2 * 1024 * 1024 },
                    fingerprint = fingerprint
                )
                val updatedList = loadJobs().filterNot { it.jobId == recoveredMeta.jobId || it.jobId == "local_intent_$fingerprint" } + recoveredMeta
                saveJobs(updatedList)
                return@withContext recoveredMeta
            }
            
            // Do NOT fall through to create a new job if an intent exists but we couldn't find it remotely.
            return@withContext existingLocal
        }

        // 3. Register local intent before starting any network uploads/calls
        val tempJobId = "local_intent_$fingerprint"
        val totalLength = requests.sumOf { it.second.length.toLong() }
        val anySingleLarge = requests.any { it.second.length > 2 * 1024 * 1024 }
        val useFileApi = totalLength > 15 * 1024 * 1024 || anySingleLarge

        val intentMeta = BatchJobMetadata(
            jobId = tempJobId,
            draftId = draftId,
            studentPaperIds = requests.map { it.first },
            createdAt = System.currentTimeMillis(),
            status = "SUBMISSION_STARTED",
            isFileBased = useFileApi,
            fingerprint = fingerprint
        )
        val updatedWithIntent = loadJobs().filterNot { it.jobId == tempJobId } + intentMeta
        saveJobs(updatedWithIntent)

        var fileResourceName = ""
        val requestBodyJson = if (useFileApi) {
            // V20.8: never persist student batch JSONL as plaintext. The payload is streamed
            // directly from the already in-memory request objects to the resumable upload body.
            fun jsonlLine(studentPaperId: Long, reqBodyStr: String): String {
                val reqObj = jsonParser.parseToJsonElement(reqBodyStr).jsonObject
                return buildJsonObject {
                    put("key", "paper_$studentPaperId")
                    put("request", reqObj)
                }.toString() + "\n"
            }
            try {
                val fileSize = requests.sumOf { (studentPaperId, reqBodyStr) ->
                    jsonlLine(studentPaperId, reqBodyStr).toByteArray(Charsets.UTF_8).size.toLong()
                }
                val metadataJson = buildJsonObject {
                    put("file", buildJsonObject {
                        put("displayName", "batch_input_${System.currentTimeMillis()}")
                    })
                }
                val metadataBody = metadataJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

                val initRequest = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/upload/v1beta/files")
                    .header("x-goog-api-key", apiKey)
                    .header("X-Goog-Upload-Protocol", "resumable")
                    .header("X-Goog-Upload-Command", "start")
                    .header("X-Goog-Upload-Header-Content-Length", fileSize.toString())
                    .header("X-Goog-Upload-Header-Content-Type", "application/jsonl")
                    .post(metadataBody)
                    .build()

                val initResponse = okHttpClient.executeCancellable(initRequest)
                val uploadUrl = initResponse.use { resp ->
                    if (!resp.isSuccessful) throw Exception("Resumable upload initialization failed")
                    resp.header("X-Goog-Upload-URL") ?: resp.header("Location")
                }

                if (uploadUrl.isNullOrBlank()) {
                    throw Exception("No upload URL returned")
                }

                // Upload and finalize by streaming; no student JSONL is written to disk.
                val fileBody = object : RequestBody() {
                    override fun contentType() = "application/jsonl".toMediaType()
                    override fun contentLength(): Long = fileSize
                    override fun writeTo(sink: BufferedSink) {
                        requests.forEach { (studentPaperId, reqBodyStr) ->
                            sink.writeUtf8(jsonlLine(studentPaperId, reqBodyStr))
                        }
                    }
                }
                val uploadRequest = Request.Builder()
                    .url(uploadUrl)
                    .header("X-Goog-Upload-Offset", "0")
                    .header("X-Goog-Upload-Command", "upload, finalize")
                    .post(fileBody)
                    .build()

                val uploadResponse = okHttpClient.executeCancellable(uploadRequest)
                fileResourceName = uploadResponse.use { resp ->
                    if (!resp.isSuccessful) throw Exception("Upload finalization failed")
                    val respStr = resp.body?.string() ?: throw Exception("Empty upload response body")
                    val respJson = jsonParser.parseToJsonElement(respStr).jsonObject
                    val fileObj = respJson["file"]?.jsonObject
                    fileObj?.get("name")?.jsonPrimitive?.content ?: ""
                }

                // Persist the remote resource IMMEDIATELY. If the network dies while creating
                // the Batch operation, recovery still knows exactly which student-data file
                // must later be deleted.
                if (fileResourceName.isNotBlank()) {
                    val current = loadJobs().toMutableList()
                    val idx = current.indexOfFirst { it.jobId == tempJobId }
                    val withFile = intentMeta.copy(inputFileResourceName = fileResourceName)
                    if (idx >= 0) current[idx] = withFile else current += withFile
                    saveJobs(current)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val currentJobs = loadJobs().toMutableList()
                val idx = currentJobs.indexOfFirst { it.jobId == tempJobId }
                if (fileResourceName.isNotBlank()) {
                    val deleted = remoteDeleteFileConfirmed(fileResourceName, apiKey)
                    if (deleted) {
                        currentJobs.removeAll { it.jobId == tempJobId }
                    } else {
                        val retained = intentMeta.copy(
                            inputFileResourceName = fileResourceName,
                            cleanupStatus = "REMOTE_DELETE_PENDING",
                            cleanupLastError = "Upload/finalizasyon hatasından sonra uzak giriş dosyası silinemedi.",
                            cleanupUpdatedAt = System.currentTimeMillis()
                        )
                        if (idx >= 0) currentJobs[idx] = retained else currentJobs += retained
                    }
                } else {
                    currentJobs.removeAll { it.jobId == tempJobId }
                }
                saveJobs(currentJobs)
                return@withContext null
            }

            if (fileResourceName.isBlank()) {
                val currentJobs = loadJobs().filterNot { it.jobId == tempJobId }
                saveJobs(currentJobs)
                return@withContext null
            }

            // Create Batch Job referencing the uploaded file via input_config.file_name
            buildJsonObject {
                put("batch", buildJsonObject {
                    put("display_name", "exam_batch_${draftId}_$fingerprint")
                    put("model", GeminiModelRegistry.modelResource(evaluationModelId))
                    put("input_config", buildJsonObject {
                        put("file_name", fileResourceName)
                    })
                })
            }
        } else {
            // Inline Batch creation
            val batchRequests = buildJsonArray {
                requests.forEach { (studentPaperId, reqBodyStr) ->
                    val reqObj = jsonParser.parseToJsonElement(reqBodyStr).jsonObject
                    add(buildJsonObject {
                        put("metadata", buildJsonObject {
                            put("key", "paper_$studentPaperId")
                        })
                        put("request", reqObj)
                    })
                }
            }

            buildJsonObject {
                put("batch", buildJsonObject {
                    put("display_name", "exam_batch_${draftId}_$fingerprint")
                    put("model", GeminiModelRegistry.modelResource(evaluationModelId))
                    put("input_config", buildJsonObject {
                        put("requests", buildJsonObject {
                            put("requests", batchRequests)
                        })
                    })
                })
            }
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val body = requestBodyJson.toString().toRequestBody(mediaType)
        val request = Request.Builder()
            .url(GeminiModelRegistry.batchGenerateContentUrl(evaluationModelId))
            .header("x-goog-api-key", apiKey)
            .post(body)
            .build()

        try {
            val response = okHttpClient.executeCancellable(request)
            response.use { resp ->
                if (!resp.isSuccessful) {
                    val currentJobs = loadJobs().toMutableList()
                    if (fileResourceName.isNotBlank() && !remoteDeleteFileConfirmed(fileResourceName, apiKey)) {
                        val idx = currentJobs.indexOfFirst { it.jobId == tempJobId }
                        val retained = intentMeta.copy(
                            inputFileResourceName = fileResourceName,
                            cleanupStatus = "REMOTE_DELETE_PENDING",
                            cleanupLastError = "Batch oluşturma reddedildi; uzak giriş dosyası silme doğrulaması bekliyor.",
                            cleanupUpdatedAt = System.currentTimeMillis()
                        )
                        if (idx >= 0) currentJobs[idx] = retained else currentJobs += retained
                    } else {
                        currentJobs.removeAll { it.jobId == tempJobId }
                    }
                    saveJobs(currentJobs)
                    return@withContext null
                }
                val bodyStr = resp.body?.string() ?: throw Exception("Empty batch response")
                val jsonObj = jsonParser.parseToJsonElement(bodyStr).jsonObject
                val jobId = jsonObj["name"]?.jsonPrimitive?.content ?: throw Exception("No job ID in response")
                val metadataObj = jsonObj["metadata"]?.jsonObject
                val rawState = metadataObj?.get("state")?.jsonPrimitive?.content 
                    ?: jsonObj["state"]?.jsonPrimitive?.content 
                    ?: "JOB_STATE_PENDING"
                val state = normalizeState(rawState)

                val metadata = BatchJobMetadata(
                    jobId = jobId,
                    draftId = draftId,
                    studentPaperIds = requests.map { it.first },
                    createdAt = System.currentTimeMillis(),
                    status = state,
                    isFileBased = useFileApi,
                    fingerprint = fingerprint,
                    inputFileResourceName = fileResourceName.takeIf { it.isNotBlank() },
                    modelId = evaluationModelId
                )

                // Clean up the local intent and store the actual batch job metadata
                val currentJobs = loadJobs().filterNot { it.jobId == tempJobId || it.jobId == jobId }
                saveJobs(currentJobs + metadata)
                return@withContext metadata
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Network failure may occur after the server accepted the operation. Keep the
            // recoverable intent, including the already-persisted remote input file name.
            return@withContext loadJobs().firstOrNull { it.jobId == tempJobId } ?: intentMeta
        }
    }

    suspend fun checkJobStatus(
        jobId: String,
        apiKey: String
    ): Pair<BatchJobMetadata, List<BatchStudentResult>?> = withContext(Dispatchers.IO) {
        val jobs = loadJobs()
        val meta = jobs.find { it.jobId == jobId } ?: BatchJobMetadata(jobId, 0L, emptyList(), 0L, "JOB_STATE_FAILED")

        if (jobId.startsWith("local_intent_") || meta.status == "SUBMISSION_STARTED" || meta.status == "SUBMISSION_UNCERTAIN") {
            // This is not a real remote job yet. Return as is without polling.
            return@withContext Pair(meta, null)
        }

        val urlPath = if (jobId.contains("/")) jobId else "batches/$jobId"
        val request = Request.Builder()
            .url("$baseUrl/$urlPath")
            .header("x-goog-api-key", apiKey)
            .get()
            .build()

        try {
            val response = okHttpClient.executeCancellable(request)
            response.use { resp ->
                if (!resp.isSuccessful) {
                    if (resp.code == 404 || resp.code == 400) {
                        val updatedMeta = meta.copy(status = "JOB_STATE_FAILED")
                        updateJobStatusInStore(jobId, "JOB_STATE_FAILED")
                        return@withContext Pair(updatedMeta, null)
                    } else {
                        // Transient failure, keep the current state
                        return@withContext Pair(meta, null)
                    }
                }

                val bodyStr = resp.body?.string() ?: ""
                val jsonObj = jsonParser.parseToJsonElement(bodyStr).jsonObject
                val isDone = jsonObj["done"]?.jsonPrimitive?.booleanOrNull ?: false
                
                val metadataObj = jsonObj["metadata"]?.jsonObject
                val rawState = metadataObj?.get("state")?.jsonPrimitive?.content 
                    ?: jsonObj["state"]?.jsonPrimitive?.content 
                    ?: (if (isDone) "JOB_STATE_SUCCEEDED" else "JOB_STATE_RUNNING")
                
                val state = normalizeState(rawState)
                val updatedMeta = meta.copy(status = state)

                if (state == "JOB_STATE_SUCCEEDED") {
                    val resultsList = mutableListOf<BatchStudentResult>()
                    if (meta.isFileBased) {
                        // Current API: GenerateContentBatch.output.responsesFile. Older operation
                        // wrappers are also accepted by the recursive extractor.
                        val resultsFileId = extractOutputFileResourceName(jsonObj)
                        
                        if (resultsFileId != null) {
                            // Persist output resource before download so a crash can never orphan it.
                            val jobsWithOutput = loadJobs().toMutableList()
                            val outputIndex = jobsWithOutput.indexOfFirst { it.jobId == jobId }
                            if (outputIndex >= 0) {
                                jobsWithOutput[outputIndex] = jobsWithOutput[outputIndex].copy(outputFileResourceName = resultsFileId)
                                saveJobs(jobsWithOutput)
                            }
                            // Download output JSONL file contents using correct download/v1beta endpoint with :download suffix
                            val downloadUrl = "https://generativelanguage.googleapis.com/download/v1beta/$resultsFileId:download?alt=media"
                            val downloadRequest = Request.Builder()
                                .url(downloadUrl)
                                .header("x-goog-api-key", apiKey)
                                .get()
                                .build()
                            try {
                                val downloadResponse = okHttpClient.executeCancellable(downloadRequest)
                                downloadResponse.use { dlResp ->
                                    if (dlResp.isSuccessful) {
                                        val fileContent = dlResp.body?.string() ?: ""
                                        val lines = fileContent.split("\n")
                                        for (line in lines) {
                                            if (line.trim().isBlank()) continue
                                            try {
                                                val lineObj = jsonParser.parseToJsonElement(line).jsonObject
                                                val customId = lineObj["key"]?.jsonPrimitive?.content
                                                    ?: lineObj["customId"]?.jsonPrimitive?.content
                                                    ?: lineObj["metadata"]?.jsonObject?.get("key")?.jsonPrimitive?.content
                                                    ?: ""
                                                val paperId = customId.removePrefix("paper_").toLongOrNull() ?: continue
                                                val studentRespObj = lineObj["response"]?.jsonObject
                                                val studentRespStr = studentRespObj?.toString()
                                                val err = lineObj["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content

                                                resultsList.add(
                                                    BatchStudentResult(
                                                        studentPaperId = paperId,
                                                        responseJson = studentRespStr,
                                                        isSuccess = err.isNullOrBlank() && !studentRespStr.isNullOrBlank(),
                                                        errorMessage = err
                                                    )
                                                )
                                            } catch (_: Exception) {}
                                        }
                                        // Keep remote resource names in the cleanup ledger until the caller
                                        // confirms local persistence, then transactional cleanup deletes them.
                                        // Update status in store now that it's successfully downloaded
                                        updateJobStatusInStore(jobId, state)
                                    } else {
                                        // Download failed, treat as soft failure and do not update status in store.
                                        // Return the original meta (which keeps its old state like JOB_STATE_RUNNING) to allow retry on next poll.
                                        return@withContext Pair(meta, null)
                                    }
                                }
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                // Download failed, treat as soft failure and do not update status in store.
                                return@withContext Pair(meta, null)
                            }
                        } else {
                            // Results file ID missing, fail the job
                            val failedMeta = meta.copy(status = "JOB_STATE_FAILED")
                            updateJobStatusInStore(jobId, "JOB_STATE_FAILED")
                            return@withContext Pair(failedMeta, null)
                        }
                    } else {
                        // Current API nests the list as
                        // output.inlinedResponses.inlinedResponses[]. Accept legacy flat variants too.
                        val resultsArray = findInlineResponses(jsonObj)
                            ?: (jsonObj["results"] as? JsonArray)

                        if (resultsArray != null) {
                            for ((resultIndex, resItem) in resultsArray.withIndex()) {
                                val rObj = resItem.jsonObject
                                val customId = rObj["metadata"]?.jsonObject?.get("key")?.jsonPrimitive?.contentOrNull
                                    ?: rObj["customId"]?.jsonPrimitive?.contentOrNull
                                    ?: rObj["custom_id"]?.jsonPrimitive?.contentOrNull
                                    ?: rObj["key"]?.jsonPrimitive?.contentOrNull
                                // Current API promises inline responses in input order. Metadata should
                                // normally be echoed, but order is a safe compatibility fallback.
                                val paperId = customId?.removePrefix("paper_")?.toLongOrNull()
                                    ?: meta.studentPaperIds.getOrNull(resultIndex)
                                    ?: continue
                                val studentRespObj = rObj["response"]?.jsonObject
                                val studentRespStr = studentRespObj?.toString()
                                val err = rObj["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content

                                resultsList.add(
                                    BatchStudentResult(
                                        studentPaperId = paperId,
                                        responseJson = studentRespStr,
                                        isSuccess = err.isNullOrBlank() && !studentRespStr.isNullOrBlank(),
                                        errorMessage = err
                                    )
                                )
                            }
                            // Update status in store
                            updateJobStatusInStore(jobId, state)
                        } else {
                            // Results array missing, fail the job
                            val failedMeta = meta.copy(status = "JOB_STATE_FAILED")
                            updateJobStatusInStore(jobId, "JOB_STATE_FAILED")
                            return@withContext Pair(failedMeta, null)
                        }
                    }

                    // Strict validation: Ensure student integrity. Ensure every requested student is accounted for.
                    val parsedPaperIds = resultsList.map { it.studentPaperId }.toSet()
                    val missingPaperIds = meta.studentPaperIds.filter { it !in parsedPaperIds }
                    for (missingId in missingPaperIds) {
                        resultsList.add(
                            BatchStudentResult(
                                studentPaperId = missingId,
                                responseJson = null,
                                isSuccess = false,
                                errorMessage = "Değerlendirme sonucu batch çıktısında bulunamadı (Eksik öğrenci)."
                            )
                        )
                    }

                    return@withContext Pair(updatedMeta, resultsList)
                } else {
                    // Keep remote resource identifiers until transactional cleanup is confirmed.
                    // Update status in store for other non-SUCCEEDED states (e.g. RUNNING, FAILED)
                    updateJobStatusInStore(jobId, state)
                    return@withContext Pair(updatedMeta, null)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Treat as soft failure (network timeout/error) and do NOT update status in store.
            // Just return the current meta and null results to let the next poll try again.
            return@withContext Pair(meta, null)
        }
    }
}
