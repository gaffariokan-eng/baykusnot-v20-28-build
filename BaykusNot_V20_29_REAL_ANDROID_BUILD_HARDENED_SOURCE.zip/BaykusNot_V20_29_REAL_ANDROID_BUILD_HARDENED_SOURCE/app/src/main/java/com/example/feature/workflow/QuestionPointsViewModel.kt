package com.example.feature.workflow

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.ExamObjectiveRepository
import com.example.core.data.ExamQuestionExtractionDraftRepository
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.model.WorkflowStage
import com.example.core.model.ListeningSourcePolicy
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.database.hasAudio
import com.example.core.data.SaveExamQuestionsResult
import com.example.core.data.LockExamQuestionSetResult
import com.example.core.data.UnlockExamQuestionSetResult
import com.example.feature.workflow.QuestionPointsFormEvaluator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class QuestionPointsViewModel(
    private val draftId: Long,
    private val examQuestionRepository: ExamQuestionRepository,
    private val examDraftRepository: ExamDraftRepository,
    private val objectiveRepository: com.example.core.data.ExamObjectiveRepository,
    private val examQuestionExtractionDraftRepository: ExamQuestionExtractionDraftRepository,
    private val matcher: com.example.core.network.ExamQuestionObjectiveMatcher,
    private val examRubricRepository: ExamRubricRepository? = null,
    private val examListeningMaterialRepository: ExamListeningMaterialRepository? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ViewModel() {

    private enum class EditableSource {
        CANONICAL,
        EXTRACTION_STAGING
    }

    private var currentSource = EditableSource.CANONICAL

    private val _uiState = MutableStateFlow(
        QuestionPointsUiState(
            draftId = draftId,
            draftExists = false,
            editableQuestions = emptyList(),
            expectedTotalPoints = 0,
            calculatedTotalPoints = 0L,
            remainingPoints = 0L,
            validationIssues = emptyList(),
            inputIssues = emptyList(),
            canSave = false,
            canLock = false,
            canContinue = false,
            isLocked = false,
            lockedAt = null,
            revision = 0,
            isLoading = true,
            isSaving = false,
            isLocking = false,
            isUnlocking = false,
            message = null,
            hasUnsavedChanges = false
        )
    )
    val uiState: StateFlow<QuestionPointsUiState> = _uiState.asStateFlow()

    private var draftExists = false
    private var expectedTotalPoints = 0
    private var examType: ExamType = ExamType.WRITTEN
    private var listeningTranscript: String = ""
    private var hasListeningAudio: Boolean = false
    private var listeningPlaybackCount: Int = 2
    private var listeningInstructions: String = ""
    private var isListeningMaterialReady: Boolean = true
    private var persistedQuestions: List<ExamQuestion> = emptyList()
    private var editableQuestions: List<EditableExamQuestion> = emptyList()
    private var metadata: ExamQuestionSetMetadata? = null
    private var isLoading = true
    private var message: String? = null
    private var isSaving = false
    private var isSuggestingObjectives = false
    private var objectiveSuggestionJob: Job? = null
    private var isLocking = false
    private var isUnlocking = false
    internal var nextLocalId = 1L

    private var persistedCrossRefMap: Map<Long, Set<Long>> = emptyMap()

    private var isFirstQuestionEmission = true
    private var isFirstMetadataEmission = true
    private var isObjectiveMappingApproved = false
    private var isMismatchAccepted = false
    private var objectives: List<com.example.core.database.ExamObjectiveEntity>? = null
    private var isObjectivesMappingValid: Boolean = true
    private var hasScenario = false
    private var isScenarioApproved = false

    private fun objectiveSingularLabel(): String =
        if (examType == ExamType.READINESS) "ön koşul bilgi/beceri hedefi" else "kazanım"

    private fun objectivePluralLabel(): String =
        if (examType == ExamType.READINESS) "ön koşul bilgi/beceri hedefleri" else "kazanımlar"

    private fun scenarioLabel(): String =
        if (examType == ExamType.READINESS) "hazırbulunuşluk senaryosu" else "sınav senaryosu"

    fun cancelActiveAuthoringWork() {
        objectiveSuggestionJob?.cancel()
    }

    private var candidateSource = EditableSource.CANONICAL
    private var candidateQuestions: List<EditableExamQuestion> = emptyList()
    private var candidateNextLocalId = 1L

    private var liveQuestionsReceived: List<ExamQuestion>? = null
    private var liveMetadataReceived: ExamQuestionSetMetadata? = null
    private var hasResolvedInitialState = false

    init {
        viewModelScope.launch {
            val draft = withContext(ioDispatcher) {
                examDraftRepository.getDraftByIdOnce(draftId)
            }
            if (draft == null) {
                draftExists = false
                expectedTotalPoints = 0
                isLoading = false
                editableQuestions = emptyList()
                metadata = null
                message = "Sınav taslağı bulunamadı."
                publishState()
            } else {
                draftExists = true
                examType = draft.examType

                if (draft.examType == ExamType.LISTENING) {
                    val listeningRepository = examListeningMaterialRepository
                    val initialMaterial = withContext(ioDispatcher) {
                        listeningRepository?.getOnce(draftId)
                    }
                    applyListeningMaterial(initialMaterial)
                    isListeningMaterialReady = if (listeningRepository != null) {
                        withContext(ioDispatcher) { listeningRepository.isReadyForQuestions(draftId) }
                    } else {
                        false
                    }

                    if (listeningRepository != null) {
                        viewModelScope.launch(ioDispatcher) {
                            listeningRepository.observe(draftId).collectLatest { material ->
                                applyListeningMaterial(material)
                                isListeningMaterialReady = listeningRepository.isReadyForQuestions(draftId)
                                withContext(Dispatchers.Main) { publishState() }
                            }
                        }
                    }
                } else {
                    isListeningMaterialReady = true
                }

                viewModelScope.launch(ioDispatcher) {
                    kotlinx.coroutines.flow.combine(
                        examDraftRepository.getDraftById(draftId),
                        objectiveRepository.observeApprovedObjectivesByDraftId(draftId)
                    ) { d, obs ->
                        Pair(d, obs)
                    }.collectLatest { (draft, obs) ->
                        if (draft != null) {
                            if (draft.currentWorkflowStage != WorkflowStage.QUESTION_POINTS) {
                                cancelActiveAuthoringWork()
                            }
                            hasScenario = draft.hasScenario
                            isScenarioApproved = draft.isScenarioApproved
                            isObjectiveMappingApproved = draft.isObjectiveMappingApproved
                            isMismatchAccepted = draft.isMismatchAccepted
                            objectives = if (draft.hasScenario && draft.isScenarioApproved && obs.isNotEmpty()) obs else null
                            validateObjectivesMapping()
                            withContext(Dispatchers.Main) { publishState() }
                        }
                    }
                }
                viewModelScope.launch(ioDispatcher) {
                    objectiveRepository.observeQuestionObjectiveCrossRefsByDraftId(draftId).collectLatest { refs ->
                        val map = refs.groupBy { it.questionId }.mapValues { it.value.map { r -> r.objectiveId }.toSet() }
                        persistedCrossRefMap = map
                        val hasUnsaved = QuestionPointsDirtyStateEvaluator.hasUnsavedChanges(
                            editableQuestions = editableQuestions,
                            persistedQuestions = persistedQuestions,
                            persistedCrossRefMap = map
                        )
                        if (!hasUnsaved) {
                            editableQuestions = editableQuestions.map { eq ->
                                eq.copy(selectedObjectiveIds = map[eq.persistedId] ?: emptySet())
                            }
                        }
                        validateObjectivesMapping()
                        withContext(Dispatchers.Main) { publishState() }
                    }
                }
                expectedTotalPoints = draft.totalPoints


                // One-shot read for snapshot. When the question set is unlocked, fresh extraction
                // staging is the review source of truth; old canonical rows remain only as rollback history.
                val initialQuestions = withContext(ioDispatcher) { examQuestionRepository.getQuestionsOnce(draftId) }
                val initialMetadata = withContext(ioDispatcher) { examQuestionRepository.getMetadataOnce(draftId) }
                val initialStaging = if (initialMetadata?.isLocked == true) emptyList() else withContext(ioDispatcher) {
                    examQuestionExtractionDraftRepository.getStagingOnce(draftId)
                }

                if (initialMetadata?.isLocked == true) {
                    candidateSource = EditableSource.CANONICAL
                    val mapping = QuestionPointsEditableMapper.map(initialQuestions, 1L)
                    candidateQuestions = mapping.editableQuestions
                    candidateNextLocalId = mapping.nextLocalId
                } else if (initialStaging.isNotEmpty()) {
                    candidateSource = EditableSource.EXTRACTION_STAGING
                    candidateQuestions = initialStaging.mapIndexed { index, entity ->
                        EditableExamQuestion(
                            localId = 1L + index,
                            persistedId = 0L,
                            orderIndex = entity.orderIndex,
                            questionNumber = entity.rawQuestionNumber,
                            questionText = entity.rawQuestionText,
                            pointsText = entity.rawPoints?.toString() ?: ""
                        )
                    }
                    candidateNextLocalId = 1L + initialStaging.size
                } else {
                    candidateSource = EditableSource.CANONICAL
                    val mapping = QuestionPointsEditableMapper.map(initialQuestions, 1L)
                    candidateQuestions = mapping.editableQuestions
                    candidateNextLocalId = mapping.nextLocalId
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examQuestionRepository.observeQuestions(draftId)
                    }.collectLatest { incomingQuestions ->
                        handleIncomingQuestions(incomingQuestions)
                    }
                }
                
                launch {
                    withContext(ioDispatcher) {
                        examQuestionRepository.observeMetadata(draftId)
                    }.collectLatest { incomingMetadata ->
                        handleIncomingMetadata(incomingMetadata)
                    }
                }
            }
        }
    }

    private fun handleIncomingQuestions(incomingQuestions: List<ExamQuestion>) {
        if (isFirstQuestionEmission) {
            isFirstQuestionEmission = false
            liveQuestionsReceived = incomingQuestions
            checkInitialLoadingComplete()
            return
        }

        if (currentSource == EditableSource.EXTRACTION_STAGING && incomingQuestions.isNotEmpty()) {
            val stagingPromoted = editableQuestions.size == incomingQuestions.size &&
                editableQuestions.sortedBy { it.orderIndex }.zip(incomingQuestions.sortedBy { it.orderIndex }).all { (editable, canonical) ->
                    editable.orderIndex == canonical.orderIndex &&
                        editable.questionNumber.trim() == canonical.questionNumber.trim() &&
                        editable.questionText.trim() == canonical.questionText.trim() &&
                        editable.pointsText.toIntOrNull() == canonical.points
                }
            persistedQuestions = incomingQuestions
            if (stagingPromoted) {
                currentSource = EditableSource.CANONICAL
                val mapping = QuestionPointsEditableMapper.map(incomingQuestions, nextLocalId)
                editableQuestions = mapping.editableQuestions
                nextLocalId = mapping.nextLocalId
            }
            publishState()
            return
        }

        val wasDirty = QuestionPointsDirtyStateEvaluator.hasUnsavedChanges(
            editableQuestions = editableQuestions,
            persistedQuestions = persistedQuestions,
            persistedCrossRefMap = persistedCrossRefMap
        )

        val contentsChanged = persistedQuestions != incomingQuestions

        if (!wasDirty) {
            if (contentsChanged) {
                val mapping = QuestionPointsEditableMapper.map(incomingQuestions, nextLocalId)
                editableQuestions = mapping.editableQuestions
                nextLocalId = mapping.nextLocalId
            }
        }
        
        persistedQuestions = incomingQuestions
        publishState()
    }

    private fun handleIncomingMetadata(incomingMetadata: ExamQuestionSetMetadata?) {
        if (isFirstMetadataEmission) {
            isFirstMetadataEmission = false
            liveMetadataReceived = incomingMetadata
            checkInitialLoadingComplete()
            return
        }

        metadata = incomingMetadata
        publishState()
    }

    private fun checkInitialLoadingComplete() {
        if (!isFirstQuestionEmission && !isFirstMetadataEmission && !hasResolvedInitialState) {
            hasResolvedInitialState = true
            resolveInitialState(
                liveQuestions = liveQuestionsReceived ?: emptyList(),
                liveMetadata = liveMetadataReceived
            )
            isLoading = false
            publishState()
        }
    }

    private fun resolveInitialState(
        liveQuestions: List<ExamQuestion>,
        liveMetadata: ExamQuestionSetMetadata?
    ) {
        persistedQuestions = liveQuestions
        metadata = liveMetadata

        if (liveMetadata?.isLocked == true) {
            currentSource = EditableSource.CANONICAL
            val mapping = QuestionPointsEditableMapper.map(liveQuestions, 1L)
            editableQuestions = mapping.editableQuestions
            nextLocalId = mapping.nextLocalId
        } else if (candidateSource == EditableSource.EXTRACTION_STAGING && candidateQuestions.isNotEmpty()) {
            currentSource = EditableSource.EXTRACTION_STAGING
            editableQuestions = candidateQuestions
            nextLocalId = candidateNextLocalId
        } else {
            currentSource = EditableSource.CANONICAL
            val mapping = QuestionPointsEditableMapper.map(liveQuestions, 1L)
            editableQuestions = mapping.editableQuestions
            nextLocalId = mapping.nextLocalId
        }
    }

    private fun applyListeningMaterial(material: com.example.core.database.ExamListeningMaterialEntity?) {
        listeningTranscript = material?.transcript.orEmpty()
        hasListeningAudio = material?.hasAudio() == true
        listeningPlaybackCount = material?.playbackCount ?: 2
        listeningInstructions = material?.instructions.orEmpty()
        // Provisional UI value; repository verification immediately replaces this with a
        // physical-file-aware result when audio is the selected source.
        isListeningMaterialReady = ListeningSourcePolicy.isReady(
            hasUsableAudio = hasListeningAudio,
            listeningText = listeningTranscript
        )
    }

    private fun validateObjectivesMapping() {
        isObjectivesMappingValid = true
        val obs = objectives ?: return
        
        var allQuestionsMapped = true
        for (eq in editableQuestions) {
            if (eq.selectedObjectiveIds.isEmpty()) {
                allQuestionsMapped = false
                break
            }
        }
        
        // As long as all questions have an objective, it's structurally valid.
        isObjectivesMappingValid = allQuestionsMapped
    }


    fun suggestObjectives() {
        val targets = if (editableQuestions.isNotEmpty()) editableQuestions else candidateQuestions
        if (objectives == null || targets.isEmpty()) return
        isSuggestingObjectives = true
        publishState()
        
        val job = viewModelScope.launch(ioDispatcher) {
            try {
                val stageDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (stageDraft?.currentWorkflowStage != WorkflowStage.QUESTION_POINTS) return@launch
                // The AI needs the text of the questions. 
                val fakeQuestions = targets.map { eq ->
                    com.example.core.model.ExamQuestion(
                        id = eq.persistedId.takeIf { it != 0L } ?: eq.localId, // Use localId as fallback for mapping
                        examDraftId = draftId,
                        orderIndex = eq.orderIndex,
                        questionNumber = eq.questionNumber,
                        questionText = eq.questionText,
                        points = 0
                    )
                }
                
                val result = matcher.matchQuestionsToObjectivesForExam(draftId, fakeQuestions, objectives!!, examType)
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft?.currentWorkflowStage != WorkflowStage.QUESTION_POINTS) return@launch
                if (result is com.example.core.network.ExamQuestionObjectiveMatchingResult.Success) {
                    if (editableQuestions.isNotEmpty()) {
                        val newEditable = editableQuestions.map { eq ->
                            val idToLookup = eq.persistedId.takeIf { it != 0L } ?: eq.localId
                            val suggestedIds = result.mappings[idToLookup] ?: emptyList()
                            eq.copy(selectedObjectiveIds = suggestedIds.toSet())
                        }
                        editableQuestions = newEditable
                        validateObjectivesMapping()
                        
                        isObjectiveMappingApproved = false
                        isMismatchAccepted = false
                        val draft = examDraftRepository.getDraftByIdOnce(draftId)
                        if (draft?.currentWorkflowStage == WorkflowStage.QUESTION_POINTS) {
                            examDraftRepository.updateDraft(draft.copy(
                                isObjectiveMappingApproved = false,
                                isMismatchAccepted = false
                            ))
                        }
                    } else {
                        val newCandidates = candidateQuestions.map { eq ->
                            val idToLookup = eq.persistedId.takeIf { it != 0L } ?: eq.localId
                            val suggestedIds = result.mappings[idToLookup] ?: emptyList()
                            eq.copy(selectedObjectiveIds = suggestedIds.toSet())
                        }
                        candidateQuestions = newCandidates
                    }
                }
            } finally {
                isSuggestingObjectives = false
                publishState()
            }
        }
        objectiveSuggestionJob = job
        job.invokeOnCompletion {
            if (objectiveSuggestionJob === job) objectiveSuggestionJob = null
            isSuggestingObjectives = false
            publishState()
        }
    }

    fun approveObjectivesMapping() {
        viewModelScope.launch(ioDispatcher) {
            try {
                if (!isObjectivesMappingValid) {
                    message = "Her soruya en az bir ${objectiveSingularLabel()} seçilmelidir."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }
                val draft = examDraftRepository.getDraftByIdOnce(draftId)
                if (draft == null) {
                    message = "Sınav taslağı bulunamadı."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }
                
                // 1. Senaryo approved mu?
                if (!draft.isScenarioApproved) {
                    message = "Öncelikle ${scenarioLabel()} onaylanmalıdır."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }

                // 2. Kaydedilmemiş değişiklik var mı?
                val hasUnsavedChanges = QuestionPointsDirtyStateEvaluator.hasUnsavedChanges(
                    editableQuestions = editableQuestions,
                    persistedQuestions = persistedQuestions,
                    persistedCrossRefMap = persistedCrossRefMap
                )
                if (hasUnsavedChanges) {
                    message = "Lütfen önce değişikliklerinizi kaydedin."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }

                // 3. Kalıcı veriyi oku ve doğrula
                val savedQuestions = examQuestionRepository.getQuestionsOnce(draftId)
                if (savedQuestions.isEmpty()) {
                    message = "Sınavda kaydedilmiş soru bulunmamaktadır."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }

                val approvedObjectives = objectiveRepository.getApprovedObjectivesByDraftId(draftId)
                val approvedObjectiveIds = approvedObjectives.map { it.id }.toSet()
                
                val savedRefs = objectiveRepository.getQuestionObjectiveCrossRefsByDraftId(draftId)
                val savedQuestionIds = savedQuestions.map { it.id }.toSet()

                // - her gerçek soru en az bir approved kazanıma bağlı
                // - bağlı objectiveId aynı sınavın approved kazanımına ait
                // - başka sınav objective'i yok
                // - orphan questionId/objectiveId ilişkisi yok
                val refsByQuestion = savedRefs.groupBy { it.questionId }
                
                var isValid = true
                for (sq in savedQuestions) {
                    val refs = refsByQuestion[sq.id] ?: emptyList()
                    if (refs.isEmpty()) {
                        isValid = false
                    }
                    if (refs.any { !approvedObjectiveIds.contains(it.objectiveId) }) {
                        isValid = false
                    }
                }
                
                // check for orphan / foreign refs
                for (ref in savedRefs) {
                    if (!savedQuestionIds.contains(ref.questionId)) {
                        isValid = false
                    }
                    if (!approvedObjectiveIds.contains(ref.objectiveId)) {
                        isValid = false
                    }
                }

                if (!isValid) {
                    message = "${objectivePluralLabel().replaceFirstChar { it.uppercase() }} eşleştirme bütünlüğü doğrulanamadı. Lütfen tüm sorulara geçerli ${objectivePluralLabel()} seçip kaydedin."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }

                // 4. Mismatch check
                val hasMismatch = calculateIsMismatch(approvedObjectives, savedQuestions.map { sq ->
                    val refs = refsByQuestion[sq.id] ?: emptyList()
                    EditableExamQuestion(
                        localId = sq.id,
                        persistedId = sq.id,
                        orderIndex = sq.orderIndex,
                        questionNumber = sq.questionNumber,
                        questionText = sq.questionText,
                        pointsText = sq.points.toString(),
                        selectedObjectiveIds = refs.map { it.objectiveId }.toSet()
                    )
                })

                if (hasMismatch && !draft.isMismatchAccepted) {
                    message = "${scenarioLabel().replaceFirstChar { it.uppercase() }} içindeki soru sayıları ile mevcut soru sayıları uyuşmuyor. Lütfen bu uyumsuzluğu kabul ettiğinizi belirten onay kutusunu işaretleyin."
                    withContext(Dispatchers.Main) { publishState() }
                    return@launch
                }

                // All valid, approve!
                examDraftRepository.updateDraft(draft.copy(isObjectiveMappingApproved = true))
                isObjectiveMappingApproved = true
                message = "${objectivePluralLabel().replaceFirstChar { it.uppercase() }} eşleştirmesi onaylandı."
                withContext(Dispatchers.Main) { publishState() }
            } catch (e: Exception) {
                message = "Hata oluştu: ${e.localizedMessage}"
                withContext(Dispatchers.Main) { publishState() }
            }
        }
    }

    fun acceptMismatch(accepted: Boolean) {
        viewModelScope.launch(ioDispatcher) {
            try {
                val draft = examDraftRepository.getDraftByIdOnce(draftId)
                if (draft != null) {
                    examDraftRepository.updateDraft(draft.copy(isMismatchAccepted = accepted))
                    isMismatchAccepted = accepted
                    withContext(Dispatchers.Main) { publishState() }
                }
            } catch (e: Exception) {
                message = "Uyumsuzluk onayı kaydedilemedi. Soru seti kilitlenemez."
                withContext(Dispatchers.Main) { publishState() }
            }
        }
    }

    private fun invalidateMappingApproval() {
        if (message == "Sorular kaydedildi.") {
            message = null
        }
        if (isObjectiveMappingApproved || isMismatchAccepted) {
            isObjectiveMappingApproved = false
            isMismatchAccepted = false
            viewModelScope.launch(ioDispatcher) {
                try {
                    val draft = examDraftRepository.getDraftByIdOnce(draftId)
                    if (draft != null) {
                        examDraftRepository.updateDraft(draft.copy(
                            isObjectiveMappingApproved = false,
                            isMismatchAccepted = false
                        ))
                    }
                } catch (e: Exception) {
                    message = "Kazanım eşleştirme onayı geçersizleştirilemedi. Güvenli yeniden doğrulama gerekiyor."
                    withContext(Dispatchers.Main) { publishState() }
                }
            }
        }
    }

    private fun calculateIsMismatch(
        objectives: List<com.example.core.database.ExamObjectiveEntity>,
        questions: List<EditableExamQuestion>
    ): Boolean {
        if (objectives.isEmpty()) return false

        val allCountsKnown = objectives.all { it.expectedQuestionCount != null }
        if (allCountsKnown) {
            val expectedTotal = objectives.sumOf { it.expectedQuestionCount ?: 0 }
            val actualTotal = questions.size
            if (expectedTotal != actualTotal) {
                return true
            }
        }

        val counts = objectives.associate { it.id to 0L }.toMutableMap()
        questions.forEach { eq ->
            eq.selectedObjectiveIds.forEach { oid ->
                if (counts.containsKey(oid)) {
                    counts[oid] = (counts[oid] ?: 0L) + 1L
                }
            }
        }

        for (obj in objectives) {
            val expected = obj.expectedQuestionCount
            if (expected != null) {
                val actual = counts[obj.id] ?: 0L
                if (actual != expected.toLong()) {
                    return true
                }
            }
        }
        return false
    }

    private fun checkAndResetMismatchAcceptance() {
        val objs = objectives ?: return
        val currentMismatch = calculateIsMismatch(objs, editableQuestions)
        if (!currentMismatch && isMismatchAccepted) {
            isMismatchAccepted = false
            viewModelScope.launch(ioDispatcher) {
                try {
                    val draft = examDraftRepository.getDraftByIdOnce(draftId)
                    if (draft != null) {
                        examDraftRepository.updateDraft(draft.copy(isMismatchAccepted = false))
                    }
                } catch (e: Exception) {
                    message = "Uyumsuzluk onayı temizlenemedi. Güvenli yeniden doğrulama gerekiyor."
                    withContext(Dispatchers.Main) { publishState() }
                }
            }
        }
    }
    
    private fun publishState() {
        checkAndResetMismatchAcceptance()
        val hasUnsavedChanges = QuestionPointsDirtyStateEvaluator.hasUnsavedChanges(
            editableQuestions = editableQuestions,
            persistedQuestions = persistedQuestions,
            persistedCrossRefMap = persistedCrossRefMap
        )

        _uiState.value = QuestionPointsUiStateFactory.create(
            draftId = draftId,
            draftExists = draftExists,
            editableQuestions = editableQuestions,
            expectedTotalPoints = expectedTotalPoints,
            metadata = metadata,
            hasUnsavedChanges = hasUnsavedChanges,
            isLoading = isLoading,
            isSaving = isSaving,
            isLocking = isLocking,
            isUnlocking = isUnlocking,
            isSuggestingObjectives = isSuggestingObjectives,
            message = message,
            objectives = objectives,
            isObjectivesMappingValid = isObjectivesMappingValid,
            isObjectiveMappingApproved = isObjectiveMappingApproved,
            isMismatchAccepted = isMismatchAccepted,
            hasScenario = hasScenario,
            hasObjectiveMismatch = objectives?.let { calculateIsMismatch(it, editableQuestions) } ?: false,
            examType = examType,
            listeningTranscript = listeningTranscript,
            hasListeningAudio = hasListeningAudio,
            listeningPlaybackCount = listeningPlaybackCount,
            listeningInstructions = listeningInstructions,
            isListeningMaterialReady = isListeningMaterialReady
        )
    }

fun toggleObjective(localId: Long, objectiveId: Long) {
        val q = editableQuestions.find { it.localId == localId } ?: return
        val currentSet = q.selectedObjectiveIds.toMutableSet()
        if (currentSet.contains(objectiveId)) {
            currentSet.remove(objectiveId)
        } else {
            currentSet.add(objectiveId)
        }
        val newQ = q.copy(selectedObjectiveIds = currentSet)
        editableQuestions = editableQuestions.map { if (it.localId == localId) newQ else it }
        
        invalidateMappingApproval()
        
        validateObjectivesMapping()
        publishState()
    }
    
    fun reloadQuestionSources() {
        if (!draftExists || metadata?.isLocked == true) return
        viewModelScope.launch {
            val staging = withContext(ioDispatcher) { examQuestionExtractionDraftRepository.getStagingOnce(draftId) }
            if (staging.isNotEmpty()) {
                currentSource = EditableSource.EXTRACTION_STAGING
                editableQuestions = staging.mapIndexed { index, entity ->
                    EditableExamQuestion(
                        localId = 1L + index,
                        persistedId = 0L,
                        orderIndex = entity.orderIndex,
                        questionNumber = entity.rawQuestionNumber,
                        questionText = entity.rawQuestionText,
                        pointsText = entity.rawPoints?.toString() ?: ""
                    )
                }
                nextLocalId = 1L + staging.size
                message = "Yeni kaynaktan çıkarılan sorular yüklendi. Kaydetmeden önce soru metinlerini ve puanları kontrol edin."
                publishState()
                return@launch
            }

            val canonical = withContext(ioDispatcher) { examQuestionRepository.getQuestionsOnce(draftId) }
            if (canonical.isNotEmpty()) {
                persistedQuestions = canonical
                currentSource = EditableSource.CANONICAL
                val mapping = QuestionPointsEditableMapper.map(canonical, 1L)
                editableQuestions = mapping.editableQuestions
                nextLocalId = mapping.nextLocalId
                message = "Kayıtlı sorular yüklendi. Puanları ve soru metinlerini kontrol edin."
            } else {
                message = "Soru kaynağından incelenebilir soru çıkarılamadı. Kaynağı yeniden yükleyebilir veya soruları elle girebilirsiniz."
            }
            publishState()
        }
    }

    fun addQuestion() {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        if (nextLocalId == Long.MAX_VALUE) {
            message = "Yeni soru eklenemedi."
            publishState()
            return
        }

        val updatedQuestions = EditableExamQuestionListEditor.addQuestion(
            questions = editableQuestions,
            localId = nextLocalId
        )
        if (updatedQuestions !== editableQuestions) {
            editableQuestions = updatedQuestions
            nextLocalId++
        }
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun removeQuestion(localId: Long) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.removeQuestion(
            questions = editableQuestions,
            localId = localId
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun updateQuestionNumber(localId: Long, value: String) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.updateQuestionNumber(
            questions = editableQuestions,
            localId = localId,
            value = value
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun updateQuestionText(localId: Long, value: String) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.updateQuestionText(
            questions = editableQuestions,
            localId = localId,
            value = value
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun updateQuestionPoints(localId: Long, value: String) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.updateQuestionPoints(
            questions = editableQuestions,
            localId = localId,
            value = value
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun moveQuestionUp(localId: Long) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.moveQuestionUp(
            questions = editableQuestions,
            localId = localId
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun moveQuestionDown(localId: Long) {
        if (!draftExists || isLoading || metadata?.isLocked == true) return

        editableQuestions = EditableExamQuestionListEditor.moveQuestionDown(
            questions = editableQuestions,
            localId = localId
        )
        invalidateMappingApproval()
        validateObjectivesMapping()
        publishState()
    }

    fun dismissMessage() {
        message = null
        publishState()
    }

    fun saveQuestions() {
        if (!draftExists || isLoading || isSaving || metadata?.isLocked == true || !_uiState.value.canSave) return

        val evaluation = QuestionPointsFormEvaluator.evaluate(
            examDraftId = draftId,
            expectedTotalPoints = expectedTotalPoints,
            editableQuestions = editableQuestions
        )

        val questions = evaluation.domainQuestions ?: return
        val expectedRevision = metadata?.revision ?: 0

        isSaving = true
        message = null
        publishState()

        val sourceAtSave = currentSource

        viewModelScope.launch {
            var saveSucceeded = false
            try {
                val result = withContext(ioDispatcher) {
                    if (!objectiveRepository.invalidateQuestionObjectiveMappingApproval(draftId)) {
                        throw IllegalStateException("MAPPING_APPROVAL_INVALIDATION_FAILED")
                    }
                    examQuestionRepository.saveQuestions(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision,
                        questions = questions
                    )
                }
                when (result) {
                    is SaveExamQuestionsResult.Success -> {
                        // Save cross refs
                        val savedQuestions = examQuestionRepository.getQuestionsOnce(draftId)
                        val refs = mutableListOf<com.example.core.database.QuestionObjectiveCrossRef>()
                        val newPersistedCrossRefMap = mutableMapOf<Long, Set<Long>>()
                        
                        val updatedEditableQuestions = editableQuestions.map { eq ->
                            val sq = savedQuestions.find { it.id == eq.persistedId }
                                ?: savedQuestions.find { it.orderIndex == eq.orderIndex && it.questionNumber == eq.questionNumber }
                                ?: savedQuestions.find { it.questionNumber == eq.questionNumber }
                                ?: savedQuestions.find { it.orderIndex == eq.orderIndex }
                            if (sq != null) {
                                for (objId in eq.selectedObjectiveIds) {
                                    refs.add(
                                        com.example.core.database.QuestionObjectiveCrossRef(
                                            questionId = sq.id,
                                            objectiveId = objId
                                        )
                                    )
                                }
                                newPersistedCrossRefMap[sq.id] = eq.selectedObjectiveIds
                                eq.copy(persistedId = sq.id)
                            } else {
                                eq
                            }
                        }
                        
                        withContext(ioDispatcher) {
                            objectiveRepository.replaceQuestionObjectiveCrossRefsForDraft(draftId, refs)
                        }
                        persistedCrossRefMap = newPersistedCrossRefMap
                        metadata = result.metadata
                        message = "Sorular kaydedildi."
                        saveSucceeded = true
                        
                        // Update persistedId of editable questions to stay in sync
                        editableQuestions = updatedEditableQuestions
                    }
                    SaveExamQuestionsResult.DraftNotFound -> {
                        draftExists = false
                        message = "Sınav taslağı bulunamadı."
                    }
                    is SaveExamQuestionsResult.ValidationFailed -> {
                        message = "Sorular kaydedilemedi. Soru bilgilerini kontrol edin."
                    }
                    is SaveExamQuestionsResult.Locked -> {
                        message = "Kilitli soru seti kaydedilemez."
                    }
                    is SaveExamQuestionsResult.RevisionConflict -> {
                        message = "Soru seti başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    is SaveExamQuestionsResult.Failure -> {
                        message = "Sorular kaydedilemedi."
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                message = "Sorular kaydedilemedi."
            } finally {
                isSaving = false
                publishState()
            }

            if (saveSucceeded && sourceAtSave == EditableSource.EXTRACTION_STAGING) {
                withContext(ioDispatcher) {
                    examQuestionExtractionDraftRepository.clearStaging(draftId)
                }
                currentSource = EditableSource.CANONICAL
                publishState()
            }
        }
    }

    fun lockQuestionSet() {
        if (!draftExists || isLoading || isSaving || isLocking || !uiState.value.canLock) return

        val expectedRevision = metadata?.revision ?: return

        isLocking = true
        message = null
        publishState()

        viewModelScope.launch {
            try {
                val draft = withContext(ioDispatcher) { examDraftRepository.getDraftByIdOnce(draftId) }
                if (draft == null) {
                    message = "Sınav taslağı bulunamadı."
                    return@launch
                }

                val savedQuestions = withContext(ioDispatcher) { examQuestionRepository.getQuestionsOnce(draftId) }
                if (savedQuestions.isEmpty()) {
                    message = "Kaydedilmiş soru bulunmamaktadır."
                    return@launch
                }

                val hasUnsavedChanges = QuestionPointsDirtyStateEvaluator.hasUnsavedChanges(
                    editableQuestions = editableQuestions,
                    persistedQuestions = persistedQuestions,
                    persistedCrossRefMap = persistedCrossRefMap
                )
                if (hasUnsavedChanges) {
                    message = "Kaydedilmemiş değişiklikler var. Kilitlemeden önce lütfen kaydedin."
                    return@launch
                }

                if (draft.hasScenario) {
                    if (!draft.isScenarioApproved) {
                        message = "Soru setini kilitlemeden önce ${scenarioLabel()} onaylanmış olmalıdır."
                        return@launch
                    }

                    if (!draft.isObjectiveMappingApproved) {
                        message = "Soru setini kilitlemeden önce ${objectivePluralLabel()} eşleştirmesi onaylanmış olmalıdır."
                        return@launch
                    }

                    val approvedObjectives = withContext(ioDispatcher) { objectiveRepository.getApprovedObjectivesByDraftId(draftId) }
                    val approvedObjectiveIds = approvedObjectives.map { it.id }.toSet()
                    val savedRefs = withContext(ioDispatcher) { objectiveRepository.getQuestionObjectiveCrossRefsByDraftId(draftId) }
                    val savedQuestionIds = savedQuestions.map { it.id }.toSet()

                    val refsByQuestion = savedRefs.groupBy { it.questionId }
                    var allQuestionsMapped = true
                    for (sq in savedQuestions) {
                        val refs = refsByQuestion[sq.id] ?: emptyList()
                        if (refs.isEmpty()) {
                            allQuestionsMapped = false
                        }
                    }

                    if (!allQuestionsMapped) {
                        message = "Taslaktaki tüm sorulara en az bir ${objectiveSingularLabel()} atanmış olmalıdır."
                        return@launch
                    }

                    var hasOrphanOrForeign = false
                    for (ref in savedRefs) {
                        if (!savedQuestionIds.contains(ref.questionId)) {
                            hasOrphanOrForeign = true
                        }
                        if (!approvedObjectiveIds.contains(ref.objectiveId)) {
                            hasOrphanOrForeign = true
                        }
                    }

                    if (hasOrphanOrForeign) {
                        message = "Geçersiz ${objectiveSingularLabel()} referansları tespit edildi. Eşleştirmeyi kontrol edip tekrar kaydedin."
                        return@launch
                    }

                    val editableQuestionsListForMismatch = savedQuestions.map { sq ->
                        val refs = refsByQuestion[sq.id] ?: emptyList()
                        EditableExamQuestion(
                            localId = sq.id,
                            persistedId = sq.id,
                            orderIndex = sq.orderIndex,
                            questionNumber = sq.questionNumber,
                            questionText = sq.questionText,
                            pointsText = sq.points.toString(),
                            selectedObjectiveIds = refs.map { it.objectiveId }.toSet()
                        )
                    }

                    val recalculateMismatch = calculateIsMismatch(approvedObjectives, editableQuestionsListForMismatch)
                    if (recalculateMismatch && !draft.isMismatchAccepted) {
                        message = "${scenarioLabel().replaceFirstChar { it.uppercase() }} içindeki soru sayıları ile mevcut soru sayıları uyuşmuyor. Lütfen bu uyumsuzluğu kabul ettiğinizi belirten onay kutusunu işaretleyin."
                        return@launch
                    }
                }

                val result = withContext(ioDispatcher) {
                    examQuestionRepository.lockQuestionSet(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision
                    )
                }

                when (result) {
                    is LockExamQuestionSetResult.Success -> {
                        metadata = result.metadata
                        message = "Soru seti kilitlendi."
                    }
                    LockExamQuestionSetResult.DraftNotFound -> {
                        draftExists = false
                        message = "Sınav taslağı bulunamadı."
                    }
                    LockExamQuestionSetResult.MetadataMissing -> {
                        message = "Kaydedilmiş soru seti bulunamadı."
                    }
                    is LockExamQuestionSetResult.ValidationFailed -> {
                        message = "Soru seti kilitlenemedi. Soru bilgilerini kontrol edin."
                    }
                    is LockExamQuestionSetResult.AlreadyLocked -> {
                        message = "Soru seti zaten kilitli."
                    }
                    is LockExamQuestionSetResult.RevisionConflict -> {
                        message = "Soru seti başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    is LockExamQuestionSetResult.Failure -> {
                        message = "Soru seti kilitlenemedi."
                    }
                }
            } finally {
                isLocking = false
                publishState()
            }
        }
    }

    fun unlockQuestionSet() {
        if (!draftExists || isLoading || isSaving || isLocking || isUnlocking || metadata?.isLocked != true) return

        val expectedRevision = metadata?.revision ?: return

        isUnlocking = true
        message = null
        publishState()

        viewModelScope.launch {
            try {
                val result = withContext(ioDispatcher) {
                    examQuestionRepository.unlockQuestionSet(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision
                    )
                }

                when (result) {
                    is UnlockExamQuestionSetResult.Success -> {
                        metadata = result.metadata
                        message = "Soru setinin kilidi açıldı."
                    }
                    UnlockExamQuestionSetResult.MetadataMissing -> {
                        message = "Kaydedilmiş soru seti bulunamadı."
                    }
                    is UnlockExamQuestionSetResult.AlreadyUnlocked -> {
                        message = "Soru setinin kilidi zaten açık."
                    }
                    is UnlockExamQuestionSetResult.RevisionConflict -> {
                        message = "Soru seti başka bir işlemle güncellendi. Lütfen yeniden deneyin."
                    }
                    is UnlockExamQuestionSetResult.Failure -> {
                        message = "Soru setinin kilidi açılamadı."
                    }
                }
            } finally {
                isUnlocking = false
                publishState()
            }
        }
    }

    class Factory(
        private val draftId: Long,
        private val examQuestionRepository: ExamQuestionRepository,
        private val examDraftRepository: ExamDraftRepository,
        private val objectiveRepository: ExamObjectiveRepository,
        private val examQuestionExtractionDraftRepository: ExamQuestionExtractionDraftRepository,
        private val matcher: com.example.core.network.ExamQuestionObjectiveMatcher,
        private val examRubricRepository: ExamRubricRepository? = null,
        private val examListeningMaterialRepository: ExamListeningMaterialRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(QuestionPointsViewModel::class.java)) {
                return QuestionPointsViewModel(
                    draftId = draftId,
                    examQuestionRepository = examQuestionRepository,
                    examDraftRepository = examDraftRepository,
                    objectiveRepository = objectiveRepository,
                    examQuestionExtractionDraftRepository = examQuestionExtractionDraftRepository,
                    matcher = matcher,
                    examRubricRepository = examRubricRepository,
                    examListeningMaterialRepository = examListeningMaterialRepository
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
