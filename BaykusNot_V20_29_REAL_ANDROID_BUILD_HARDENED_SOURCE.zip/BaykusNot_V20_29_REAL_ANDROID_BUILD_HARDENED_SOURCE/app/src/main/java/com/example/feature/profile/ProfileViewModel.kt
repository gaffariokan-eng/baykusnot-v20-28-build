package com.example.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.TeacherProfileRepository
import com.example.core.database.TeacherProfileEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val repository: TeacherProfileRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                val profile = repository.getProfileOnce()
                if (profile != null) {
                    _uiState.value = ProfileUiState(
                        academicYear = profile.academicYear.trim(),
                        institutionName = profile.institutionName.trim(),
                        defaultCourseName = profile.defaultCourseName.trim(),
                        teachers = profile.teacherNames.map { it.trim() }.filter { it.isNotBlank() }.distinct(),
                        isLoaded = true
                    )
                } else {
                    _uiState.value = _uiState.value.copy(isLoaded = true)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoaded = true,
                    errorMessage = "Kurum ve öğretmen bilgileri yüklenemedi. Lütfen tekrar deneyin."
                )
            }
        }
    }

    fun updateAcademicYear(year: String) { _uiState.value = _uiState.value.copy(academicYear = year) }
    fun updateInstitutionName(name: String) { _uiState.value = _uiState.value.copy(institutionName = name) }
    fun updateDefaultCourseName(name: String) { _uiState.value = _uiState.value.copy(defaultCourseName = name) }
    
    fun addTeacher(name: String) {
        val normalized = name.trim()
        if (normalized.isNotBlank()) {
            val updated = (_uiState.value.teachers + normalized).map { it.trim() }.filter { it.isNotBlank() }.distinct()
            _uiState.value = _uiState.value.copy(teachers = updated, errorMessage = null)
        }
    }
    
    fun removeTeacher(name: String) {
        val updated = _uiState.value.teachers - name
        _uiState.value = _uiState.value.copy(teachers = updated)
    }

    fun saveProfile(onSuccess: () -> Unit) {
        val state = _uiState.value
        if (state.isSaving) return
        val academicYear = state.academicYear.trim()
        val institutionName = state.institutionName.trim()
        val courseName = state.defaultCourseName.trim()
        val teachers = state.teachers.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (academicYear.isBlank() || institutionName.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Eğitim-öğretim yılı ve kurum adı zorunludur.")
            return
        }
        _uiState.value = state.copy(isSaving = true, errorMessage = null)
        viewModelScope.launch {
            try {
                repository.saveProfile(
                    TeacherProfileEntity(
                        academicYear = academicYear,
                        institutionName = institutionName,
                        defaultCourseName = courseName,
                        teacherNames = teachers
                    )
                )
                _uiState.value = _uiState.value.copy(isSaving = false, teachers = teachers)
                onSuccess()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    errorMessage = "Bilgiler kaydedilemedi. Lütfen tekrar deneyin."
                )
            }
        }
    }

    class Factory(
        private val repository: TeacherProfileRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ProfileViewModel(repository) as T
        }
    }
}

data class ProfileUiState(
    val academicYear: String = "2026-2027",
    val institutionName: String = "",
    val defaultCourseName: String = "",
    val teachers: List<String> = emptyList(),
    val isLoaded: Boolean = false,
    val isSaving: Boolean = false,
    val errorMessage: String? = null
)
