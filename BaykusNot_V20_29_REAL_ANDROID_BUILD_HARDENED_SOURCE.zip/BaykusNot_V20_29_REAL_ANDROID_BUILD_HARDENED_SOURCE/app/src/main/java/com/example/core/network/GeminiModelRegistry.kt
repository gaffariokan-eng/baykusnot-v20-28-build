package com.example.core.network

/** Runtime-switchable, locally persisted AI profile. No `*-latest` alias is allowed. */
data class GeminiModelProfile(
    val evaluationModel: String = "gemini-3.6-flash",
    val feedbackModel: String = "gemini-3.1-flash-lite",
    val authoringModel: String = "gemini-3.6-flash",
    val evaluationInputPerMillionUsd: Double = 0.75,
    val evaluationOutputPerMillionUsd: Double = 3.75,
    val evaluationCachedInputPerMillionUsd: Double = 0.075,
    val cacheStoragePerMillionTokenHourUsd: Double = 0.50,
    val feedbackInputPerMillionUsd: Double = 0.25,
    val feedbackOutputPerMillionUsd: Double = 1.50,
    val authoringInputPerMillionUsd: Double = 0.75,
    val authoringOutputPerMillionUsd: Double = 3.75,
    val authoringCachedInputPerMillionUsd: Double = 0.075,
    /** Set to the provider's current Batch/standard multiplier, e.g. 0.5. */
    val batchPriceFactor: Double = 0.5,
    val highImageTokens: Int = 1120,
    val supportsHighMediaResolution: Boolean = true,
    val supportsBatch: Boolean = true,
    val supportsPromptCaching: Boolean = true,
    val supportsThinkingLevel: Boolean = true,
    val preferBatchEvaluation: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Single runtime source of truth for every Gemini model used by BaykuşNot.
 * The profile is loaded from local app settings before network components are created.
 */
object GeminiModelRegistry {
    private val defaultProfile = GeminiModelProfile()

    @Volatile
    private var activeProfile: GeminiModelProfile = defaultProfile

    @Volatile private var approvedEvaluationModels: Map<String, Long> = emptyMap()
    @Volatile private var approvedFeedbackModels: Map<String, Long> = emptyMap()
    @Volatile private var approvedAuthoringModels: Map<String, Long> = emptyMap()

    val evaluationModel: String get() = activeProfile.evaluationModel
    val feedbackModel: String get() = activeProfile.feedbackModel
    val authoringModel: String get() = activeProfile.authoringModel
    val connectionTestModel: String get() = activeProfile.evaluationModel

    const val apiRoot: String = "https://generativelanguage.googleapis.com/v1beta"

    data class Pricing(
        val inputPerMillionUsd: Double,
        val outputPerMillionUsd: Double,
        val cachedInputPerMillionUsd: Double = 0.0,
        val cacheStoragePerMillionTokenHourUsd: Double = 0.0
    )

    fun configure(profile: GeminiModelProfile) {
        require(isStableExplicitModelId(profile.evaluationModel)) { "Ana model kimliği sabit ve açık olmalıdır." }
        require(isStableExplicitModelId(profile.feedbackModel)) { "Dönüt modeli kimliği sabit ve açık olmalıdır." }
        require(isStableExplicitModelId(profile.authoringModel)) { "İçerik modeli kimliği sabit ve açık olmalıdır." }
        activeProfile = profile.copy(
            evaluationInputPerMillionUsd = profile.evaluationInputPerMillionUsd.coerceAtLeast(0.0),
            evaluationOutputPerMillionUsd = profile.evaluationOutputPerMillionUsd.coerceAtLeast(0.0),
            evaluationCachedInputPerMillionUsd = profile.evaluationCachedInputPerMillionUsd.coerceAtLeast(0.0),
            cacheStoragePerMillionTokenHourUsd = profile.cacheStoragePerMillionTokenHourUsd.coerceAtLeast(0.0),
            feedbackInputPerMillionUsd = profile.feedbackInputPerMillionUsd.coerceAtLeast(0.0),
            feedbackOutputPerMillionUsd = profile.feedbackOutputPerMillionUsd.coerceAtLeast(0.0),
            authoringInputPerMillionUsd = profile.authoringInputPerMillionUsd.coerceAtLeast(0.0),
            authoringOutputPerMillionUsd = profile.authoringOutputPerMillionUsd.coerceAtLeast(0.0),
            authoringCachedInputPerMillionUsd = profile.authoringCachedInputPerMillionUsd.coerceAtLeast(0.0),
            batchPriceFactor = profile.batchPriceFactor.coerceIn(0.05, 1.0),
            highImageTokens = profile.highImageTokens.coerceIn(128, 16384),
            preferBatchEvaluation = profile.preferBatchEvaluation && profile.supportsBatch
        )
    }

    fun currentProfile(): GeminiModelProfile = activeProfile
    fun defaultProfile(): GeminiModelProfile = defaultProfile

    fun setBenchmarkApprovalSnapshot(
        evaluation: Map<String, Long>,
        feedback: Map<String, Long>,
        authoring: Map<String, Long>
    ) {
        approvedEvaluationModels = normalizeApprovalSnapshot(evaluation)
        approvedFeedbackModels = normalizeApprovalSnapshot(feedback)
        approvedAuthoringModels = normalizeApprovalSnapshot(authoring)
    }

    private fun normalizeApprovalSnapshot(source: Map<String, Long>): Map<String, Long> =
        source.entries.mapNotNull { (model, expiresAt) ->
            val clean = model.trim()
            if (clean.isBlank() || expiresAt <= 0L) null else clean to expiresAt
        }.toMap()

    private fun hasCurrentApproval(source: Map<String, Long>, modelId: String): Boolean {
        val expiresAt = source[modelId.trim()] ?: return false
        return System.currentTimeMillis() / 1000L <= expiresAt
    }

    fun requireEvaluationModelApproved(modelId: String) {
        require(hasCurrentApproval(approvedEvaluationModels, modelId)) {
            "Değerlendirme modeli için geçerli imzalı gerçek-anonim benchmark onayı yok veya onayın süresi dolmuş."
        }
    }

    fun requireFeedbackModelApproved(modelId: String) {
        require(hasCurrentApproval(approvedFeedbackModels, modelId)) {
            "Dönüt modeli için geçerli imzalı gerçek-anonim benchmark onayı yok veya onayın süresi dolmuş."
        }
    }

    fun requireAuthoringModelApproved(modelId: String) {
        require(hasCurrentApproval(approvedAuthoringModels, modelId)) {
            "Soru/rubrik hazırlık modeli için geçerli imzalı gerçek-anonim benchmark onayı yok veya onayın süresi dolmuş."
        }
    }

    fun isStableExplicitModelId(modelId: String): Boolean {
        val clean = modelId.trim()
        return clean.isNotBlank() && !clean.contains("latest", ignoreCase = true) && !clean.contains(' ')
    }

    fun evaluationPricing(useBatchApi: Boolean): Pricing {
        val p = activeProfile
        val factor = if (useBatchApi) p.batchPriceFactor else 1.0
        val input = p.evaluationInputPerMillionUsd * factor
        val output = p.evaluationOutputPerMillionUsd * factor
        return Pricing(
            inputPerMillionUsd = input,
            outputPerMillionUsd = output,
            // Gemini Batch applies the same Batch multiplier to context-cache hit token price.
            // Cache *storage* remains on its separately published per-token-hour tariff.
            cachedInputPerMillionUsd = p.evaluationCachedInputPerMillionUsd * factor,
            cacheStoragePerMillionTokenHourUsd = p.cacheStoragePerMillionTokenHourUsd
        )
    }

    fun feedbackPricing(useBatchApi: Boolean = false): Pricing {
        val p = activeProfile
        val factor = if (useBatchApi) p.batchPriceFactor else 1.0
        return Pricing(
            inputPerMillionUsd = p.feedbackInputPerMillionUsd * factor,
            outputPerMillionUsd = p.feedbackOutputPerMillionUsd * factor
        )
    }

    fun authoringPricing(): Pricing {
        val p = activeProfile
        return Pricing(
            inputPerMillionUsd = p.authoringInputPerMillionUsd,
            outputPerMillionUsd = p.authoringOutputPerMillionUsd,
            cachedInputPerMillionUsd = p.authoringCachedInputPerMillionUsd
        )
    }

    fun generateContentUrl(modelId: String): String = "$apiRoot/models/$modelId:generateContent"
    fun batchGenerateContentUrl(modelId: String): String = "$apiRoot/models/$modelId:batchGenerateContent"
    fun modelResource(modelId: String): String = "models/$modelId"
}
