package com.example.feature.workflow

import com.example.core.model.ObjectiveInterpretationPolicy
import com.example.core.model.ReadinessSupportPriorityPolicy
import com.example.core.model.MultipleChoiceReportAnswer
import com.example.core.model.MultipleChoiceReportPolicy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamEvaluationRepository
import com.example.core.database.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch


data class ObjectiveReportData(
    val objectiveId: Long,
    val learningArea: String?,
    val objectiveCode: String?,
    val objectiveText: String,
    val totalScore: Double,
    val maxScore: Double,
    val successPercentage: Double,
    val level: String,
    val questionCount: Int = 0,
    val supportStudentCount: Int = 0,
    val measuredStudentCount: Int = 0,
    val supportRatePercentage: Double = 0.0
)

data class ReportsUiState(
    val isLoading: Boolean = true,
    val draft: ExamDraftEntity? = null,
    val preferences: ExamEvaluationPreferencesEntity? = null,
    val classReportGroups: Map<String, ClassReportData> = emptyMap(),
    val individualReports: List<IndividualReportData> = emptyList(),
    val questionReports: List<QuestionReportData> = emptyList(),
    val error: String? = null,
    val objectiveIntegrityError: String? = null,
    val answerImagesPresent: Boolean = false,
    val isCleaningAnswerImages: Boolean = false,
    val cleanupMessage: String? = null,
    val isGeneratingFeedback: Boolean = false,
    val feedbackPendingCount: Int = 0,
    val feedbackCompletedCount: Int = 0,
    val feedbackMessage: String? = null,
    val aiUsageSummary: ExamEvaluationRepository.AiUsageSummary? = null
)

data class ClassReportData(
    val classAndBranch: String,
    val studentCount: Int,
    val classAverage: Double,
    val maxScore: Double,
    val minScore: Double,
    val classObjectiveScores: List<ObjectiveReportData> = emptyList(),
    val prioritySupportObjectives: List<ObjectiveReportData> = emptyList(),
    val students: List<ClassReportStudent>,
    val testAverageCorrect: Double = 0.0,
    val testAverageWrong: Double = 0.0,
    val testAverageBlank: Double = 0.0
)

data class ClassReportStudent(
    val paperId: Long,
    val studentName: String,
    val studentNumber: String,
    val classAndBranch: String,
    val totalScore: Double,
    val totalMaxScore: Double
)

data class IndividualReportData(
    val paperId: Long,
    val studentName: String,
    val studentNumber: String,
    val classAndBranch: String,
    val totalScore: Double,
    val totalMaxScore: Double,
    val questionScores: List<IndividualQuestionScore>,
    val pages: List<ExamPaperPageEntity>,
    val overallFeedback: String? = null,
    val teacherNote: String? = null,
    val spellingPunctuationFeedback: String? = null,
    val spellingPunctuationDeduction: Double? = null,
    val objectiveScores: List<ObjectiveReportData> = emptyList(),
    val prioritySupportObjectives: List<ObjectiveReportData> = emptyList(),
    val testCorrectCount: Int = 0,
    val testWrongCount: Int = 0,
    val testBlankCount: Int = 0,
    val aiDisclosure: String = ""
)

data class IndividualQuestionScore(
    val questionNumber: String,
    val score: Double,
    val maxScore: Double,
    val feedback: String?,
    val answerType: String = "NORMAL",
    val needsReview: Boolean = false
)

data class QuestionReportData(
    val questionOrderIndex: Int,
    val questionNumber: String,
    val questionText: String,
    val maxScore: Double,
    val studentCount: Int,
    val averageScore: Double,
    val successPercentage: Double,
    val students: List<QuestionStudentDistribution>,
    val objectives: List<ExamObjectiveEntity> = emptyList(),
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val blankCount: Int = 0,
    val correctChoice: String? = null,
    val choiceDistribution: Map<String, Int> = emptyMap()
)

data class QuestionStudentDistribution(
    val studentName: String,
    val studentNumber: String,
    val classAndBranch: String,
    val score: Double,
    val maxScore: Double
)

class ReportsViewModel(
    private val objectiveRepository: com.example.core.data.ExamObjectiveRepository,
    private val draftRepository: ExamDraftRepository,
    private val evaluationRepository: ExamEvaluationRepository,
    private val paperUploadRepository: com.example.core.data.ExamPaperUploadRepository,
    private val evaluationDao: ExamEvaluationDao,
    private val paperDao: ExamPaperUploadDao,
    private val questionDao: ExamQuestionDao,
    private val preferencesDao: ExamEvaluationPreferencesDao,
    private val draftId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()
    private var feedbackGenerationJob: Job? = null

    fun cancelActiveFeedbackGeneration() {
        feedbackGenerationJob?.cancel()
    }

    private fun getObjectiveLevel(examType: com.example.core.model.ExamType, percentage: Double): String =
        ObjectiveInterpretationPolicy.level(examType, percentage)

    private fun testReportAnswers(rows: List<ExamQuestionEvaluationEntity>): List<MultipleChoiceReportAnswer> =
        rows.map { MultipleChoiceReportAnswer(it.score, it.maxScore, it.answerType, it.readAnswerText) }

    init {
        loadReports()
        viewModelScope.launch {
            draftRepository.getDraftById(draftId).collectLatest { draft ->
                if (draft?.currentWorkflowStage != com.example.core.model.WorkflowStage.REPORTS) {
                    cancelActiveFeedbackGeneration()
                }
            }
        }
    }

    private fun loadReports() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val draft = draftRepository.getDraftByIdOnce(draftId)
                if (draft == null) {
                    _uiState.value = ReportsUiState(isLoading = false, error = "Değerlendirme taslağı bulunamadı.")
                    return@launch
                }
                val copy = reportCopy(draft.examType)
                val documentLabel = when (draft.examType) {
                    com.example.core.model.ExamType.HOMEWORK -> "Ödev"
                    com.example.core.model.ExamType.READINESS -> "Hazırbulunuşluk sınavı"
                    com.example.core.model.ExamType.MULTIPLE_CHOICE -> "Test sınavı"
                    else -> "Sınav"
                }
                val objectiveSingular = ObjectiveInterpretationPolicy.singular(draft.examType)
                val objectivePlural = ObjectiveInterpretationPolicy.plural(draft.examType)

                // Perform Integrity Check First
                val integrityResult = evaluationRepository.checkFinalResultsIntegrity(draftId)
                if (integrityResult.isFailure) {
                    val integrityLabel = when (draft.examType) {
                    com.example.core.model.ExamType.HOMEWORK -> "Ödev sonuç bütünlüğü"
                    com.example.core.model.ExamType.READINESS -> "Hazırbulunuşluk sonuç bütünlüğü"
                    com.example.core.model.ExamType.MULTIPLE_CHOICE -> "Test sonuç bütünlüğü"
                    else -> "Sınav sonuç bütünlüğü"
                }
                    _uiState.value = ReportsUiState(
                        isLoading = false,
                        draft = draft,
                        error = "$integrityLabel doğrulanamadı:\n${integrityResult.exceptionOrNull()?.message}\nLütfen Öğretmen İncelemesi aşamasına dönüp eksikleri tamamlayın."
                    )
                    return@launch
                }

                val storedPrefs = preferencesDao.getPreferencesOnce(draftId)
                val prefs = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                    (storedPrefs ?: ExamEvaluationPreferencesEntity(examDraftId = draftId)).copy(
                        reportClass = true,
                        reportIndividual = true,
                        reportQuestion = true,
                        deductWritingAndPunctuationPoints = false,
                        provideWritingAndPunctuationFeedback = false,
                        useBatchApi = false,
                        usePromptCaching = false
                    )
                } else storedPrefs
                if (prefs == null) {
                    _uiState.value = ReportsUiState(isLoading = false, draft = draft, error = "Değerlendirme tercihleri bulunamadı.")
                    return@launch
                }

                val papers = paperDao.getPapersForExamOnce(draftId)
                val evals = evaluationDao.getStudentEvaluationsForExamOnce(draftId)
                val qEvals = evaluationDao.getQuestionEvaluationsForExamOnce(draftId)
                val aiUsageSummary = evaluationRepository.getAiUsageSummary(draftId)
                val processingMode = evaluationRepository.getProcessingMode(draftId)
                val authoringUsed = aiUsageSummary.stages.any { it.startsWith("AUTHORING_") }
                val evaluationUsed = aiUsageSummary.stages.any { it.startsWith("EVALUATION") || it.startsWith("SECOND") }
                val feedbackUsed = aiUsageSummary.stages.any { it.contains("FEEDBACK") }
                val aiDisclosure = when {
                    processingMode.evaluationSource == "MANUAL" && !authoringUsed && !evaluationUsed && !feedbackUsed ->
                        "Bu sınavın öğrenci cevapları yapay zekâ kullanılmadan öğretmen tarafından manuel değerlendirilmiştir. Nihai akademik karar ve e-Okul kaydı öğretmene aittir."
                    processingMode.evaluationSource == "MANUAL" && authoringUsed && !evaluationUsed && !feedbackUsed ->
                        "Öğrenci cevapları yapay zekâ kullanılmadan öğretmen tarafından manuel değerlendirilmiştir. Sınav hazırlığının bazı aşamalarında yapay zekâ kullanılmıştır; öğrenci puanlamasında ve final dönütünde AI kullanılmamıştır. Nihai akademik karar öğretmene aittir."
                    processingMode.evaluationSource == "MANUAL" ->
                        "Bu çalışmada daha önce AI işlemi denenmiş olabilir; ancak aktif değerlendirme modu MANUEL'dir ve nihai öğrenci puanları öğretmen tarafından yeniden oluşturulmuştur. Manuel moda geçildikten sonra AI ikinci okuma ve otomatik final dönütü kullanılmaz. Nihai akademik karar öğretmene aittir."

                    draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE && !evaluationUsed && !feedbackUsed && !authoringUsed ->
                        "Bu rapor BaykuşNot'un yerel optik okuması ve kilitli öğretmen cevap anahtarıyla hazırlanmıştır; öğrenci cevabı yapay zekâ ile puanlanmamıştır. Nihai akademik kayıt öğretmene aittir."
                    draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE && !evaluationUsed && !feedbackUsed && authoringUsed ->
                        "Öğrenci puanlaması BaykuşNot'un yerel optik okuması ve kilitli öğretmen cevap anahtarıyla yapılmıştır; öğrenci cevabı yapay zekâ ile puanlanmamıştır. Sınav hazırlığının bazı aşamalarında yapay zekâ kullanılmıştır. Nihai akademik kayıt öğretmene aittir."
                    else ->
                        "Bu rapor BaykuşNot'un yapay zekâ destekli değerlendirme akışıyla hazırlanmıştır. Yapay zekâ çıktıları hata/halüsinasyon içerebilir; nihai akademik karar ve e-Okul kaydı öğretmene aittir. Sonradan yapılan yeniden inceleme veya not değişikliğinde öğretmenin güncel kaydı esas alınır."
                }
                val pendingFeedback = evaluationRepository.countMissingFinalFeedback(draftId)
                if (pendingFeedback > 0 && _uiState.value.feedbackMessage.isNullOrBlank()) {
                    _uiState.value = _uiState.value.copy(
                        feedbackPendingCount = pendingFeedback,
                        feedbackMessage = "$pendingFeedback öğrenci için kişisel dönüt henüz hazırlanmadı. Dönütler yalnız öğretmen başlattığında, en fazla 25 öğrenci olarak hazırlanır."
                    )
                }
                
                val questions = questionDao.getByExamDraftIdOnce(draftId)
                val allPages = paperDao.getPagesForExamOnce(draftId)
                val testAnswerKeyByOrder = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                    evaluationRepository.getRubricsOnce(draftId)
                        .associate { it.questionOrderIndex to it.expectedAnswer.trim().uppercase() }
                } else emptyMap()
                
                var objectives: List<com.example.core.database.ExamObjectiveEntity> = emptyList()
                var crossRefs: List<com.example.core.database.QuestionObjectiveCrossRef> = emptyList()
                var objectiveIntegrityError: String? = null

                if (draft.hasScenario) {
                    var integrityCheckPassed = true
                    
                    if (!draft.isScenarioApproved || !draft.isObjectiveMappingApproved) {
                        integrityCheckPassed = false
                        objectiveIntegrityError = "$documentLabel senaryo ve $objectivePlural bütünlüğü doğrulanamadı. Senaryo ve $objectivePlural eşleştirmesi onaylanmış olmalıdır."
                    }
                    
                    val loadedObjectives = objectiveRepository.getApprovedObjectivesByDraftId(draftId)
                    val loadedCrossRefs = objectiveRepository.getQuestionObjectiveCrossRefsByDraftId(draftId)
                    
                    if (integrityCheckPassed && loadedObjectives.isEmpty()) {
                        integrityCheckPassed = false
                        objectiveIntegrityError = "Onaylı $objectivePlural listesi boş. Lütfen geçerli bir senaryo onaylayın."
                    }
                    
                    if (integrityCheckPassed && loadedCrossRefs.isEmpty()) {
                        integrityCheckPassed = false
                        objectiveIntegrityError = "${copy.itemLabel}-$objectiveSingular eşleştirmesi bulunamadı. Lütfen $objectivePlural eşleştirmelerini yapıp onaylayın."
                    }
                    
                    if (integrityCheckPassed) {
                        val approvedObjectiveIds = loadedObjectives.map { it.id }.toSet()
                        val savedQuestionIds = questions.map { it.id }.toSet()
                        
                        var hasOrphanOrForeign = false
                        for (ref in loadedCrossRefs) {
                            if (!savedQuestionIds.contains(ref.questionId) || !approvedObjectiveIds.contains(ref.objectiveId)) {
                                hasOrphanOrForeign = true
                                break
                            }
                        }
                        
                        if (hasOrphanOrForeign) {
                            integrityCheckPassed = false
                            objectiveIntegrityError = "$documentLabel ${copy.itemPluralLabel.lowercase()} veya $objectivePlural eşleştirmeleri güncel değil. Geçersiz $objectiveSingular referansları tespit edildi."
                        }
                    }
                    
                    if (integrityCheckPassed) {
                        val refsByQuestion = loadedCrossRefs.groupBy { it.questionId }
                        var allQuestionsMapped = true
                        for (sq in questions) {
                            val refs = refsByQuestion[sq.id] ?: emptyList()
                            if (refs.isEmpty()) {
                                allQuestionsMapped = false
                                break
                            }
                        }
                        
                        if (!allQuestionsMapped) {
                            integrityCheckPassed = false
                            objectiveIntegrityError = "Taslaktaki tüm ${copy.itemPluralLabel.lowercase()} için en az bir $objectiveSingular atanmış olmalıdır."
                        }
                    }
                    
                    if (integrityCheckPassed) {
                        objectives = loadedObjectives
                        crossRefs = loadedCrossRefs
                    } else {
                        objectives = emptyList()
                        crossRefs = emptyList()
                    }
                }
                
                val qOrderToId = questions.associate { it.orderIndex to it.id }
                val questionIdToObjectives = crossRefs.groupBy { it.questionId }.mapValues { it.value.map { ref -> ref.objectiveId }.toSet() }
                
                val evalMap = evals.associateBy { it.studentPaperId }
                val qEvalMap = qEvals.groupBy { it.studentPaperId }
                val pagesMap = allPages.groupBy { it.studentPaperId }
                
                // 1. Prepare raw student data sorted by class, branch, and school number
                val rawStudents = papers.mapNotNull { paper ->
                    val eval = evalMap[paper.id]
                    if (eval == null || !eval.isTeacherApproved) return@mapNotNull null
                    
                    val name = paper.studentName ?: "İsimsiz"
                    val number = paper.schoolNumber ?: "0"
                    val classLevel = paper.classLevel ?: "Belirtilmemiş"
                    val branch = paper.branch ?: ""
                    val classAndBranch = if (branch.isNotBlank()) "$classLevel/$branch" else classLevel
                    
                    val num = number.filter { it.isDigit() }.toIntOrNull() ?: 0
                    
                    Triple(paper, eval, Triple(classLevel, branch, num))
                }.sortedWith(compareBy({ it.third.first }, { it.third.second }, { it.third.third }))

                // 2. Class Reports
                val classGroups = mutableMapOf<String, ClassReportData>()
                if (prefs.reportClass) {
                    val groupedByClass = rawStudents.groupBy { 
                        val cl = it.first.classLevel ?: "Belirtilmemiş"
                        val br = it.first.branch ?: ""
                        if (br.isNotBlank()) "$cl/$br" else cl
                    }
                    
                    groupedByClass.forEach { (className, studentsInClass) ->
                        val reportStudents = studentsInClass.map { (paper, eval, _) ->
                            ClassReportStudent(
                                paperId = paper.id,
                                studentName = paper.studentName ?: "İsimsiz",
                                studentNumber = paper.schoolNumber ?: "-",
                                classAndBranch = className,
                                totalScore = eval.totalScore ?: 0.0,
                                totalMaxScore = eval.totalMaxScore ?: 100.0
                            )
                        }
                        
                        val scores = reportStudents.map { it.totalScore }
                        val avg = if (scores.isNotEmpty()) scores.average() else 0.0
                        val max = if (scores.isNotEmpty()) scores.maxOrNull() ?: 0.0 else 0.0
                        val min = if (scores.isNotEmpty()) scores.minOrNull() ?: 0.0 else 0.0

                        val classObjectiveScores = objectives.map { obj ->
                            val objQuestions = questions.filter { q ->
                                questionIdToObjectives[q.id]?.contains(obj.id) == true
                            }
                            val questionCount = objQuestions.size
                            val isMeasured = questionCount > 0
                            val objMaxScore = if (isMeasured) objQuestions.sumOf { it.points.toDouble() } else 0.0

                            var totalClassObjScore = 0.0
                            var supportStudentCount = 0
                            val measuredStudentCount = if (isMeasured) studentsInClass.size else 0

                            if (isMeasured) {
                                studentsInClass.forEach { (paper, _, _) ->
                                    val paperQEvals = qEvalMap[paper.id] ?: emptyList()
                                    val paperObjScore = objQuestions.sumOf { q ->
                                        paperQEvals.find { it.questionOrderIndex == q.orderIndex }?.score ?: 0.0
                                    }
                                    totalClassObjScore += paperObjScore

                                    if (draft.examType == com.example.core.model.ExamType.READINESS && objMaxScore > 0.0) {
                                        val paperObjPct = (paperObjScore / objMaxScore) * 100.0
                                        if (ReadinessSupportPriorityPolicy.needsSupport(paperObjPct)) {
                                            supportStudentCount++
                                        }
                                    }
                                }
                            }

                            val classAvgObjScore = if (isMeasured && studentsInClass.isNotEmpty()) totalClassObjScore / studentsInClass.size else 0.0
                            val classObjPct = if (isMeasured && objMaxScore > 0) (classAvgObjScore / objMaxScore) * 100 else 0.0
                            val levelStr = if (isMeasured) getObjectiveLevel(draft.examType, classObjPct) else copy.notMeasuredText
                            val supportRate = if (draft.examType == com.example.core.model.ExamType.READINESS) {
                                ReadinessSupportPriorityPolicy.supportRatePercentage(supportStudentCount, measuredStudentCount)
                            } else 0.0

                            ObjectiveReportData(
                                objectiveId = obj.id,
                                learningArea = obj.learningArea,
                                objectiveCode = obj.objectiveCode,
                                objectiveText = obj.objectiveText,
                                totalScore = classAvgObjScore,
                                maxScore = objMaxScore,
                                successPercentage = classObjPct,
                                level = levelStr,
                                questionCount = questionCount,
                                supportStudentCount = supportStudentCount,
                                measuredStudentCount = measuredStudentCount,
                                supportRatePercentage = supportRate
                            )
                        }

                        val prioritySupportObjectives = if (draft.examType == com.example.core.model.ExamType.READINESS) {
                            classObjectiveScores
                                .filter { it.questionCount > 0 && it.supportStudentCount > 0 }
                                .sortedWith(
                                    compareByDescending<ObjectiveReportData> { it.supportRatePercentage }
                                        .thenBy { it.successPercentage }
                                        .thenBy { it.objectiveCode ?: it.objectiveText }
                                )
                                .take(5)
                        } else {
                            emptyList()
                        }

                        val testCounts = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) {
                            studentsInClass.map { (paper, _, _) ->
                                MultipleChoiceReportPolicy.tally(testReportAnswers(qEvalMap[paper.id].orEmpty()))
                            }
                        } else emptyList()
                        val testAvgCorrect = if (testCounts.isNotEmpty()) testCounts.map { it.correct }.average() else 0.0
                        val testAvgWrong = if (testCounts.isNotEmpty()) testCounts.map { it.wrong }.average() else 0.0
                        val testAvgBlank = if (testCounts.isNotEmpty()) testCounts.map { it.blank }.average() else 0.0

                        classGroups[className] = ClassReportData(
                            classAndBranch = className,
                            studentCount = reportStudents.size,
                            classAverage = avg,
                            maxScore = max,
                            minScore = min,
                            students = reportStudents,
                            classObjectiveScores = classObjectiveScores,
                            prioritySupportObjectives = prioritySupportObjectives,
                            testAverageCorrect = testAvgCorrect,
                            testAverageWrong = testAvgWrong,
                            testAverageBlank = testAvgBlank
                        )
                    }
                }

                // 3. Individual Reports
                val individualReports = mutableListOf<IndividualReportData>()
                if (prefs.reportIndividual) {
                    rawStudents.forEach { (paper, eval, sortingTrips) ->
                        val studentQEvals = qEvalMap[paper.id]?.sortedBy { it.questionOrderIndex } ?: emptyList()
                        val studentPages = pagesMap[paper.id]?.sortedBy { it.pageIndex } ?: emptyList()
                        
                        val objectiveScores = objectives.map { obj ->
                            val objQuestions = questions.filter { q -> 
                                questionIdToObjectives[q.id]?.contains(obj.id) == true 
                            }
                            val questionCount = objQuestions.size
                            val isMeasured = questionCount > 0
                            val objMaxScore = if (isMeasured) objQuestions.sumOf { it.points.toDouble() } else 0.0
                            
                            val objScore = if (isMeasured) {
                                objQuestions.sumOf { q ->
                                    studentQEvals.find { it.questionOrderIndex == q.orderIndex }?.score ?: 0.0
                                }
                            } else 0.0
                            
                            val objPct = if (isMeasured && objMaxScore > 0) (objScore / objMaxScore) * 100 else 0.0
                            val levelStr = if (isMeasured) getObjectiveLevel(draft.examType, objPct) else copy.notMeasuredText
                            ObjectiveReportData(
                                objectiveId = obj.id,
                                learningArea = obj.learningArea,
                                objectiveCode = obj.objectiveCode,
                                objectiveText = obj.objectiveText,
                                totalScore = objScore,
                                maxScore = objMaxScore,
                                successPercentage = objPct,
                                level = levelStr,
                                questionCount = questionCount
                            )
                        }

                        val prioritySupportObjectives = if (draft.examType == com.example.core.model.ExamType.READINESS) {
                            objectiveScores
                                .filter { it.questionCount > 0 && ReadinessSupportPriorityPolicy.needsSupport(it.successPercentage) }
                                .sortedWith(
                                    compareBy<ObjectiveReportData> { it.successPercentage }
                                        .thenBy { it.objectiveCode ?: it.objectiveText }
                                )
                                .take(5)
                        } else {
                            emptyList()
                        }

                        val questionScores = studentQEvals.map { qEval ->
                            val cleanFeedback = if (prefs.feedbackDetailLevel != com.example.core.model.FeedbackDetailLevel.SCORE_ONLY) {
                                val isUnreadable = qEval.answerType == "UNREADABLE" ||
                                        (qEval.answerType == "LOW_CONFIDENCE" && qEval.needsReview && !qEval.isResolved) ||
                                        (qEval.needsReview && !qEval.isResolved && (qEval.readAnswerText.isBlank() || qEval.readAnswerText.contains("okunamadı", ignoreCase = true)))
                                if (isUnreadable) {
                                    if (draft.examType == com.example.core.model.ExamType.HOMEWORK) {
                                        "Bu görev/maddeye ait içerik güvenilir biçimde okunamadığı için öğretmen incelemesine bırakıldı."
                                    } else {
                                        "Bu cevap güvenilir biçimde okunamadığı için öğretmen incelemesine bırakıldı."
                                    }
                                } else {
                                    qEval.feedback
                                }
                            } else null

                            IndividualQuestionScore(
                                questionNumber = qEval.questionNumber,
                                score = qEval.score,
                                maxScore = qEval.maxScore,
                                feedback = cleanFeedback,
                                answerType = qEval.answerType,
                                needsReview = qEval.needsReview
                            )
                        }
                        
                        val classAndBranch = if (sortingTrips.second.isNotBlank()) "${sortingTrips.first}/${sortingTrips.second}" else sortingTrips.first

                        individualReports.add(
                            IndividualReportData(
                                paperId = paper.id,
                                studentName = paper.studentName ?: "İsimsiz",
                                studentNumber = paper.schoolNumber ?: "-",
                                classAndBranch = classAndBranch,
                                totalScore = eval.totalScore ?: 0.0,
                                totalMaxScore = eval.totalMaxScore ?: 100.0,
                                questionScores = questionScores,
                                pages = studentPages,
                                overallFeedback = eval.overallFeedback,
                                teacherNote = eval.teacherNote,
                                spellingPunctuationFeedback = if (prefs.provideWritingAndPunctuationFeedback) eval.spellingPunctuationFeedback else null,
                                spellingPunctuationDeduction = if (prefs.provideWritingAndPunctuationFeedback) eval.spellingPunctuationDeduction else null,
                                objectiveScores = objectiveScores,
                                prioritySupportObjectives = prioritySupportObjectives,
                                testCorrectCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(studentQEvals)).correct else 0,
                                testWrongCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(studentQEvals)).wrong else 0,
                                testBlankCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(studentQEvals)).blank else 0,
                                aiDisclosure = aiDisclosure
                            )
                        )
                    }
                }

                // 4. Question Reports
                val questionReports = mutableListOf<QuestionReportData>()
                if (prefs.reportQuestion) {
                    val groupedQEvals = qEvals.groupBy { it.questionOrderIndex }
                    
                    questions.forEach { question ->
                        val qEvalsForQ = groupedQEvals[question.orderIndex] ?: emptyList()
                        // Only include teacher approved
                        val validQEvals = qEvalsForQ.filter { qEval -> evalMap[qEval.studentPaperId]?.isTeacherApproved == true }
                        
                        val qObjectives = objectives.filter { obj ->
                            questionIdToObjectives[question.id]?.contains(obj.id) == true
                        }

                        val scores = validQEvals.map { it.score }
                        val avg = if (scores.isNotEmpty()) scores.average() else 0.0
                        val maxScore = question.points.toDouble()
                        val percentage = if (maxScore > 0 && scores.isNotEmpty()) (avg / maxScore) * 100 else 0.0
                        
                        val distributions = validQEvals.mapNotNull { qEval ->
                            val paper = papers.find { it.id == qEval.studentPaperId } ?: return@mapNotNull null
                            val cl = paper.classLevel ?: "Belirtilmemiş"
                            val br = paper.branch ?: ""
                            val classAndBranch = if (br.isNotBlank()) "$cl/$br" else cl
                            val num = paper.schoolNumber?.filter { c -> c.isDigit() }?.toIntOrNull() ?: 0
                            
                            class SortingData(
                                val dist: QuestionStudentDistribution,
                                val cl: String,
                                val br: String,
                                val num: Int
                            )
                            
                            SortingData(QuestionStudentDistribution(
                                studentName = paper.studentName ?: "İsimsiz",
                                studentNumber = paper.schoolNumber ?: "-",
                                classAndBranch = classAndBranch,
                                score = qEval.score,
                                maxScore = maxScore
                            ), cl, br, num)
                        }.sortedWith(compareBy({ it.cl }, { it.br }, { it.num })).map { it.dist }
                        
                        questionReports.add(
                            QuestionReportData(
                                questionOrderIndex = question.orderIndex,
                                questionNumber = question.questionNumber,
                                questionText = question.questionText,
                                maxScore = maxScore,
                                studentCount = validQEvals.size,
                                averageScore = avg,
                                successPercentage = percentage,
                                students = distributions,
                                objectives = qObjectives,
                                correctCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(validQEvals)).correct else 0,
                                wrongCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(validQEvals)).wrong else 0,
                                blankCount = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.tally(testReportAnswers(validQEvals)).blank else 0,
                                correctChoice = testAnswerKeyByOrder[question.orderIndex],
                                choiceDistribution = if (draft.examType == com.example.core.model.ExamType.MULTIPLE_CHOICE) MultipleChoiceReportPolicy.choiceDistribution(testReportAnswers(validQEvals)) else emptyMap()
                            )
                        )
                    }
                }

                _uiState.value = ReportsUiState(
                    isLoading = false,
                    draft = draft,
                    preferences = prefs,
                    classReportGroups = classGroups,
                    individualReports = individualReports,
                    questionReports = questionReports,
                    error = null,
                    objectiveIntegrityError = objectiveIntegrityError,
                    answerImagesPresent = paperDao.getPagesForExamOnce(draftId).isNotEmpty(),
                    feedbackPendingCount = pendingFeedback,
                    feedbackCompletedCount = 0,
                    feedbackMessage = _uiState.value.feedbackMessage,
                    aiUsageSummary = aiUsageSummary
                )

            } catch (e: Exception) {
                _uiState.value = ReportsUiState(isLoading = false, error = e.message ?: "Raporlar yüklenirken bir hata oluştu.")
            }
        }
    }

    fun retryMissingFeedback() {
        if (_uiState.value.isGeneratingFeedback || feedbackGenerationJob?.isActive == true) return
        val job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val pending = evaluationRepository.countMissingFinalFeedback(draftId)
                if (pending <= 0) {
                    _uiState.value = _uiState.value.copy(feedbackPendingCount = 0, feedbackMessage = "Eksik ayrıntılı dönüt yok.")
                    return@launch
                }
                val batchSize = minOf(pending, 25)
                _uiState.value = _uiState.value.copy(
                    isGeneratingFeedback = true,
                    feedbackPendingCount = pending,
                    feedbackCompletedCount = 0,
                    feedbackMessage = "$batchSize öğrenci için dönüt hazırlanıyor..."
                )
                val result = evaluationRepository.generateMissingFinalFeedback(draftId, maxItems = batchSize) { completed, total ->
                    _uiState.value = _uiState.value.copy(
                        isGeneratingFeedback = true,
                        feedbackPendingCount = pending,
                        feedbackCompletedCount = completed,
                        feedbackMessage = "Bu tur: $completed/$total"
                    )
                }
                val summary = result.getOrNull()
                val remaining = evaluationRepository.countMissingFinalFeedback(draftId)
                _uiState.value = _uiState.value.copy(
                    feedbackPendingCount = remaining,
                    feedbackMessage = when {
                        result.isFailure -> "Dönüt turu tamamlanamadı: ${result.exceptionOrNull()?.message ?: "beklenmeyen hata"}"
                        (summary?.failed ?: 0) > 0 -> "Bu turda ${summary?.failed} dönüt hazırlanamadı. Kalan: $remaining."
                        remaining > 0 -> "Bu tur tamamlandı. Kalan $remaining öğrenci için sonraki 25'lik grubu öğretmen başlatabilir."
                        else -> "Tüm kişisel dönütler hazır."
                    }
                )
                loadReports()
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(feedbackMessage = "Dönütler yeniden hazırlanamadı: ${e.message ?: "beklenmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isGeneratingFeedback = false)
            }
        }
        feedbackGenerationJob = job
        job.invokeOnCompletion {
            if (feedbackGenerationJob === job) feedbackGenerationJob = null
        }
    }

    fun deleteAnswerImagesAfterArchive() {
        if (_uiState.value.isCleaningAnswerImages || !_uiState.value.answerImagesPresent) return
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = _uiState.value.copy(isCleaningAnswerImages = true, cleanupMessage = null)
            try {
                val evaluations = evaluationRepository.getStudentEvaluationsForExamOnce(draftId)
                if (evaluations.isEmpty() || evaluations.any { !it.isTeacherApproved }) {
                    _uiState.value = _uiState.value.copy(
                        isCleaningAnswerImages = false,
                        cleanupMessage = "Cevap görüntüleri ancak tüm sonuçlar öğretmen tarafından onaylandıktan sonra silinebilir."
                    )
                    return@launch
                }
                val cleanup = paperUploadRepository.deleteAnswerImagesKeepEvaluationRecords(draftId)
                val fullyDeleted = cleanup.failed == 0
                _uiState.value = _uiState.value.copy(
                    isCleaningAnswerImages = false,
                    answerImagesPresent = !fullyDeleted,
                    individualReports = if (fullyDeleted) {
                        _uiState.value.individualReports.map { it.copy(pages = emptyList()) }
                    } else _uiState.value.individualReports,
                    cleanupMessage = if (fullyDeleted) {
                        "${cleanup.deleted} cevap sayfası görüntüsü cihazdan silindi. Puanlar, dönütler ve öğretmen onayları korunuyor."
                    } else {
                        "${cleanup.deleted}/${cleanup.attempted} cevap görüntüsü silindi; ${cleanup.failed} dosya fiziksel olarak silinemedi ve kayıtları yeniden deneme için korundu."
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isCleaningAnswerImages = false,
                    cleanupMessage = "Cevap görüntüleri silinemedi: ${e.message ?: "beklenmeyen hata"}"
                )
            }
        }
    }

    class Factory(
        private val draftRepository: ExamDraftRepository,
        private val evaluationRepository: ExamEvaluationRepository,
        private val paperUploadRepository: com.example.core.data.ExamPaperUploadRepository,
        private val evaluationDao: ExamEvaluationDao,
        private val paperDao: ExamPaperUploadDao,
        private val questionDao: ExamQuestionDao,
        private val preferencesDao: ExamEvaluationPreferencesDao,
        private val objectiveRepository: com.example.core.data.ExamObjectiveRepository,
        private val draftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(
                objectiveRepository, draftRepository, evaluationRepository, paperUploadRepository, evaluationDao, paperDao, questionDao, preferencesDao, draftId
            ) as T
        }
    }
}
