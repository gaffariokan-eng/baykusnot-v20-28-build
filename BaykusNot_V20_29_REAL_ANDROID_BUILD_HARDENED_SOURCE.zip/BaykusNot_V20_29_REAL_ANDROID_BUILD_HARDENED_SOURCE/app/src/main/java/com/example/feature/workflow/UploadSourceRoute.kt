package com.example.feature.workflow

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.data.PdfSelectionResolver
import com.example.core.data.SelectedPdfSource
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

internal suspend fun handleSelectedUris(
    uris: List<Uri>,
    context: Context,
    resolver: PdfSelectionResolver,
    onResolved: suspend (SelectedPdfSource) -> Unit,
    onResolutionError: () -> Unit
) {
    if (uris.isEmpty()) return
    coroutineContext.ensureActive()
    if (uris.size == 1) {
        val uri = uris.first()
        try {
            resolver.takePersistableReadPermission(uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onResolutionError()
            return
        }
        val resolvedSource = try {
            resolver.resolve(uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onResolutionError()
            return
        }
        onResolved(resolvedSource)
    } else {
        if (uris.size > 100) {
            onResolutionError()
            return
        }
        val tempZip = kotlin.runCatching { java.io.File.createTempFile("baykusnot_source_", ".zip", context.cacheDir) }.getOrNull()
            ?: run { onResolutionError(); return }
        try {
            var totalUncompressed = 0L
            ZipOutputStream(tempZip.outputStream().buffered()).use { zos ->
                uris.forEachIndexed { index, uri ->
                    coroutineContext.ensureActive()
                    val resolved = resolver.resolve(uri)
                    val extension = getExtension(resolved.mimeType)
                    if (extension == ".img") throw IllegalArgumentException("Desteklenmeyen görsel türü")
                    val input = resolved.openInputStream() ?: throw IllegalStateException("Görsel açılamadı")
                    val paddedIndex = index.toString().padStart(4, '0')
                    zos.putNextEntry(ZipEntry("image_$paddedIndex$extension"))
                    input.use { stream ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            coroutineContext.ensureActive()
                            val read = stream.read(buffer)
                            if (read < 0) break
                            totalUncompressed += read
                            if (totalUncompressed > 50L * 1024L * 1024L) {
                                throw IllegalArgumentException("Seçilen görsellerin toplam boyutu 50 MB sınırını aşıyor")
                            }
                            zos.write(buffer, 0, read)
                        }
                    }
                    zos.closeEntry()
                }
            }
            onResolved(
                SelectedPdfSource(
                    originalUri = tempZip.absolutePath,
                    displayName = "Gorseller.zip",
                    mimeType = "application/zip",
                    declaredSizeBytes = tempZip.length(),
                    openInputStream = {
                        object : FileInputStream(tempZip) {
                            override fun close() {
                                try { super.close() } finally { tempZip.delete() }
                            }
                        }
                    },
                    cleanup = { tempZip.delete() }
                )
            )
        } catch (e: CancellationException) {
            tempZip.delete()
            throw e
        } catch (_: Exception) {
            tempZip.delete()
            onResolutionError()
        }
    }
}

internal val DEFAULT_SOURCE_MIME_TYPES = listOf(
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/jpeg",
    "image/png",
    "image/webp"
)

private fun getExtension(mimeType: String): String {
    val lower = mimeType.lowercase()
    return when {
        lower.contains("png") -> ".png"
        lower.contains("webp") -> ".webp"
        lower.contains("jpeg") || lower.contains("jpg") -> ".jpg"
        else -> ".img"
    }
}

@Composable
fun UploadSourceRoute(
    viewModel: UploadSourceViewModel,
    pdfSelectionResolver: PdfSelectionResolver,
    onContinue: () -> Unit,
    copy: UploadSourceCopy = UploadSourceCopy(),
    showScenarioSection: Boolean = true,
    allowedSourceMimeTypes: List<String> = DEFAULT_SOURCE_MIME_TYPES,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    DisposableEffect(viewModel) {
        onDispose { viewModel.cancelActiveAuthoringWork() }
    }
    var selectionMessage by remember { mutableStateOf<String?>(null) }
    var showPasteDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var pickingScenario by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (pickingScenario && uris.size > 1) {
            selectionMessage = "Senaryo için tek bir PDF veya görsel seçin."
            return@rememberLauncherForActivityResult
        }
        val hasMultipleNonImages = uris.size > 1 && !uris.all { uri ->
            try {
                val type = context.contentResolver.getType(uri)?.lowercase() ?: ""
                type == "image/jpeg" || type == "image/jpg" || type == "image/png" || type == "image/webp"
            } catch (e: Exception) {
                false
            }
        }
        if (hasMultipleNonImages) {
            selectionMessage = "Birden fazla dosya seçimi yalnızca desteklenen görseller (JPEG, PNG, WebP) için geçerlidir."
            return@rememberLauncherForActivityResult
        }
        if (uris.size == 1) {
            val uri = uris.first()
            try {
                val type = context.contentResolver.getType(uri)?.lowercase() ?: ""
                if (type.startsWith("image/") && type != "image/jpeg" && type != "image/jpg" && type != "image/png" && type != "image/webp") {
                    selectionMessage = "Yalnızca JPEG, PNG ve WebP görselleri desteklenir."
                    return@rememberLauncherForActivityResult
                }
            } catch (e: Exception) {
                selectionMessage = "Dosya türü doğrulanamadı. Lütfen dosyayı yeniden seçin."
                return@rememberLauncherForActivityResult
            }
        }
        coroutineScope.launch(Dispatchers.IO) {
            handleSelectedUris(
                uris = uris,
                context = context,
                resolver = pdfSelectionResolver,
                onResolved = { selected ->
                    withContext(Dispatchers.Main.immediate) {
                        selectionMessage = null
                        if (pickingScenario) {
                            // Multiple scenario inputs are rejected above, so no temporary ZIP is owned here.
                            viewModel.extractScenario(mimeType = selected.mimeType, openInputStream = selected.openInputStream)
                            selected.cleanup()
                            pickingScenario = false
                        } else {
                            viewModel.importDocument(
                                originalUri = selected.originalUri,
                                displayName = selected.displayName,
                                mimeType = selected.mimeType,
                                declaredSizeBytes = selected.declaredSizeBytes,
                                openInputStream = selected.openInputStream,
                                onFinished = selected.cleanup
                            )
                        }
                    }
                },
                onResolutionError = {
                    coroutineScope.launch { selectionMessage = "Seçilen dosyaların bilgileri okunamadı veya toplam görsel boyutu sınırı aşıldı." }
                }
            )
        }
    }
    
    val contentState = uiState.copy(
        message = uiState.message ?: selectionMessage
    )

    UploadSourceContent(
        uiState = contentState,
        onPasteText = { showPasteDialog = true },
        onSelectPdf = {
            pickingScenario = false
            if (!uiState.isLoading && uiState.draftExists == true && !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting) {
                selectionMessage = null
                launcher.launch(allowedSourceMimeTypes.toTypedArray())
            }
        },
        onReplacePdf = {
            pickingScenario = false
            if (!uiState.isLoading && uiState.draftExists == true && !uiState.isImporting && !uiState.isRemoving && !uiState.isExtracting) {
                selectionMessage = null
                launcher.launch(allowedSourceMimeTypes.toTypedArray())
            }
        },
        onRemovePdf = viewModel::removeSource,
        onContinue = {
            viewModel.extractQuestions(onReviewableResult = onContinue)
        },
        onClearMessage = {
            viewModel.clearMessage()
            selectionMessage = null
        },
        onSelectScenarioPdf = {
            pickingScenario = true
            selectionMessage = null
            launcher.launch(arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp"))
        },
        onConfirmScenario = viewModel::confirmScenario,
        onUpdateStagingObjective = viewModel::updateStagingObjective,
        onAddStagingObjective = viewModel::addStagingObjective,
        onDeleteStagingObjective = viewModel::deleteStagingObjective,
        onClearScenarioPreview = viewModel::clearScenarioPreview,
        onRemoveScenario = viewModel::removeScenario,
        copy = copy,
        showScenarioSection = showScenarioSection,
        modifier = modifier
    )

    if (showPasteDialog) {
        PasteTextDialog(
            onDismissRequest = { showPasteDialog = false },
            onSaveText = { text ->
                showPasteDialog = false
                viewModel.importDocument(
                    originalUri = "",
                    displayName = "Yapistirilmis_Metin.txt",
                    mimeType = "text/plain",
                    declaredSizeBytes = text.toByteArray().size.toLong(),
                    openInputStream = { ByteArrayInputStream(text.toByteArray()) }
                )
            }
        )
    }
}
