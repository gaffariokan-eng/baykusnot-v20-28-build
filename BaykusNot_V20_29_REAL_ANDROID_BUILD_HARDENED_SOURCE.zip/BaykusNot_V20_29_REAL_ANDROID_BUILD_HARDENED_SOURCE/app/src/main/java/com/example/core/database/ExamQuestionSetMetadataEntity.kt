package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_question_set_metadata",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamQuestionSetMetadataEntity(
    @PrimaryKey
    val examDraftId: Long,
    val isLocked: Boolean,
    val lockedAt: Long?,
    val revision: Int,
    val createdAt: Long,
    val updatedAt: Long
)
