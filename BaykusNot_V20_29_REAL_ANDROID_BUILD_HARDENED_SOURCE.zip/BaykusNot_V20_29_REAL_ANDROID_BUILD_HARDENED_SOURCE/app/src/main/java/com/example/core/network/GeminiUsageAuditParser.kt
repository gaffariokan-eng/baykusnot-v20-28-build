package com.example.core.network

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Normalizes provider usage/audit metadata from both Interactions and generateContent responses. */
object GeminiUsageAuditParser {
    fun fromInteractions(root: JsonObject): AiUsageMetadata {
        val usage = root["usage"]?.jsonObject
        val modelStatus = root["model_status"]?.jsonObject ?: root["modelStatus"]?.jsonObject
        return AiUsageMetadata(
            inputTokens = usage?.get("total_input_tokens")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            cachedInputTokens = usage?.get("total_cached_tokens")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            outputTokens = usage?.get("total_output_tokens")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            thinkingTokens = usage?.get("total_thought_tokens")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            actualModelVersion = root["model"]?.jsonPrimitive?.contentOrNull,
            responseId = root["id"]?.jsonPrimitive?.contentOrNull,
            modelStatusStage = modelStatus?.get("stage")?.jsonPrimitive?.contentOrNull,
            modelRetirementTime = modelStatus?.get("retirement_time")?.jsonPrimitive?.contentOrNull
                ?: modelStatus?.get("retirementTime")?.jsonPrimitive?.contentOrNull,
            modelStatusMessage = modelStatus?.get("message")?.jsonPrimitive?.contentOrNull
        )
    }

    fun fromGenerateContent(root: JsonObject): AiUsageMetadata {
        val usage = root["usageMetadata"]?.jsonObject
        val modelStatus = root["modelStatus"]?.jsonObject
        return AiUsageMetadata(
            inputTokens = usage?.get("promptTokenCount")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            cachedInputTokens = usage?.get("cachedContentTokenCount")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            outputTokens = usage?.get("candidatesTokenCount")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            thinkingTokens = usage?.get("thoughtsTokenCount")?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L,
            actualModelVersion = root["modelVersion"]?.jsonPrimitive?.contentOrNull,
            responseId = root["responseId"]?.jsonPrimitive?.contentOrNull,
            modelStatusStage = modelStatus?.get("stage")?.jsonPrimitive?.contentOrNull,
            modelRetirementTime = modelStatus?.get("retirementTime")?.jsonPrimitive?.contentOrNull,
            modelStatusMessage = modelStatus?.get("message")?.jsonPrimitive?.contentOrNull
        )
    }
}
