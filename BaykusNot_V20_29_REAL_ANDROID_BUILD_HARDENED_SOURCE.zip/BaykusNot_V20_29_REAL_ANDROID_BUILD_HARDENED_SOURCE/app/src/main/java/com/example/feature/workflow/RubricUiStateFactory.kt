package com.example.feature.workflow

import com.example.core.model.ExamQuestion
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.ExamRubricSetMetadata
import com.example.core.model.ExamType
import com.example.core.model.MultipleChoiceOptionPolicy

object RubricUiStateFactory {

    fun create(
        draftId: Long,
        draftExists: Boolean,
        examType: ExamType = ExamType.WRITTEN,
        questions: List<ExamQuestion>,
        questionSetMetadata: ExamQuestionSetMetadata?,
        rubricMetadata: ExamRubricSetMetadata?,
        editableCriteria: List<EditableExamRubricCriterion>,
        deductWritingPunctuationPoints: Boolean?,
        isGenerating: Boolean,
        hasUnsavedChanges: Boolean,
        isLoading: Boolean,
        isSaving: Boolean,
        isLocking: Boolean,
        isUnlocking: Boolean,
        message: String?,
        evaluationSourceType: String,
        originalTeacherAnswerKey: String?,
        originalTeacherRubric: String?,
        elaboratedAnswerKey: String? = null,
        elaboratedRubric: String? = null,
        isAsIs: Boolean,
        isMatching: Boolean,
        answerKeyDocument: UploadedDocumentInfo? = null,
        rubricDocument: UploadedDocumentInfo? = null,
        isProcessingDocument: Boolean = false,
        documentProcessingProgress: String? = null
    ): RubricUiState {
        val evaluation = RubricFormEvaluator.evaluate(
            examDraftId = draftId,
            questions = questions,
            questionSetMetadata = questionSetMetadata,
            rubricMetadata = rubricMetadata,
            editableCriteria = editableCriteria,
            hasUnsavedChanges = hasUnsavedChanges
        )

        val operationInProgress =
            isSaving || isLocking || isUnlocking || isMatching || isProcessingDocument

        val canSave =
            draftExists &&
            !isLoading &&
            !operationInProgress &&
            evaluation.canSave

        val testAnswerKeyValid = examType != ExamType.MULTIPLE_CHOICE || questions.all { question ->
            val qCriteria = editableCriteria.filter { it.questionOrderIndex == question.orderIndex }
            qCriteria.size == 1 &&
                MultipleChoiceOptionPolicy.normalizeChoice(qCriteria.single().expectedAnswer) != null &&
                qCriteria.single().maxPointsText.toIntOrNull() == question.points
        }

        val canLock =
            draftExists &&
            !isLoading &&
            !operationInProgress &&
            evaluation.canLock &&
            testAnswerKeyValid

        val canContinue =
            draftExists &&
            !isLoading &&
            !operationInProgress &&
            rubricMetadata?.isLocked == true &&
            !hasUnsavedChanges &&
            evaluation.currentValidation?.isValid == true &&
            testAnswerKeyValid

        return RubricUiState(
            draftId = draftId,
            draftExists = draftExists,
            examType = examType,
            questions = questions,
            editableCriteria = editableCriteria,
            calculatedPointsByQuestionOrder = evaluation.calculatedPointsByQuestionOrder,
            validationIssues = evaluation.saveValidation?.issues ?: emptyList(),
            currentValidationIssues = evaluation.currentValidation?.issues ?: emptyList(),
            inputIssues = evaluation.inputIssues,
            canSave = canSave,
            canLock = canLock,
            canContinue = canContinue,
            isLocked = rubricMetadata?.isLocked ?: false,
            lockedAt = rubricMetadata?.lockedAt,
            revision = rubricMetadata?.revision ?: 0,
            questionSetRevision = questionSetMetadata?.revision,
            rubricQuestionSetRevision = rubricMetadata?.questionSetRevision,
            deductWritingPunctuationPoints = deductWritingPunctuationPoints,
            isLoading = isLoading,
            isGenerating = isGenerating,
            isSaving = isSaving,
            isLocking = isLocking,
            isUnlocking = isUnlocking,
            message = message,
            hasUnsavedChanges = hasUnsavedChanges,
            evaluationSourceType = evaluationSourceType,
            originalTeacherAnswerKey = originalTeacherAnswerKey,
            originalTeacherRubric = originalTeacherRubric,
            elaboratedAnswerKey = elaboratedAnswerKey ?: rubricMetadata?.elaboratedAnswerKey,
            elaboratedRubric = elaboratedRubric ?: rubricMetadata?.elaboratedRubric,
            isAsIs = isAsIs,
            isMatching = isMatching,
            answerKeyDocument = answerKeyDocument,
            rubricDocument = rubricDocument,
            isProcessingDocument = isProcessingDocument,
            documentProcessingProgress = documentProcessingProgress
        )
    }
}
