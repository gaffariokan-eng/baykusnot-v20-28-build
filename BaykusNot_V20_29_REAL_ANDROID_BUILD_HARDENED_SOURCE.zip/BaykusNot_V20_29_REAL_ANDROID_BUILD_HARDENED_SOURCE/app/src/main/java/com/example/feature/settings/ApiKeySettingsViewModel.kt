package com.example.feature.settings

import com.example.BuildConfig
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.ModelQualityPreferenceStore
import com.example.core.model.ModelQualityTier
import com.example.core.network.ConnectionTestResult
import com.example.core.network.GeminiModelProfile
import com.example.core.network.GeminiModelProfileStore
import com.example.core.network.GeminiModelRegistry
import com.example.core.network.GeminiBatchJobManager
import com.example.core.network.GeminiCacheManager
import com.example.core.network.GatewaySessionManager
import com.example.core.network.StoredApiKeyConnectionChecker
import com.example.core.security.SecureApiKeyStore
import com.example.core.security.YazekComplianceStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ApiKeySettingsUiState(
    val hasApiKey: Boolean = false,
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val isTestingConnection: Boolean = false,
    val connectionTestMessage: String? = null,
    val isConnectionTestSuccessful: Boolean? = null,
    val selectedModelQualityTier: ModelQualityTier = ModelQualityTier.STANDARD,
    val modelProfile: GeminiModelProfile = GeminiModelRegistry.currentProfile(),
    val approvedModelIds: Set<String> = emptySet(),
    val approvedEvaluationModelIds: Set<String> = emptySet(),
    val approvedFeedbackModelIds: Set<String> = emptySet(),
    val approvedAuthoringModelIds: Set<String> = emptySet(),
    val academicYear: String = "",
    val isGatewayManaged: Boolean = BuildConfig.AI_GATEWAY_BASE_URL.isNotBlank(),
    val isGatewayEnrolled: Boolean = false,
    val directClientAllowed: Boolean = BuildConfig.ALLOW_DIRECT_GEMINI,
    val productionAiBlocked: Boolean = !BuildConfig.ALLOW_DIRECT_GEMINI && BuildConfig.AI_GATEWAY_BASE_URL.isBlank()
)

class ApiKeySettingsViewModel(
    private val secureApiKeyStore: SecureApiKeyStore,
    private val storedApiKeyConnectionChecker: StoredApiKeyConnectionChecker? = null,
    private val modelQualityPreferenceStore: ModelQualityPreferenceStore? = null,
    private val geminiModelProfileStore: GeminiModelProfileStore? = null,
    private val yazekComplianceStore: YazekComplianceStore? = null,
    private val gatewaySessionManager: GatewaySessionManager? = null,
    private val geminiBatchJobManager: GeminiBatchJobManager? = null,
    private val geminiCacheManager: GeminiCacheManager? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(ApiKeySettingsUiState())
    val uiState: StateFlow<ApiKeySettingsUiState> = _uiState.asStateFlow()

    init {
        checkApiKeyStatus()
        checkGatewayEnrollmentStatus()
        geminiModelProfileStore?.let { store ->
            _uiState.update {
                it.copy(
                    modelProfile = store.loadAndApply(),
                    approvedModelIds = store.approvedModelIds(),
                    approvedEvaluationModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.EVALUATION),
                    approvedFeedbackModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.FEEDBACK),
                    approvedAuthoringModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.AUTHORING)
                )
            }
        }
        yazekComplianceStore?.let { store ->
            _uiState.update { it.copy(academicYear = store.currentAcademicYear()) }
        }
        modelQualityPreferenceStore?.let { store ->
            viewModelScope.launch {
                store.selectedTier.collectLatest { tier ->
                    _uiState.update { it.copy(selectedModelQualityTier = tier) }
                }
            }
        }
    }

    private fun checkApiKeyStatus() {
        viewModelScope.launch {
            val hasKey = secureApiKeyStore.hasApiKey()
            _uiState.update { it.copy(hasApiKey = hasKey, isLoading = false) }
        }
    }


    private fun checkGatewayEnrollmentStatus() {
        val manager = gatewaySessionManager ?: return
        viewModelScope.launch {
            val enrolled = runCatching { manager.isEnrolled() }.getOrDefault(false)
            _uiState.update { it.copy(isGatewayEnrolled = enrolled) }
        }
    }

    fun enrollGateway(enrollmentToken: String) {
        val manager = gatewaySessionManager
        if (!_uiState.value.isGatewayManaged || manager == null) {
            _uiState.update { it.copy(errorMessage = "Gateway oturum yöneticisi yapılandırılmamış.", successMessage = null) }
            return
        }
        val value = enrollmentToken.trim()
        if (value.length < 16) {
            _uiState.update { it.copy(errorMessage = "Kurumsal eşleştirme kodu geçersiz.", successMessage = null) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, errorMessage = null, successMessage = null) }
            val enrollmentResult = runCatching { manager.enroll(value) }
            if (enrollmentResult.isSuccess) {
                data class EnrollmentCleanupSummary(val confirmed: Int, val pending: Int)
                val cleanup = runCatching {
                    secureApiKeyStore.useApiKey { credential ->
                        val batch = geminiBatchJobManager?.retryPendingRemoteCleanup(credential)
                        val cache = geminiCacheManager?.retryPendingRemoteCleanup(credential)
                        EnrollmentCleanupSummary(
                            confirmed = (batch?.confirmedRemoteDeleted ?: 0) + (cache?.confirmedRemoteDeleted ?: 0),
                            pending = (batch?.pendingRemoteDeletion ?: 0) + (cache?.pendingRemoteDeletion ?: 0)
                        )
                    }
                }.getOrNull()
                val cleanupSuffix = cleanup?.let { result ->
                    if (result.pending > 0) {
                        " ${result.pending} uzak veri silme kaydı sonraki bağlantıda yeniden denenecek."
                    } else if (result.confirmed > 0) {
                        " ${result.confirmed} bekleyen uzak veri kaydı da doğrulanarak temizlendi."
                    } else ""
                }.orEmpty()
                _uiState.update {
                    it.copy(
                        isGatewayEnrolled = true,
                        isTestingConnection = false,
                        successMessage = "Kurumsal gateway eşleştirildi ve kısa ömürlü oturum doğrulandı.$cleanupSuffix",
                        errorMessage = null
                    )
                }
            } else {
                val error = enrollmentResult.exceptionOrNull()
                _uiState.update {
                    it.copy(
                        isGatewayEnrolled = false,
                        isTestingConnection = false,
                        errorMessage = error?.message ?: "Gateway eşleştirmesi doğrulanamadı.",
                        successMessage = null
                    )
                }
            }
        }
    }

    fun clearGatewayEnrollment() {
        val manager = gatewaySessionManager ?: return
        viewModelScope.launch {
            val result = runCatching { manager.clearEnrollment() }
            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        isGatewayEnrolled = false,
                        successMessage = "Gateway eşleştirmesi cihazdan kaldırıldı.",
                        errorMessage = null
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        errorMessage = result.exceptionOrNull()?.message
                            ?: "Gateway eşleştirmesi cihazdan kaldırılamadı.",
                        successMessage = null
                    )
                }
            }
        }
    }

    fun selectModelQualityTier(tier: ModelQualityTier) {
        _uiState.update {
            it.copy(selectedModelQualityTier = tier)
        }

        val store = modelQualityPreferenceStore ?: return

        viewModelScope.launch {
            store.setSelectedTier(tier)
        }
    }

    fun saveApiKey(apiKey: String) {
        if (!_uiState.value.directClientAllowed) {
            _uiState.update { it.copy(errorMessage = "Release sürümünde mobil Gemini API anahtarı saklanamaz. Güvenli AI gateway yapılandırılmalıdır.", successMessage = null) }
            return
        }
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Geçerli bir API anahtarı girin.", successMessage = null) }
            return
        }
        
        if (trimmed.length < 10) {
            _uiState.update { it.copy(errorMessage = "API anahtarı çok kısa. Geçerli bir API anahtarı girin.", successMessage = null) }
            return
        }

        viewModelScope.launch {
            try {
                secureApiKeyStore.saveApiKey(trimmed)
                _uiState.update { 
                    it.copy(
                        hasApiKey = true, 
                        errorMessage = null,
                        successMessage = "API anahtarı güvenli biçimde kaydedildi."
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Anahtar kaydedilemedi.", successMessage = null) }
            }
        }
    }

    fun deleteApiKey() {
        if (!_uiState.value.directClientAllowed) {
            _uiState.update { it.copy(errorMessage = "Gateway yönetimli release sürümünde cihaz anahtarı kullanılmaz.", successMessage = null) }
            return
        }
        viewModelScope.launch {
            try {
                secureApiKeyStore.deleteApiKey()
                _uiState.update { 
                    it.copy(
                        hasApiKey = false,
                        errorMessage = null,
                        successMessage = "API anahtarı silindi."
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Silme işlemi başarısız.", successMessage = null) }
            }
        }
    }

    fun saveModelProfile(
        evaluationModel: String,
        feedbackModel: String,
        authoringModel: String,
        evaluationInputPrice: String,
        evaluationOutputPrice: String,
        evaluationCachedInputPrice: String,
        cacheStoragePrice: String,
        feedbackInputPrice: String,
        feedbackOutputPrice: String,
        authoringInputPrice: String,
        authoringOutputPrice: String,
        authoringCachedInputPrice: String,
        batchFactor: String,
        highImageTokens: String,
        supportsHighMediaResolution: Boolean,
        supportsBatch: Boolean,
        supportsPromptCaching: Boolean,
        supportsThinkingLevel: Boolean
    ) {
        val store = geminiModelProfileStore ?: return
        val current = _uiState.value.modelProfile
        val profile = current.copy(
            evaluationModel = evaluationModel.trim(),
            feedbackModel = feedbackModel.trim(),
            authoringModel = authoringModel.trim(),
            evaluationInputPerMillionUsd = evaluationInputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            evaluationOutputPerMillionUsd = evaluationOutputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            evaluationCachedInputPerMillionUsd = evaluationCachedInputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            cacheStoragePerMillionTokenHourUsd = cacheStoragePrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            feedbackInputPerMillionUsd = feedbackInputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            feedbackOutputPerMillionUsd = feedbackOutputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            authoringInputPerMillionUsd = authoringInputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            authoringOutputPerMillionUsd = authoringOutputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            authoringCachedInputPerMillionUsd = authoringCachedInputPrice.replace(',', '.').toDoubleOrNull() ?: -1.0,
            batchPriceFactor = batchFactor.replace(',', '.').toDoubleOrNull() ?: -1.0,
            highImageTokens = highImageTokens.toIntOrNull() ?: -1,
            supportsHighMediaResolution = supportsHighMediaResolution,
            supportsBatch = supportsBatch,
            supportsPromptCaching = supportsPromptCaching,
            supportsThinkingLevel = supportsThinkingLevel,
            updatedAt = System.currentTimeMillis()
        )
        if (!GeminiModelRegistry.isStableExplicitModelId(profile.evaluationModel) ||
            !GeminiModelRegistry.isStableExplicitModelId(profile.feedbackModel) ||
            !GeminiModelRegistry.isStableExplicitModelId(profile.authoringModel)
        ) {
            _uiState.update { it.copy(errorMessage = "Model kimlikleri boş olamaz ve '*-latest' kullanılamaz.", successMessage = null) }
            return
        }
        if (listOf(profile.evaluationInputPerMillionUsd, profile.evaluationOutputPerMillionUsd, profile.evaluationCachedInputPerMillionUsd, profile.cacheStoragePerMillionTokenHourUsd, profile.feedbackInputPerMillionUsd, profile.feedbackOutputPerMillionUsd, profile.authoringInputPerMillionUsd, profile.authoringOutputPerMillionUsd, profile.authoringCachedInputPerMillionUsd).any { it < 0.0 } || profile.batchPriceFactor !in 0.05..1.0 || profile.highImageTokens !in 128..16384) {
            _uiState.update { it.copy(errorMessage = "Fiyatları geçerli sayılarla, Batch katsayısını 0,05–1,00 ve HIGH görsel token bütçesini 128–16384 arasında girin.", successMessage = null) }
            return
        }
        val result = store.saveAndApply(profile)
        if (result.isSuccess) {
            _uiState.update {
                it.copy(
                    modelProfile = result.getOrThrow(),
                    approvedModelIds = store.approvedModelIds(),
                    approvedEvaluationModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.EVALUATION),
                    approvedFeedbackModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.FEEDBACK),
                    approvedAuthoringModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.AUTHORING),
                    errorMessage = null,
                    successMessage = "Model profili kaydedildi. Yeni sınavlar bu profili kullanacak; başlamış sınavların kilitli modeli değişmez."
                )
            }
        } else {
            _uiState.update { it.copy(errorMessage = "Model profili kaydedilemedi: ${result.exceptionOrNull()?.message.orEmpty()}", successMessage = null) }
        }
    }


    fun approveBenchmarkedModel(modelId: String, approvalCode: String) {
        val store = geminiModelProfileStore ?: return
        val result = store.approveModelFromBenchmark(modelId, approvalCode)
        if (result.isSuccess) {
            _uiState.update {
                it.copy(
                    approvedModelIds = store.approvedModelIds(),
                    approvedEvaluationModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.EVALUATION),
                    approvedFeedbackModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.FEEDBACK),
                    approvedAuthoringModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.AUTHORING),
                    errorMessage = null,
                    successMessage = "İmzalı BNBENCH4 onayı doğrulandı: ${modelId.trim()}"
                )
            }
        } else {
            _uiState.update { it.copy(errorMessage = "Model onaylanamadı: ${result.exceptionOrNull()?.message.orEmpty()}", successMessage = null) }
        }
    }

    fun setPreferBatchEvaluation(enabled: Boolean) {
        val store = geminiModelProfileStore ?: return
        val result = store.saveAndApply(_uiState.value.modelProfile.copy(preferBatchEvaluation = enabled, updatedAt = System.currentTimeMillis()))
        if (result.isSuccess) {
            _uiState.update { it.copy(modelProfile = result.getOrThrow(), errorMessage = null, successMessage = if (enabled) "Ekonomik toplu değerlendirme etkin. Normal öğretmen akışı değişmez." else "Hızlı standart değerlendirme etkin.") }
        } else {
            _uiState.update { it.copy(errorMessage = "Değerlendirme modu kaydedilemedi.", successMessage = null) }
        }
    }

    fun restoreDefaultModelProfile() {
        val store = geminiModelProfileStore ?: return
        val profile = store.restoreDefaults()
        _uiState.update {
            it.copy(
                modelProfile = profile,
                approvedModelIds = store.approvedModelIds(),
                approvedEvaluationModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.EVALUATION),
                approvedFeedbackModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.FEEDBACK),
                approvedAuthoringModelIds = store.approvedModelIds(GeminiModelProfileStore.BenchmarkRole.AUTHORING),
                errorMessage = null,
                successMessage = "Varsayılan BaykuşNot model profili geri yüklendi. Üretim onayları imzalı release manifestinden doğrulanır."
            )
        }
    }

    fun buildAiDeploymentTransparencyNote(): String {
        val p = _uiState.value.modelProfile
        return """
            TEKNİK AI DAĞITIM / ŞEFFAFLIK NOTU
            Bu metin resmî YAZEK Etik Beyan Formu değildir ve form alanlarının yerine geçmez. Sınava özel YAZEK beyan bilgileri, gerçek öğrenci verisi AI değerlendirmesine gönderilmeden önce AI Değerlendirmesi ekranındaki “YAZEK Beyan Bilgilerini Kopyala” bölümünden alınır.

            BaykuşNot, öğretmenin yazılı/ödev değerlendirmesini destekleyen bir yapay zekâ aracıdır. Üretim sürümünde Gemini kimlik bilgisi mobil uygulamada tutulmaz; güvenli sunucu/gateway üzerinden yönetilir.
            Yapay zekâ rolleri ayrı tutulur. Ana değerlendirme modeli: ${p.evaluationModel}. Nihai öğrenci dönütü modeli: ${p.feedbackModel}. Soru çıkarma, rubrik hazırlama/denetleme, senaryo-kazanım çıkarma ve kazanım eşleme hazırlık modeli: ${p.authoringModel}. Her rol için gerçek kullanım model/yanıt/token/maliyet audit kaydına bağlanır. Gerçek öğrenci verisi yalnız gerekli öğrenci/veli veri bilgilendirme ve açık rıza/aydınlatılmış onam süreci tamamlandıktan ve faturalandırılmış/kurumsal, veri koşulları uygun Gemini projesi doğrulandıktan sonra işlenir.
            BaykuşNot tarafından oluşturulan cevap kâğıtlarında ad-soyad, okul numarası, sınıf/şube ve QR kimlik başlığı yapay zekâya gönderilmeden önce cihaz üzerinde çıkarılır. İlk değerlendirmede anonimleştirilmiş cevap sayfalarının bütünlüğü korunur; yalnız düşük güvenli sorular gerektiğinde ilgili cevap alanı yakın plan ikinci okumaya gönderilir.
            Yapay zekâ puanı nihai not değildir. Öğretmen tüm sonuçları inceleyebilir, değiştirebilir ve onaylar. Ayrıntılı öğrenci dönütü öğretmenin onayladığı nihai puanlardan sonra hazırlanır. Resmî/güncel not öğretmenin ve e-Okul'un kaydıdır.
            Basılı dönüt raporu öğrencinin bilgilendirilmesi ve öğretmen dosyası için kullanılabilir; orijinal fiziksel cevap kâğıdı öğretmen/kurum arşivinde tutulabilir. Gereksiz dijital cevap görüntüleri raporlama sonrasında cihazdan silinebilir.
        """.trimIndent()
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    fun testConnection() {
        if (_uiState.value.isTestingConnection) return

        val checker = storedApiKeyConnectionChecker
        if (checker == null) {
            _uiState.update {
                it.copy(
                    isTestingConnection = false,
                    connectionTestMessage = "Bağlantı testi kullanılamıyor.",
                    isConnectionTestSuccessful = false
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isTestingConnection = true,
                    connectionTestMessage = null,
                    isConnectionTestSuccessful = null
                )
            }

            val result = try {
                checker.testStoredApiKey()
            } catch (e: Exception) {
                ConnectionTestResult.UnexpectedError
            }

            val message = when (result) {
                ConnectionTestResult.Success ->
                    "Gemini bağlantısı başarılı."

                ConnectionTestResult.InvalidApiKey ->
                    "API anahtarı geçersiz veya yetkisiz."

                ConnectionTestResult.RateLimited ->
                    "Gemini kullanım sınırına ulaşıldı. Daha sonra tekrar deneyin."

                ConnectionTestResult.NoInternet ->
                    "İnternet bağlantısı bulunamadı."

                ConnectionTestResult.ServiceUnavailable ->
                    "Gemini hizmetine şu anda ulaşılamıyor."

                ConnectionTestResult.UnexpectedError ->
                    "Bağlantı testi sırasında beklenmeyen bir sorun oluştu."

                null ->
                    "Kayıtlı API anahtarı bulunamadı."
            }

            _uiState.update {
                it.copy(
                    isTestingConnection = false,
                    connectionTestMessage = message,
                    isConnectionTestSuccessful = result == ConnectionTestResult.Success
                )
            }
        }
    }

    class Factory(
        private val secureApiKeyStore: SecureApiKeyStore,
        private val storedApiKeyConnectionChecker: StoredApiKeyConnectionChecker? = null,
        private val modelQualityPreferenceStore: ModelQualityPreferenceStore? = null,
        private val geminiModelProfileStore: GeminiModelProfileStore? = null,
        private val yazekComplianceStore: YazekComplianceStore? = null,
        private val gatewaySessionManager: GatewaySessionManager? = null,
        private val geminiBatchJobManager: GeminiBatchJobManager? = null,
        private val geminiCacheManager: GeminiCacheManager? = null
    ) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ApiKeySettingsViewModel::class.java)) {
                return ApiKeySettingsViewModel(
                    secureApiKeyStore = secureApiKeyStore,
                    storedApiKeyConnectionChecker = storedApiKeyConnectionChecker,
                    modelQualityPreferenceStore = modelQualityPreferenceStore,
                    geminiModelProfileStore = geminiModelProfileStore,
                    yazekComplianceStore = yazekComplianceStore,
                    gatewaySessionManager = gatewaySessionManager,
                    geminiBatchJobManager = geminiBatchJobManager,
                    geminiCacheManager = geminiCacheManager
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
