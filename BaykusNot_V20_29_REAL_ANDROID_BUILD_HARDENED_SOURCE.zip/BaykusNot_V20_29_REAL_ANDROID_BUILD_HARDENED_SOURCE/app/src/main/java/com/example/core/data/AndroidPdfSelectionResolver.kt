package com.example.core.data

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns

interface PdfSelectionResolver {
    fun resolve(uri: Uri): SelectedPdfSource
    fun takePersistableReadPermission(uri: Uri): Boolean
}

class AndroidPdfSelectionResolver(
    private val contentResolver: ContentResolver
) : PdfSelectionResolver {

    override fun resolve(uri: Uri): SelectedPdfSource {
        var resolvedDisplayName: String? = null
        var resolvedSize: Long? = null

        try {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        resolvedDisplayName = cursor.getString(nameIndex)
                    }

                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                        val size = cursor.getLong(sizeIndex)
                        if (size >= 0) {
                            resolvedSize = size
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // query exception handled implicitly by falling back
        }

        val finalDisplayName = if (!resolvedDisplayName.isNullOrBlank()) {
            resolvedDisplayName!!
        } else {
            "Sınav.pdf"
        }

        val resolvedMimeType = try {
            contentResolver.getType(uri)
        } catch (e: Exception) {
            null
        }

        val finalMimeType = if (!resolvedMimeType.isNullOrBlank()) {
            resolvedMimeType!!
        } else {
            ExamSourceDocumentRepository.PDF_MIME_TYPE
        }

        return SelectedPdfSource(
            originalUri = uri.toString(),
            displayName = finalDisplayName,
            mimeType = finalMimeType,
            declaredSizeBytes = resolvedSize,
            openInputStream = {
                contentResolver.openInputStream(uri)
            }
        )
    }

    override fun takePersistableReadPermission(uri: Uri): Boolean {
        return try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            true
        } catch (e: SecurityException) {
            false
        } catch (e: IllegalArgumentException) {
            false
        } catch (e: UnsupportedOperationException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
