package com.example.core.data

import com.example.core.database.ExamObjectiveDao
import com.example.core.database.ExamObjectiveEntity
import com.example.core.database.QuestionObjectiveCrossRef
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ExamObjectiveRepository(
    private val objectiveDao: ExamObjectiveDao
) {

    suspend fun replaceStagingObjectivesForDraft(draftId: Long, objectives: List<ExamObjectiveEntity>) = withContext(Dispatchers.IO) {
        objectiveDao.replaceStagingObjectivesForDraft(draftId, objectives)
    }

    suspend fun approveStagingObjectivesAndDraft(draftId: Long) = withContext(Dispatchers.IO) {
        objectiveDao.approveStagingObjectivesAndDraft(draftId)
    }

    suspend fun approveStagingObjectives(draftId: Long) = withContext(Dispatchers.IO) {
        objectiveDao.deleteApprovedObjectivesByDraftId(draftId)
        objectiveDao.approveStagingObjectives(draftId)
    }

    fun observeApprovedObjectivesByDraftId(draftId: Long): Flow<List<ExamObjectiveEntity>> {
        return objectiveDao.observeApprovedObjectivesByDraftId(draftId)
    }

    fun observeStagingObjectivesByDraftId(draftId: Long): Flow<List<ExamObjectiveEntity>> {
        return objectiveDao.observeStagingObjectivesByDraftId(draftId)
    }

    suspend fun getApprovedObjectivesByDraftId(draftId: Long): List<ExamObjectiveEntity> = withContext(Dispatchers.IO) {
        return@withContext objectiveDao.getApprovedObjectivesByDraftId(draftId)
    }

    suspend fun getStagingObjectivesByDraftId(draftId: Long): List<ExamObjectiveEntity> = withContext(Dispatchers.IO) {
        return@withContext objectiveDao.getStagingObjectivesByDraftId(draftId)
    }

    suspend fun replaceObjectivesForDraft(draftId: Long, objectives: List<ExamObjectiveEntity>) = withContext(Dispatchers.IO) {
        objectiveDao.replaceObjectivesForDraft(draftId, objectives)
    }
    
    fun observeObjectivesByDraftId(draftId: Long): Flow<List<ExamObjectiveEntity>> {
        return objectiveDao.observeObjectivesByDraftId(draftId)
    }

    suspend fun getObjectivesByDraftId(draftId: Long): List<ExamObjectiveEntity> = withContext(Dispatchers.IO) {
        return@withContext objectiveDao.getObjectivesByDraftId(draftId)
    }
    
    suspend fun invalidateQuestionObjectiveMappingApproval(draftId: Long, updatedAt: Long = System.currentTimeMillis()): Boolean = withContext(Dispatchers.IO) {
        objectiveDao.invalidateQuestionObjectiveMappingApproval(draftId, updatedAt) == 1
    }

    suspend fun replaceQuestionObjectiveCrossRefsForDraft(
        draftId: Long,
        refs: List<QuestionObjectiveCrossRef>,
        updatedAt: Long = System.currentTimeMillis()
    ) = withContext(Dispatchers.IO) {
        objectiveDao.replaceQuestionObjectiveCrossRefsForDraft(draftId, refs, updatedAt)
    }
    
    fun observeQuestionObjectiveCrossRefsByDraftId(draftId: Long): Flow<List<QuestionObjectiveCrossRef>> {
        return objectiveDao.observeQuestionObjectiveCrossRefsByDraftId(draftId)
    }

    suspend fun getQuestionObjectiveCrossRefsByDraftId(draftId: Long): List<QuestionObjectiveCrossRef> = withContext(Dispatchers.IO) {
        return@withContext objectiveDao.getQuestionObjectiveCrossRefsByDraftId(draftId)
    }

    suspend fun getQuestionObjectiveCrossRefsByDraftIdOnce(draftId: Long): List<QuestionObjectiveCrossRef> = withContext(Dispatchers.IO) {
        return@withContext objectiveDao.getQuestionObjectiveCrossRefsByDraftId(draftId)
    }
}