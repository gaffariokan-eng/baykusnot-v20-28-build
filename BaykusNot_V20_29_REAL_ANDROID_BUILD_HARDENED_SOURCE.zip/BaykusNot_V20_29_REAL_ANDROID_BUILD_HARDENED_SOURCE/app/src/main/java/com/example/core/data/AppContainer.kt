package com.example.core.data

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.preferencesDataStoreFile
import com.example.core.database.AppDatabase
import com.example.core.model.DataStoreModelQualityPreferenceStore
import com.example.core.model.ModelQualityPreferenceStore
import com.example.core.network.ExamEvaluator
import com.example.core.network.HttpGeminiExamEvaluator
import com.example.core.network.GeminiConnectionTester
import com.example.core.network.ExamQuestionExtractor
import com.example.core.network.ExamRubricGenerator
import com.example.core.network.HttpGeminiConnectionTester
import com.example.core.network.HttpGeminiExamQuestionExtractor
import com.example.core.network.HttpGeminiExamRubricGenerator
import com.example.core.network.HttpGeminiStudentFeedbackWriter
import com.example.core.network.GeminiModelProfileStore
import com.example.core.network.StoredApiKeyConnectionChecker
import com.example.core.security.EncryptedApiKeyStore
import com.example.core.security.SecureApiKeyStore
import com.example.core.security.GatewayAwareApiKeyStore
import com.example.core.security.GatewayAuthTokenStore
import com.example.core.security.GatewayEnrollmentStore
import com.example.core.network.GatewaySessionManager
import com.example.core.security.YazekComplianceStore
import com.example.core.security.StudentAiComplianceGate
import com.example.core.security.HomeworkPrivacyMaskStore
import okhttp3.OkHttpClient
import com.example.core.network.GeminiProductionSecurityInterceptor
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(private val context: Context) {
    private val maintenanceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val yazekComplianceStore: YazekComplianceStore = YazekComplianceStore(context)
    val studentAiComplianceGate: StudentAiComplianceGate = StudentAiComplianceGate(yazekComplianceStore)
    val homeworkPrivacyMaskStore: HomeworkPrivacyMaskStore = HomeworkPrivacyMaskStore(context)
    val evaluationPauseGuard: EvaluationPauseGuard = EvaluationPauseGuard(context)
    val geminiModelProfileStore: GeminiModelProfileStore = GeminiModelProfileStore(context).also { it.loadAndApply() }

    private val database: AppDatabase by lazy { AppDatabase.getDatabase(context) }
    
    val examEvaluationDao by lazy { database.examEvaluationDao() }
    val aiUsageLedger by lazy { com.example.core.network.AiUsageLedger(examEvaluationDao) }
    val examObjectiveDao by lazy { database.examObjectiveDao() }
    val examPaperUploadDao by lazy { database.examPaperUploadDao() }
    val examQuestionDao by lazy { database.examQuestionDao() }
    val examEvaluationPreferencesDao by lazy { database.examEvaluationPreferencesDao() }
    
    val teacherProfileRepository: TeacherProfileRepository by lazy {
        TeacherProfileRepository(database.teacherProfileDao())
    }
    
    val examDraftRepository: ExamDraftRepository by lazy {
        ExamDraftRepository(database.examDraftDao())
    }

    val examDeletionRepository: ExamDeletionRepository by lazy {
        ExamDeletionRepository(
            context = context,
            draftRepository = examDraftRepository,
            paperUploadDao = database.examPaperUploadDao(),
            homeworkPrivacyMaskStore = homeworkPrivacyMaskStore,
            batchJobManager = geminiBatchJobManager,
            cacheManager = geminiCacheManager,
            apiKeyStore = secureApiKeyStore
        )
    }

    val examListeningMaterialRepository: ExamListeningMaterialRepository by lazy {
        ExamListeningMaterialRepository(
            filesRoot = context.filesDir,
            materialDao = database.examListeningMaterialDao(),
            examDraftDao = database.examDraftDao(),
            questionDao = database.examQuestionDao()
        )
    }


    val questionObjectiveMatcher: com.example.core.network.ExamQuestionObjectiveMatcher by lazy {
        com.example.core.network.HttpGeminiQuestionObjectiveMatcher(
            okHttpClient = okHttpClient.newBuilder()
                .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                .callTimeout(90, java.util.concurrent.TimeUnit.SECONDS)
                .build(),
            apiKeyStore = secureApiKeyStore,
            aiUsageLedger = aiUsageLedger
        )
    }

    val examScenarioExtractor: com.example.core.network.ExamScenarioExtractor by lazy {
        // Senaryo PDF'leri çok sayfalı olabildiği için normal soru çıkarımından daha uzun süre tanı.
        // Kullanıcıdaki gerçek cihaz testinde 90 sn çağrı sınırı zaman aşımına uğradı.
        com.example.core.network.HttpGeminiExamScenarioExtractor(
            okHttpClient.newBuilder()
                .readTimeout(180, TimeUnit.SECONDS)
                .callTimeout(240, TimeUnit.SECONDS)
                .build(),
            secureApiKeyStore,
            aiUsageLedger = aiUsageLedger
        )
    }

    val examObjectiveRepository: ExamObjectiveRepository by lazy {
        ExamObjectiveRepository(examObjectiveDao)
    }



    val examSourceDocumentRepository: ExamSourceDocumentRepository by lazy {
        ExamSourceDocumentRepository(
            filesRoot = context.filesDir,
            sourceDocumentDao = database.examSourceDocumentDao(),
            examDraftDao = database.examDraftDao()
        )
    }

    val examEvaluationPreferencesRepository:
        ExamEvaluationPreferencesRepository by lazy {
            ExamEvaluationPreferencesRepository(
                preferencesDao =
                    database.examEvaluationPreferencesDao(),
                examDraftDao =
                    database.examDraftDao()
            )
        }

    val examQuestionRepository:
        ExamQuestionRepository by lazy {
            ExamQuestionRepository(
                questionDao =
                    database.examQuestionDao(),
                examDraftDao =
                    database.examDraftDao()
            )
        }

    val examQuestionExtractionDraftRepository:
        ExamQuestionExtractionDraftRepository by lazy {
            ExamQuestionExtractionDraftRepository(
                extractionDraftDao =
                    database.examQuestionExtractionDraftDao()
            )
        }

    val examQuestionExtractor: ExamQuestionExtractor by lazy {
        HttpGeminiExamQuestionExtractor(
            okHttpClient = okHttpClient.newBuilder()
                .readTimeout(60, TimeUnit.SECONDS)
                .callTimeout(90, TimeUnit.SECONDS)
                .build(),
            apiKeyStore = secureApiKeyStore,
            aiUsageLedger = aiUsageLedger
        )
    }

    val examQuestionExtractionCoordinator: ExamQuestionExtractionCoordinator by lazy {
        ExamQuestionExtractionCoordinator(
            extractor = examQuestionExtractor,
            draftRepository = examQuestionExtractionDraftRepository,
            questionRepository = examQuestionRepository,
            stageValidator = { id ->
                examDraftRepository.getDraftByIdOnce(id)?.currentWorkflowStage == com.example.core.model.WorkflowStage.UPLOAD_SOURCE
            }
        )
    }

    val examRubricRepository: ExamRubricRepository by lazy {
        ExamRubricRepository(
            rubricDao = database.examRubricDao(),
            questionDao = database.examQuestionDao(),
            examDraftDao = database.examDraftDao(),
            objectiveDao = database.examObjectiveDao(),
            preferencesDao = database.examEvaluationPreferencesDao()
        )
    }

    val examRubricGenerator: ExamRubricGenerator by lazy {
        HttpGeminiExamRubricGenerator(
            okHttpClient = okHttpClient.newBuilder()
                .readTimeout(60, TimeUnit.SECONDS)
                .callTimeout(90, TimeUnit.SECONDS)
                .build(),
            apiKeyStore = secureApiKeyStore,
            aiUsageLedger = aiUsageLedger
        )
    }

    val examRubricGenerationPreflight: ExamRubricGenerationPreflight by lazy {
        ExamRubricGenerationPreflight(
            questionRepository = examQuestionRepository,
            rubricRepository = examRubricRepository,
            preferencesRepository = examEvaluationPreferencesRepository,
            draftRepository = examDraftRepository,
            listeningMaterialRepository = examListeningMaterialRepository,
            sourceDocumentRepository = examSourceDocumentRepository
        )
    }

    val examRubricGenerationInvoker: ExamRubricGenerationInvoker by lazy {
        ExamRubricGenerationInvoker(
            generator = examRubricGenerator
        )
    }

    val examRubricGenerationPersistenceStage: ExamRubricGenerationPersistenceStage by lazy {
        ExamRubricGenerationPersistenceStage(
            repository = examRubricRepository
        )
    }

    val examRubricGenerationCoordinator: ExamRubricGenerationCoordinator by lazy {
        ExamRubricGenerationCoordinator(
            preflight = examRubricGenerationPreflight,
            invoker = examRubricGenerationInvoker,
            validationStage = ExamRubricGenerationValidationStage,
            persistenceStage = examRubricGenerationPersistenceStage,
            stageValidator = { id ->
                examDraftRepository.getDraftByIdOnce(id)?.currentWorkflowStage == com.example.core.model.WorkflowStage.RUBRIC
            }
        )
    }

    val examAnswerSheetRepository: ExamAnswerSheetRepository by lazy {
        ExamAnswerSheetRepository(
            configDao = database.examAnswerSheetConfigDao(),
            draftDao = database.examDraftDao(),
            questionDao = database.examQuestionDao(),
            rubricDao = database.examRubricDao(),
            paperUploadDao = database.examPaperUploadDao(),
            context = context,
            listeningMaterialDao = database.examListeningMaterialDao()
        )
    }

    val examPaperUploadRepository: ExamPaperUploadRepository by lazy {
        ExamPaperUploadRepository(
            paperUploadDao = database.examPaperUploadDao(),
            configDao = database.examAnswerSheetConfigDao(),
            questionDao = database.examQuestionDao(),
            rubricDao = database.examRubricDao(),
            context = context,
            answerSheetRepository = examAnswerSheetRepository
        )
    }

    val geminiCacheManager: com.example.core.network.GeminiCacheManager by lazy {
        com.example.core.network.GeminiCacheManager(
            context = context,
            okHttpClient = okHttpClient
        )
    }

    val geminiBatchJobManager: com.example.core.network.GeminiBatchJobManager by lazy {
        com.example.core.network.GeminiBatchJobManager(
            context = context,
            okHttpClient = okHttpClient
        )
    }

    val studentFeedbackWriter: HttpGeminiStudentFeedbackWriter by lazy {
        HttpGeminiStudentFeedbackWriter(
            okHttpClient = okHttpClient.newBuilder()
                .readTimeout(90, TimeUnit.SECONDS)
                .callTimeout(120, TimeUnit.SECONDS)
                .build(),
            apiKeyStore = secureApiKeyStore
        )
    }

    val examEvaluator: ExamEvaluator by lazy {
        HttpGeminiExamEvaluator(
            okHttpClient = okHttpClient.newBuilder()
                .readTimeout(90, TimeUnit.SECONDS)
                .callTimeout(120, TimeUnit.SECONDS)
                .build(),
            apiKeyStore = secureApiKeyStore,
            context = context,
            sharedCacheManager = geminiCacheManager
        )
    }

    val examEvaluationRepository: ExamEvaluationRepository by lazy {
        ExamEvaluationRepository(
            evaluationDao = database.examEvaluationDao(),
            paperUploadDao = database.examPaperUploadDao(),
            questionDao = database.examQuestionDao(),
            objectiveDao = database.examObjectiveDao(),
            rubricDao = database.examRubricDao(),
            preferencesDao = database.examEvaluationPreferencesDao(),
            evaluator = examEvaluator,
            apiKeyStore = secureApiKeyStore,
            batchJobManager = geminiBatchJobManager,
            draftDao = database.examDraftDao(),
            paperUploadRepository = examPaperUploadRepository,
            feedbackWriter = studentFeedbackWriter,
            studentAiComplianceGate = studentAiComplianceGate,
            modelProfileStore = geminiModelProfileStore,
            homeworkPrivacyMaskStore = homeworkPrivacyMaskStore,
            evaluationPauseGuard = evaluationPauseGuard
        )
    }

    val secureApiKeyStore: SecureApiKeyStore by lazy {
        GatewayAwareApiKeyStore(
            directStore = EncryptedApiKeyStore(context),
            gatewaySessionManager = gatewaySessionManager
        )
    }

    private val modelQualityDataStore by lazy {
        PreferenceDataStoreFactory.create(
            produceFile = {
                context.preferencesDataStoreFile(
                    "model_quality.preferences_pb"
                )
            }
        )
    }

    val modelQualityPreferenceStore: ModelQualityPreferenceStore by lazy {
        DataStoreModelQualityPreferenceStore(
            dataStore = modelQualityDataStore
        )
    }

    val gatewayAuthTokenStore: GatewayAuthTokenStore by lazy { GatewayAuthTokenStore() }
    val gatewayEnrollmentStore: GatewayEnrollmentStore by lazy { GatewayEnrollmentStore(context) }
    private val gatewayBootstrapClient: OkHttpClient by lazy { OkHttpClient.Builder().build() }
    val gatewaySessionManager: GatewaySessionManager by lazy {
        GatewaySessionManager(
            bootstrapClient = gatewayBootstrapClient,
            enrollmentStore = gatewayEnrollmentStore,
            tokenStore = gatewayAuthTokenStore
        )
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .addInterceptor(GeminiProductionSecurityInterceptor(gatewayAuthTokenStore, gatewaySessionManager))
            .build()
    }

    private val geminiConnectionTester: GeminiConnectionTester by lazy {
        HttpGeminiConnectionTester(okHttpClient)
    }

    val storedApiKeyConnectionChecker: StoredApiKeyConnectionChecker by lazy {
        StoredApiKeyConnectionChecker(
            secureApiKeyStore = secureApiKeyStore,
            connectionTester = geminiConnectionTester
        )
    }

    init {
        // Finish local destructive-deletion intents first; this is independent of network enrollment.
        maintenanceScope.launch { runCatching { examDeletionRepository.retryPendingLocalDeletion() } }
        // Retry privacy-critical remote deletions left pending by a previous offline/crashed run.
        maintenanceScope.launch {
            runCatching {
                secureApiKeyStore.useApiKey { key ->
                    geminiBatchJobManager.retryPendingRemoteCleanup(key)
                    geminiCacheManager.retryPendingRemoteCleanup(key)
                }
            }
        }
    }

}
