package com.example.feature.workflow

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamDeletionRepository
import com.example.core.data.ExamObjectiveRepository
import com.example.core.data.TeacherProfileRepository
import com.example.core.database.ExamDraftEntity
import com.example.core.model.ExamType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class NewDraftViewModel(
    private val draftRepository: ExamDraftRepository,
    private val profileRepository: TeacherProfileRepository,
    private val deletionRepository: ExamDeletionRepository,
    private val objectiveRepository: ExamObjectiveRepository,
    private val examTypeId: String,
    private val draftId: Long
) : ViewModel() {

    private val resolvedExamType: ExamType =
        ExamType.entries.firstOrNull { it.name == examTypeId || it.id == examTypeId } ?: ExamType.WRITTEN

    private val _uiState = MutableStateFlow(NewDraftUiState(examType = resolvedExamType))
    val uiState: StateFlow<NewDraftUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                val profile = profileRepository.getProfileOnce()
                val profileTeachers = profile?.teacherNames.orEmpty()
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()

                if (draftId != 0L) {
                    val draft = draftRepository.getDraftByIdOnce(draftId)
                    if (draft == null) {
                        _uiState.value = _uiState.value.copy(
                            isLoaded = true,
                            loadError = "Bu çalışma artık bulunamıyor veya silinmiş."
                        )
                        return@launch
                    }
                    val draftTeachers = draft.teachers
                        .map { it.trim() }
                        .filter { it.isNotBlank() }
                        .distinct()
                    _uiState.value = NewDraftUiState(
                        isLoaded = true,
                        examType = draft.examType,
                        draftName = draft.draftName,
                        academicYear = draft.academicYear,
                        institutionName = draft.institutionName,
                        courseName = draft.courseName,
                        gradeLevel = draft.gradeLevel,
                        term = draft.term,
                        examSequenceNumber = draft.examSequenceNumber,
                        totalPoints = draft.totalPoints.toString(),
                        selectedTeachers = draftTeachers,
                        availableTeachers = (profileTeachers + draftTeachers).distinct(),
                        examDate = draft.examDate
                    )
                } else {
                    val current = _uiState.value
                    _uiState.value = current.copy(
                        isLoaded = true,
                        academicYear = if (current.academicYear.isBlank()) profile?.academicYear.orEmpty().trim() else current.academicYear,
                        institutionName = if (current.institutionName.isBlank()) profile?.institutionName.orEmpty().trim() else current.institutionName,
                        courseName = if (current.courseName.isBlank()) profile?.defaultCourseName.orEmpty().trim() else current.courseName,
                        availableTeachers = profileTeachers,
                        selectedTeachers = if (current.selectedTeachers.isEmpty()) profileTeachers.take(1) else current.selectedTeachers
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoaded = true,
                    loadError = "Sınav bilgileri yüklenemedi. Lütfen geri dönüp yeniden deneyin."
                )
            }
        }
    }
    
    fun updateField(field: DraftField, value: String) {
        val current = _uiState.value
        _uiState.value = when(field) {
            DraftField.DRAFT_NAME -> current.copy(draftName = value)
            DraftField.ACADEMIC_YEAR -> current.copy(academicYear = value)
            DraftField.INSTITUTION_NAME -> current.copy(institutionName = value)
            DraftField.COURSE_NAME -> current.copy(courseName = value)
            DraftField.GRADE_LEVEL -> current.copy(gradeLevel = value)
            DraftField.TERM -> current.copy(term = value)
            DraftField.EXAM_SEQUENCE -> current.copy(examSequenceNumber = value)
            DraftField.TOTAL_POINTS -> current.copy(totalPoints = value)
            DraftField.EXAM_DATE -> {
                val parsedDate = value.toLongOrNull() ?: current.examDate
                current.copy(examDate = parsedDate)
            }
        }
    }

    fun toggleTeacher(teacherName: String) {
        val current = _uiState.value.selectedTeachers
        val updated = if (current.contains(teacherName)) current - teacherName else current + teacherName
        _uiState.value = _uiState.value.copy(selectedTeachers = updated)
    }

    fun saveDraft(onSuccess: (Long) -> Unit, onError: (String) -> Unit) {
        val state = _uiState.value
        if (state.isSaving || state.isDeleting) return
        if (state.loadError != null) {
            onError(state.loadError)
            return
        }

        val draftName = state.draftName.trim()
        val academicYear = state.academicYear.trim()
        val institutionName = state.institutionName.trim()
        val courseName = state.courseName.trim()
        val gradeLevel = state.gradeLevel.trim()
        val term = state.term.trim()
        val examSequence = state.examSequenceNumber.trim()
        val teachers = state.selectedTeachers.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val points = state.totalPoints.trim().toIntOrNull() ?: 0

        if (draftName.isBlank() || academicYear.isBlank() || institutionName.isBlank() ||
            courseName.isBlank() || gradeLevel.isBlank() || points <= 0) {
            onError("Taslak adı, eğitim-öğretim yılı, kurum, ders, sınıf ve toplam puan alanlarını geçerli biçimde doldurun.")
            return
        }
        if (teachers.isEmpty()) {
            onError("En az bir öğretmen seçin. Öğretmen listesi boşsa önce Profil ekranından öğretmen bilgisini ekleyin.")
            return
        }

        _uiState.value = state.copy(isSaving = true)
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                if (draftId != 0L) {
                    val existing = draftRepository.getDraftByIdOnce(draftId)
                    if (existing == null) {
                        onError("Bu çalışma artık bulunamıyor veya silinmiş.")
                        return@launch
                    }
                    val scopeChanged = existing.courseName.trim() != courseName ||
                        existing.gradeLevel.trim() != gradeLevel ||
                        existing.term.trim() != term ||
                        existing.examSequenceNumber.trim() != examSequence

                    if (scopeChanged) {
                        // Fail closed: eski senaryo/kazanım ve soru-kazanım bağları yeni kapsama taşınamaz.
                        objectiveRepository.replaceQuestionObjectiveCrossRefsForDraft(draftId, emptyList())
                        objectiveRepository.replaceStagingObjectivesForDraft(draftId, emptyList())
                        objectiveRepository.replaceObjectivesForDraft(draftId, emptyList())
                    }

                    val updated = existing.copy(
                        academicYear = academicYear,
                        institutionName = institutionName,
                        courseName = courseName,
                        teachers = teachers,
                        gradeLevel = gradeLevel,
                        term = term,
                        examSequenceNumber = examSequence,
                        totalPoints = points,
                        draftName = draftName,
                        examDate = state.examDate,
                        hasScenario = if (scopeChanged) false else existing.hasScenario,
                        isScenarioApproved = if (scopeChanged) false else existing.isScenarioApproved,
                        isObjectiveMappingApproved = if (scopeChanged) false else existing.isObjectiveMappingApproved,
                        isMismatchAccepted = if (scopeChanged) false else existing.isMismatchAccepted,
                        stagingCourseName = if (scopeChanged) null else existing.stagingCourseName,
                        stagingGradeLevel = if (scopeChanged) null else existing.stagingGradeLevel,
                        stagingTerm = if (scopeChanged) null else existing.stagingTerm,
                        stagingExamSequenceNumber = if (scopeChanged) null else existing.stagingExamSequenceNumber,
                        approvedCourseName = if (scopeChanged) null else existing.approvedCourseName,
                        approvedGradeLevel = if (scopeChanged) null else existing.approvedGradeLevel,
                        approvedTerm = if (scopeChanged) null else existing.approvedTerm,
                        approvedExamSequenceNumber = if (scopeChanged) null else existing.approvedExamSequenceNumber,
                        updatedAt = now
                    )
                    draftRepository.updateDraft(updated)
                    onSuccess(draftId)
                } else {
                    val entity = ExamDraftEntity(
                        id = 0L,
                        examType = state.examType,
                        academicYear = academicYear,
                        institutionName = institutionName,
                        courseName = courseName,
                        teachers = teachers,
                        gradeLevel = gradeLevel,
                        term = term,
                        examSequenceNumber = examSequence,
                        examDate = state.examDate,
                        totalPoints = points,
                        draftName = draftName,
                        updatedAt = now
                    )
                    val newId = draftRepository.insertDraft(entity)
                    onSuccess(newId)
                }
            } catch (e: Exception) {
                onError("Bu çalışma kaydedilemedi. Veriler değiştirilmedi; lütfen tekrar deneyin.")
            } finally {
                _uiState.value = _uiState.value.copy(isSaving = false)
            }
        }
    }
    
    fun deleteDraft(onDeleted: (String?) -> Unit, onError: (String) -> Unit) {
        if (draftId == 0L) return
        val state = _uiState.value
        if (state.isSaving || state.isDeleting) return
        _uiState.value = state.copy(isDeleting = true)
        viewModelScope.launch {
            try {
                val result = deletionRepository.deleteExamCompletely(draftId)
                result.onSuccess { summary ->
                    onDeleted(summary.userNoticeOrNull())
                }.onFailure {
                    onError("Çalışmanın tüm verileri silinemedi. İşlem tamamlanmadı.")
                }
            } catch (e: Exception) {
                onError("Silme işlemi başarısız oldu.")
            } finally {
                _uiState.value = _uiState.value.copy(isDeleting = false)
            }
        }
    }

    class Factory(
        private val draftRepository: ExamDraftRepository,
        private val profileRepository: TeacherProfileRepository,
        private val deletionRepository: ExamDeletionRepository,
        private val objectiveRepository: ExamObjectiveRepository,
        private val examTypeId: String,
        private val draftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NewDraftViewModel(draftRepository, profileRepository, deletionRepository, objectiveRepository, examTypeId, draftId) as T
        }
    }
}

data class NewDraftUiState(
    val isLoaded: Boolean = false,
    val isSaving: Boolean = false,
    val isDeleting: Boolean = false,
    val loadError: String? = null,
    val examType: ExamType = ExamType.WRITTEN,
    val draftName: String = "",
    val academicYear: String = "",
    val institutionName: String = "",
    val courseName: String = "",
    val gradeLevel: String = "",
    val term: String = "",
    val examSequenceNumber: String = "",
    val totalPoints: String = "100",
    val selectedTeachers: List<String> = emptyList(),
    val availableTeachers: List<String> = emptyList(),
    val examDate: Long = System.currentTimeMillis()
)

enum class DraftField {
    DRAFT_NAME, ACADEMIC_YEAR, INSTITUTION_NAME, COURSE_NAME, GRADE_LEVEL, TERM, EXAM_SEQUENCE, TOTAL_POINTS, EXAM_DATE
}
