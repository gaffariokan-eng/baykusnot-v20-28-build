package com.example.feature.workflow

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamRubricGenerationCoordinator
import com.example.core.data.ExamRubricRepository
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.network.ExamRubricGenerator

@Composable
internal fun RubricRoute(
    draftId: Long,
    examRubricRepository: ExamRubricRepository,
    examQuestionRepository: ExamQuestionRepository,
    examDraftRepository: ExamDraftRepository,
    preferencesRepository: ExamEvaluationPreferencesRepository,
    examListeningMaterialRepository: ExamListeningMaterialRepository? = null,
    rubricGenerationCoordinator: ExamRubricGenerationCoordinator? = null,
    examRubricGenerator: ExamRubricGenerator? = null,
    modifier: Modifier = Modifier,
    onContinue: () -> Unit = {}
) {
    val factory = RubricViewModel.Factory(
        draftId = draftId,
        examRubricRepository = examRubricRepository,
        examQuestionRepository = examQuestionRepository,
        examDraftRepository = examDraftRepository,
        preferencesRepository = preferencesRepository,
        examListeningMaterialRepository = examListeningMaterialRepository,
        rubricGenerationCoordinator = rubricGenerationCoordinator,
        examRubricGenerator = examRubricGenerator
    )

    val viewModel: RubricViewModel = viewModel(
        key = "rubric_$draftId",
        factory = factory
    )

    RubricRoute(
        viewModel = viewModel,
        modifier = modifier,
        onContinue = onContinue
    )
}

@Composable
internal fun RubricRoute(
    viewModel: RubricViewModel,
    modifier: Modifier = Modifier,
    onContinue: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    DisposableEffect(viewModel) {
        onDispose { viewModel.cancelActiveAuthoringWork() }
    }
    val context = LocalContext.current
    val saveRubricPdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) viewModel.savePdfToUri(context, uri)
    }

    var activeUploadTarget by remember { mutableStateOf<String?>(null) }
    var saveAndAdvanceRequested by remember { mutableStateOf(false) }

    LaunchedEffect(saveAndAdvanceRequested, uiState.isSaving, uiState.isLocking, uiState.isLocked, uiState.hasUnsavedChanges, uiState.canLock) {
        if (!saveAndAdvanceRequested || uiState.isSaving || uiState.isLocking) return@LaunchedEffect
        when {
            uiState.isLocked -> { saveAndAdvanceRequested = false; onContinue() }
            uiState.hasUnsavedChanges && uiState.canSave -> viewModel.saveRubric()
            uiState.canLock -> viewModel.lockRubricSet()
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val target = activeUploadTarget ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            try {
                val contentResolver = context.contentResolver
                var fileName = "document"
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            fileName = cursor.getString(nameIndex)
                        }
                    }
                }
                val mimeType = contentResolver.getType(uri) ?: "*/*"
                val inputStream = contentResolver.openInputStream(uri)
                val bytes = inputStream?.use { com.example.core.security.BoundedInputReader.read(it, com.example.core.security.BoundedInputReader.MAX_DOCUMENT_BYTES, "Rubrik/cevap anahtarı belgesi") } ?: ByteArray(0)

                if (bytes.isNotEmpty()) {
                    viewModel.processUploadedDocument(
                        targetType = target,
                        fileName = fileName,
                        mimeType = mimeType,
                        bytes = bytes
                    )
                }
            } catch (e: Exception) {
                viewModel.reportDocumentSelectionError(e.message ?: "Dosya güvenli biçimde okunamadı.")
            }
        }
    }

    LaunchedEffect(uiState.isLocked) {
        if (uiState.isLocked) {
            viewModel.checkTeacherRubricPdfStatus(context)
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(uiState.saveSuccessMessage) {
        uiState.saveSuccessMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSaveSuccessMessage()
        }
    }

    RubricScreen(
        uiState = uiState,
        modifier = modifier,
        onCriterionTitleChange = viewModel::updateCriterionTitle,
        onCriterionDescriptionChange = viewModel::updateCriterionDescription,
        onCriterionMaxPointsChange = viewModel::updateCriterionMaxPoints,
        onCriterionExpectedAnswerChange = viewModel::updateCriterionExpectedAnswer,
        onCriterionPartialCreditGuidanceChange = viewModel::updateCriterionPartialCreditGuidance,
        onCriterionCommonMistakesChange = viewModel::updateCriterionCommonMistakes,
        onSaveWritingPunctuationPreference = viewModel::saveWritingAndPunctuationPreference,
        onGenerateRubric = viewModel::generateRubric,
        onSaveClick = { saveAndAdvanceRequested = true },
        onLockClick = { saveAndAdvanceRequested = true },
        onUnlockClick = viewModel::unlockRubricSet,
        onContinueClick = onContinue,
        onEvaluationSourceTypeChange = viewModel::setEvaluationSourceType,
        onOriginalAnswerKeyChange = viewModel::updateOriginalTeacherAnswerKey,
        onOriginalRubricChange = viewModel::updateOriginalTeacherRubric,
        onIsAsIsChange = viewModel::setIsAsIs,
        onMatchWithQuestionsClick = viewModel::matchWithQuestions,
        onUploadDocumentClick = { target ->
            activeUploadTarget = target
            filePickerLauncher.launch("*/*")
        },
        onRemoveDocumentClick = viewModel::removeUploadedDocument,
        onGeneratePdf = viewModel::generateTeacherRubricPdf,
        onSavePdf = {
            val file = uiState.generatedPdfFile
            if (file != null && file.exists()) saveRubricPdfLauncher.launch(file.name)
        },
        onSharePdf = { file -> sharePdfFile(context, file) },
        onSelectPage = viewModel::selectPreviewPage
    )
}

private fun sharePdfFile(context: Context, file: File) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(shareIntent, "Öğretmen Rubriği PDF Paylaş"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "PDF paylaşılamadı. Lütfen tekrar deneyin.", android.widget.Toast.LENGTH_SHORT).show()
    }
}
