package com.example.core.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.ExifInterface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.AtomicFile
import com.example.core.database.ExamAnswerSheetConfigDao
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamPaperUploadDao
import com.example.core.database.ExamQuestionDao
import com.example.core.database.ExamRubricDao
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.model.ExamType
import com.example.core.security.StudentImageCrypto
import com.example.core.security.SafeBitmapDecoder
import com.google.zxing.BinaryBitmap
import com.google.zxing.LuminanceSource
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class IdentityValidationResult(
    val isValid: Boolean,
    val normalizedClass: String? = null,
    val normalizedBranch: String? = null,
    val normalizedSchoolNo: String? = null,
    val reason: String? = null
)

fun validateStudentIdentity(
    classLevel: String?,
    branch: String?,
    schoolNumber: String?
): IdentityValidationResult {
    if (classLevel.isNullOrBlank() || branch.isNullOrBlank() || schoolNumber.isNullOrBlank()) {
        return IdentityValidationResult(
            isValid = false,
            reason = "Sınıf, Şube ve Okul No alanları eksik."
        )
    }

    val cleanClass = classLevel.trim().replace(Regex("[^0-9]"), "")
    val allowedClasses = listOf("5", "6", "7", "8", "9", "10", "11", "12")
    if (!allowedClasses.contains(cleanClass)) {
        return IdentityValidationResult(
            isValid = false,
            reason = "Sınıf 5 ile 12 arasında olmalıdır (5, 6, 7, 8, 9, 10, 11, 12)."
        )
    }

    val cleanBranch = BranchConstants.normalizeBranch(branch) ?: ""
    if (!BranchConstants.CANONICAL_BRANCHES.contains(cleanBranch)) {
        return IdentityValidationResult(
            isValid = false,
            reason = "Şube geçerli bir Türkçe şube harfi olmalıdır (A, B, C, Ç … Ş, Ü, Y, Z)."
        )
    }

    val cleanSchoolNo = schoolNumber.trim()
    if (!cleanSchoolNo.matches(Regex("^\\d{1,4}$"))) {
        return IdentityValidationResult(
            isValid = false,
            reason = "Okul Numarası 1 ile 4 basamak arasında rakamlardan oluşmalıdır (Örn: 1234)."
        )
    }

    return IdentityValidationResult(
        isValid = true,
        normalizedClass = cleanClass,
        normalizedBranch = cleanBranch,
        normalizedSchoolNo = cleanSchoolNo,
        reason = null
    )
}

data class QrParsedInfo(
    val version: Int,
    val examDraftId: Long,
    val formToken: String?,
    val studentSeq: Int,
    val pageIndex: Int,
    val totalPages: Int,
    val rawContent: String
)

data class AnswerImageCleanupResult(
    val attempted: Int,
    val deleted: Int,
    val failed: Int
)

class ExamPaperUploadRepository(
    private val paperUploadDao: ExamPaperUploadDao,
    private val configDao: ExamAnswerSheetConfigDao,
    private val questionDao: ExamQuestionDao? = null,
    private val rubricDao: ExamRubricDao? = null,
    private val context: Context? = null,
    private val answerSheetRepository: ExamAnswerSheetRepository? = null
 ) {

    init {
        // Never wipe a newly captured TakePicture file just because Android recreated the process.
        // Only old, untracked plaintext artifacts are scrubbed; the active capture is journaled.
        context?.let { CameraCaptureJournal.cleanupStaleUntracked(it) }
    }

    suspend fun getLayoutDensity(examDraftId: Long): String = withContext(Dispatchers.IO) {
        configDao.getConfig(examDraftId)?.layoutDensity ?: "AUTOMATIC"
    }

    suspend fun getLineOverrides(examDraftId: Long): Map<Int, Int> = withContext(Dispatchers.IO) {
        answerSheetRepository?.getLineOverrides(examDraftId)
            ?: ExamAnswerSheetRepository.getLineOverrides(examDraftId, context)
    }

    suspend fun getAnswerSheetGuidance(examDraftId: Long): ListeningAnswerSheetGuidance? =
        withContext(Dispatchers.IO) {
            answerSheetRepository?.getListeningGuidance(examDraftId)
        }

    suspend fun getActualTotalPages(examDraftId: Long): Int = withContext(Dispatchers.IO) {
        try {
            if (questionDao != null && rubricDao != null) {
                val questions = questionDao.getByExamDraftIdOnce(examDraftId)
                val rubrics = rubricDao.getCriteriaByExamDraftIdOnce(examDraftId)
                if (questions.isNotEmpty()) {
                    val density = configDao.getConfig(examDraftId)?.layoutDensity ?: "AUTOMATIC"
                    val lineOverrides = getLineOverrides(examDraftId)
                    val listeningGuidance = getAnswerSheetGuidance(examDraftId)
                    val draftType = (answerSheetRepository?.validatePreflight(examDraftId) as? ExamAnswerSheetPreflightResult.Success)?.draft?.examType
                        ?: ExamType.WRITTEN
                    val layouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
                        questions = questions,
                        rubricCriteria = rubrics,
                        densitySetting = density,
                        lineOverrides = lineOverrides,
                        listeningGuidance = listeningGuidance,
                        examType = draftType
                    )
                    if (layouts.isNotEmpty()) {
                        return@withContext layouts.size
                    }
                }
            }
            val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
            pages.maxOfOrNull { it.totalPages }?.coerceAtLeast(1) ?: 1
        } catch (_: Exception) {
            1
        }
    }

    fun getStudentPapers(examDraftId: Long): Flow<List<ExamStudentPaperEntity>> {
        return paperUploadDao.getPapersForExam(examDraftId)
    }

    suspend fun getStudentPapersOnce(examDraftId: Long): List<ExamStudentPaperEntity> = withContext(Dispatchers.IO) {
        paperUploadDao.getPapersForExamOnce(examDraftId)
    }

    fun getPages(examDraftId: Long): Flow<List<ExamPaperPageEntity>> {
        return paperUploadDao.getPagesForExam(examDraftId)
    }

    suspend fun getPaperByIdOnce(paperId: Long): ExamStudentPaperEntity? = withContext(Dispatchers.IO) {
        paperUploadDao.getPaperByIdOnce(paperId)
    }

    suspend fun getPagesForPaperOnce(paperId: Long): List<ExamPaperPageEntity> = withContext(Dispatchers.IO) {
        paperUploadDao.getPagesForPaperOnce(paperId)
    }

    suspend fun getPagesForExamOnce(examDraftId: Long): List<ExamPaperPageEntity> = withContext(Dispatchers.IO) {
        paperUploadDao.getPagesForExamOnce(examDraftId)
    }

    suspend fun recoverInterruptedImport(
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val appContext = context
            ?: return@withContext Result.success(false)
        runCatching { recoverInterruptedImportInternal(appContext, examDraftId, examType) }
    }

    suspend fun processBatchPdf(
        context: Context,
        examDraftId: Long,
        pdfUri: Uri,
        examType: ExamType = ExamType.WRITTEN
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            recoverInterruptedImportInternal(context, examDraftId, examType)
            beginImportJournal(context, examDraftId)
            val pfd = context.contentResolver.openFileDescriptor(pdfUri, "r")
                ?: throw IllegalStateException("PDF dosyası açılamadı.")
            var pageCount = 0
            pfd.use { descriptor ->
                val sourceBytes = descriptor.statSize
                if (sourceBytes > 0L && sourceBytes > 200L * 1024L * 1024L) {
                    throw IllegalStateException("PDF 200 MB güvenlik sınırını aşıyor. Dosyayı daha küçük parçalara bölün.")
                }
                PdfRenderer(descriptor).use { renderer ->
                    pageCount = renderer.pageCount
                    if (pageCount == 0) throw IllegalStateException("PDF sayfa içermiyor.")
                    val expectedStudents = (configDao.getConfig(examDraftId)?.studentCount ?: 20).coerceIn(1, 500)
                    val expectedPagesPerStudent = if (examType == ExamType.HOMEWORK) 1 else getActualTotalPages(examDraftId).coerceAtLeast(1)
                    val expectedTotalPages = expectedStudents * expectedPagesPerStudent
                    val dynamicCap = maxOf(100, expectedTotalPages * 2).coerceAtMost(2000)
                    require(pageCount <= dynamicCap) {
                        "PDF $pageCount sayfa içeriyor; bu sınav için tek aktarım güvenlik sınırı $dynamicCap sayfadır. Dosyayı bölün veya öğrenci/sayfa ayarını kontrol edin."
                    }
                    val uploadDir = File(context.filesDir, "paper_uploads/$examDraftId").apply { mkdirs() }

                    for (i in 0 until pageCount) {
                        renderer.openPage(i).use { page ->
                            val width = 2000
                            val height = (width * 1.414).toInt()
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            try {
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                val imageFile = File(uploadDir, "page_${UUID.randomUUID()}.jpg")
                                addImportJournalPath(context, examDraftId, imageFile)
                                StudentImageCrypto.writeBitmap(imageFile, bitmap, 94)
                                saveAndRegisterPage(
                                    examDraftId = examDraftId,
                                    imagePath = imageFile.absolutePath,
                                    qrInfo = decodeQrCode(bitmap),
                                    isReadabilityOk = checkImageReadability(bitmap),
                                    examType = examType
                                )
                            } finally {
                                if (!bitmap.isRecycled) bitmap.recycle()
                            }
                        }
                    }
                }
            }
            regroupStudentPapers(examDraftId, examType)
            commitImportJournal(context, examDraftId)
            Result.success(pageCount)
        } catch (e: Exception) {
            val rollback = runCatching { rollbackImportJournal(context, examDraftId, examType) }
            if (rollback.isFailure) {
                Result.failure(IllegalStateException(
                    "PDF aktarımı başarısız oldu ve yarım aktarım tamamen geri alınamadı; uygulama yeniden açıldığında güvenli kurtarma tekrar denenecek.",
                    rollback.exceptionOrNull() ?: e
                ))
            } else Result.failure(e)
        }
    }

    suspend fun processImageFiles(
        context: Context,
        examDraftId: Long,
        imageUris: List<Uri>,
        examType: ExamType = ExamType.WRITTEN
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            require(imageUris.isNotEmpty()) { "Fotoğraf seçilmedi." }
            require(imageUris.size <= 100) { "Tek aktarımda en fazla 100 fotoğraf seçilebilir; kalanları ikinci aktarımda ekleyin." }
            recoverInterruptedImportInternal(context, examDraftId, examType)
            beginImportJournal(context, examDraftId)
            val uploadDir = File(context.filesDir, "paper_uploads/$examDraftId").apply { mkdirs() }
            var count = 0

            for (uri in imageUris) {
                val bitmap = decodeUriRespectingExif(context, uri)
                    ?: throw IllegalStateException("Seçilen fotoğraflardan biri okunamadı; kısmi aktarım yapılmadı.")
                try {
                    val imageFile = File(uploadDir, "page_${UUID.randomUUID()}.jpg")
                    addImportJournalPath(context, examDraftId, imageFile)
                    StudentImageCrypto.writeBitmap(imageFile, bitmap, 94)
                    saveAndRegisterPage(
                        examDraftId = examDraftId,
                        imagePath = imageFile.absolutePath,
                        qrInfo = decodeQrCode(bitmap),
                        isReadabilityOk = checkImageReadability(bitmap),
                        examType = examType
                    )
                    count++
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }

            if (count != imageUris.size) throw IllegalStateException("Fotoğraf aktarımı eksik tamamlandı.")
            regroupStudentPapers(examDraftId, examType)
            commitImportJournal(context, examDraftId)
            Result.success(count)
        } catch (e: Exception) {
            val rollback = runCatching { rollbackImportJournal(context, examDraftId, examType) }
            if (rollback.isFailure) {
                Result.failure(IllegalStateException(
                    "Fotoğraf aktarımı başarısız oldu ve yarım aktarım tamamen geri alınamadı; uygulama yeniden açıldığında güvenli kurtarma tekrar denenecek.",
                    rollback.exceptionOrNull() ?: e
                ))
            } else Result.failure(e)
        }
    }

    suspend fun processCameraImageFile(
        examDraftId: Long,
        imageFile: File,
        examType: ExamType = ExamType.WRITTEN
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val bitmap = decodeFileRespectingExif(imageFile)
                ?: throw IllegalStateException("Fotoğraf yüklenemedi.")

            try {
                val appContext = context
                    ?: throw IllegalStateException("Güvenli kamera saklama alanı kullanılamıyor.")
                val uploadDir = File(appContext.filesDir, "paper_uploads/$examDraftId").apply { mkdirs() }
                val secureImageFile = File(uploadDir, "page_${UUID.randomUUID()}.jpg")
                try {
                    StudentImageCrypto.writeBitmap(secureImageFile, bitmap, 94)
                    val qrInfo = decodeQrCode(bitmap)
                    val isReadabilityOk = checkImageReadability(bitmap)

                    // TakePicture must temporarily create a normal JPEG. Do not register the
                    // encrypted copy until that plaintext cache artifact is provably gone.
                    check(CameraCaptureJournal.scrubPlaintext(imageFile)) {
                        "Kamera geçici görüntüsü güvenli biçimde silinemedi; öğrenci kâğıdı kaydı oluşturulmadı."
                    }
                    CameraCaptureJournal.clearIfMatches(appContext, imageFile)

                    try {
                        saveAndRegisterPage(
                            examDraftId = examDraftId,
                            imagePath = secureImageFile.absolutePath,
                            qrInfo = qrInfo,
                            isReadabilityOk = isReadabilityOk,
                            examType = examType
                        )
                    } catch (dbError: Throwable) {
                        check(!secureImageFile.exists() || secureImageFile.delete()) {
                            "Kamera kaydı DB'ye yazılamadı ve şifreli yetim görüntü temizlenemedi."
                        }
                        throw dbError
                    }
                } catch (error: Throwable) {
                    if (secureImageFile.exists() && !secureImageFile.delete()) {
                        throw IllegalStateException(
                            "Kamera işleme hatasından sonra şifreli yetim görüntü temizlenemedi.",
                            error
                        )
                    }
                    throw error
                }
            } finally {
                if (!bitmap.isRecycled) bitmap.recycle()
            }

            regroupStudentPapers(examDraftId, examType)
            Result.success(true)
        } catch (e: Exception) {
            context?.let { appContext ->
                if (!imageFile.exists() || CameraCaptureJournal.scrubPlaintext(imageFile)) {
                    CameraCaptureJournal.clearIfMatches(appContext, imageFile)
                }
            }
            Result.failure(e)
        }
    }

    private fun decodeUriRespectingExif(context: Context, uri: Uri): Bitmap? {
        val orientation = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val bitmap = SafeBitmapDecoder.decodeUri(context, uri) ?: return null
        return applyExifOrientation(bitmap, orientation)
    }

    private fun decodeFileRespectingExif(file: File): Bitmap? {
        val orientation = runCatching {
            ExifInterface(file.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val bitmap = SafeBitmapDecoder.decodeFile(file) ?: return null
        return applyExifOrientation(bitmap, orientation)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return bitmap
        }
        return try {
            val transformed = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (transformed !== bitmap) bitmap.recycle()
            transformed
        } catch (_: Exception) {
            bitmap
        }
    }

    private suspend fun saveAndRegisterPage(
        examDraftId: Long,
        imagePath: String,
        qrInfo: QrParsedInfo?,
        isReadabilityOk: Boolean,
        examType: ExamType = ExamType.WRITTEN
    ): Long {
        val status: String
        val reason: String?
        val actualTotalPages = if (examType == ExamType.HOMEWORK) 1 else getActualTotalPages(examDraftId)
        val expectedStudentCount = configDao.getConfig(examDraftId)?.studentCount ?: 20
        val currentFormToken = if (examType == ExamType.HOMEWORK) null else runCatching {
            answerSheetRepository?.getCurrentFormToken(examDraftId)
        }.getOrNull()

        if (!isReadabilityOk) {
            status = if (examType == ExamType.HOMEWORK) "UNREADABLE_IMAGE" else "UNREADABLE_QR"
            reason = if (examType == ExamType.HOMEWORK) {
                "Ödev teslimi görüntüsü net değil veya okunabilirlik düşük."
            } else {
                "Kâğıt görüntüsü net değil veya okunabilirlik düşük."
            }
        } else if (examType == ExamType.HOMEWORK) {
            // Homework submissions are external student work. Any QR visible on
            // the page may belong to a textbook, worksheet, publisher or another
            // system and must never be used as BaykuşNot identity metadata.
            // Assignment is deliberately teacher-controlled.
            status = "UNASSIGNED"
            reason = "Ödev sayfası henüz bir öğrenci teslimine bağlanmadı."
        } else if (qrInfo == null) {
            status = "UNREADABLE_QR"
            reason = "Karekod okunamadı veya kâğıt net değil."
        } else if (qrInfo.examDraftId != examDraftId) {
            status = "WRONG_EXAM"
            reason = if (examType == ExamType.READINESS) {
                "Bu cevap kâğıdı başka bir hazırbulunuşluk sınavına aittir! (Çalışma ID: ${qrInfo.examDraftId})"
            } else if (examType == ExamType.MULTIPLE_CHOICE) {
                "Bu test cevap formu başka bir Test Sınavına aittir! (Test ID: ${qrInfo.examDraftId})"
            } else {
                "Bu cevap kâğıdı başka bir sınava aittir! (Sınav ID: ${qrInfo.examDraftId})"
            }
        } else if (qrInfo.version != 4 || currentFormToken == null || qrInfo.formToken != currentFormToken ||
            qrInfo.totalPages != actualTotalPages || qrInfo.pageIndex !in 1..actualTotalPages
        ) {
            status = "STALE_FORM"
            reason = "Bu cevap kâğıdı güncel sınav/soru/rubrik/form yapısıyla uyuşmuyor. Cevap Kâğıdı aşamasından güncel PDF'yi yeniden oluşturup kullanın."
        } else if (qrInfo.studentSeq !in 1..expectedStudentCount) {
            status = "MISMATCHED"
            reason = "Test formundaki öğrenci sıra numarası (${qrInfo.studentSeq}) bu çalışma için oluşturulan 1-$expectedStudentCount aralığının dışında. Formu kontrol edin veya doğru öğrenciye manuel bağlayın."
        } else {
            status = "VALID"
            reason = null
        }

        val finalTotalPages = if (examType == ExamType.HOMEWORK) {
            1
        } else if (qrInfo != null && qrInfo.totalPages > 0) {
            qrInfo.totalPages
        } else {
            actualTotalPages
        }

        val pageEntity = ExamPaperPageEntity(
            examDraftId = examDraftId,
            studentPaperId = 0, // Unassigned until regroup
            pageIndex = if (examType == ExamType.HOMEWORK) 1 else (qrInfo?.pageIndex ?: 1),
            totalPages = finalTotalPages,
            qrStudentSeq = if (examType == ExamType.HOMEWORK) null else qrInfo?.studentSeq,
            imagePath = imagePath,
            qrRawContent = if (examType == ExamType.HOMEWORK) null else qrInfo?.rawContent,
            isReadabilityOk = isReadabilityOk,
            status = status,
            statusReason = reason
        )

        return paperUploadDao.insertPage(pageEntity)
    }

    private fun importJournalFile(context: Context, examDraftId: Long): File {
        val dir = File(context.filesDir, "paper_import_journal").apply { mkdirs() }
        return File(dir, "exam_${examDraftId}.paths")
    }

    private fun readImportJournal(context: Context, examDraftId: Long): List<String> {
        val file = importJournalFile(context, examDraftId)
        if (!file.exists()) return emptyList()
        return runCatching {
            AtomicFile(file).openRead().bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.map { it.trim() }.filter { it.isNotBlank() }.distinct().toList()
            }
        }.getOrElse { throw IllegalStateException("Yarım aktarım günlüğü okunamadı.", it) }
    }

    private fun writeImportJournal(context: Context, examDraftId: Long, paths: List<String>) {
        val atomic = AtomicFile(importJournalFile(context, examDraftId))
        val out = atomic.startWrite()
        try {
            val payload = paths.distinct().joinToString(separator = "\n", postfix = if (paths.isEmpty()) "" else "\n")
            out.write(payload.toByteArray(Charsets.UTF_8))
            out.fd.sync()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }

    private fun beginImportJournal(context: Context, examDraftId: Long) {
        val existing = readImportJournal(context, examDraftId)
        check(existing.isEmpty()) { "Önceki yarım aktarım temizlenmeden yeni aktarım başlatılamaz." }
        writeImportJournal(context, examDraftId, emptyList())
    }

    private fun addImportJournalPath(context: Context, examDraftId: Long, file: File) {
        val uploadRoot = File(context.filesDir, "paper_uploads/$examDraftId").canonicalFile
        val canonical = file.canonicalFile
        require(canonical.parentFile == uploadRoot) { "Aktarım dosyası sınavın güvenli dizini dışında." }
        val paths = readImportJournal(context, examDraftId).toMutableList()
        paths += canonical.absolutePath
        writeImportJournal(context, examDraftId, paths)
    }

    private fun commitImportJournal(context: Context, examDraftId: Long) {
        val atomic = AtomicFile(importJournalFile(context, examDraftId))
        atomic.delete()
    }

    private suspend fun recoverInterruptedImportInternal(
        context: Context,
        examDraftId: Long,
        examType: ExamType
    ): Boolean {
        val paths = readImportJournal(context, examDraftId)
        if (paths.isEmpty()) {
            // Empty journal is a valid "begun but no file yet" state.
            if (importJournalFile(context, examDraftId).exists()) commitImportJournal(context, examDraftId)
            return false
        }
        rollbackImportJournal(context, examDraftId, examType)
        return true
    }

    private suspend fun rollbackImportJournal(
        context: Context,
        examDraftId: Long,
        examType: ExamType
    ) {
        val tracked = readImportJournal(context, examDraftId).toSet()
        if (tracked.isEmpty()) {
            commitImportJournal(context, examDraftId)
            return
        }
        val uploadRoot = File(context.filesDir, "paper_uploads/$examDraftId").canonicalFile
        val safeTracked = tracked.map { path ->
            val file = File(path).canonicalFile
            require(file.parentFile == uploadRoot) { "Yarım aktarım günlüğünde güvenli dizin dışında dosya bulundu." }
            file
        }
        val trackedPaths = safeTracked.map { it.absolutePath }.toSet()
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId).filter { page ->
            runCatching { File(page.imagePath).canonicalPath in trackedPaths }.getOrDefault(false)
        }

        // Physical student content must disappear before its DB reference is removed.
        for (page in pages) {
            val file = File(page.imagePath)
            check(!file.exists() || file.delete()) { "Yarım aktarım görüntüsü silinemedi: ${file.name}" }
            paperUploadDao.deletePage(page.id)
        }
        for (file in safeTracked) {
            check(!file.exists() || file.delete()) { "Yarım aktarım yetim görüntüsü silinemedi: ${file.name}" }
        }
        regroupStudentPapers(examDraftId, examType)
        commitImportJournal(context, examDraftId)
    }

    private fun discardImportJournalFiles(context: Context, examDraftId: Long) {
        val uploadRoot = File(context.filesDir, "paper_uploads/$examDraftId").canonicalFile
        val paths = readImportJournal(context, examDraftId)
        for (path in paths) {
            val file = File(path).canonicalFile
            require(file.parentFile == uploadRoot) { "Aktarım günlüğünde güvenli dizin dışında dosya bulundu." }
            check(!file.exists() || file.delete()) { "Yarım aktarım dosyası silinemedi: ${file.name}" }
        }
        commitImportJournal(context, examDraftId)
    }

    suspend fun validateUploadProgress(
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val config = configDao.getConfig(examDraftId)
            val expectedStudentCount = config?.studentCount ?: 20

            val papers = paperUploadDao.getPapersForExamOnce(examDraftId)
            val pages = paperUploadDao.getPagesForExamOnce(examDraftId)

            if (pages.isEmpty()) {
                val message = if (examType == ExamType.HOMEWORK) {
                    "Lütfen önce öğrenci ödev teslimlerini yükleyin veya kamerayla çekin."
                } else {
                    "Lütfen önce öğrenci cevap kâğıtlarını yükleyin veya kamerayla çekin."
                }
                return@withContext Result.failure(Exception(message))
            }

            val unmatchedPages = pages.filter { page ->
                if (examType == ExamType.HOMEWORK) {
                    page.studentPaperId == 0L || !page.isManuallyAssigned || page.status != "VALID"
                } else if (page.isManuallyAssigned) {
                    page.studentPaperId == 0L || page.status != "VALID"
                } else {
                    page.studentPaperId == 0L || page.status != "VALID" || page.qrStudentSeq == null
                }
            }
            if (unmatchedPages.isNotEmpty()) {
                val message = if (examType == ExamType.HOMEWORK) {
                    "${unmatchedPages.size} adet öğrenciye bağlanmamış veya okunabilirlik sorunu olan ödev sayfası var. Lütfen inceleyin, öğrenciye bağlayın veya silin."
                } else {
                    "${unmatchedPages.size} adet eşleşmemiş veya QR kodu okunamayan sorunlu sayfa var. Lütfen inceleyin veya silin."
                }
                return@withContext Result.failure(Exception(message))
            }

            val wrongExamPages = pages.filter { it.status == "WRONG_EXAM" }
            if (wrongExamPages.isNotEmpty()) {
                return@withContext Result.failure(Exception("${wrongExamPages.size} adet başka sınava ait sayfa var. Lütfen silin."))
            }

            if (examType != ExamType.HOMEWORK && papers.size < expectedStudentCount) {
                return@withContext Result.failure(Exception("Eksik öğrenci kâğıdı var! Beklenen: $expectedStudentCount, Yüklenen: ${papers.size} öğrenci seti."))
            }

            if (examType != ExamType.HOMEWORK && papers.size > expectedStudentCount) {
                return@withContext Result.failure(Exception("Fazla öğrenci kâğıdı seti var! Beklenen: $expectedStudentCount, Yüklenen: ${papers.size} öğrenci seti. Lütfen fazla setleri silin."))
            }

            if (examType == ExamType.HOMEWORK && papers.isEmpty()) {
                return@withContext Result.failure(Exception("Değerlendirilecek öğrenci ödev teslimi bulunamadı."))
            }

            val problemPaper = papers.firstOrNull { it.status != "READY" }
            if (problemPaper != null) {
                val reason = problemPaper.statusReason ?: "Eksik/tekrarlayan sayfa veya kimlik çözülmeme sorunu var."
                return@withContext Result.failure(Exception("Öğrenci seti #${problemPaper.studentSequenceIndex} hazır değil: $reason"))
            }

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun regroupStudentPapers(
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ) = withContext(Dispatchers.IO) {
        val allPages = paperUploadDao.getPagesForExamOnce(examDraftId)
        val existingPapers = paperUploadDao.getPapersForExamOnce(examDraftId).associateBy { it.studentSequenceIndex }.toMutableMap()

        val pagesByStudentSeq = mutableMapOf<Int, MutableList<ExamPaperPageEntity>>()

        for (page in allPages) {
            val targetSeq = if (page.isManuallyAssigned && page.studentPaperId > 0) {
                existingPapers.values.find { it.id == page.studentPaperId }?.studentSequenceIndex ?: page.qrStudentSeq ?: -1
            } else {
                page.qrStudentSeq ?: -1
            }

            if (targetSeq > 0) {
                pagesByStudentSeq.getOrPut(targetSeq) { mutableListOf() }.add(page)
            }
        }

        val actualTotalPages = if (examType == ExamType.HOMEWORK) 1 else getActualTotalPages(examDraftId)
        val activePaperIds = mutableSetOf<Long>()

        for ((studentSeq, seqPages) in pagesByStudentSeq) {
            val existingPaper = existingPapers[studentSeq]
            val expectedTotalPages = if (examType == ExamType.HOMEWORK) {
                seqPages.maxOfOrNull { it.pageIndex }?.coerceAtLeast(1) ?: 1
            } else {
                actualTotalPages
            }

            val sortedPages = seqPages.sortedBy { it.pageIndex }
            val pageIndices = sortedPages.map { it.pageIndex }

            val hasWrongExam = sortedPages.any { it.status == "WRONG_EXAM" }
            val hasStaleForm = examType != ExamType.HOMEWORK && sortedPages.any { it.status == "STALE_FORM" }
            val hasUnreadableQr = if (examType == ExamType.HOMEWORK) {
                sortedPages.any { !it.isReadabilityOk || it.status == "UNREADABLE_IMAGE" }
            } else {
                sortedPages.any { (it.status == "UNREADABLE_QR" || !it.isReadabilityOk) && !it.isManuallyAssigned }
            }
            val hasDuplicates = pageIndices.size != pageIndices.toSet().size
            val isMissing = examType != ExamType.HOMEWORK && pageIndices.toSet().size < expectedTotalPages

            val opticalInfo = if (examType != ExamType.HOMEWORK && sortedPages.any { it.pageIndex == 1 }) {
                val p1 = sortedPages.first { it.pageIndex == 1 }
                try {
                    val b = StudentImageCrypto.decodeBitmap(p1.imagePath)
                    if (b != null) {
                        try { extractOpticalStudentInfo(b) } finally { if (!b.isRecycled) b.recycle() }
                    } else OpticalStudentInfo()
                } catch (_: Exception) { OpticalStudentInfo() }
            } else OpticalStudentInfo()

            val rawSchoolNumber = if (examType == ExamType.HOMEWORK) {
                existingPaper?.schoolNumber
            } else if (existingPaper?.isManuallyCorrected == true) {
                existingPaper.schoolNumber
            } else {
                opticalInfo.schoolNumber ?: existingPaper?.schoolNumber
            }
            val rawClassLevel = if (examType == ExamType.HOMEWORK) {
                existingPaper?.classLevel
            } else if (existingPaper?.isManuallyCorrected == true) {
                existingPaper.classLevel
            } else {
                opticalInfo.classLevel ?: existingPaper?.classLevel
            }
            val rawBranch = if (examType == ExamType.HOMEWORK) {
                existingPaper?.branch
            } else if (existingPaper?.isManuallyCorrected == true) {
                existingPaper.branch
            } else {
                opticalInfo.branch ?: existingPaper?.branch
            }

            val validation = validateStudentIdentity(rawClassLevel, rawBranch, rawSchoolNumber)

            val calculatedStatus: String
            val statusReason: String?

            if (hasWrongExam) {
                calculatedStatus = "ERROR"
                statusReason = when (examType) {
                    ExamType.HOMEWORK -> "Başka bir ödev kontrolüne ait sayfa içeriyor."
                    ExamType.READINESS -> "Başka bir hazırbulunuşluk sınavına ait sayfa içeriyor."
                    else -> "Yanlış sınava ait sayfa içeriyor."
                }
            } else if (hasStaleForm) {
                calculatedStatus = "ERROR"
                statusReason = "Eski veya güncel cevap formu yapısıyla uyuşmayan sayfa içeriyor. Güncel formu yeniden oluşturup yükleyin."
            } else if (hasUnreadableQr) {
                calculatedStatus = "ERROR"
                statusReason = if (examType == ExamType.HOMEWORK) {
                    "Okunabilirlik sorunu olan ödev sayfası içeriyor."
                } else {
                    "Karekod okunamayan veya düşük kaliteli sayfa içeriyor."
                }
            } else if (hasDuplicates) {
                calculatedStatus = "DUPLICATE_PAGES"
                statusReason = "Aynı sayfa birden fazla kez yüklenmiş."
            } else if (isMissing) {
                calculatedStatus = "MISSING_PAGES"
                statusReason = "Eksik sayfa var (${pageIndices.toSet().size}/$expectedTotalPages)."
            } else if (!validation.isValid) {
                calculatedStatus = "UNMATCHED_IDENTITY"
                statusReason = validation.reason ?: "Sınıf/Şube/Okul No eksik veya geçersiz."
            } else if (examType != ExamType.HOMEWORK && existingPaper?.isManuallyCorrected != true && !opticalInfo.isHighConfidence) {
                calculatedStatus = "UNMATCHED_IDENTITY"
                statusReason = "Optik kimlik okuması belirsiz (hizalama/kalite düşük). Lütfen öğretmen doğrulaması yapın."
            } else {
                calculatedStatus = "READY"
                statusReason = null
            }

            val updatedSchoolNumber = if (validation.isValid) validation.normalizedSchoolNo else rawSchoolNumber
            val updatedClassLevel = if (validation.isValid) validation.normalizedClass else rawClassLevel
            val updatedBranch = if (validation.isValid) validation.normalizedBranch else rawBranch

            val paperToSave = if (existingPaper != null) {
                existingPaper.copy(
                    schoolNumber = updatedSchoolNumber,
                    classLevel = updatedClassLevel,
                    branch = updatedBranch,
                    status = calculatedStatus,
                    statusReason = if (existingPaper.isManuallyCorrected && calculatedStatus == "READY") null else statusReason,
                    updatedAt = System.currentTimeMillis()
                )
            } else {
                ExamStudentPaperEntity(
                    examDraftId = examDraftId,
                    studentSequenceIndex = studentSeq,
                    studentName = "Öğrenci $studentSeq",
                    classLevel = updatedClassLevel,
                    branch = updatedBranch,
                    schoolNumber = updatedSchoolNumber,
                    status = calculatedStatus,
                    statusReason = statusReason,
                    isManuallyCorrected = false
                )
            }

            val paperId = paperUploadDao.insertPaper(paperToSave)
            activePaperIds.add(paperId)

            for (p in seqPages) {
                val newStatus = when {
                    examType == ExamType.HOMEWORK && p.isManuallyAssigned && p.isReadabilityOk -> "VALID"
                    (p.status == "UNREADABLE_QR" || p.status == "MISMATCHED") && p.isManuallyAssigned -> "VALID"
                    else -> p.status
                }
                val normalizedTotalPages = if (examType == ExamType.HOMEWORK) expectedTotalPages else p.totalPages
                if (p.studentPaperId != paperId || p.status != newStatus || p.totalPages != normalizedTotalPages) {
                    paperUploadDao.updatePage(
                        p.copy(
                            studentPaperId = paperId,
                            status = newStatus,
                            totalPages = normalizedTotalPages,
                            statusReason = if (newStatus == "VALID") null else p.statusReason
                        )
                    )
                }
            }
        }

        // Clean up empty student papers with 0 pages (Requirement 3)
        val currentDbPapers = paperUploadDao.getPapersForExamOnce(examDraftId)
        for (paper in currentDbPapers) {
            if (!activePaperIds.contains(paper.id)) {
                val pagesForPaper = paperUploadDao.getPagesForPaperOnce(paper.id)
                if (pagesForPaper.isEmpty()) {
                    paperUploadDao.deletePaper(paper.id)
                }
            }
        }
    }

    suspend fun updateStudentPaperDetails(
        paperId: Long,
        studentName: String?,
        classLevel: String?,
        branch: String?,
        schoolNumber: String?,
        examType: ExamType = ExamType.WRITTEN
    ) = withContext(Dispatchers.IO) {
        val paper = paperUploadDao.getPaperByIdOnce(paperId) ?: return@withContext
        val validation = validateStudentIdentity(classLevel, branch, schoolNumber)

        val updated = paper.copy(
            studentName = studentName,
            classLevel = if (validation.isValid) validation.normalizedClass else classLevel,
            branch = if (validation.isValid) validation.normalizedBranch else branch,
            schoolNumber = if (validation.isValid) validation.normalizedSchoolNo else schoolNumber,
            isManuallyCorrected = true,
            status = if (validation.isValid) paper.status else "UNMATCHED_IDENTITY",
            statusReason = if (validation.isValid) null else validation.reason,
            updatedAt = System.currentTimeMillis()
        )
        paperUploadDao.updatePaper(updated)
        regroupStudentPapers(paper.examDraftId, examType)
    }

    suspend fun reassignPage(
        pageId: Long,
        targetStudentSeq: Int,
        targetPageIndex: Int,
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ) = withContext(Dispatchers.IO) {
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        val targetPage = pages.find { it.id == pageId } ?: return@withContext

        val papers = paperUploadDao.getPapersForExamOnce(examDraftId)
        var targetPaper = papers.find { it.studentSequenceIndex == targetStudentSeq }

        if (targetPaper == null) {
            val newPaper = ExamStudentPaperEntity(
                examDraftId = examDraftId,
                studentSequenceIndex = targetStudentSeq,
                studentName = "Öğrenci $targetStudentSeq",
                status = "MISSING_PAGES",
                statusReason = "Sayfalar aktarılıyor...",
                isManuallyCorrected = false
            )
            val createdId = paperUploadDao.insertPaper(newPaper)
            targetPaper = paperUploadDao.getPaperByIdOnce(createdId)
        }

        val paperId = targetPaper?.id ?: return@withContext

        val isWrongExam = targetPage.status == "WRONG_EXAM"
        val isStaleForm = examType != ExamType.HOMEWORK && targetPage.status == "STALE_FORM"
        val actualTotalPages = if (examType == ExamType.HOMEWORK) targetPageIndex.coerceAtLeast(1) else getActualTotalPages(examDraftId)

        val updatedPage = targetPage.copy(
            studentPaperId = paperId,
            pageIndex = targetPageIndex,
            totalPages = actualTotalPages,
            isManuallyAssigned = true,
            status = when {
                isWrongExam -> "WRONG_EXAM"
                isStaleForm -> "STALE_FORM"
                examType == ExamType.HOMEWORK && !targetPage.isReadabilityOk -> "UNREADABLE_IMAGE"
                else -> "VALID"
            },
            statusReason = when {
                isWrongExam -> when (examType) {
                    ExamType.HOMEWORK -> "Bu ödev sayfasında önceki bir eşleştirme sorunu var; sayfayı yeniden yükleyin."
                    ExamType.READINESS -> "Bu cevap kâğıdı başka bir hazırbulunuşluk sınavına aittir!"
                    else -> "Bu cevap kâğıdı başka bir sınava aittir!"
                }
                isStaleForm -> "Bu cevap kâğıdı eski/güncel olmayan sınav yapısına ait. Manuel eşleştirme ile kullanılamaz; güncel formu yeniden oluşturup yükleyin."
                examType == ExamType.HOMEWORK && !targetPage.isReadabilityOk -> "Ödev teslimi görüntüsü okunabilir değil."
                else -> null
            }
        )
        paperUploadDao.updatePage(updatedPage)
        regroupStudentPapers(examDraftId, examType)
    }

    suspend fun deletePage(
        pageId: Long,
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ) = withContext(Dispatchers.IO) {
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        val pageToDelete = pages.find { it.id == pageId }
        if (pageToDelete != null) {
            val file = File(pageToDelete.imagePath)
            check(!file.exists() || file.delete()) { "Cevap görüntüsü fiziksel olarak silinemedi; kayıt korunarak yeniden denemeye bırakıldı." }
            paperUploadDao.deletePage(pageId)
        }
        regroupStudentPapers(examDraftId, examType)
    }

    suspend fun deleteStudentPaper(
        paperId: Long,
        examDraftId: Long,
        examType: ExamType = ExamType.WRITTEN
    ) = withContext(Dispatchers.IO) {
        val pages = paperUploadDao.getPagesForPaperOnce(paperId)
        for (page in pages) {
            val file = File(page.imagePath)
            check(!file.exists() || file.delete()) { "Öğrenci kâğıdı görüntüsü silinemedi; kalan kayıtlar korunarak işlem durduruldu." }
            paperUploadDao.deletePage(page.id)
        }
        paperUploadDao.deletePaper(paperId)
        regroupStudentPapers(examDraftId, examType)
    }

    suspend fun clearAllPapers(examDraftId: Long) = withContext(Dispatchers.IO) {
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        for (page in pages) {
            val file = File(page.imagePath)
            check(!file.exists() || file.delete()) { "Cevap görüntülerinin tamamı silinemedi; başarısız kayıt yeniden denemeye bırakıldı." }
            paperUploadDao.deletePage(page.id)
        }
        context?.let { appContext ->
            discardImportJournalFiles(appContext, examDraftId)
            val uploadDir = File(appContext.filesDir, "paper_uploads/$examDraftId")
            if (uploadDir.exists()) check(uploadDir.deleteRecursively()) {
                "Kâğıt yükleme klasöründeki yetim dosyalar tamamen temizlenemedi."
            }
        }
        paperUploadDao.clearPapersForExam(examDraftId)
    }

    /**
     * Privacy cleanup after final reports are printed/archived.
     * Keeps student paper identity rows, scores, teacher approvals and reports; removes only
     * the captured/scanned answer image files and their page records from the device.
     */
    suspend fun deleteAnswerImagesKeepEvaluationRecords(examDraftId: Long): AnswerImageCleanupResult = withContext(Dispatchers.IO) {
        val pages = paperUploadDao.getPagesForExamOnce(examDraftId)
        var deleted = 0
        for (page in pages) {
            val file = File(page.imagePath)
            if (!file.exists() || file.delete()) {
                paperUploadDao.deletePage(page.id)
                deleted++
            }
        }
        AnswerImageCleanupResult(
            attempted = pages.size,
            deleted = deleted,
            failed = pages.size - deleted
        )
    }

    private fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap {
        val matrix = android.graphics.Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun decodeQrCode(bitmap: Bitmap): QrParsedInfo? {
        var decodedText = tryDecode(bitmap) ?: tryDecodeCropped(bitmap)
        if (decodedText != null) {
            val parsed = parseQrContent(decodedText)
            if (parsed != null) return parsed
        }

        val angles = listOf(90f, 180f, 270f)
        for (angle in angles) {
            val rotated = rotateBitmap(bitmap, angle)
            decodedText = tryDecode(rotated) ?: tryDecodeCropped(rotated)
            if (rotated != bitmap) {
                rotated.recycle()
            }
            if (decodedText != null) {
                val parsed = parseQrContent(decodedText)
                if (parsed != null) return parsed
            }
        }

        return null
    }

    private fun tryDecode(bitmap: Bitmap): String? {
        return try {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            val source: LuminanceSource = RGBLuminanceSource(width, height, pixels)
            val bBitmap = BinaryBitmap(HybridBinarizer(source))
            val result = QRCodeReader().decode(bBitmap)
            result.text
        } catch (_: Exception) {
            null
        }
    }

    private fun tryDecodeCropped(bitmap: Bitmap): String? {
        return try {
            // QR is located near the top-right corner on the answer sheet
            val cropW = bitmap.width / 2
            val cropH = bitmap.height / 3
            val cropped = Bitmap.createBitmap(bitmap, bitmap.width - cropW, 0, cropW, cropH)
            try {
                val pixels = IntArray(cropped.width * cropped.height)
                cropped.getPixels(pixels, 0, cropped.width, 0, 0, cropped.width, cropped.height)
                val source: LuminanceSource = RGBLuminanceSource(cropped.width, cropped.height, pixels)
                val bBitmap = BinaryBitmap(HybridBinarizer(source))
                QRCodeReader().decode(bBitmap).text
            } finally {
                if (!cropped.isRecycled) cropped.recycle()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseQrContent(raw: String): QrParsedInfo? {
        // Current format: AIEKSAM|V:4|E:12|F:<token>|S:1|P:1|T:3
        if (!raw.startsWith("AIEKSAM")) return null
        val parts = raw.split("|")
        var version = 0
        var examId: Long? = null
        var formToken: String? = null
        var seq: Int? = null
        var pIdx: Int? = null
        var tPages: Int? = null

        for (part in parts) {
            when {
                part.startsWith("V:") -> version = part.removePrefix("V:").toIntOrNull() ?: 0
                part.startsWith("E:") -> examId = part.removePrefix("E:").toLongOrNull()
                part.startsWith("F:") -> formToken = part.removePrefix("F:").trim().takeIf { it.isNotEmpty() }
                part.startsWith("S:") -> seq = part.removePrefix("S:").toIntOrNull()
                part.startsWith("P:") -> pIdx = part.removePrefix("P:").toIntOrNull()
                part.startsWith("T:") -> tPages = part.removePrefix("T:").toIntOrNull()
            }
        }

        if (examId != null && seq != null && pIdx != null && tPages != null) {
            return QrParsedInfo(
                version = version,
                examDraftId = examId,
                formToken = formToken,
                studentSeq = seq,
                pageIndex = pIdx,
                totalPages = tPages,
                rawContent = raw
            )
        }
        return null
    }

    private fun checkImageReadability(bitmap: Bitmap): Boolean {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 250) return false

        val step = maxOf(1, w / 30)
        var sum = 0.0
        val samples = mutableListOf<Double>()
        for (y in 0 until h step step * 2) {
            for (x in 0 until w step step) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val lum = 0.299 * r + 0.587 * g + 0.114 * b
                sum += lum
                samples.add(lum)
            }
        }

        if (samples.isEmpty()) return false
        val avg = sum / samples.size
        if (avg < 20.0 || avg > 248.0) return false

        var varSum = 0.0
        for (l in samples) {
            varSum += (l - avg) * (l - avg)
        }
        val stdDev = Math.sqrt(varSum / samples.size)
        return stdDev >= 10.0
    }

    private fun sampleBubbleFillRatio(bitmap: Bitmap, w: Int, h: Int, relX: Float, relY: Float): Double {
        var maxFill = 0.0
        val searchOffsetW = (w * 0.004f).toInt().coerceAtLeast(2)
        val searchOffsetH = (h * 0.004f).toInt().coerceAtLeast(2)
        val radiusW = (w * 0.005f).toInt().coerceAtLeast(3)
        val radiusH = (h * 0.005f).toInt().coerceAtLeast(3)

        for (dx in listOf(-searchOffsetW, 0, searchOffsetW)) {
            for (dy in listOf(-searchOffsetH, 0, searchOffsetH)) {
                val cx = (w * relX).toInt() + dx
                val cy = (h * relY).toInt() + dy

                if (cx < radiusW || cx >= w - radiusW || cy < radiusH || cy >= h - radiusH) continue

                var darkPixels = 0
                var totalPixels = 0

                for (px in (cx - radiusW)..(cx + radiusW)) {
                    for (py in (cy - radiusH)..(cy + radiusH)) {
                        val pixel = bitmap.getPixel(px, py)
                        val r = (pixel shr 16) and 0xFF
                        val g = (pixel shr 8) and 0xFF
                        val b = pixel and 0xFF
                        val lum = 0.299 * r + 0.587 * g + 0.114 * b
                        // Strict threshold for filled dark pencil/pen mark (< 100)
                        if (lum < 100.0) {
                            darkPixels++
                        }
                        totalPixels++
                    }
                }

                if (totalPixels > 0) {
                    val fillRatio = darkPixels.toDouble() / totalPixels
                    if (fillRatio > maxFill) {
                        maxFill = fillRatio
                    }
                }
            }
        }
        return maxFill
    }

    private fun extractOpticalStudentInfo(bitmap: Bitmap): OpticalStudentInfo {
        val w = bitmap.width
        val h = bitmap.height

        return try {
            // School number 4 digits matrix
            val digits = mutableListOf<Int>()
            for (col in 0..3) {
                val colXRel = (388f + col * 22f) / 595f
                var darkestDigit = -1
                var maxFill = 0.0
                var secondMaxFill = 0.0

                for (digit in 0..9) {
                    val rowYRel = (90.5f + digit * 8.2f) / 842f
                    val fill = sampleBubbleFillRatio(bitmap, w, h, colXRel, rowYRel)

                    if (fill > maxFill) {
                        secondMaxFill = maxFill
                        maxFill = fill
                        darkestDigit = digit
                    } else if (fill > secondMaxFill) {
                        secondMaxFill = fill
                    }
                }

                // Strict threshold: maxFill >= 0.42 and difference >= 0.22
                if (maxFill >= 0.42 && (maxFill - secondMaxFill) >= 0.22) {
                    digits.add(darkestDigit)
                }
            }
            val schoolNo = if (digits.size == 4) digits.joinToString("") else null

            // Class level ("5".."12")
            val grades = listOf("5", "6", "7", "8", "9", "10", "11", "12")
            var detectedGrade: String? = null
            var maxGradeFill = 0.0
            var secondMaxGradeFill = 0.0

            val gradeYRel = 87.5f / 842f
            for ((idx, grade) in grades.withIndex()) {
                val gradeXRel = (102f + idx * 12f) / 595f
                val fill = sampleBubbleFillRatio(bitmap, w, h, gradeXRel, gradeYRel)

                if (fill > maxGradeFill) {
                    secondMaxGradeFill = maxGradeFill
                    maxGradeFill = fill
                    detectedGrade = grade
                } else if (fill > secondMaxGradeFill) {
                    secondMaxGradeFill = fill
                }
            }

            if (maxGradeFill < 0.42 || (maxGradeFill - secondMaxGradeFill) < 0.22) {
                detectedGrade = null
            }

            // Branch (29 Turkish letters in 2 compact balanced rows: 15 and 14)
            val branches = BranchConstants.CANONICAL_BRANCHES
            var detectedBranch: String? = null
            var maxBranchFill = 0.0
            var secondMaxBranchFill = 0.0

            for ((idx, branch) in branches.withIndex()) {
                val isSecondRow = idx >= 15
                val colIdx = if (isSecondRow) idx - 15 else idx
                val branchYRel = if (isSecondRow) (103.5f + 11f) / 842f else 103.5f / 842f
                val branchXRel = (102f + colIdx * 11.5f) / 595f
                val fill = sampleBubbleFillRatio(bitmap, w, h, branchXRel, branchYRel)

                if (fill > maxBranchFill) {
                    secondMaxBranchFill = maxBranchFill
                    maxBranchFill = fill
                    detectedBranch = branch
                } else if (fill > secondMaxBranchFill) {
                    secondMaxBranchFill = fill
                }
            }

            if (maxBranchFill < 0.42 || (maxBranchFill - secondMaxBranchFill) < 0.22) {
                detectedBranch = null
            }

            val isAspectNormal = (w.toFloat() / h.toFloat()) in 0.62f..0.78f
            val isHighConfidence = isAspectNormal && schoolNo != null && detectedGrade != null && detectedBranch != null

            OpticalStudentInfo(
                schoolNumber = schoolNo,
                classLevel = detectedGrade,
                branch = detectedBranch,
                isHighConfidence = isHighConfidence
            )
        } catch (_: Exception) {
            OpticalStudentInfo()
        }
    }
}

data class OpticalStudentInfo(
    val schoolNumber: String? = null,
    val classLevel: String? = null,
    val branch: String? = null,
    val isHighConfidence: Boolean = false
)

