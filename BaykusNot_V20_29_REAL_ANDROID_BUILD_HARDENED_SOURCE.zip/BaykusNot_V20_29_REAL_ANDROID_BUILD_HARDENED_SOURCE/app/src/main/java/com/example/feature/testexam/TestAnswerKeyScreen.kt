package com.example.feature.testexam

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

@Composable
fun TestAnswerKeyScreen(
    viewModel: TestAnswerKeyViewModel,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var saveAndAdvanceRequested by remember { mutableStateOf(false) }

    LaunchedEffect(saveAndAdvanceRequested, state.isSaving, state.isLocked, state.canContinue) {
        if (!saveAndAdvanceRequested || state.isSaving) return@LaunchedEffect
        if (state.isLocked && state.canContinue) {
            saveAndAdvanceRequested = false
            onContinue()
        }
    }
    val answerKeyFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val imported = runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = com.example.core.security.BoundedInputReader.read(
                        input,
                        1_000_000L,
                        "Test cevap anahtarı metni"
                    )
                    String(bytes, Charsets.UTF_8)
                }
            }.getOrNull()
            if (!imported.isNullOrBlank()) viewModel.applyBulkText(imported)
        }
    }
    val teacherOpticalFormLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.importTeacherAnswerKeyForms(context, uris)
    }
    if (state.isLoading) {
        Box(modifier.fillMaxSize()) { CircularProgressIndicator() }
        return
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Cevap Anahtarı", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Testte yapay zekâ ve rubrik kullanılmaz. Her soru için doğru seçeneği belirleyin; BaykuşNot öğrenci işaretlerini cihaz içinde optik olarak okuyup bu anahtarla karşılaştırır.")
        }
        state.message?.let { msg ->
            item {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    tonalElevation = 1.dp
                ) {
                    Text(msg, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Test Yapısı", fontWeight = FontWeight.Bold)
                    if (state.isLocked) {
                        Text("${state.questionCount} soru • ${state.optionCount} seçenek • toplam ${state.totalPoints} puan")
                    } else {
                        OutlinedTextField(
                            value = state.questionCountText,
                            onValueChange = viewModel::updateQuestionCountText,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Soru sayısı") },
                            supportingText = { Text("Toplam ${state.totalPoints} puan sorulara otomatik dağıtılır.") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                        Text("Seçenek sayısı")
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            (4..8).forEach { count ->
                                val endLabel = ('A'.code + count - 1).toChar()
                                FilterChip(
                                    selected = state.optionCount == count,
                                    onClick = { viewModel.updateOptionCount(count) },
                                    label = { Text("A–$endLabel ($count)") }
                                )
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Optik Öğretmen Cevap Anahtarı Formu", fontWeight = FontWeight.Bold)
                    Text("İsterseniz BaykuşNot'un standart formunu oluşturup yazdırın. Doğru seçenekleri tek ve koyu işaretleyin; doldurulmuş formu fotoğraf veya PDF olarak geri yüklediğinizde cevaplar cihaz içinde, yapay zekâ/API kullanılmadan okunur.")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.generateTeacherAnswerKeyForm(context) },
                            enabled = !state.isGeneratingTeacherForm && !state.isReadingTeacherForm && state.items.isNotEmpty() && state.questionCountText.toIntOrNull() == state.questionCount,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.isGeneratingTeacherForm) "Hazırlanıyor..." else "Boş Form PDF Oluştur")
                        }
                        Button(
                            onClick = { teacherOpticalFormLauncher.launch(arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp")) },
                            enabled = !state.isLocked && !state.isReadingTeacherForm && !state.isGeneratingTeacherForm && state.questionCountText.toIntOrNull() == state.questionCount,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.isReadingTeacherForm) "Okunuyor..." else "Doldurulmuş Formu Yükle")
                        }
                    }
                    state.teacherFormFile?.takeIf { it.exists() }?.let { file ->
                        OutlinedButton(
                            onClick = { shareTeacherAnswerKeyPdf(context, file) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Öğretmen Formu PDF'yi Paylaş / Yazdır") }
                        Text("${file.name} • ${file.length() / 1024} KB", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Birden fazla fotoğraf yükleyecekseniz sayfaları 1, 2, 3... sırasıyla seçin. Çok sayfalı form için tek PDF daha güvenlidir.", style = MaterialTheme.typography.bodySmall)
                    if (state.isReadingTeacherForm) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
        if (!state.isLocked) {
            item {
                OutlinedTextField(
                    value = state.bulkText,
                    onValueChange = viewModel::updateBulkText,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Toplu cevap anahtarı") },
                    placeholder = { Text("Örn: 1-A 2-C 3-D 4-B veya ACDB...") },
                    minLines = 2
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.applyBulkText() }) { Text("Metni Uygula") }
                    OutlinedButton(
                        onClick = { answerKeyFileLauncher.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel")) }
                    ) { Text("TXT / CSV Yükle") }
                }
            }
        }
        items(state.items, key = { it.question.orderIndex }) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Soru ${item.question.questionNumber} • ${item.question.points} puan", fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    ) {
                        item.options.forEach { option ->
                            FilterChip(
                                selected = item.selectedChoice == option,
                                onClick = { viewModel.selectChoice(item.question.orderIndex, option) },
                                enabled = !state.isLocked,
                                label = { Text(option) }
                            )
                        }
                    }
                }
            }
        }
        item {
            if (state.isLocked) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = viewModel::unlock,
                        enabled = !state.isSaving && !state.isGeneratingTeacherForm && !state.isReadingTeacherForm,
                        modifier = Modifier.weight(1f)
                    ) { Text("Düzenlemeye Aç") }
                    Button(
                        onClick = onContinue,
                        enabled = state.canContinue && !state.isSaving && !state.isGeneratingTeacherForm && !state.isReadingTeacherForm,
                        modifier = Modifier.weight(1f)
                    ) { Text("İlerle") }
                }
            } else {
                Button(
                    onClick = {
                        saveAndAdvanceRequested = true
                        viewModel.saveAndLock()
                    },
                    enabled = !state.isSaving && !state.isGeneratingTeacherForm && !state.isReadingTeacherForm && state.items.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)
                ) {
                    Text(if (state.isSaving) "Kaydediliyor..." else "Kaydet ve İlerle", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}


private fun shareTeacherAnswerKeyPdf(context: android.content.Context, file: File) {
    runCatching {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Öğretmen Cevap Anahtarı Formu"))
    }
}
