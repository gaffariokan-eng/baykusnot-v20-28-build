package com.example.feature.workflow

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.data.ExamEvaluationRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ListeningAnswerSheetGuidance
import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamQuestionEvaluationEntity
import com.example.core.database.ExamStudentEvaluationEntity
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.model.ExamQuestion
import com.example.core.security.YazekComplianceStore
import com.example.core.security.HomeworkPrivacyMaskStore
import com.example.core.security.PrivacyMaskRect
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

import com.example.core.database.ExamRubricCriterionEntity
import kotlinx.coroutines.delay

data class SelectedDetailItem(
    val studentPaper: ExamStudentPaperEntity,
    val pages: List<ExamPaperPageEntity>,
    val question: ExamQuestion,
    val questionEvaluation: ExamQuestionEvaluationEntity?,
    val studentEvaluation: ExamStudentEvaluationEntity?
)

data class AiEvaluationUiState(
    val examDraftId: Long = 0L,
    val studentPapers: List<ExamStudentPaperEntity> = emptyList(),
    val studentEvaluations: Map<Long, ExamStudentEvaluationEntity> = emptyMap(),
    val questionEvaluations: Map<Long, List<ExamQuestionEvaluationEntity>> = emptyMap(),
    val questions: List<ExamQuestion> = emptyList(),
    val rubrics: List<ExamRubricCriterionEntity> = emptyList(),
    val preferences: ExamEvaluationPreferencesEntity? = null,
    val layoutDensity: String = "AUTOMATIC",
    val lineOverrides: Map<Int, Int> = emptyMap(),
    val listeningGuidance: ListeningAnswerSheetGuidance? = null,
    val isEvaluating: Boolean = false,
    val activeEvaluationModel: String? = null,
    val currentEvaluatingPaperId: Long? = null,
    val currentStepMessage: String? = null,
    val selectedDetailItem: SelectedDetailItem? = null,
    val errorMessage: String? = null,
    val academicYear: String = "",
    val yazekAcknowledged: Boolean = false,
    val yazekScopeSummary: String = "",
    val yazekStudentParentNotice: String = "",
    val processingEvaluationSource: String = "AI",
    val showYazekGate: Boolean = false,
    val showHomeworkPrivacyGate: Boolean = false,
    val homeworkPrivacyPages: List<ExamPaperPageEntity> = emptyList(),
    val homeworkPrivacyMasks: Map<Long, List<PrivacyMaskRect>> = emptyMap(),
    val homeworkPrivacyViewedPageIds: Set<Long> = emptySet(),
    val showLegacyPrivacyGate: Boolean = false,
    val legacyPrivacyPages: List<ExamPaperPageEntity> = emptyList(),
    val legacyPrivacyViewedPageIds: Set<Long> = emptySet()
)

class AiEvaluationViewModel(
    private val examDraftId: Long,
    private val evaluationRepository: ExamEvaluationRepository,
    private val paperUploadRepository: ExamPaperUploadRepository,
    private val questionRepository: ExamQuestionRepository,
    private val preferencesRepository: ExamEvaluationPreferencesRepository,
    private val yazekComplianceStore: YazekComplianceStore? = null,
    private val homeworkPrivacyMaskStore: HomeworkPrivacyMaskStore? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiEvaluationUiState(examDraftId = examDraftId))
    val uiState: StateFlow<AiEvaluationUiState> = _uiState.asStateFlow()

    private var evaluationJob: Job? = null
    private var homeworkPrivacyConfirmedForRun: Boolean = false

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            val questions = questionRepository.getQuestionsOnce(examDraftId)
            val preferences = preferencesRepository.observePreferences(examDraftId).first()
            val rubrics = evaluationRepository.getRubricsOnce(examDraftId)
            val density = paperUploadRepository.getLayoutDensity(examDraftId)
            val lineOverrides = paperUploadRepository.getLineOverrides(examDraftId)
            val listeningGuidance = paperUploadRepository.getAnswerSheetGuidance(examDraftId)
            val processingMode = evaluationRepository.getProcessingMode(examDraftId)

            _uiState.value = _uiState.value.copy(
                questions = questions,
                preferences = preferences,
                rubrics = rubrics,
                layoutDensity = density,
                lineOverrides = lineOverrides,
                listeningGuidance = listeningGuidance,
                processingEvaluationSource = processingMode.evaluationSource
            )

            // Resolve any user-requested remote Batch cancellation first. This path may clean
            // provider resources, but it must never restart evaluation work.
            evaluationRepository.retryPendingPauseRemoteCleanup(examDraftId)
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = error.message ?: "Uzak Batch iptali/temizliği güvenli biçimde doğrulanamadı."
                    )
                }

            // If Android killed the process during a user-requested long evaluation, resume it
            // from durable DB/Batch checkpoints when the teacher returns to this screen.
            runCatching { evaluationRepository.resumeDurableEvaluationIfNeeded(examDraftId) }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = error.message ?: "Yarım kalan değerlendirme güvenli biçimde devam ettirilemedi."
                    )
                }

            // Periodic monitor for in-memory progress. The locked model is durable Room data,
            // so never query it every 500 ms while this screen is idle. Refresh it once on load
            // and once when a new evaluation run transitions to active.
            launch {
                var lockedModel = evaluationRepository.getLockedEvaluationModel(examDraftId)
                var wasEvaluating = false
                while (true) {
                    val evaluating = evaluationRepository.isEvaluating(examDraftId)
                    if (evaluating && !wasEvaluating) {
                        lockedModel = evaluationRepository.getLockedEvaluationModel(examDraftId)
                    }
                    val progress = evaluationRepository.getProgress(examDraftId)
                    val paperId = evaluationRepository.getCurrentEvaluatingPaperId(examDraftId)
                    val errorMsg = evaluationRepository.getEvaluationError(examDraftId)

                    _uiState.value = _uiState.value.copy(
                        isEvaluating = evaluating,
                        activeEvaluationModel = lockedModel,
                        currentEvaluatingPaperId = paperId,
                        errorMessage = if (evaluating) progress.takeIf { it.isNotEmpty() } else errorMsg
                    )
                    wasEvaluating = evaluating
                    delay(500)
                }
            }

            // Combine flows for realtime live monitoring
            combine(
                paperUploadRepository.getStudentPapers(examDraftId),
                evaluationRepository.getStudentEvaluationsForExam(examDraftId),
                evaluationRepository.getQuestionEvaluationsForExam(examDraftId)
            ) { papers, evaluations, questionEvaluations ->
                val evalMap = evaluations.associateBy { it.studentPaperId }
                val qEvalMap = questionEvaluations.groupBy { it.studentPaperId }

                _uiState.value.copy(
                    studentPapers = papers,
                    studentEvaluations = evalMap,
                    questionEvaluations = qEvalMap
                )
            }.onEach { newState ->
                _uiState.value = _uiState.value.copy(
                    studentPapers = newState.studentPapers,
                    studentEvaluations = newState.studentEvaluations,
                    questionEvaluations = newState.questionEvaluations
                )
            }.launchIn(viewModelScope)
        }
    }

    fun startEvaluationProcess() {
        viewModelScope.launch {
            val mode = evaluationRepository.getProcessingMode(examDraftId)
            if (mode.evaluationSource == "MANUAL") {
                _uiState.value = _uiState.value.copy(
                    processingEvaluationSource = "MANUAL",
                    errorMessage = "Bu çalışma manuel modda. AI değerlendirmesini yeniden kullanmak istiyorsanız önce açıkça yeniden etkinleştirin."
                )
                return@launch
            }
            runCatching {
                val scope = evaluationRepository.getYazekDeclarationScope(examDraftId)
                val acknowledged = evaluationRepository.isYazekDeclarationAcknowledged(examDraftId)
                scope to acknowledged
            }.onSuccess { (scope, acknowledged) ->
                _uiState.value = _uiState.value.copy(
                    academicYear = scope.academicYear,
                    yazekAcknowledged = acknowledged,
                    yazekScopeSummary = scope.humanSummary(),
                    yazekStudentParentNotice = scope.studentParentDataNotice(),
                    showYazekGate = !acknowledged,
                    errorMessage = null
                )
                if (acknowledged) startEvaluationAfterComplianceGate()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = error.message ?: "YAZEK kapsamı doğrulanamadı; AI değerlendirmesi başlatılmadı."
                )
            }
        }
    }

    fun confirmYazekAndStart(
        referenceNote: String? = null,
        officialDeclarationApplied: Boolean,
        noticeAndConsentCompleted: Boolean
    ) {
        viewModelScope.launch {
            runCatching {
                evaluationRepository.acknowledgeYazekDeclaration(
                    examDraftId = examDraftId,
                    referenceNote = referenceNote,
                    officialDeclarationApplied = officialDeclarationApplied,
                    noticeAndConsentCompleted = noticeAndConsentCompleted
                )
            }.onSuccess {
                _uiState.value = _uiState.value.copy(
                    yazekAcknowledged = true,
                    showYazekGate = false,
                    errorMessage = null
                )
                startEvaluationAfterComplianceGate()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = error.message ?: "YAZEK kapsam doğrulaması kaydedilemedi."
                )
            }
        }
    }

    fun dismissYazekGate() {
        _uiState.value = _uiState.value.copy(showYazekGate = false)
    }

    private fun startEvaluationAfterComplianceGate() {
        viewModelScope.launch {
            if (evaluationRepository.requiresLegacyPrivacyApproval(examDraftId)) {
                _uiState.value = _uiState.value.copy(
                    showLegacyPrivacyGate = true,
                    legacyPrivacyPages = evaluationRepository.getLegacyPrivacyPages(examDraftId),
                    legacyPrivacyViewedPageIds = emptySet()
                )
                return@launch
            }
            if (evaluationRepository.isHomeworkExam(examDraftId) && evaluationRepository.requiresHomeworkPrivacyApproval(examDraftId)) {
                val privacyPages = paperUploadRepository.getPages(examDraftId).first()
                _uiState.value = _uiState.value.copy(
                    showHomeworkPrivacyGate = true,
                    homeworkPrivacyPages = privacyPages,
                    homeworkPrivacyMasks = privacyPages.associate { page -> page.id to homeworkPrivacyMaskStore?.masksForPage(page.id).orEmpty() },
                    homeworkPrivacyViewedPageIds = emptySet()
                )
                return@launch
            }
            evaluationRepository.startEvaluation(examDraftId, useBatch = false)
        }
    }

    fun markLegacyPrivacyPageViewed(pageId: Long, previewAvailable: Boolean) {
        if (!previewAvailable) return
        _uiState.value = _uiState.value.copy(
            legacyPrivacyViewedPageIds = _uiState.value.legacyPrivacyViewedPageIds + pageId
        )
    }

    fun markHomeworkPrivacyPageViewed(pageId: Long, previewAvailable: Boolean) {
        if (!previewAvailable) return
        _uiState.value = _uiState.value.copy(
            homeworkPrivacyViewedPageIds = _uiState.value.homeworkPrivacyViewedPageIds + pageId
        )
    }

    fun confirmLegacyPrivacyAndContinue() {
        viewModelScope.launch {
            runCatching {
                evaluationRepository.approveLegacyPrivacy(examDraftId, _uiState.value.legacyPrivacyViewedPageIds)
            }.onSuccess {
                _uiState.value = _uiState.value.copy(
                    showLegacyPrivacyGate = false,
                    legacyPrivacyPages = emptyList(),
                    legacyPrivacyViewedPageIds = emptySet(),
                    errorMessage = null
                )
                startEvaluationAfterComplianceGate()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = error.message ?: "Tüm eski form sayfaları güvenli biçimde görüntülenmeden devam edilemez."
                )
            }
        }
    }

    fun dismissLegacyPrivacyGate() {
        _uiState.value = _uiState.value.copy(
            showLegacyPrivacyGate = false,
            legacyPrivacyPages = emptyList(),
            legacyPrivacyViewedPageIds = emptySet()
        )
    }

    fun addHomeworkPrivacyMask(pageId: Long, normalizedX: Float, normalizedY: Float) {
        homeworkPrivacyMaskStore?.addTapMask(pageId, normalizedX, normalizedY)
        refreshHomeworkMasks()
    }

    fun undoHomeworkPrivacyMask(pageId: Long) {
        homeworkPrivacyMaskStore?.undoLast(pageId)
        refreshHomeworkMasks()
    }

    fun clearHomeworkPrivacyMasks(pageId: Long) {
        homeworkPrivacyMaskStore?.clear(pageId)
        refreshHomeworkMasks()
    }

    private fun refreshHomeworkMasks() {
        val pages = _uiState.value.homeworkPrivacyPages
        _uiState.value = _uiState.value.copy(
            homeworkPrivacyMasks = pages.associate { page -> page.id to homeworkPrivacyMaskStore?.masksForPage(page.id).orEmpty() }
        )
    }

    fun confirmHomeworkPrivacyAndStart() {
        viewModelScope.launch {
            runCatching {
                evaluationRepository.approveHomeworkPrivacy(examDraftId, _uiState.value.homeworkPrivacyViewedPageIds)
            }.onSuccess {
                homeworkPrivacyConfirmedForRun = true
                _uiState.value = _uiState.value.copy(
                    showHomeworkPrivacyGate = false,
                    homeworkPrivacyPages = emptyList(),
                    homeworkPrivacyViewedPageIds = emptySet(),
                    errorMessage = null
                )
                evaluationRepository.startEvaluation(examDraftId, useBatch = false)
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    errorMessage = error.message ?: "Tüm ödev sayfaları güvenli biçimde görüntülenmeden devam edilemez."
                )
            }
        }
    }

    fun dismissHomeworkPrivacyGate() {
        _uiState.value = _uiState.value.copy(
            showHomeworkPrivacyGate = false,
            homeworkPrivacyPages = emptyList(),
            homeworkPrivacyViewedPageIds = emptySet()
        )
    }

    fun switchToManualTeacherReview() {
        viewModelScope.launch {
            evaluationRepository.prepareManualTeacherReview(examDraftId)
                .onSuccess {
                    val pendingRemote = evaluationRepository.getPendingRemoteCleanupCount(examDraftId)
                    val message = if (pendingRemote > 0) {
                        "Manuel öğretmen değerlendirmesi hazırlandı. $pendingRemote uzak AI kaynağının silme doğrulaması bekliyor; kayıt korundu ve yeniden denenecek."
                    } else {
                        "AI kullanılmadan manuel öğretmen değerlendirmesi hazırlandı. Aktif AI işi durduruldu; Öğretmen İncelemesine geçebilirsiniz."
                    }
                    _uiState.value = _uiState.value.copy(
                        errorMessage = null,
                        currentStepMessage = message
                    )
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = error.message ?: "Manuel değerlendirme akışı hazırlanamadı."
                    )
                }
        }
    }

    fun reenableAiEvaluation() {
        viewModelScope.launch {
            runCatching { evaluationRepository.enableAiProcessing(examDraftId) }
                .onSuccess {
                    _uiState.value = _uiState.value.copy(
                        processingEvaluationSource = "AI",
                        errorMessage = null,
                        currentStepMessage = "AI değerlendirmesi öğretmen tarafından yeniden etkinleştirildi."
                    )
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(errorMessage = error.message ?: "AI modu yeniden etkinleştirilemedi.")
                }
        }
    }

    fun allowBypassCacheAndRetry() {
        evaluationRepository.allowBypassCacheForDraft(examDraftId, true)
        evaluationRepository.clearEvaluationError(examDraftId)
        startEvaluationProcess()
    }

    fun dismissError() {
        evaluationRepository.clearEvaluationError(examDraftId)
    }

    fun stopEvaluationProcess() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                currentStepMessage = "Uzak Batch durduruluyor ve veri kaynakları temizleniyor...",
                errorMessage = null
            )
            evaluationRepository.pauseEvaluationAndCancelRemote(examDraftId)
                .onSuccess {
                    _uiState.value = _uiState.value.copy(
                        isEvaluating = false,
                        currentStepMessage = "Değerlendirme durduruldu; uzak Batch iptali doğrulandı.",
                        errorMessage = null
                    )
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        isEvaluating = false,
                        currentStepMessage = null,
                        errorMessage = error.message ?: "Değerlendirme durduruldu ancak uzak Batch iptali henüz doğrulanamadı."
                    )
                }
        }
    }

    fun pauseEvaluationProcess() {
        stopEvaluationProcess()
    }

    fun retryStudentPaper(paperId: Long) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(currentEvaluatingPaperId = paperId, errorMessage = null)
            evaluationRepository.retryStudentPaper(paperId, examDraftId)
            _uiState.value = _uiState.value.copy(currentEvaluatingPaperId = null)
        }
    }

    fun selectCell(studentPaperId: Long, questionOrderIndex: Int) {
        viewModelScope.launch {
            val paper = paperUploadRepository.getPaperByIdOnce(studentPaperId) ?: return@launch
            val pages = paperUploadRepository.getPagesForPaperOnce(studentPaperId)
            val question = _uiState.value.questions.find { it.orderIndex == questionOrderIndex } ?: return@launch
            val qEvals = _uiState.value.questionEvaluations[studentPaperId] ?: emptyList()
            val qEval = qEvals.find { it.questionOrderIndex == questionOrderIndex }
            val sEval = _uiState.value.studentEvaluations[studentPaperId]

            _uiState.value = _uiState.value.copy(
                selectedDetailItem = SelectedDetailItem(
                    studentPaper = paper,
                    pages = pages,
                    question = question,
                    questionEvaluation = qEval,
                    studentEvaluation = sEval
                )
            )
        }
    }

    fun dismissDetail() {
        _uiState.value = _uiState.value.copy(selectedDetailItem = null)
    }

    class Factory(
        private val examDraftId: Long,
        private val evaluationRepository: ExamEvaluationRepository,
        private val paperUploadRepository: ExamPaperUploadRepository,
        private val questionRepository: ExamQuestionRepository,
        private val preferencesRepository: ExamEvaluationPreferencesRepository,
        private val yazekComplianceStore: YazekComplianceStore? = null,
        private val homeworkPrivacyMaskStore: HomeworkPrivacyMaskStore? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AiEvaluationViewModel(
                examDraftId,
                evaluationRepository,
                paperUploadRepository,
                questionRepository,
                preferencesRepository,
                yazekComplianceStore,
                homeworkPrivacyMaskStore
            ) as T
        }
    }
}


private fun Boolean?.orFalse(): Boolean = this ?: false
