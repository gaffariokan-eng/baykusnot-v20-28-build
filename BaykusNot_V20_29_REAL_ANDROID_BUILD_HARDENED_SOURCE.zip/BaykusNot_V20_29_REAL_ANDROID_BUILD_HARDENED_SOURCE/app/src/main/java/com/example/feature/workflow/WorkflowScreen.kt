package com.example.feature.workflow

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.EvaluatorApplication
import com.example.core.model.ExamType
import com.example.core.model.defaultWorkflowTitle
import com.example.core.model.sourceStageLabel
import com.example.core.model.workflowStages
import com.example.core.model.workflowStageLabel
import com.example.core.model.WorkflowStage
import com.example.core.ui.BaykusBanner
import com.example.core.ui.BaykusTopAppBar
import com.example.core.ui.BaykusWorkflowStepper
import com.example.core.ui.StatusType
import com.example.feature.homework.HomeworkAssignmentScreen
import com.example.feature.listening.ListeningMaterialRoute
import com.example.feature.listening.ListeningMaterialViewModel
import com.example.feature.readiness.ReadinessSourceRoute
import com.example.feature.testexam.TestAnswerKeyScreen
import com.example.feature.testexam.TestAnswerKeyViewModel
import com.example.feature.testexam.TestOpticalReadingScreen
import com.example.feature.testexam.TestOpticalReadingViewModel
import com.example.feature.preferences.EvaluationPreferencesScreen
import com.example.feature.preferences.EvaluationPreferencesViewModel

internal object WorkflowTestTags {
    const val SCREEN = "workflow_screen"
    const val LOADING = "workflow_loading"
    const val NOT_FOUND = "workflow_not_found"
    const val ERROR = "workflow_error"
    const val STEP_INDICATOR = "workflow_step_indicator"
    const val PLACEHOLDER = "workflow_placeholder"
    const val READING_PREFERENCES = "workflow_reading_preferences"
    const val MESSAGE = "workflow_message"
    const val CONTINUE_READING_PREFERENCES = "continue_reading_preferences"
    const val EXAM_INFO = "workflow_exam_info"
    const val UPLOAD_SOURCE = "workflow_upload_source"
    const val QUESTION_POINTS = "workflow_question_points"
}

@Composable
fun WorkflowScreen(
    draftId: Long,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val application = context.applicationContext as EvaluatorApplication
    val appContainer = application.container
    
    val viewModel: WorkflowViewModel = viewModel(
        factory = WorkflowViewModel.Factory(
            examDraftRepository = appContainer.examDraftRepository,
            sourceDocumentRepository = appContainer.examSourceDocumentRepository,
            listeningMaterialRepository = appContainer.examListeningMaterialRepository,
            preferencesRepository = appContainer.examEvaluationPreferencesRepository,
            examQuestionRepository = appContainer.examQuestionRepository,
            examRubricRepository = appContainer.examRubricRepository,
            examAnswerSheetRepository = appContainer.examAnswerSheetRepository,
            examPaperUploadRepository = appContainer.examPaperUploadRepository,
            examEvaluationRepository = appContainer.examEvaluationRepository,
            draftId = draftId
        )
    )
    
    val uiState by viewModel.uiState.collectAsState()

    var readingPreferencesLocked = false
    var readingPreferencesAdvanceRequested by remember(draftId) { mutableStateOf(false) }
    var readingPreferencesContent: @Composable () -> Unit = {}
    
    var questionPointsContent: @Composable () -> Unit = {}
    var rubricContent: @Composable () -> Unit = {}
    var answerSheetContent: @Composable () -> Unit = {}
    var reportsContent: @Composable () -> Unit = {}
    
    var examInfoSaveMessage by remember(draftId) { mutableStateOf<String?>(null) }
    var isExamInfoSaveRequested by remember(draftId) { mutableStateOf(false) }
    var showExamInfoDeleteConfirm by remember(draftId) { mutableStateOf(false) }
    var examInfoDeletionNotice by remember(draftId) { mutableStateOf<String?>(null) }
    var examInfoContent: @Composable () -> Unit = {}
    
    var uploadSourceContent: @Composable () -> Unit = {}
    
    if (uiState.currentStage == WorkflowStage.UPLOAD_SOURCE && uiState.draft?.examType == ExamType.WRITTEN) {
        val uploadSourceViewModel: UploadSourceViewModel = viewModel(
            key = "upload_source_$draftId",
            factory = UploadSourceViewModel.Factory(
                examDraftRepository = appContainer.examDraftRepository,
                sourceDocumentRepository = appContainer.examSourceDocumentRepository,
                coordinator = appContainer.examQuestionExtractionCoordinator,
                questionRepository = appContainer.examQuestionRepository,
                objectiveRepository = appContainer.examObjectiveRepository,
                scenarioExtractor = appContainer.examScenarioExtractor,
                draftId = draftId
            )
        )
        val pdfSelectionResolver = remember(context) {
            com.example.core.data.AndroidPdfSelectionResolver(context.contentResolver)
        }
        uploadSourceContent = {
            UploadSourceRoute(
                viewModel = uploadSourceViewModel,
                pdfSelectionResolver = pdfSelectionResolver,
                onContinue = viewModel::advanceFromUploadSource,
                copy = UploadSourceCopy()
            )
        }
    } else if (uiState.currentStage == WorkflowStage.UPLOAD_SOURCE && uiState.draft?.examType == ExamType.READINESS) {
        val readinessSourceViewModel: UploadSourceViewModel = viewModel(
            key = "readiness_source_$draftId",
            factory = UploadSourceViewModel.Factory(
                examDraftRepository = appContainer.examDraftRepository,
                sourceDocumentRepository = appContainer.examSourceDocumentRepository,
                coordinator = appContainer.examQuestionExtractionCoordinator,
                questionRepository = appContainer.examQuestionRepository,
                objectiveRepository = appContainer.examObjectiveRepository,
                scenarioExtractor = appContainer.examScenarioExtractor,
                draftId = draftId
            )
        )
        val readinessSourceResolver = remember(context) {
            com.example.core.data.AndroidPdfSelectionResolver(context.contentResolver)
        }
        uploadSourceContent = {
            ReadinessSourceRoute(
                viewModel = readinessSourceViewModel,
                pdfSelectionResolver = readinessSourceResolver,
                onContinue = viewModel::advanceFromUploadSource,
                modifier = Modifier.fillMaxSize()
            )
        }
    } else if (uiState.currentStage == WorkflowStage.UPLOAD_SOURCE && uiState.draft?.examType == ExamType.LISTENING) {
        val listeningMaterialViewModel: ListeningMaterialViewModel = viewModel(
            key = "listening_material_$draftId",
            factory = ListeningMaterialViewModel.Factory(
                repository = appContainer.examListeningMaterialRepository,
                questionRepository = appContainer.examQuestionRepository,
                draftId = draftId
            )
        )
        uploadSourceContent = {
            ListeningMaterialRoute(
                viewModel = listeningMaterialViewModel,
                onContinue = viewModel::advanceFromUploadSource,
                modifier = Modifier.fillMaxSize()
            )
        }
    } else if (uiState.currentStage == WorkflowStage.UPLOAD_SOURCE && uiState.draft?.examType == ExamType.HOMEWORK) {
        uploadSourceContent = {
            HomeworkAssignmentScreen(
                draftId = draftId,
                draftRepository = appContainer.examDraftRepository,
                questionRepository = appContainer.examQuestionRepository,
                rubricRepository = appContainer.examRubricRepository,
                preferencesRepository = appContainer.examEvaluationPreferencesRepository,
                onContinue = viewModel::advanceFromUploadSource,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    if (uiState.currentStage == WorkflowStage.EXAM_INFO) {
        val newDraftViewModel: NewDraftViewModel = viewModel(
            key = "exam_info_$draftId",
            factory = NewDraftViewModel.Factory(
                draftRepository = appContainer.examDraftRepository,
                profileRepository = appContainer.teacherProfileRepository,
                deletionRepository = appContainer.examDeletionRepository,
                objectiveRepository = appContainer.examObjectiveRepository,
                examTypeId = uiState.draft?.examType?.name.orEmpty(),
                draftId = draftId
            )
        )
        val examInfoUiState by newDraftViewModel.uiState.collectAsState()
        
        examInfoContent = {
            ExamInfoContent(
                uiState = examInfoUiState,
                isEditMode = true,
                onFieldChange = newDraftViewModel::updateField,
                onToggleTeacher = newDraftViewModel::toggleTeacher,
                onSave = {
                    if (!isExamInfoSaveRequested && !uiState.isAdvancing) {
                        isExamInfoSaveRequested = true
                        examInfoSaveMessage = null
                        newDraftViewModel.saveDraft(
                            onSuccess = {
                                isExamInfoSaveRequested = false
                                examInfoSaveMessage = null
                                viewModel.advanceFromExamInfo()
                            },
                            onError = { message ->
                                isExamInfoSaveRequested = false
                                examInfoSaveMessage = message
                            }
                        )
                    }
                },
                onDeleteRequest = { showExamInfoDeleteConfirm = true },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (showExamInfoDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showExamInfoDeleteConfirm = false },
                title = { Text("Taslağı Sil") },
                text = { Text("Bu çalışma ve bağlı uygulama verileri kalıcı olarak silinecek. Daha önce dışa aktarıp cihazda seçtiğiniz konuma kaydettiğiniz PDF kopyaları otomatik silinmez. Bu işlem geri alınamaz.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showExamInfoDeleteConfirm = false
                            newDraftViewModel.deleteDraft(
                                onDeleted = { notice ->
                                    if (notice == null) onNavigateBack()
                                    else examInfoDeletionNotice = notice
                                },
                                onError = { message -> examInfoSaveMessage = message }
                            )
                        }
                    ) { Text("Sil", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = {
                    TextButton(onClick = { showExamInfoDeleteConfirm = false }) { Text("Vazgeç") }
                }
            )
        }

        if (examInfoDeletionNotice != null) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Silme işlemi izleniyor") },
                text = { Text(examInfoDeletionNotice.orEmpty()) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            examInfoDeletionNotice = null
                            onNavigateBack()
                        }
                    ) { Text("Tamam") }
                }
            )
        }
    }

    if (uiState.currentStage == WorkflowStage.READING_PREFS) {
        val preferencesViewModel: EvaluationPreferencesViewModel = viewModel(
            key = "evaluation_preferences_$draftId",
            factory = EvaluationPreferencesViewModel.Factory(
                preferencesRepository = appContainer.examEvaluationPreferencesRepository,
                examDraftRepository = appContainer.examDraftRepository,
                paperUploadRepository = appContainer.examPaperUploadRepository,
                questionRepository = appContainer.examQuestionRepository,
                rubricRepository = appContainer.examRubricRepository,
                answerSheetRepository = appContainer.examAnswerSheetRepository,
                examDraftId = draftId
            )
        )
        val preferencesUiState by preferencesViewModel.uiState.collectAsState()
        readingPreferencesLocked = preferencesUiState.isLocked == true

        LaunchedEffect(
            readingPreferencesAdvanceRequested,
            preferencesUiState.isSaving,
            preferencesUiState.isLocking,
            preferencesUiState.isLocked,
            preferencesUiState.preferencesExist,
            preferencesUiState.isDirty
        ) {
            if (!readingPreferencesAdvanceRequested || preferencesUiState.isSaving || preferencesUiState.isLocking) return@LaunchedEffect
            when {
                preferencesUiState.isLocked == true -> {
                    readingPreferencesAdvanceRequested = false
                    viewModel.advanceFromReadingPreferences()
                }
                !preferencesUiState.preferencesExist || preferencesUiState.isDirty -> preferencesViewModel.savePreferences()
                else -> preferencesViewModel.lockPreferences()
            }
        }

        readingPreferencesContent = {
            EvaluationPreferencesScreen(
                uiState = preferencesUiState,
                onEvaluationModeChange = preferencesViewModel::updateEvaluationMode,
                onRubricAdherenceLevelChange = preferencesViewModel::updateRubricAdherenceLevel,
                onFeedbackDetailLevelChange = preferencesViewModel::updateFeedbackDetailLevel,
                onDeductWritingAndPunctuationPointsChange = preferencesViewModel::updateDeductWritingAndPunctuationPoints,
                onProvideWritingAndPunctuationFeedbackChange = preferencesViewModel::updateProvideWritingAndPunctuationFeedback,
                onModelQualityTierChange = preferencesViewModel::updateModelQualityTier,
                onReportClassChange = preferencesViewModel::updateReportClass,
                onReportIndividualChange = preferencesViewModel::updateReportIndividual,
                onReportQuestionChange = preferencesViewModel::updateReportQuestion,
                onUseBatchApiChange = preferencesViewModel::updateUseBatchApi,
                onUsePromptCachingChange = preferencesViewModel::updateUsePromptCaching,
                onCalculateCost = preferencesViewModel::calculateCost,
                onShowConfirmation = preferencesViewModel::showConfirmationDialog,
                onDismissConfirmation = preferencesViewModel::dismissConfirmationDialog,
                onConfirmAndLock = { readingPreferencesAdvanceRequested = true },
                onUnlockPreferences = preferencesViewModel::unlockPreferences,
                onSavePreferences = { readingPreferencesAdvanceRequested = true },
                onLockPreferences = { readingPreferencesAdvanceRequested = true },
                onLoadCopySources = preferencesViewModel::loadCopySources,
                onCopySourceSelected = preferencesViewModel::selectCopySource,
                onCopyPreferences = preferencesViewModel::copyPreferences,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    if (uiState.currentStage == WorkflowStage.QUESTION_POINTS) {
        questionPointsContent = {
            if (uiState.draft?.examType == ExamType.LISTENING) {
                ListeningQuestionSetupRoute(
                    draftId = draftId,
                    examQuestionRepository = appContainer.examQuestionRepository,
                    examDraftRepository = appContainer.examDraftRepository,
                    examQuestionExtractionDraftRepository = appContainer.examQuestionExtractionDraftRepository,
                    objectiveRepository = appContainer.examObjectiveRepository,
                    matcher = appContainer.questionObjectiveMatcher,
                    examRubricRepository = appContainer.examRubricRepository,
                    examListeningMaterialRepository = appContainer.examListeningMaterialRepository,
                    sourceDocumentRepository = appContainer.examSourceDocumentRepository,
                    coordinator = appContainer.examQuestionExtractionCoordinator,
                    scenarioExtractor = appContainer.examScenarioExtractor,
                    onContinue = viewModel::advanceFromQuestionPoints,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                QuestionPointsRoute(
                    draftId = draftId,
                    examQuestionRepository = appContainer.examQuestionRepository,
                    examDraftRepository = appContainer.examDraftRepository,
                    examQuestionExtractionDraftRepository = appContainer.examQuestionExtractionDraftRepository,
                    objectiveRepository = appContainer.examObjectiveRepository,
                    matcher = appContainer.questionObjectiveMatcher,
                    examRubricRepository = appContainer.examRubricRepository,
                    examListeningMaterialRepository = appContainer.examListeningMaterialRepository,
                    onContinue = viewModel::advanceFromQuestionPoints,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    if (uiState.currentStage == WorkflowStage.RUBRIC) {
        if (uiState.draft?.examType == ExamType.MULTIPLE_CHOICE) {
            val answerKeyViewModel: TestAnswerKeyViewModel = viewModel(
                key = "test_answer_key_$draftId",
                factory = TestAnswerKeyViewModel.Factory(
                    draftId = draftId,
                    draftRepository = appContainer.examDraftRepository,
                    questionRepository = appContainer.examQuestionRepository,
                    rubricRepository = appContainer.examRubricRepository,
                    evaluationRepository = appContainer.examEvaluationRepository,
                    paperUploadRepository = appContainer.examPaperUploadRepository
                )
            )
            rubricContent = {
                TestAnswerKeyScreen(
                    viewModel = answerKeyViewModel,
                    onContinue = viewModel::advanceFromRubric,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            rubricContent = {
                RubricRoute(
                    draftId = draftId,
                    examRubricRepository = appContainer.examRubricRepository,
                    examQuestionRepository = appContainer.examQuestionRepository,
                    examDraftRepository = appContainer.examDraftRepository,
                    preferencesRepository = appContainer.examEvaluationPreferencesRepository,
                    examListeningMaterialRepository = appContainer.examListeningMaterialRepository,
                    rubricGenerationCoordinator = appContainer.examRubricGenerationCoordinator,
                    examRubricGenerator = appContainer.examRubricGenerator,
                    onContinue = viewModel::advanceFromRubric,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    if (uiState.currentStage == WorkflowStage.ANSWER_SHEET) {
        answerSheetContent = {
            AnswerSheetRoute(
                draftId = draftId,
                repository = appContainer.examAnswerSheetRepository,
                onContinue = viewModel::advanceFromAnswerSheet,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    var uploadPapersContent: @Composable () -> Unit = {}
    if (uiState.currentStage == WorkflowStage.UPLOAD_PAPERS) {
        uploadPapersContent = {
            UploadPapersRoute(
                examDraftId = draftId,
                examType = uiState.draft?.examType ?: ExamType.WRITTEN,
                uploadRepository = appContainer.examPaperUploadRepository,
                answerSheetRepository = appContainer.examAnswerSheetRepository,
                onContinue = viewModel::advanceFromUploadPapers,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    var aiEvaluationContent: @Composable () -> Unit = {}
    if (uiState.currentStage == WorkflowStage.AI_EVALUATION) {
        if (uiState.draft?.examType == ExamType.MULTIPLE_CHOICE) {
            val opticalViewModel: TestOpticalReadingViewModel = viewModel(
                key = "test_optical_$draftId",
                factory = TestOpticalReadingViewModel.Factory(
                    examDraftId = draftId,
                    evaluationRepository = appContainer.examEvaluationRepository,
                    paperUploadRepository = appContainer.examPaperUploadRepository,
                    questionRepository = appContainer.examQuestionRepository
                )
            )
            aiEvaluationContent = {
                TestOpticalReadingScreen(
                    viewModel = opticalViewModel,
                    onContinue = viewModel::advanceFromAiEvaluation,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            val aiEvaluationViewModel: AiEvaluationViewModel = viewModel(
                key = "ai_evaluation_$draftId",
                factory = AiEvaluationViewModel.Factory(
                    examDraftId = draftId,
                    evaluationRepository = appContainer.examEvaluationRepository,
                    paperUploadRepository = appContainer.examPaperUploadRepository,
                    questionRepository = appContainer.examQuestionRepository,
                    preferencesRepository = appContainer.examEvaluationPreferencesRepository,
                    yazekComplianceStore = appContainer.yazekComplianceStore,
                    homeworkPrivacyMaskStore = appContainer.homeworkPrivacyMaskStore
                )
            )
            aiEvaluationContent = {
                AiEvaluationScreen(
                    viewModel = aiEvaluationViewModel,
                    examType = uiState.draft?.examType ?: ExamType.WRITTEN,
                    onAdvanceToTeacherReview = viewModel::advanceFromAiEvaluation,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    var teacherReviewContent: @Composable () -> Unit = {}
    if (uiState.currentStage == WorkflowStage.TEACHER_REVIEW) {
        teacherReviewContent = {
            TeacherReviewRoute(
                draftId = draftId,
                examType = uiState.draft?.examType ?: ExamType.WRITTEN,
                evaluationRepository = appContainer.examEvaluationRepository,
                paperUploadRepository = appContainer.examPaperUploadRepository,
                questionRepository = appContainer.examQuestionRepository,
                onAdvanceToReports = viewModel::advanceFromTeacherReview,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    if (uiState.currentStage == WorkflowStage.REPORTS) {
        val reportsViewModel: ReportsViewModel = viewModel(
            key = "reports_$draftId",
            factory = ReportsViewModel.Factory(
                draftRepository = appContainer.examDraftRepository,
                evaluationRepository = appContainer.examEvaluationRepository,
                paperUploadRepository = appContainer.examPaperUploadRepository,
                evaluationDao = appContainer.examEvaluationDao,
                paperDao = appContainer.examPaperUploadDao,
                questionDao = appContainer.examQuestionDao,
                preferencesDao = appContainer.examEvaluationPreferencesDao,
                objectiveRepository = appContainer.examObjectiveRepository,
                draftId = draftId
            )
        )
        reportsContent = {
            ReportsScreen(
                viewModel = reportsViewModel,
                onNavigateBack = onNavigateBack
            )
        }
    }

    WorkflowContent(
        uiState = uiState,
        onNavigateBack = onNavigateBack,
        examInfoMessage = examInfoSaveMessage,
        examInfoContent = examInfoContent,
        uploadSourceContent = uploadSourceContent,
        readingPreferencesLocked = readingPreferencesLocked,
        onContinueFromReadingPreferences = viewModel::advanceFromReadingPreferences,
        readingPreferencesContent = readingPreferencesContent,
        questionPointsContent = questionPointsContent,
        rubricContent = rubricContent,
        answerSheetContent = answerSheetContent,
        uploadPapersContent = uploadPapersContent,
        aiEvaluationContent = aiEvaluationContent,
        teacherReviewContent = teacherReviewContent,
        reportsContent = reportsContent,
        onStageClick = viewModel::selectStage
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun WorkflowContent(
    uiState: WorkflowUiState,
    onNavigateBack: () -> Unit,
    examInfoMessage: String?,
    examInfoContent: @Composable () -> Unit,
    uploadSourceContent: @Composable () -> Unit,
    readingPreferencesLocked: Boolean,
    onContinueFromReadingPreferences: () -> Unit,
    readingPreferencesContent: @Composable () -> Unit,
    questionPointsContent: @Composable () -> Unit = {},
    rubricContent: @Composable () -> Unit = {},
    answerSheetContent: @Composable () -> Unit = {},
    uploadPapersContent: @Composable () -> Unit = {},
    aiEvaluationContent: @Composable () -> Unit = {},
    teacherReviewContent: @Composable () -> Unit = {},
    reportsContent: @Composable () -> Unit = {},
    onStageClick: (WorkflowStage) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val draftTitle = uiState.draft?.draftName?.takeIf { it.isNotBlank() }
        ?: uiState.draft?.examType?.defaultWorkflowTitle()
        ?: "Sınav Değerlendirme"

    Scaffold(
        modifier = modifier.testTag(WorkflowTestTags.SCREEN),
        topBar = {
            BaykusTopAppBar(
                title = draftTitle,
                subtitle = when (uiState.draft?.examType) {
                    ExamType.HOMEWORK -> "Ödev Kontrolü İş Akışı"
                    ExamType.READINESS -> "Hazırbulunuşluk Sınavı İş Akışı"
                    else -> "Sınav İş Akışı"
                },
                onNavigateBack = onNavigateBack
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (uiState.isLoading) {
                Box(modifier = Modifier.fillMaxSize().testTag(WorkflowTestTags.LOADING), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            if (uiState.draft?.examType == ExamType.HOMEWORK) "Ödev kontrolü yükleniyor..." else "Sınav iş akışı yükleniyor...",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            } else if (uiState.draftExists == false) {
                Box(modifier = Modifier.fillMaxSize().testTag(WorkflowTestTags.NOT_FOUND), contentAlignment = Alignment.Center) {
                    Text("Sınav taslağı bulunamadı.", style = MaterialTheme.typography.bodyLarge)
                }
            } else if (uiState.draftExists == null && uiState.message != null) {
                Box(modifier = Modifier.fillMaxSize().testTag(WorkflowTestTags.ERROR), contentAlignment = Alignment.Center) {
                    Text(uiState.message ?: "Sınav iş akışı yüklenemedi.", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                val currentStage = uiState.currentStage ?: WorkflowStage.EXAM_INFO
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.testTag(WorkflowTestTags.STEP_INDICATOR)) {
                        WorkflowStepIndicator(
                            currentStage = currentStage,
                            furthestStage = uiState.draft?.currentWorkflowStage ?: WorkflowStage.EXAM_INFO,
                            isQuestionsLocked = uiState.isQuestionsLocked,
                            isRubricLocked = uiState.isRubricLocked,
                            isPreferencesLocked = uiState.isPreferencesLocked,
                            isAnswerSheetStale = uiState.isAnswerSheetStale,
                            examInfoStageLabel = (uiState.draft?.examType ?: ExamType.WRITTEN).workflowStageLabel(WorkflowStage.EXAM_INFO),
                            sourceStageLabel = uiState.draft?.examType?.sourceStageLabel() ?: "Sınav Kaynağı",
                            questionStageLabel = (uiState.draft?.examType ?: ExamType.WRITTEN).workflowStageLabel(WorkflowStage.QUESTION_POINTS),
                            rubricStageLabel = (uiState.draft?.examType ?: ExamType.WRITTEN).workflowStageLabel(WorkflowStage.RUBRIC),
                            uploadPapersStageLabel = submissionCopy(uiState.draft?.examType ?: ExamType.WRITTEN).stageLabel,
                            evaluationStageLabel = (uiState.draft?.examType ?: ExamType.WRITTEN).workflowStageLabel(WorkflowStage.AI_EVALUATION),
                            visibleStages = (uiState.draft?.examType ?: ExamType.WRITTEN).workflowStages(),
                            onStageClick = onStageClick
                        )
                    }
                    
                    val visibleMessage = uiState.message ?: examInfoMessage
                    if (visibleMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        BaykusBanner(
                            message = visibleMessage,
                            type = StatusType.ERROR,
                            modifier = Modifier.testTag(WorkflowTestTags.MESSAGE)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        when (currentStage) {
                            WorkflowStage.EXAM_INFO -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag(WorkflowTestTags.EXAM_INFO)
                                ) {
                                    examInfoContent()
                                }
                            }
                            WorkflowStage.UPLOAD_SOURCE -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag(WorkflowTestTags.UPLOAD_SOURCE)
                                ) {
                                    uploadSourceContent()
                                }
                            }
                            WorkflowStage.READING_PREFS -> {
                                Column(
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                    ) {
                                        readingPreferencesContent()
                                    }

                                    if (readingPreferencesLocked) {
                                        Button(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp)
                                                .testTag(WorkflowTestTags.CONTINUE_READING_PREFERENCES),
                                            enabled = !uiState.isAdvancing,
                                            onClick = onContinueFromReadingPreferences
                                        ) {
                                            Text(
                                                if (uiState.isAdvancing) {
                                                    "Geçiliyor..."
                                                } else {
                                                    "İlerle"
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                            WorkflowStage.QUESTION_POINTS -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag(WorkflowTestTags.QUESTION_POINTS)
                                ) {
                                    questionPointsContent()
                                }
                            }
                            WorkflowStage.RUBRIC -> {
                                rubricContent()
                            }
                            WorkflowStage.ANSWER_SHEET -> {
                                answerSheetContent()
                            }
                            WorkflowStage.UPLOAD_PAPERS -> {
                                uploadPapersContent()
                            }
                            WorkflowStage.AI_EVALUATION -> {
                                aiEvaluationContent()
                            }
                            WorkflowStage.TEACHER_REVIEW -> {
                                teacherReviewContent()
                            }
                            WorkflowStage.REPORTS -> {
                                reportsContent()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkflowStepIndicator(
    currentStage: WorkflowStage,
    furthestStage: WorkflowStage,
    isQuestionsLocked: Boolean,
    isRubricLocked: Boolean,
    isPreferencesLocked: Boolean,
    isAnswerSheetStale: Boolean,
    examInfoStageLabel: String = "Sınav Bilgileri",
    sourceStageLabel: String = "Boş Sınav",
    questionStageLabel: String = "Sorular",
    rubricStageLabel: String = "Rubrik",
    uploadPapersStageLabel: String = "Öğrenci Kâğıtları",
    evaluationStageLabel: String = "Değerlendirme",
    visibleStages: List<WorkflowStage> = WorkflowStage.values().sortedBy { it.order },
    onStageClick: (WorkflowStage) -> Unit
) {
    BaykusWorkflowStepper(
        currentStage = currentStage,
        furthestStage = furthestStage,
        isQuestionsLocked = isQuestionsLocked,
        isRubricLocked = isRubricLocked,
        isPreferencesLocked = isPreferencesLocked,
        isAnswerSheetStale = isAnswerSheetStale,
        examInfoStageLabel = examInfoStageLabel,
        sourceStageLabel = sourceStageLabel,
        questionStageLabel = questionStageLabel,
        rubricStageLabel = rubricStageLabel,
        uploadPapersStageLabel = uploadPapersStageLabel,
        evaluationStageLabel = evaluationStageLabel,
        visibleStages = visibleStages,
        onStageClick = onStageClick
    )
}

private fun getStageDisplayName(stage: WorkflowStage): String {
    return when (stage) {
        WorkflowStage.EXAM_INFO -> "Sınav Bilgileri"
        WorkflowStage.UPLOAD_SOURCE -> "Sınav Kaynağı"
        WorkflowStage.QUESTION_POINTS -> "Soru ve Puanlar"
        WorkflowStage.RUBRIC -> "Rubrik"
        WorkflowStage.ANSWER_SHEET -> "Cevap Kâğıdı"
        WorkflowStage.UPLOAD_PAPERS -> "Öğrenci Kâğıtları"
        WorkflowStage.READING_PREFS -> "Değerlendirme Tercihleri"
        WorkflowStage.AI_EVALUATION -> "Yapay Zekâ Değerlendirmesi"
        WorkflowStage.TEACHER_REVIEW -> "Öğretmen İncelemesi"
        WorkflowStage.REPORTS -> "Raporlar"
    }
}
