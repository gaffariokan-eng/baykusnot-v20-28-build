package com.example.feature.testexam

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamEvaluationRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.TestOpticalFormReader
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class TestOpticalPaperItem(
    val paperId: Long,
    val studentSequence: Int,
    val studentLabel: String,
    val status: String,
    val scoreText: String? = null,
    val needsReview: Boolean = false,
    val error: String? = null
)

data class TestOpticalReadingUiState(
    val isLoading: Boolean = true,
    val isReading: Boolean = false,
    val progressText: String? = null,
    val items: List<TestOpticalPaperItem> = emptyList(),
    val message: String? = null,
    val canContinue: Boolean = false
)

class TestOpticalReadingViewModel(
    private val examDraftId: Long,
    private val evaluationRepository: ExamEvaluationRepository,
    private val paperUploadRepository: ExamPaperUploadRepository,
    private val questionRepository: ExamQuestionRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(TestOpticalReadingUiState())
    val uiState: StateFlow<TestOpticalReadingUiState> = _uiState.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            try {
                val papers = paperUploadRepository.getStudentPapersOnce(examDraftId).sortedBy { it.studentSequenceIndex }
                val evals = evaluationRepository.getStudentEvaluationsForExamOnce(examDraftId).associateBy { it.studentPaperId }
                val items = papers.map { paper ->
                    val ev = evals[paper.id]
                    TestOpticalPaperItem(
                        paperId = paper.id,
                        studentSequence = paper.studentSequenceIndex,
                        studentLabel = listOfNotNull(
                            paper.studentName?.takeIf { it.isNotBlank() },
                            paper.schoolNumber?.takeIf { it.isNotBlank() }?.let { "No $it" },
                            listOfNotNull(paper.classLevel, paper.branch).takeIf { it.isNotEmpty() }?.joinToString("/")
                        ).joinToString(" • ").ifBlank { "Öğrenci #${paper.studentSequenceIndex}" },
                        status = ev?.status ?: "WAITING",
                        scoreText = ev?.let { "${formatScore(it.totalScore)} / ${formatScore(it.totalMaxScore)}" },
                        needsReview = ev?.needsReview == true,
                        error = ev?.errorMessage
                    )
                }
                val canContinue = papers.isNotEmpty() && papers.all { paper ->
                    evals[paper.id]?.status in setOf("COMPLETED", "NEEDS_REVIEW")
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    items = items,
                    canContinue = canContinue,
                    progressText = if (_uiState.value.isReading) _uiState.value.progressText else null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, message = e.message ?: "Test cevapları yüklenemedi.")
            }
        }
    }

    fun startLocalReading() {
        if (_uiState.value.isReading) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isReading = true, message = null, canContinue = false)
            try {
                val papers = paperUploadRepository.getStudentPapersOnce(examDraftId).sortedBy { it.studentSequenceIndex }
                if (papers.isEmpty()) throw IllegalStateException("Okunacak test cevap formu bulunamadı.")
                val questions = questionRepository.getQuestionsEntitiesOnce(examDraftId)
                if (questions.isEmpty()) throw IllegalStateException("Kilitli test soruları bulunamadı.")
                val answerKey = evaluationRepository.getRubricsOnce(examDraftId)
                if (answerKey.isEmpty()) throw IllegalStateException("Kilitli cevap anahtarı bulunamadı.")
                val density = paperUploadRepository.getLayoutDensity(examDraftId)

                val failures = mutableListOf<String>()
                papers.forEachIndexed { index, paper ->
                    _uiState.value = _uiState.value.copy(
                        progressText = "${index + 1} / ${papers.size} — Öğrenci #${paper.studentSequenceIndex} optik olarak okunuyor"
                    )
                    val pages = paperUploadRepository.getPagesForPaperOnce(paper.id)
                    val read = TestOpticalFormReader.read(
                        pages = pages,
                        questions = questions,
                        answerKeyCriteria = answerKey,
                        densitySetting = density
                    )
                    val saved = evaluationRepository.saveLocalMultipleChoiceEvaluation(
                        studentPaperId = paper.id,
                        examDraftId = examDraftId,
                        opticalRead = read
                    )
                    if (saved.isFailure) {
                        failures += "Öğrenci #${paper.studentSequenceIndex}: ${saved.exceptionOrNull()?.message ?: "okunamadı"}"
                    }
                    refreshSnapshot(papers.size, index + 1)
                }
                _uiState.value = _uiState.value.copy(
                    isReading = false,
                    progressText = null,
                    message = if (failures.isEmpty()) {
                        "Yerel optik okuma tamamlandı. Belirsiz/çift işaretler öğretmen incelemesine gönderildi."
                    } else {
                        "${failures.size} cevap formu tamamlanamadı. İlk hata: ${failures.first()}"
                    }
                )
                refresh()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isReading = false,
                    progressText = null,
                    message = e.message ?: "Yerel optik okuma tamamlanamadı."
                )
                refresh()
            }
        }
    }

    private suspend fun refreshSnapshot(total: Int, completed: Int) {
        val papers = paperUploadRepository.getStudentPapersOnce(examDraftId).sortedBy { it.studentSequenceIndex }
        val evals = evaluationRepository.getStudentEvaluationsForExamOnce(examDraftId).associateBy { it.studentPaperId }
        _uiState.value = _uiState.value.copy(
            items = papers.map { paper ->
                val ev = evals[paper.id]
                TestOpticalPaperItem(
                    paperId = paper.id,
                    studentSequence = paper.studentSequenceIndex,
                    studentLabel = paper.studentName?.takeIf { it.isNotBlank() } ?: "Öğrenci #${paper.studentSequenceIndex}",
                    status = ev?.status ?: "WAITING",
                    scoreText = ev?.let { "${formatScore(it.totalScore)} / ${formatScore(it.totalMaxScore)}" },
                    needsReview = ev?.needsReview == true,
                    error = ev?.errorMessage
                )
            },
            progressText = "$completed / $total cevap formu işlendi"
        )
    }

    private fun formatScore(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)

    class Factory(
        private val examDraftId: Long,
        private val evaluationRepository: ExamEvaluationRepository,
        private val paperUploadRepository: ExamPaperUploadRepository,
        private val questionRepository: ExamQuestionRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            TestOpticalReadingViewModel(examDraftId, evaluationRepository, paperUploadRepository, questionRepository) as T
    }
}
