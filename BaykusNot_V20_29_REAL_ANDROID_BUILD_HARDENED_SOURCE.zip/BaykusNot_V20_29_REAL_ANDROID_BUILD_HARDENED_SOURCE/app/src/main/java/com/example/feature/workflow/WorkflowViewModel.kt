package com.example.feature.workflow

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamSourceDocumentRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamEvaluationPreferencesRepository
import com.example.core.database.ExamDraftEntity
import com.example.core.model.WorkflowStage
import com.example.core.model.ExamType
import com.example.core.model.isWorkflowStageSupported
import com.example.core.model.stageAfterRubric
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

import com.example.core.data.ExamAnswerSheetRepository
import com.example.core.data.PdfStatus
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.validateStudentIdentity

data class WorkflowUiState(
    val isLoading: Boolean = true,
    val draftExists: Boolean? = null,
    val draft: ExamDraftEntity? = null,
    val currentStage: WorkflowStage? = null,
    val message: String? = null,
    val isAdvancing: Boolean = false,
    val isQuestionsLocked: Boolean = false,
    val isRubricLocked: Boolean = false,
    val isPreferencesLocked: Boolean = false,
    val isAnswerSheetStale: Boolean = false
)

class WorkflowViewModel(
    private val examDraftRepository: ExamDraftRepository,
    private val sourceDocumentRepository: ExamSourceDocumentRepository,
    private val listeningMaterialRepository: ExamListeningMaterialRepository,
    private val preferencesRepository: ExamEvaluationPreferencesRepository,
    private val examQuestionRepository: ExamQuestionRepository,
    private val examRubricRepository: ExamRubricRepository,
    private val examAnswerSheetRepository: ExamAnswerSheetRepository,
    private val examPaperUploadRepository: ExamPaperUploadRepository,
    private val examEvaluationRepository: com.example.core.data.ExamEvaluationRepository,
    private val draftId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkflowUiState())
    val uiState: StateFlow<WorkflowUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                var entity = examDraftRepository.getDraftByIdOnce(draftId)
                if (entity != null) {
                    // v16 homework migration: the visible Homework flow is now intentionally simple:
                    // information -> "Ödev neydi?" -> student submissions -> evaluation -> review -> reports.
                    // Older drafts parked on removed question/rubric/answer-sheet/preferences stages are
                    // returned to the assignment-description screen so they can be normalized safely.
                    if (entity.examType == ExamType.HOMEWORK && entity.currentWorkflowStage in setOf(
                            WorkflowStage.QUESTION_POINTS,
                            WorkflowStage.RUBRIC,
                            WorkflowStage.ANSWER_SHEET,
                            WorkflowStage.READING_PREFS
                        )) {
                        entity = entity.copy(currentWorkflowStage = WorkflowStage.UPLOAD_SOURCE, updatedAt = System.currentTimeMillis())
                        examDraftRepository.updateDraft(entity)
                    }
                    // Test Phase 2 migration: Test no longer uploads a blank test for AI
                    // question extraction and no longer uses AI evaluation preferences.
                    // Older Test drafts parked on those obsolete stages are moved to the
                    // nearest supported local stage without discarding existing data.
                    if (entity.examType == ExamType.MULTIPLE_CHOICE &&
                        entity.currentWorkflowStage in setOf(WorkflowStage.UPLOAD_SOURCE, WorkflowStage.QUESTION_POINTS)) {
                        entity = entity.copy(currentWorkflowStage = WorkflowStage.RUBRIC, updatedAt = System.currentTimeMillis())
                        examDraftRepository.updateDraft(entity)
                    } else if (entity.examType == ExamType.MULTIPLE_CHOICE && entity.currentWorkflowStage == WorkflowStage.READING_PREFS) {
                        entity = entity.copy(currentWorkflowStage = WorkflowStage.AI_EVALUATION, updatedAt = System.currentTimeMillis())
                        examDraftRepository.updateDraft(entity)
                    }
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = true,
                        draft = entity,
                        currentStage = entity.currentWorkflowStage,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        message = "Sınav taslağı bulunamadı."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    draftExists = null,
                    draft = null,
                    currentStage = null,
                    message = "Sınav iş akışı yüklenemedi."
                )
            }
        }

        viewModelScope.launch {
            try {
                examQuestionRepository.observeMetadata(draftId).collect { meta ->
                    _uiState.value = _uiState.value.copy(
                        isQuestionsLocked = meta?.isLocked == true
                    )
                    checkAnswerSheetStale()
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isQuestionsLocked = false,
                    message = "Soru kilidi doğrulanamadı. İlerleme güvenlik nedeniyle durduruldu."
                )
            }
        }

        viewModelScope.launch {
            try {
                examRubricRepository.observeMetadata(draftId).collect { meta ->
                    _uiState.value = _uiState.value.copy(
                        isRubricLocked = meta?.isLocked == true
                    )
                    checkAnswerSheetStale()
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isRubricLocked = false,
                    message = "Rubrik kilidi doğrulanamadı. İlerleme güvenlik nedeniyle durduruldu."
                )
            }
        }

        viewModelScope.launch {
            try {
                preferencesRepository.observePreferences(draftId).collect { pref ->
                    _uiState.value = _uiState.value.copy(
                        isPreferencesLocked = pref?.isLocked == true
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isPreferencesLocked = false,
                    message = "Değerlendirme tercihleri doğrulanamadı. İlerleme güvenlik nedeniyle durduruldu."
                )
            }
        }
    }

    fun checkAnswerSheetStale() {
        if (_uiState.value.draft?.examType == ExamType.HOMEWORK) {
            _uiState.value = _uiState.value.copy(isAnswerSheetStale = false)
            return
        }
        viewModelScope.launch {
            try {
                val config = examAnswerSheetRepository.getConfig(draftId)
                if (config != null) {
                    val status = examAnswerSheetRepository.getPdfStatus(draftId, config.studentCount)
                    _uiState.value = _uiState.value.copy(
                        isAnswerSheetStale = status is PdfStatus.Stale
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAnswerSheetStale = false
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAnswerSheetStale = true,
                    message = "Cevap kâğıdı güncelliği doğrulanamadı. Yeni doğrulama yapılmadan ilerlenemez."
                )
            }
        }
    }

    fun selectStage(stage: WorkflowStage) {
        val current = _uiState.value
        val visibleDraft = current.draft ?: return
        if (current.isAdvancing) return
        if (!visibleDraft.examType.isWorkflowStageSupported(stage)) {
            _uiState.value = current.copy(
                message = if (visibleDraft.examType == ExamType.HOMEWORK && stage == WorkflowStage.ANSWER_SHEET) {
                    "Ödev Kontrolünde cevap kâğıdı oluşturma aşaması kullanılmaz. Ödev teslimleri doğrudan yüklenir."
                } else {
                    "Bu aşama seçili çalışma türünde kullanılmıyor."
                }
            )
            return
        }

        val furthestStage = visibleDraft.currentWorkflowStage
        if (stage.order > furthestStage.order) {
            _uiState.value = current.copy(
                message = "Bu aşamaya henüz başlanmadı. Lütfen önceki adımları tamamlayın."
            )
            return
        }
        if (stage == current.currentStage) return

        _uiState.value = current.copy(isAdvancing = true, message = null)
        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (!latestDraft.examType.isWorkflowStageSupported(stage) || stage.order > latestDraft.currentWorkflowStage.order) {
                    throw IllegalStateException("Seçilen aşama artık erişilebilir değil.")
                }

                // Rewinding before evaluation invalidates every derived result and first waits for
                // local/remote evaluation work to stop. This prevents stale writes after rewind.
                if (stage.order < WorkflowStage.AI_EVALUATION.order &&
                    latestDraft.currentWorkflowStage.order >= WorkflowStage.AI_EVALUATION.order) {
                    examEvaluationRepository.stopEvaluationAndAwait(draftId, cleanupRemoteBatch = true)
                    examEvaluationRepository.resetEvaluationsForExam(draftId)
                }

                if (stage.order <= WorkflowStage.QUESTION_POINTS.order && !ensureQuestionSetUnlocked()) {
                    throw IllegalStateException("Soru seti yeniden düzenlemeye açılamadı.")
                }
                if (stage.order <= WorkflowStage.RUBRIC.order && !ensureRubricUnlocked()) {
                    throw IllegalStateException("Rubrik yeniden düzenlemeye açılamadı.")
                }
                if (stage.order <= WorkflowStage.READING_PREFS.order && !ensurePreferencesUnlocked()) {
                    throw IllegalStateException("Değerlendirme tercihleri yeniden düzenlemeye açılamadı.")
                }

                val rewound = latestDraft.copy(
                    currentWorkflowStage = stage,
                    updatedAt = System.currentTimeMillis()
                )
                examDraftRepository.updateDraft(rewound)
                val persisted = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (persisted.currentWorkflowStage != stage) {
                    throw IllegalStateException("İş akışı geri sarılamadı.")
                }
                _uiState.value = _uiState.value.copy(
                    draftExists = true,
                    draft = persisted,
                    currentStage = stage,
                    isAdvancing = false,
                    message = null
                )
                checkAnswerSheetStale()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = e.message ?: "Bu aşamaya güvenli biçimde dönülemedi."
                )
            }
        }
    }

    private suspend fun ensureQuestionSetUnlocked(): Boolean {
        val meta = examQuestionRepository.getMetadataOnce(draftId) ?: return true
        if (!meta.isLocked) return true
        return when (examQuestionRepository.unlockQuestionSet(draftId, meta.revision)) {
            is com.example.core.data.UnlockExamQuestionSetResult.Success,
            is com.example.core.data.UnlockExamQuestionSetResult.AlreadyUnlocked -> true
            else -> false
        }
    }

    private suspend fun ensureRubricUnlocked(): Boolean {
        val meta = examRubricRepository.getMetadataOnce(draftId) ?: return true
        if (!meta.isLocked) return true
        return when (examRubricRepository.unlockRubricSet(draftId, meta.revision)) {
            is com.example.core.data.UnlockExamRubricSetResult.Success,
            is com.example.core.data.UnlockExamRubricSetResult.AlreadyUnlocked -> true
            else -> false
        }
    }

    private suspend fun ensurePreferencesUnlocked(): Boolean {
        val pref = preferencesRepository.observePreferences(draftId).first() ?: return true
        if (!pref.isLocked) return true
        return preferencesRepository.unlockPreferences(draftId)
    }

    private suspend fun lockedRubricContractError(draft: ExamDraftEntity): String? {
        val questionMetadata = examQuestionRepository.getMetadataOnce(draftId)
            ?: return "Soru seti metadata kaydı bulunamadı."
        if (!questionMetadata.isLocked) return "Soru seti kilitli değil."
        val questions = examQuestionRepository.getQuestionsOnce(draftId)
        val rubricMetadata = examRubricRepository.getMetadataOnce(draftId)
            ?: return "Rubrik metadata kaydı bulunamadı."
        if (!rubricMetadata.isLocked) return "Rubrik kilitli değil."
        val criteria = examRubricRepository.getCriteriaOnce(draftId)
        val validation = com.example.core.model.ExamRubricValidator.validate(
            targetDraftId = draftId,
            questions = questions,
            questionSetRevision = questionMetadata.revision,
            questionSetLocked = questionMetadata.isLocked,
            rubricMetadata = rubricMetadata,
            criteria = criteria
        )
        if (!validation.isValid) {
            return "Rubrik güncel soru yapısıyla doğrulanamadı (${validation.issues.firstOrNull()?.code ?: "UNKNOWN"})."
        }
        if (draft.examType == ExamType.MULTIPLE_CHOICE) {
            val testIssues = com.example.core.model.MultipleChoiceAnswerKeyPolicy.validate(questions, criteria)
            if (testIssues.isNotEmpty()) {
                return "Test cevap anahtarı güncel soru yapısıyla doğrulanamadı (${testIssues.first().code})."
            }
        }
        return null
    }

    fun advanceFromExamInfo() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.EXAM_INFO || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (latestDraft.currentWorkflowStage != WorkflowStage.EXAM_INFO) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }

                val nextStage = if (latestDraft.examType == ExamType.MULTIPLE_CHOICE) {
                    WorkflowStage.RUBRIC
                } else {
                    WorkflowStage.UPLOAD_SOURCE
                }
                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = nextStage,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (persistedDraft.currentWorkflowStage == nextStage) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = nextStage,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = persistedDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "İş akışı ilerletilemedi."
                )
            }
        }
    }

    fun advanceFromUploadSource() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.UPLOAD_SOURCE || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (latestDraft.currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }

                if (latestDraft.examType == ExamType.LISTENING) {
                    if (!listeningMaterialRepository.isReadyForQuestions(draftId)) {
                        _uiState.value = _uiState.value.copy(
                            isAdvancing = false,
                            message = "Devam etmek için ses dosyası veya dinleme metni ekleyin."
                        )
                        return@launch
                    }
                } else if (latestDraft.examType != ExamType.HOMEWORK) {
                    val document = sourceDocumentRepository.getByExamDraftIdOnce(draftId)
                    if (document == null || !sourceDocumentRepository.isUsable(document)) {
                        val sourceMessage = when (latestDraft.examType) {
                            ExamType.READINESS -> "Devam etmek için geçerli bir hazırbulunuşluk sınavı kaynağı yükleyin veya sınav metnini yapıştırın."
                            else -> "Devam etmek için geçerli bir dosya yükleyin veya sınav metnini yapıştırın."
                        }
                        _uiState.value = _uiState.value.copy(
                            isAdvancing = false,
                            message = sourceMessage
                        )
                        return@launch
                    }
                } else {
                    val qMeta = examQuestionRepository.getMetadataOnce(draftId)
                    val rMeta = examRubricRepository.getMetadataOnce(draftId)
                    val prefs = preferencesRepository.observePreferences(draftId).first()
                    val criteria = examRubricRepository.getCriteriaOnce(draftId)
                    val homeworkContractValid = qMeta?.isLocked == true &&
                        rMeta?.isLocked == true &&
                        rMeta.questionSetRevision == qMeta.revision &&
                        prefs?.isLocked == true &&
                        criteria.isNotEmpty() &&
                        criteria.sumOf { it.maxPoints } == latestDraft.totalPoints
                    if (!homeworkContractValid) {
                        _uiState.value = _uiState.value.copy(
                            isAdvancing = false,
                            message = "Ödev tanımı, değerlendirme ölçütü ve tercihler birlikte güncel olarak onaylanmalıdır. Ödevi düzenlemeye açıp yeniden Kaydet ve İlerle deyin."
                        )
                        return@launch
                    }
                }

                val nextStage = if (latestDraft.examType == ExamType.HOMEWORK) WorkflowStage.UPLOAD_PAPERS else WorkflowStage.QUESTION_POINTS
                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = nextStage,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (persistedDraft.currentWorkflowStage == nextStage) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = nextStage,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = persistedDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Dosya doğrulanamadığı için sonraki aşamaya geçilemedi."
                )
            }
        }
    }

    fun advanceFromReadingPreferences() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.READING_PREFS || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (latestDraft.currentWorkflowStage != WorkflowStage.READING_PREFS) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }

                val submissionCopy = submissionCopy(latestDraft.examType)

                // 1. Check Evaluation Preferences Locked
                val preferences = preferencesRepository.observePreferences(draftId).first()
                if (preferences == null || preferences.isLocked != true) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Devam etmeden önce değerlendirme tercihlerini kaydedin ve kilitleyin."
                    )
                    return@launch
                }

                // 2. Revalidate the entire locked question/rubric contract against current persisted data.
                val rubricError = lockedRubricContractError(latestDraft)
                if (rubricError != null) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Değerlendirme tercihleri güncel rubrikle doğrulanamadı: $rubricError"
                    )
                    return@launch
                }

                // 3. Check Student Papers Upload Validation (complete set, no unassigned/error pages)
                val uploadValidation = examPaperUploadRepository.validateUploadProgress(draftId, latestDraft.examType)
                if (uploadValidation.isFailure) {
                    val errMsg = submissionCopy.localizeUploadMessage(
                        uploadValidation.exceptionOrNull()?.message ?: "Öğrenci kâğıtlarında eksik/sorunlu sayfa var."
                    ) ?: "Yüklenen öğrenci çalışmalarında eksik/sorunlu sayfa var."
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Değerlendirmeye geçilemiyor: $errMsg"
                    )
                    return@launch
                }

                // 4. Verify all student paper identities match valid rules (5-12, A-H, 1-4 digits)
                val studentPapers = examPaperUploadRepository.getStudentPapers(draftId).first()
                val invalidPaper = studentPapers.firstOrNull { paper ->
                    val validation = validateStudentIdentity(paper.classLevel, paper.branch, paper.schoolNumber)
                    !validation.isValid || paper.status != "READY"
                }
                if (invalidPaper != null) {
                    val reason = invalidPaper.statusReason ?: validateStudentIdentity(invalidPaper.classLevel, invalidPaper.branch, invalidPaper.schoolNumber).reason ?: "Kimlik bilgisi eksik veya geçersiz."
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Öğrenci #${invalidPaper.studentSequenceIndex} hazır değil: $reason"
                    )
                    return@launch
                }

                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = WorkflowStage.AI_EVALUATION,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (persistedDraft.currentWorkflowStage == WorkflowStage.AI_EVALUATION) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = WorkflowStage.AI_EVALUATION,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "İş akışı ilerletilemedi: ${e.message}"
                )
            }
        }
    }

    fun advanceFromAiEvaluation() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.AI_EVALUATION || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        val submissionCopy = submissionCopy(currentState.draft?.examType ?: com.example.core.model.ExamType.WRITTEN)

        viewModelScope.launch {
            try {
                val latestStageDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (latestStageDraft.currentWorkflowStage != WorkflowStage.AI_EVALUATION) {
                    _uiState.value = _uiState.value.copy(
                        draft = latestStageDraft,
                        currentStage = latestStageDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "Değerlendirme aşaması değişti; işlem yenilenmeden ilerlenemez."
                    )
                    return@launch
                }
                // Requirement 11: Verify all expected student papers are processed (COMPLETED or NEEDS_REVIEW)
                val studentPapers = examPaperUploadRepository.getStudentPapersOnce(draftId)
                if (studentPapers.isEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = if (submissionCopy.isHomework)
                            "Değerlendirilecek öğrenci ödev teslimi bulunamadı."
                        else
                            "Değerlendirilecek öğrenci kâğıdı bulunamadı."
                    )
                    return@launch
                }

                val studentEvals = examEvaluationRepository.getStudentEvaluationsForExamOnce(draftId)
                val evalMap = studentEvals.associateBy { it.studentPaperId }

                val unfinishedPapers = studentPapers.filter { paper ->
                    val status = evalMap[paper.id]?.status
                    status != "COMPLETED" && status != "NEEDS_REVIEW"
                }

                if (unfinishedPapers.isNotEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = if (submissionCopy.isHomework)
                            "Tüm öğrencilerin değerlendirmesi tamamlanmadan öğretmen incelemesine geçilemez (${unfinishedPapers.size} bekleyen veya hatalı ödev teslimi var)."
                        else
                            "Tüm öğrencilerin değerlendirmesi tamamlanmadan öğretmen incelemesine geçilemez (${unfinishedPapers.size} bekleyen veya hatalı kâğıt var)."
                    )
                    return@launch
                }

                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = WorkflowStage.TEACHER_REVIEW,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft != null && persistedDraft.currentWorkflowStage == WorkflowStage.TEACHER_REVIEW) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = WorkflowStage.TEACHER_REVIEW,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Aşama ilerletilemedi: ${e.message}"
                )
            }
        }
    }

    fun advanceFromTeacherReview() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.TEACHER_REVIEW || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestStageDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (latestStageDraft.currentWorkflowStage != WorkflowStage.TEACHER_REVIEW) {
                    _uiState.value = _uiState.value.copy(
                        draft = latestStageDraft,
                        currentStage = latestStageDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "Öğretmen inceleme aşaması değişti; rapora geçiş iptal edildi."
                    )
                    return@launch
                }
                val integrityResult = examEvaluationRepository.checkFinalResultsIntegrity(draftId)
                if (integrityResult.isFailure) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Sonuçlar raporlanmaya hazır değil: ${integrityResult.exceptionOrNull()?.message}"
                    )
                    return@launch
                }

                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = WorkflowStage.REPORTS,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft != null && persistedDraft.currentWorkflowStage == WorkflowStage.REPORTS) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = WorkflowStage.REPORTS,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "İş akışı raporlar aşamasına ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Aşama ilerletilemedi: ${e.message}"
                )
            }
        }
    }

    fun advanceFromRubric() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.RUBRIC || currentState.isAdvancing) {
            return
        }
        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )
        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }
                if (latestDraft.currentWorkflowStage != WorkflowStage.RUBRIC) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }
                val rubricError = lockedRubricContractError(latestDraft)
                if (rubricError != null) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Rubrik aşaması tamamlanamadı: $rubricError"
                    )
                    return@launch
                }

                val nextStage = latestDraft.examType.stageAfterRubric()
                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = nextStage,
                    updatedAt = System.currentTimeMillis()
                )
                examDraftRepository.updateDraft(updatedDraft)
                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }
                if (persistedDraft.currentWorkflowStage == nextStage) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = nextStage,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = persistedDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Bir hata oluştu."
                )
            }
        }
    }

    fun advanceFromAnswerSheet() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.ANSWER_SHEET || currentState.isAdvancing) {
            return
        }
        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )
        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }
                if (latestDraft.currentWorkflowStage != WorkflowStage.ANSWER_SHEET) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }

                // Business Rule Validation: Strict preflight and PDF validity check
                val config = examAnswerSheetRepository.getConfig(draftId)
                val targetStudentCount = config?.studentCount ?: 20
                val (canProceed, proceedReason) = examAnswerSheetRepository.canProceedToUpload(draftId, targetStudentCount)
                if (!canProceed) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = proceedReason ?: "Güncel ve kilitli soru/rubrik yapısına uygun toplu PDF olmadan bir sonraki aşamaya geçilemez."
                    )
                    return@launch
                }

                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = WorkflowStage.UPLOAD_PAPERS,
                    updatedAt = System.currentTimeMillis()
                )
                examDraftRepository.updateDraft(updatedDraft)
                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }
                if (persistedDraft.currentWorkflowStage == WorkflowStage.UPLOAD_PAPERS) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = WorkflowStage.UPLOAD_PAPERS,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = persistedDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Bir hata oluştu."
                )
            }
        }
    }

    fun advanceFromQuestionPoints() {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.QUESTION_POINTS || currentState.isAdvancing) {
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (latestDraft.currentWorkflowStage != WorkflowStage.QUESTION_POINTS) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = null
                    )
                    return@launch
                }

                if (latestDraft.examType == ExamType.LISTENING && !listeningMaterialRepository.isReadyForQuestions(draftId)) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Dinleme kaynağı artık kullanılamıyor. Ses dosyasını veya dinleme metnini kontrol edin."
                    )
                    return@launch
                }

                val metadata = examQuestionRepository.getMetadataOnce(draftId)
                val persistedQuestions = examQuestionRepository.getQuestionsOnce(draftId)
                val pointValidation = com.example.core.model.QuestionPointsValidator.validate(
                    examDraftId = draftId,
                    expectedTotalPoints = latestDraft.totalPoints,
                    questions = persistedQuestions
                )
                if (!pointValidation.canLock) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Soru puanları güncel sınav toplamıyla uyuşmuyor. Soruları yeniden doğrulayın."
                    )
                    return@launch
                }
                if (metadata == null || !metadata.isLocked) {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "Soru seti kilitlenmeden sonraki aşamaya geçilemez."
                    )
                    return@launch
                }

                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = WorkflowStage.RUBRIC,
                    updatedAt = System.currentTimeMillis()
                )

                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft == null) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        draftExists = false,
                        draft = null,
                        currentStage = null,
                        isAdvancing = false,
                        message = "Sınav taslağı bulunamadı."
                    )
                    return@launch
                }

                if (persistedDraft.currentWorkflowStage == WorkflowStage.RUBRIC) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = WorkflowStage.RUBRIC,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "İş akışı ilerletilemedi."
                )
            }
        }
    }

    fun advanceFromUploadPapers(canProceed: Boolean, blockReason: String?) {
        val currentState = _uiState.value
        if (currentState.isLoading || currentState.draftExists != true || currentState.draft == null ||
            currentState.currentStage != WorkflowStage.UPLOAD_PAPERS || currentState.isAdvancing) {
            return
        }

        if (!canProceed) {
            _uiState.value = currentState.copy(
                isAdvancing = false,
                message = blockReason ?: "Eksik sayfa veya eşleştirme hatası var. Devam etmeden önce lütfen düzeltin."
            )
            return
        }

        _uiState.value = currentState.copy(
            isAdvancing = true,
            message = null
        )

        viewModelScope.launch {
            try {
                val latestStageDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (latestStageDraft.currentWorkflowStage != WorkflowStage.UPLOAD_PAPERS) {
                    _uiState.value = _uiState.value.copy(
                        draft = latestStageDraft,
                        currentStage = latestStageDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "Öğrenci kâğıdı aşaması değişti; yükleme tekrar doğrulanmalı."
                    )
                    return@launch
                }
                // Strictly validate database records before stage progression
                val validationResult = examPaperUploadRepository.validateUploadProgress(draftId, latestStageDraft.examType)
                if (validationResult.isFailure) {
                    val copy = submissionCopy(currentState.draft?.examType ?: com.example.core.model.ExamType.WRITTEN)
                    val errMessage = copy.localizeUploadMessage(
                        validationResult.exceptionOrNull()?.message ?: "Öğrenci kâğıtları doğrulamadan geçemedi."
                    )
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = errMessage
                    )
                    return@launch
                }

                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Sınav taslağı bulunamadı.")
                if (latestDraft.currentWorkflowStage != WorkflowStage.UPLOAD_PAPERS) {
                    _uiState.value = _uiState.value.copy(
                        draft = latestDraft,
                        currentStage = latestDraft.currentWorkflowStage,
                        isAdvancing = false,
                        message = "Öğrenci kâğıdı aşaması değişti; işlem iptal edildi."
                    )
                    return@launch
                }

                // Test Sınavı has no AI preferences stage. Uploaded BaykuşNot forms go
                // directly to local optical reading (legacy enum name AI_EVALUATION is kept
                // only for database compatibility; the Test route performs no AI/network call).
                val nextStage = if (latestDraft.examType == ExamType.MULTIPLE_CHOICE || latestDraft.examType == ExamType.HOMEWORK) {
                    WorkflowStage.AI_EVALUATION
                } else {
                    WorkflowStage.READING_PREFS
                }
                val updatedDraft = latestDraft.copy(
                    currentWorkflowStage = nextStage,
                    updatedAt = System.currentTimeMillis()
                )
                examDraftRepository.updateDraft(updatedDraft)

                val persistedDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (persistedDraft != null && persistedDraft.currentWorkflowStage == nextStage) {
                    _uiState.value = _uiState.value.copy(
                        draftExists = true,
                        draft = persistedDraft,
                        currentStage = nextStage,
                        isAdvancing = false,
                        message = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        message = "İş akışı ilerletilemedi."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAdvancing = false,
                    message = "Aşama ilerletilemedi: ${e.message}"
                )
            }
        }
    }

    class Factory(
        private val examDraftRepository: ExamDraftRepository,
        private val sourceDocumentRepository: ExamSourceDocumentRepository,
        private val listeningMaterialRepository: ExamListeningMaterialRepository,
        private val preferencesRepository: ExamEvaluationPreferencesRepository,
        private val examQuestionRepository: ExamQuestionRepository,
        private val examRubricRepository: ExamRubricRepository,
        private val examAnswerSheetRepository: ExamAnswerSheetRepository,
        private val examPaperUploadRepository: ExamPaperUploadRepository,
        private val examEvaluationRepository: com.example.core.data.ExamEvaluationRepository,
        private val draftId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(WorkflowViewModel::class.java)) {
                return WorkflowViewModel(
                    examDraftRepository,
                    sourceDocumentRepository,
                    listeningMaterialRepository,
                    preferencesRepository,
                    examQuestionRepository,
                    examRubricRepository,
                    examAnswerSheetRepository,
                    examPaperUploadRepository,
                    examEvaluationRepository,
                    draftId
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
