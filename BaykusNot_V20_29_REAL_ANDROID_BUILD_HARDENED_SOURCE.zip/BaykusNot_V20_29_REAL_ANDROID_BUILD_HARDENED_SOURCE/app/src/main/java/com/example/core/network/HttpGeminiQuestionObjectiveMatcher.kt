package com.example.core.network

import com.example.core.database.ExamObjectiveEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.security.SecureApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class HttpGeminiQuestionObjectiveMatcher(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore,
    private val aiUsageLedger: AiUsageLedger? = null,
) : ExamQuestionObjectiveMatcher {

    private val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true }

    override suspend fun matchQuestionsToObjectives(
        questions: List<ExamQuestion>,
        objectives: List<ExamObjectiveEntity>,
        examType: ExamType
    ): ExamQuestionObjectiveMatchingResult = matchInternal(null, questions, objectives, examType)

    override suspend fun matchQuestionsToObjectivesForExam(
        examDraftId: Long,
        questions: List<ExamQuestion>,
        objectives: List<ExamObjectiveEntity>,
        examType: ExamType
    ): ExamQuestionObjectiveMatchingResult = matchInternal(examDraftId, questions, objectives, examType)

    private suspend fun matchInternal(
        examDraftId: Long?,
        questions: List<ExamQuestion>,
        objectives: List<ExamObjectiveEntity>,
        examType: ExamType
    ): ExamQuestionObjectiveMatchingResult {
        val result = apiKeyStore.useApiKey { apiKey ->
            if (apiKey.isNullOrBlank()) return@useApiKey ExamQuestionObjectiveMatchingResult.MissingApiKey

            val isReadiness = examType == ExamType.READINESS
            val profileSnapshot = GeminiModelRegistry.currentProfile()
            val requestedAuthoringModel = profileSnapshot.authoringModel
                GeminiModelRegistry.requireAuthoringModelApproved(requestedAuthoringModel)
            val prompt = buildString {
                if (isReadiness) {
                    append("Sen bir hazırbulunuşluk sınavı analiz asistanısın. Aşağıda konu/ünite öncesi tanılayıcı sorular ile onaylı ön koşul bilgi/beceri hedefleri verilmiştir. ")
                    append("Her soruyu yalnız gerçekten ölçtüğü ön koşul bilgi/beceri hedefleriyle eşleştir. İleri düzey veya soruda kanıtı olmayan hedef ekleme. ")
                    append("Bir soru birden fazla hedefi gerçekten ölçüyorsa birden fazla ID seçebilirsin; ancak sırf konu benzerliği nedeniyle hedef uydurma.\n\n")
                    append("ÖN KOŞUL BİLGİ/BECERİ HEDEFLERİ:\n")
                } else {
                    append("Sen bir sınav analiz asistanısın. Aşağıda sınavdaki sorular ve sınav senaryosundaki kazanımlar verilmiştir. ")
                    append("Her sorunun hangi kazanım(lar)a ait olduğunu eşleştir. Yalnız sorunun gerçekten ölçtüğü kazanımları seç.\n\n")
                    append("KAZANIMLAR:\n")
                }
                objectives.forEach { obj ->
                    append("- [ID: ${obj.id}] ${obj.objectiveCode ?: ""} ${obj.objectiveText}\n")
                }

                append(if (isReadiness) "\nHAZIRBULUNUŞLUK SORULARI:\n" else "\nSORULAR:\n")
                questions.forEach { q ->
                    append("- [ID: ${q.id}] Soru ${q.questionNumber}: ${q.questionText}\n")
                }

                if (isReadiness) {
                    append("\nZORUNLU KURAL: Çıktıda yalnız yukarıda verilen soru ID'lerini ve hedef ID'lerini kullan. Her soru için bir satır döndür. Bir sorunun onaylı hedefler arasında gerçekten ölçtüğü bir ön koşul bilgi/beceri yoksa objectiveIds alanını boş dizi [] bırak; sırf satırı doldurmak için en yakın konu başlığını seçme veya hedef uydurma. Böyle bir boş eşleşme öğretmen incelemesine bırakılacaktır.")
                }
            }

            val schema = buildJsonObject {
                put("type", "object")
                put("properties", buildJsonObject {
                    put("mappings", buildJsonObject {
                        put("type", "array")
                        put("items", buildJsonObject {
                            put("type", "object")
                            put("properties", buildJsonObject {
                                put("questionId", buildJsonObject { put("type", "integer") })
                                put("objectiveIds", buildJsonObject {
                                    put("type", "array")
                                    put("items", buildJsonObject { put("type", "integer") })
                                })
                            })
                        })
                    })
                })
            }

            val requestBodyJson = buildJsonObject {
                put("contents", buildJsonArray {
                    add(buildJsonObject {
                        put("parts", buildJsonArray {
                            add(buildJsonObject { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", buildJsonObject {
                    put("responseMimeType", "application/json")
                    put("responseSchema", schema)
                })
                put("store", false)
            }

            val body = requestBodyJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(GeminiModelRegistry.generateContentUrl(requestedAuthoringModel))
                .header("x-goog-api-key", apiKey)
                .post(body)
                .build()

            val response = okHttpClient.executeCancellable(request)
            response.use { resp ->
                if (!resp.isSuccessful) return@useApiKey ExamQuestionObjectiveMatchingResult.Failure
                
                try {
                    val rootNode = jsonParser.parseToJsonElement(resp.body!!.string()).jsonObject
                    examDraftId?.let { draftId ->
                        runCatching {
                            aiUsageLedger?.recordAuthoring(
                                draftId, "AUTHORING_OBJECTIVE_MATCH", requestedAuthoringModel, profileSnapshot,
                                GeminiUsageAuditParser.fromGenerateContent(rootNode)
                            )
                        }
                    }
                    val text = rootNode["candidates"]?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("content")?.jsonObject?.get("parts")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("text")?.jsonPrimitive?.content ?: return@useApiKey ExamQuestionObjectiveMatchingResult.Failure
                        
                    val parsedResponse = jsonParser.parseToJsonElement(text).jsonObject
                    val mappingsArray = parsedResponse["mappings"]?.jsonArray ?: return@useApiKey ExamQuestionObjectiveMatchingResult.Failure
                    
                    val allowedQuestionIds = questions.map { it.id }.toSet()
                    val allowedObjectiveIds = objectives.map { it.id }.toSet()
                    val mappingsResult = mutableMapOf<Long, List<Long>>()
                    mappingsArray.forEach { item ->
                        val obj = item.jsonObject
                        val qId = obj["questionId"]?.jsonPrimitive?.longOrNull
                        val oIds = obj["objectiveIds"]?.jsonArray
                            ?.mapNotNull { it.jsonPrimitive.longOrNull }
                            ?.filter { it in allowedObjectiveIds }
                            ?.distinct()
                            ?: emptyList()
                        if (qId != null && qId in allowedQuestionIds) {
                            mappingsResult[qId] = oIds
                        }
                    }

                    // The UI requires every real question to be mapped before approval.
                    // Missing model rows remain an explicit empty mapping instead of silently disappearing.
                    questions.forEach { question ->
                        mappingsResult.putIfAbsent(question.id, emptyList())
                    }

                    ExamQuestionObjectiveMatchingResult.Success(mappingsResult)
                } catch (e: Exception) {
                    ExamQuestionObjectiveMatchingResult.Failure
                }
            }
        }
        return result ?: ExamQuestionObjectiveMatchingResult.MissingApiKey
    }
}
