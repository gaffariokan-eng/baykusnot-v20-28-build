package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_ai_usage",
    foreignKeys = [ForeignKey(
        entity = ExamDraftEntity::class,
        parentColumns = ["id"],
        childColumns = ["examDraftId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("examDraftId"), Index("studentPaperId")]
)
data class ExamAiUsageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val examDraftId: Long,
    val studentPaperId: Long? = null,
    val stage: String,
    val modelId: String,
    val useBatchPricing: Boolean,
    val inputTokens: Long = 0,
    val cachedInputTokens: Long = 0,
    val outputTokens: Long = 0,
    val thinkingTokens: Long = 0,
    val estimatedCostUsd: Double = 0.0,
    val actualModelVersion: String? = null,
    val responseId: String? = null,
    val modelStatusStage: String? = null,
    val modelRetirementTime: String? = null,
    val modelStatusMessage: String? = null,
    val recordedAt: Long = System.currentTimeMillis()
)
