package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamPaperUploadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaper(paper: ExamStudentPaperEntity): Long

    @Update
    suspend fun updatePaper(paper: ExamStudentPaperEntity)

    @Query("DELETE FROM exam_student_paper WHERE id = :paperId")
    suspend fun deletePaper(paperId: Long)

    @Query("SELECT * FROM exam_student_paper WHERE examDraftId = :examDraftId ORDER BY studentSequenceIndex ASC")
    fun getPapersForExam(examDraftId: Long): Flow<List<ExamStudentPaperEntity>>

    @Query("SELECT * FROM exam_student_paper WHERE examDraftId = :examDraftId ORDER BY studentSequenceIndex ASC")
    suspend fun getPapersForExamOnce(examDraftId: Long): List<ExamStudentPaperEntity>

    @Query("SELECT * FROM exam_student_paper WHERE id = :paperId")
    suspend fun getPaperByIdOnce(paperId: Long): ExamStudentPaperEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: ExamPaperPageEntity): Long

    @Update
    suspend fun updatePage(page: ExamPaperPageEntity)

    @Query("DELETE FROM exam_paper_page WHERE id = :pageId")
    suspend fun deletePage(pageId: Long)

    @Query("DELETE FROM exam_paper_page WHERE studentPaperId = :paperId")
    suspend fun deletePagesForPaper(paperId: Long)

    @Query("SELECT * FROM exam_paper_page WHERE examDraftId = :examDraftId ORDER BY id ASC")
    fun getPagesForExam(examDraftId: Long): Flow<List<ExamPaperPageEntity>>

    @Query("SELECT * FROM exam_paper_page WHERE examDraftId = :examDraftId ORDER BY id ASC")
    suspend fun getPagesForExamOnce(examDraftId: Long): List<ExamPaperPageEntity>

    @Query("SELECT * FROM exam_paper_page WHERE studentPaperId = :studentPaperId ORDER BY pageIndex ASC")
    suspend fun getPagesForPaperOnce(studentPaperId: Long): List<ExamPaperPageEntity>

    @Query("DELETE FROM exam_student_paper WHERE examDraftId = :examDraftId")
    suspend fun clearPapersForExam(examDraftId: Long)

    @Query("DELETE FROM exam_paper_page WHERE examDraftId = :examDraftId")
    suspend fun clearPagesForExam(examDraftId: Long)
}
