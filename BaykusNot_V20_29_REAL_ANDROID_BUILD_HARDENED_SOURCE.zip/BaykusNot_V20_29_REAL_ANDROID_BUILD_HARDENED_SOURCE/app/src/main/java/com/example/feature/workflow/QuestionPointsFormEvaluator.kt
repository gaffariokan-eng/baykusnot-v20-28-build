package com.example.feature.workflow

import com.example.core.model.ExamQuestion
import com.example.core.model.QuestionPointsValidationCode
import com.example.core.model.QuestionPointsValidationResult
import com.example.core.model.QuestionPointsValidator

data class QuestionPointsFormEvaluation(
    val domainQuestions: List<ExamQuestion>?,
    val inputIssues: List<QuestionPointsInputIssue>,
    val validation: QuestionPointsValidationResult?,
    val calculatedTotalPoints: Long,
    val remainingPoints: Long,
    val canSave: Boolean,
    val canLock: Boolean
)

object QuestionPointsFormEvaluator {

    fun evaluate(
        examDraftId: Long,
        expectedTotalPoints: Int,
        editableQuestions: List<EditableExamQuestion>
    ): QuestionPointsFormEvaluation {
        var calculatedTotal = 0L
        val inputIssues = mutableListOf<QuestionPointsInputIssue>()
        val parsedPointsList = mutableListOf<Int>()

        for (eq in editableQuestions) {
            when (val parseResult = QuestionPointsInputParser.parse(eq.pointsText)) {
                is QuestionPointsParseResult.Parsed -> {
                    calculatedTotal += parseResult.points.toLong()
                    parsedPointsList.add(parseResult.points)
                }
                is QuestionPointsParseResult.Rejected -> {
                    inputIssues.add(
                        QuestionPointsInputIssue(
                            localId = eq.localId,
                            code = parseResult.code
                        )
                    )
                }
            }
        }

        val remaining = expectedTotalPoints.toLong() - calculatedTotal

        if (inputIssues.isNotEmpty()) {
            return QuestionPointsFormEvaluation(
                domainQuestions = null,
                inputIssues = inputIssues,
                validation = null,
                calculatedTotalPoints = calculatedTotal,
                remainingPoints = remaining,
                canSave = false,
                canLock = false
            )
        }

        val domainQuestions = editableQuestions.mapIndexed { index, eq ->
            ExamQuestion(
                id = eq.persistedId,
                examDraftId = examDraftId,
                orderIndex = eq.orderIndex,
                questionNumber = eq.questionNumber,
                questionText = eq.questionText,
                points = parsedPointsList[index]
            )
        }

        val validation = QuestionPointsValidator.validate(
            examDraftId = examDraftId,
            expectedTotalPoints = expectedTotalPoints,
            questions = domainQuestions
        )

        val canSave = validation.issues.all { issue ->
            issue.code == QuestionPointsValidationCode.EMPTY_QUESTION_LIST ||
                    issue.code == QuestionPointsValidationCode.TOTAL_POINTS_MISMATCH
        }

        val canLock = validation.canLock

        return QuestionPointsFormEvaluation(
            domainQuestions = domainQuestions,
            inputIssues = emptyList(),
            validation = validation,
            calculatedTotalPoints = validation.calculatedTotalPoints,
            remainingPoints = expectedTotalPoints.toLong() - validation.calculatedTotalPoints,
            canSave = canSave,
            canLock = canLock
        )
    }
}
