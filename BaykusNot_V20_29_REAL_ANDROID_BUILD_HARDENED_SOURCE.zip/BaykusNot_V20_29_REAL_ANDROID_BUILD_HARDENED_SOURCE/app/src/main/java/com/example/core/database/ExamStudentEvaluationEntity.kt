package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_student_evaluation",
    foreignKeys = [
        ForeignKey(
            entity = ExamStudentPaperEntity::class,
            parentColumns = ["id"],
            childColumns = ["studentPaperId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["examDraftId"])]
)
data class ExamStudentEvaluationEntity(
    @PrimaryKey val studentPaperId: Long,
    val examDraftId: Long,
    val status: String, // "WAITING", "EVALUATING", "COMPLETED", "NEEDS_REVIEW", "ERROR"
    val totalScore: Double = 0.0,
    val totalMaxScore: Double = 0.0,
    /** Final student-facing writing/punctuation prose; populated only after teacher approval. */
    val spellingPunctuationFeedback: String? = null,
    /** Compact main-model diagnosis kept separately so final prose can be regenerated safely. */
    val writingStrengths: List<String> = emptyList(),
    val writingIssues: List<String> = emptyList(),
    val writingNextSteps: List<String> = emptyList(),
    val spellingPunctuationDeduction: Double = 0.0,
    val overallConfidence: Double = 1.0,
    val needsReview: Boolean = false,
    val errorMessage: String? = null,
    val isTeacherApproved: Boolean = false,
    /** Generated only after final teacher approval, from final scores. */
    val overallFeedback: String? = null,
    val feedbackGeneratedAt: Long? = null,
    /** Short teacher-authored note shown separately from AI feedback on the student report. */
    val teacherNote: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
