package com.example.core.network

enum class ExamRubricGenerationValidationCode {
    EMPTY_GENERATED_CRITERIA,
    UNKNOWN_QUESTION_ORDER_INDEX,
    MISSING_CRITERIA_FOR_QUESTION,
    QUESTION_NUMBER_SNAPSHOT_MISMATCH,
    INVALID_CRITERION_ORDER_INDEX,
    DUPLICATE_CRITERION_ORDER_INDEX,
    BLANK_CRITERION_TITLE,
    BLANK_CRITERION_DESCRIPTION,
    BLANK_EXPECTED_ANSWER,
    NON_POSITIVE_MAX_POINTS,
    QUESTION_POINTS_MISMATCH
}

data class ExamRubricGenerationValidationIssue(
    val code: ExamRubricGenerationValidationCode,
    val questionOrderIndex: Int? = null,
    val criterionOrderIndex: Int? = null,
    val value: String? = null
)

data class ExamRubricGenerationValidationResult(
    val calculatedPointsByQuestionOrder: Map<Int, Long>,
    val issues: List<ExamRubricGenerationValidationIssue>,
    val criteria: List<GeneratedExamRubricCriterion> = emptyList()
) {
    val isValid: Boolean
        get() = issues.isEmpty()
}

object ExamRubricGenerationValidator {
    fun validate(
        input: ExamRubricGenerationInput,
        criteria: List<GeneratedExamRubricCriterion>
    ): ExamRubricGenerationValidationResult {
        val issues = mutableListOf<ExamRubricGenerationValidationIssue>()

        if (criteria.isEmpty()) {
            issues.add(ExamRubricGenerationValidationIssue(code = ExamRubricGenerationValidationCode.EMPTY_GENERATED_CRITERIA))
            return ExamRubricGenerationValidationResult(
                calculatedPointsByQuestionOrder = emptyMap(),
                issues = issues,
                criteria = criteria
            )
        }

        val questionMap = input.questions.associateBy { it.questionOrderIndex }
        val criteriaByQuestion = mutableMapOf<Int, MutableList<GeneratedExamRubricCriterion>>()

        for (criterion in criteria) {
            val question = questionMap[criterion.questionOrderIndex]
            if (question == null) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.UNKNOWN_QUESTION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            } else {
                if (criterion.questionNumberSnapshot != question.questionNumber) {
                    issues.add(
                        ExamRubricGenerationValidationIssue(
                            code = ExamRubricGenerationValidationCode.QUESTION_NUMBER_SNAPSHOT_MISMATCH,
                            questionOrderIndex = criterion.questionOrderIndex,
                            criterionOrderIndex = criterion.criterionOrderIndex
                        )
                    )
                }
            }

            if (criterion.criterionOrderIndex <= 0) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.INVALID_CRITERION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }

            val listForQuestion = criteriaByQuestion.getOrPut(criterion.questionOrderIndex) { mutableListOf() }
            if (listForQuestion.any { it.criterionOrderIndex == criterion.criterionOrderIndex }) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.DUPLICATE_CRITERION_ORDER_INDEX,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            listForQuestion.add(criterion)

            if (criterion.title.isBlank()) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.BLANK_CRITERION_TITLE,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.description.isBlank()) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.BLANK_CRITERION_DESCRIPTION,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.expectedAnswer.isBlank()) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.BLANK_EXPECTED_ANSWER,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
            if (criterion.maxPoints <= 0) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.NON_POSITIVE_MAX_POINTS,
                        questionOrderIndex = criterion.questionOrderIndex,
                        criterionOrderIndex = criterion.criterionOrderIndex
                    )
                )
            }
        }

        val calculatedPointsByQuestionOrder = linkedMapOf<Int, Long>()
        for (question in input.questions) {
            val qCriteria = criteriaByQuestion[question.questionOrderIndex].orEmpty()
            val total = qCriteria.sumOf { it.maxPoints.toLong() }
            calculatedPointsByQuestionOrder[question.questionOrderIndex] = total
            if (qCriteria.isEmpty()) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.MISSING_CRITERIA_FOR_QUESTION,
                        questionOrderIndex = question.questionOrderIndex
                    )
                )
            }
        }

        for (question in input.questions) {
            val total = calculatedPointsByQuestionOrder.getValue(question.questionOrderIndex)
            if (total != question.points.toLong()) {
                issues.add(
                    ExamRubricGenerationValidationIssue(
                        code = ExamRubricGenerationValidationCode.QUESTION_POINTS_MISMATCH,
                        questionOrderIndex = question.questionOrderIndex,
                        value = "expected=${question.points},actual=$total"
                    )
                )
            }
        }

        return ExamRubricGenerationValidationResult(
            calculatedPointsByQuestionOrder = calculatedPointsByQuestionOrder,
            issues = issues,
            criteria = criteria
        )
    }
}
