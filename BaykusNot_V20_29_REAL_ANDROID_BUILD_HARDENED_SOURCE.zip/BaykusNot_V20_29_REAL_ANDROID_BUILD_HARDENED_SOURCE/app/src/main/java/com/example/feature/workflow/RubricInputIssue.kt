package com.example.feature.workflow

enum class RubricInputIssueCode {
    BLANK_MAX_POINTS,
    INVALID_MAX_POINTS_FORMAT,
    MAX_POINTS_OUT_OF_RANGE
}

data class RubricInputIssue(
    val localId: Long,
    val code: RubricInputIssueCode
)
