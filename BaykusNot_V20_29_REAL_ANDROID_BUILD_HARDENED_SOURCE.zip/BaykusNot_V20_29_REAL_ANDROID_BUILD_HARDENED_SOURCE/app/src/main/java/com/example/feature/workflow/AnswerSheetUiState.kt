package com.example.feature.workflow

import com.example.core.data.AnswerSheetPageLayout
import com.example.core.data.ListeningAnswerSheetGuidance
import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import java.io.File

data class AnswerSheetUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val saveSuccessMessage: String? = null,
    val draft: ExamDraftEntity? = null,
    val questions: List<ExamQuestionEntity> = emptyList(),
    val rubricCriteria: List<ExamRubricCriterionEntity> = emptyList(),
    val studentCount: Int = 20,
    val layoutDensity: String = "AUTOMATIC",
    val layoutSummaryText: String = "",
    val isGeneratingPdf: Boolean = false,
    val isSavingSettings: Boolean = false,
    val pdfGenerationProgress: String? = null,
    val generatedPdfFile: File? = null,
    val generatedPdfStudentCount: Int? = null,
    val isPdfUpToDate: Boolean = false,
    val pdfStaleTitle: String? = null,
    val pdfStaleSubtitle: String? = null,
    val lineOverrides: Map<Int, Int> = emptyMap(),
    val hasUploadedPapers: Boolean = false,
    val pageLayouts: List<AnswerSheetPageLayout> = emptyList(),
    val selectedPreviewPageIndex: Int = 1,
    val titleHeader: String = "",
    val listeningGuidance: ListeningAnswerSheetGuidance? = null,
    val isPreflightValid: Boolean = false
)
