package com.example.core.data

import java.util.Locale

object BranchConstants {
    val CANONICAL_BRANCHES = listOf(
        "A", "B", "C", "Ç", "D", "E", "F", "G", "Ğ", "H", "I", "İ", "J", "K", "L",
        "M", "N", "O", "Ö", "P", "R", "S", "Ş", "T", "U", "Ü", "V", "Y", "Z"
    )

    val CANONICAL_ROW1_BRANCHES = CANONICAL_BRANCHES.subList(0, 15) // 15 items: A to L
    val CANONICAL_ROW2_BRANCHES = CANONICAL_BRANCHES.subList(15, 29) // 14 items: M to Z

    fun normalizeBranch(branch: String?): String? {
        if (branch.isNullOrBlank()) return null
        val cleaned = branch.trim()
            .replace("i", "İ")
            .replace("ı", "I")
            .uppercase(Locale("tr", "TR"))
        return if (CANONICAL_BRANCHES.contains(cleaned)) cleaned else null
    }

    fun isValidBranch(branch: String?): Boolean {
        val normalized = normalizeBranch(branch)
        return normalized != null && CANONICAL_BRANCHES.contains(normalized)
    }
}
