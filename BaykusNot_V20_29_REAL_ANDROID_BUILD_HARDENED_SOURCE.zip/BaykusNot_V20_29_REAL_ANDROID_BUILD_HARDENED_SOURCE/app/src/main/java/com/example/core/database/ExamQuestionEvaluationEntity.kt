package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exam_question_evaluation",
    foreignKeys = [
        ForeignKey(
            entity = ExamStudentPaperEntity::class,
            parentColumns = ["id"],
            childColumns = ["studentPaperId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["studentPaperId"]),
        Index(value = ["examDraftId"])
    ]
)
data class ExamQuestionEvaluationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentPaperId: Long,
    val examDraftId: Long,
    val questionNumber: String,
    val questionOrderIndex: Int,
    val readAnswerText: String = "",
    val score: Double = 0.0,
    val maxScore: Double = 0.0,
    /** Compact diagnostic before teacher approval; final student-facing prose after approval. */
    val feedback: String? = null,
    val interpretedMeaning: String? = null,
    val gradingEvidence: String? = null,
    val readingConfidence: Double = 1.0,
    val evaluationConfidence: Double = 1.0,
    val answerType: String = "NORMAL", // "NORMAL", "UNANSWERED", "UNREADABLE", "LOW_CONFIDENCE"
    val needsReview: Boolean = false,
    val reviewReason: String? = null,
    val originalScore: Double = 0.0,
    val isTeacherModified: Boolean = false,
    val isResolved: Boolean = true,
    /** Rubric-grounded pedagogical facts; kept separate so cheap prose generation does not re-grade. */
    val strengths: List<String> = emptyList(),
    val missingElements: List<String> = emptyList(),
    val misconceptions: List<String> = emptyList(),
    val nextSteps: List<String> = emptyList()
)
