package com.example.core.model

data class ExamQuestion(
    val id: Long = 0L,
    val examDraftId: Long,
    val orderIndex: Int,
    val questionNumber: String,
    val questionText: String,
    val points: Int,
    val selectedObjectiveIds: Set<Long> = emptySet()
)
