package com.example.core.security

/**
 * Central fail-closed gate for operations that send real student assessment data to an external
 * AI service. The gate is scope-aware: a prior YAZEK declaration can be reused only when the
 * application scope, educational purpose, AI tool and target audience are unchanged.
 */
class StudentAiComplianceGate(
    private val store: YazekComplianceStore
) {
    fun requireAllowed(scope: YazekDeclarationScope) {
        scope.requireComplete()
        ProviderDataProtectionProfile.current().requireReady()
        check(store.isAcknowledged(scope)) {
            "Bu çalışma kapsamı için YAZEK etik beyan doğrulaması bulunmuyor veya kapsam değişti. " +
                "Öğrenci verisi AI hizmetine gönderilmeden önce YAZEK'te kapsam, eğitsel amaç, AI aracı ve hedef kitleyi doğrulayın."
        }
    }

    fun isAllowed(scope: YazekDeclarationScope): Boolean =
        ProviderDataProtectionProfile.current().validationProblems().isEmpty() && store.isAcknowledged(scope)

    fun acknowledge(
        scope: YazekDeclarationScope,
        referenceNote: String? = null,
        officialDeclarationApplied: Boolean,
        noticeAndConsentCompleted: Boolean
    ) {
        scope.requireComplete()
        ProviderDataProtectionProfile.current().requireReady()
        store.acknowledge(
            scope = scope,
            referenceNote = referenceNote,
            officialDeclarationApplied = officialDeclarationApplied,
            noticeAndConsentCompleted = noticeAndConsentCompleted
        )
    }

    fun acknowledgementTime(scope: YazekDeclarationScope): Long? = store.acknowledgementTime(scope)

    fun referenceNote(scope: YazekDeclarationScope): String? = store.referenceNote(scope)
}
