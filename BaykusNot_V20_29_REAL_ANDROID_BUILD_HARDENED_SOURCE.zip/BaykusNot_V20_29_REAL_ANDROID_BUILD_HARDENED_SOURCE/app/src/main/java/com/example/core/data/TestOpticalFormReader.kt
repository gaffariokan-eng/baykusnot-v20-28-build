package com.example.core.data

import android.content.Context
import android.graphics.Bitmap
import com.example.core.security.StudentImageCrypto
import com.example.core.security.SafeBitmapDecoder
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.model.MultipleChoiceOpticalClassifier
import com.example.core.model.OpticalChoiceStatus
import java.io.File
import com.google.zxing.BinaryBitmap
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import kotlin.math.max
import kotlin.math.min

data class TestOpticalQuestionRead(
    val questionNumber: String,
    val questionOrderIndex: Int,
    val markedChoice: String?,
    val status: OpticalChoiceStatus,
    val confidence: Double,
    val fillRatios: Map<String, Double>,
    val reason: String? = null
)

data class TestOpticalPaperRead(
    val questions: List<TestOpticalQuestionRead>,
    val registrationConfidence: Double,
    val needsReview: Boolean,
    val errorMessage: String? = null
)

/**
 * Local OMR reader for BaykuşNot-generated Test answer forms.
 * It does not call Gemini, any API, OCR service or network endpoint.
 */
object TestOpticalFormReader {
    private const val CANONICAL_WIDTH = 1190
    private const val CANONICAL_HEIGHT = 1684

    fun read(
        pages: List<ExamPaperPageEntity>,
        questions: List<ExamQuestionEntity>,
        answerKeyCriteria: List<ExamRubricCriterionEntity>,
        densitySetting: String = "AUTOMATIC"
    ): TestOpticalPaperRead {
        if (pages.isEmpty()) {
            return TestOpticalPaperRead(emptyList(), 0.0, true, "Test cevap formuna ait sayfa bulunamadı.")
        }
        val layouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = questions,
            rubricCriteria = answerKeyCriteria,
            densitySetting = densitySetting,
            examType = ExamType.MULTIPLE_CHOICE
        )
        if (layouts.isEmpty()) {
            return TestOpticalPaperRead(emptyList(), 0.0, true, "Test cevap formu yerleşimi hesaplanamadı.")
        }

        val pageByIndex = pages.associateBy { it.pageIndex }
        val results = mutableListOf<TestOpticalQuestionRead>()
        val registrationScores = mutableListOf<Double>()

        for (layout in layouts) {
            val page = pageByIndex[layout.pageIndex]
            if (page == null || page.imagePath.isBlank() || !File(page.imagePath).exists()) {
                layout.questions.forEach { q ->
                    results += TestOpticalQuestionRead(
                        questionNumber = q.questionNumber,
                        questionOrderIndex = q.orderIndex,
                        markedChoice = null,
                        status = OpticalChoiceStatus.AMBIGUOUS,
                        confidence = 0.0,
                        fillRatios = emptyMap(),
                        reason = "Bu sorunun bulunduğu test cevap formu sayfası eksik."
                    )
                }
                continue
            }

            val decoded = StudentImageCrypto.decodeBitmap(page.imagePath)
            if (decoded == null) {
                layout.questions.forEach { q ->
                    results += TestOpticalQuestionRead(
                        q.questionNumber, q.orderIndex, null, OpticalChoiceStatus.AMBIGUOUS, 0.0, emptyMap(),
                        "Sayfa görseli açılamadı."
                    )
                }
                continue
            }

            val normalized = normalizePage(decoded)
            if (normalized.bitmap !== decoded) decoded.recycle()
            registrationScores += normalized.confidence

            try {
                layout.questions.forEach { qBox ->
                    val question = questions.firstOrNull { it.orderIndex == qBox.orderIndex }
                    val labels = com.example.core.model.MultipleChoiceOptionPolicy.detectLabels(question?.questionText.orEmpty())
                    val centerYPt = qBox.topYPt + qBox.headerHeightPt + ((qBox.heightPt - qBox.headerHeightPt) / 2f)
                    val fills = linkedMapOf<String, Double>()
                    labels.forEachIndexed { index, label ->
                        val xPt = TestOpticalFormGeometry.optionCenterX(index)
                        fills[label] = sampleBubbleInterior(
                            normalized.bitmap,
                            xPt / TestOpticalFormGeometry.pageWidthPt,
                            centerYPt / TestOpticalFormGeometry.pageHeightPt
                        )
                    }
                    val classified = MultipleChoiceOpticalClassifier.classify(fills)
                    val registrationPenalty = if (normalized.confidence >= 0.55) 1.0 else 0.65
                    val effectiveConfidence = (classified.confidence * registrationPenalty).coerceIn(0.0, 1.0)
                    val forceReview = normalized.confidence < 0.35 && classified.status == OpticalChoiceStatus.MARKED
                    results += TestOpticalQuestionRead(
                        questionNumber = qBox.questionNumber,
                        questionOrderIndex = qBox.orderIndex,
                        markedChoice = if (forceReview) null else classified.choice,
                        status = if (forceReview) OpticalChoiceStatus.AMBIGUOUS else classified.status,
                        confidence = if (forceReview) 0.0 else effectiveConfidence,
                        fillRatios = fills,
                        reason = if (forceReview) "Form hizalama işaretleri yeterince güvenilir okunamadı." else classified.reason
                    )
                }
            } finally {
                normalized.bitmap.recycle()
            }
        }

        val avgRegistration = if (registrationScores.isEmpty()) 0.0 else registrationScores.average()
        val needsReview = results.any { it.status == OpticalChoiceStatus.MULTIPLE || it.status == OpticalChoiceStatus.AMBIGUOUS }
        return TestOpticalPaperRead(
            questions = results.sortedBy { it.questionOrderIndex },
            registrationConfidence = avgRegistration,
            needsReview = needsReview
        )
    }


    /**
     * Reads a teacher-filled BaykuşNot answer-key form from one PDF or one/more image files.
     * The form uses the same canonical bubble geometry as the student Test form.
     * No OCR, AI, API or network call is performed.
     */
    fun readTeacherAnswerKey(
        context: Context,
        uris: List<Uri>,
        questions: List<ExamQuestion>
    ): TestOpticalPaperRead {
        if (uris.isEmpty()) {
            return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen cevap anahtarı formu seçilmedi.")
        }
        val entities = questions.sortedBy { it.orderIndex }.map { q ->
            ExamQuestionEntity(
                id = 0L,
                examDraftId = q.examDraftId,
                orderIndex = q.orderIndex,
                questionNumber = q.questionNumber,
                normalizedQuestionNumber = q.questionNumber.trim(),
                questionText = q.questionText,
                points = q.points,
                createdAt = 0L,
                updatedAt = 0L
            )
        }
        val layouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = entities,
            rubricCriteria = emptyList(),
            examType = ExamType.MULTIPLE_CHOICE
        )
        if (layouts.isEmpty()) {
            return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen cevap anahtarı formu yerleşimi hesaplanamadı.")
        }
        val expectedDraftId = questions.firstOrNull()?.examDraftId
            ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Test kimliği doğrulanamadı.")
        val expectedToken = TestTeacherAnswerKeyFormGenerator.formToken(expectedDraftId, questions)

        fun isPdf(uri: Uri): Boolean {
            val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
            return mime == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")
        }

        try {
            // First validate only page counts. No page bitmap is retained during this pass.
            var totalPages = 0
            for (uri in uris) {
                if (isPdf(uri)) {
                    val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
                        ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Seçilen PDF açılamadı.")
                    descriptor.use { pfd ->
                        PdfRenderer(pfd).use { renderer ->
                            if (renderer.pageCount <= 0) {
                                return TestOpticalPaperRead(emptyList(), 0.0, true, "Seçilen PDF boş.")
                            }
                            totalPages += renderer.pageCount
                            if (totalPages > layouts.size) {
                                return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formunun sayfa sayısı güncel test yapısıyla uyuşmuyor.")
                            }
                        }
                    }
                } else {
                    totalPages += 1
                    if (totalPages > layouts.size) {
                        return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formunun sayfa sayısı güncel test yapısıyla uyuşmuyor.")
                    }
                }
            }
            if (totalPages != layouts.size) {
                return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formunun sayfa sayısı güncel test yapısıyla uyuşmuyor.")
            }

            val results = mutableListOf<TestOpticalQuestionRead>()
            val registrationScores = mutableListOf<Double>()
            var globalPageIndex = 0

            fun consumeBitmap(bitmap: Bitmap): TestOpticalPaperRead? {
                val layout = layouts.getOrNull(globalPageIndex)
                    ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formunda beklenmeyen fazla sayfa bulundu.")
                val rawQr = decodeTeacherFormQr(bitmap)
                    ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formu karekodu okunamadı. Güncel BaykuşNot formunu yeniden yazdırın.")
                val identity = parseTeacherFormQr(rawQr)
                    ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Seçilen dosya geçerli BaykuşNot öğretmen cevap anahtarı formu değil.")
                val expectedPage = globalPageIndex + 1
                if (identity.version != TestTeacherAnswerKeyFormGenerator.FORM_VERSION ||
                    identity.examDraftId != expectedDraftId ||
                    identity.formToken != expectedToken ||
                    identity.pageIndex != expectedPage ||
                    identity.totalPages != layouts.size) {
                    return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen cevap anahtarı formu eski veya başka bir test yapısına ait. Güncel formu yeniden oluşturun.")
                }
                val pageRead = readBitmapPage(bitmap, layout, entities)
                results += pageRead.first
                registrationScores += pageRead.second
                globalPageIndex++
                return null
            }

            for (uri in uris) {
                if (isPdf(uri)) {
                    val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
                        ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Seçilen PDF açılamadı.")
                    descriptor.use { pfd ->
                        PdfRenderer(pfd).use { renderer ->
                            for (pageIndex in 0 until renderer.pageCount) {
                                renderer.openPage(pageIndex).use { page ->
                                    if (page.width <= 0 || page.height <= 0) {
                                        return TestOpticalPaperRead(emptyList(), 0.0, true, "PDF sayfa boyutu geçersiz.")
                                    }
                                    val aspect = page.height.toDouble() / page.width.toDouble()
                                    if (aspect !in 0.5..2.0) {
                                        return TestOpticalPaperRead(emptyList(), 0.0, true, "PDF sayfa oranı geçerli BaykuşNot formuyla uyuşmuyor.")
                                    }
                                    val width = CANONICAL_WIDTH
                                    val height = (width * aspect).toInt().coerceIn(CANONICAL_HEIGHT / 2, CANONICAL_HEIGHT * 2)
                                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                    try {
                                        Canvas(bitmap).drawColor(android.graphics.Color.WHITE)
                                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                        consumeBitmap(bitmap)?.let { return it }
                                    } finally {
                                        if (!bitmap.isRecycled) bitmap.recycle()
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val bitmap = SafeBitmapDecoder.decodeUri(context, uri)
                        ?: return TestOpticalPaperRead(emptyList(), 0.0, true, "Seçilen öğretmen formu görsel olarak açılamadı.")
                    try {
                        consumeBitmap(bitmap)?.let { return it }
                    } finally {
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
                }
            }

            if (globalPageIndex != layouts.size) {
                return TestOpticalPaperRead(emptyList(), 0.0, true, "Öğretmen formunun tüm sayfaları güvenilir biçimde okunamadı.")
            }
            val avgRegistration = if (registrationScores.isEmpty()) 0.0 else registrationScores.average()
            val needsReview = results.any { it.status != OpticalChoiceStatus.MARKED }
            return TestOpticalPaperRead(
                questions = results.sortedBy { it.questionOrderIndex },
                registrationConfidence = avgRegistration,
                needsReview = needsReview
            )
        } catch (e: Exception) {
            return TestOpticalPaperRead(
                questions = emptyList(),
                registrationConfidence = 0.0,
                needsReview = true,
                errorMessage = e.message ?: "Öğretmen cevap anahtarı formu okunamadı."
            )
        }
    }

    private fun readBitmapPage(
        source: Bitmap,
        layout: AnswerSheetPageLayout,
        questions: List<ExamQuestionEntity>
    ): Pair<List<TestOpticalQuestionRead>, Double> {
        val normalized = normalizePage(source)
        val results = mutableListOf<TestOpticalQuestionRead>()
        try {
            layout.questions.forEach { qBox ->
                val question = questions.firstOrNull { it.orderIndex == qBox.orderIndex }
                val labels = com.example.core.model.MultipleChoiceOptionPolicy.detectLabels(question?.questionText.orEmpty())
                val centerYPt = qBox.topYPt + qBox.headerHeightPt + ((qBox.heightPt - qBox.headerHeightPt) / 2f)
                val fills = linkedMapOf<String, Double>()
                labels.forEachIndexed { index, label ->
                    val xPt = TestOpticalFormGeometry.optionCenterX(index)
                    fills[label] = sampleBubbleInterior(
                        normalized.bitmap,
                        xPt / TestOpticalFormGeometry.pageWidthPt,
                        centerYPt / TestOpticalFormGeometry.pageHeightPt
                    )
                }
                val classified = MultipleChoiceOpticalClassifier.classify(fills)
                val registrationPenalty = if (normalized.confidence >= 0.55) 1.0 else 0.65
                val effectiveConfidence = (classified.confidence * registrationPenalty).coerceIn(0.0, 1.0)
                val forceReview = normalized.confidence < 0.35 && classified.status == OpticalChoiceStatus.MARKED
                results += TestOpticalQuestionRead(
                    questionNumber = qBox.questionNumber,
                    questionOrderIndex = qBox.orderIndex,
                    markedChoice = if (forceReview) null else classified.choice,
                    status = if (forceReview) OpticalChoiceStatus.AMBIGUOUS else classified.status,
                    confidence = if (forceReview) 0.0 else effectiveConfidence,
                    fillRatios = fills,
                    reason = if (forceReview) "Form hizalama işaretleri yeterince güvenilir okunamadı." else classified.reason
                )
            }
        } finally {
            if (normalized.bitmap !== source && !normalized.bitmap.isRecycled) normalized.bitmap.recycle()
        }
        return results to normalized.confidence
    }

    private data class NormalizedPage(val bitmap: Bitmap, val confidence: Double)
    private data class Marker(val x: Float, val y: Float, val score: Double)

    private data class TeacherFormIdentity(
        val version: Int,
        val examDraftId: Long,
        val formToken: String,
        val pageIndex: Int,
        val totalPages: Int
    )

    private fun parseTeacherFormQr(raw: String): TeacherFormIdentity? {
        if (!raw.startsWith("AIEKSAM-TEACHER|")) return null
        var version: Int? = null
        var examId: Long? = null
        var token: String? = null
        var pageIndex: Int? = null
        var totalPages: Int? = null
        raw.split('|').forEach { part ->
            when {
                part.startsWith("V:") -> version = part.removePrefix("V:").toIntOrNull()
                part.startsWith("E:") -> examId = part.removePrefix("E:").toLongOrNull()
                part.startsWith("F:") -> token = part.removePrefix("F:").trim().takeIf { it.isNotEmpty() }
                part.startsWith("P:") -> pageIndex = part.removePrefix("P:").toIntOrNull()
                part.startsWith("T:") -> totalPages = part.removePrefix("T:").toIntOrNull()
            }
        }
        return TeacherFormIdentity(version ?: return null, examId ?: return null, token ?: return null, pageIndex ?: return null, totalPages ?: return null)
    }

    private fun decodeTeacherFormQr(bitmap: Bitmap): String? {
        fun decode(sourceBitmap: Bitmap): String? = try {
            val pixels = IntArray(sourceBitmap.width * sourceBitmap.height)
            sourceBitmap.getPixels(pixels, 0, sourceBitmap.width, 0, 0, sourceBitmap.width, sourceBitmap.height)
            val source = RGBLuminanceSource(sourceBitmap.width, sourceBitmap.height, pixels)
            QRCodeReader().decode(BinaryBitmap(HybridBinarizer(source))).text
        } catch (_: Exception) { null }

        decode(bitmap)?.let { return it }
        return try {
            val left = (bitmap.width * 0.70f).toInt().coerceAtLeast(0)
            val top = 0
            val width = (bitmap.width - left).coerceAtLeast(1)
            val height = (bitmap.height * 0.25f).toInt().coerceAtLeast(1)
            val cropped = Bitmap.createBitmap(bitmap, left, top, width, height.coerceAtMost(bitmap.height))
            try { decode(cropped) } finally { if (!cropped.isRecycled) cropped.recycle() }
        } catch (_: Exception) { null }
    }

    private fun normalizePage(source: Bitmap): NormalizedPage {
        val rotations = listOf(0f, 90f, 180f, 270f).map { angle ->
            val bitmap = if (angle == 0f) source else rotate(source, angle)
            val markers = findRegistrationMarkers(bitmap)
            Triple(bitmap, markers, markers.map { it?.score ?: 0.0 }.average())
        }
        val best = rotations.maxByOrNull { (_, markers, score) ->
            markers.count { it != null } * 10.0 + score
        } ?: return NormalizedPage(source.copy(Bitmap.Config.ARGB_8888, false), 0.0)

        rotations.forEach { item ->
            if (item.first !== best.first && item.first !== source) item.first.recycle()
        }
        val oriented = best.first
        val markers = best.second
        val markerCount = markers.count { it != null }

        if (markerCount == 4) {
            val srcPoints = FloatArray(8)
            markers.forEachIndexed { index, marker ->
                val m = marker!!
                srcPoints[index * 2] = m.x
                srcPoints[index * 2 + 1] = m.y
            }
            val dstPoints = FloatArray(8)
            TestOpticalFormGeometry.registrationCentersPt.forEachIndexed { index, (xPt, yPt) ->
                dstPoints[index * 2] = xPt / TestOpticalFormGeometry.pageWidthPt * CANONICAL_WIDTH
                dstPoints[index * 2 + 1] = yPt / TestOpticalFormGeometry.pageHeightPt * CANONICAL_HEIGHT
            }
            val matrix = Matrix()
            if (matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)) {
                val canonical = Bitmap.createBitmap(CANONICAL_WIDTH, CANONICAL_HEIGHT, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(canonical)
                canvas.drawColor(android.graphics.Color.WHITE)
                canvas.drawBitmap(oriented, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                if (oriented !== source) oriented.recycle()
                return NormalizedPage(canonical, best.third.coerceIn(0.0, 1.0))
            }
        }

        val portrait = if (oriented.width > oriented.height) rotate(oriented, 90f) else oriented
        val canonical = Bitmap.createScaledBitmap(portrait, CANONICAL_WIDTH, CANONICAL_HEIGHT, true)
        if (canonical !== portrait && portrait !== oriented && portrait !== source) portrait.recycle()
        if (canonical !== oriented && oriented !== source && oriented !== portrait) oriented.recycle()
        return NormalizedPage(canonical, (best.third * 0.5).coerceIn(0.0, 0.5))
    }

    private fun findRegistrationMarkers(bitmap: Bitmap): List<Marker?> {
        return TestOpticalFormGeometry.registrationCentersPt.map { (xPt, yPt) ->
            val expectedX = xPt / TestOpticalFormGeometry.pageWidthPt
            val expectedY = yPt / TestOpticalFormGeometry.pageHeightPt
            findDarkSquare(bitmap, expectedX, expectedY)
        }
    }

    private fun findDarkSquare(bitmap: Bitmap, expectedRelX: Float, expectedRelY: Float): Marker? {
        val w = bitmap.width
        val h = bitmap.height
        val searchRadiusX = max(10, (w * 0.022f).toInt())
        val searchRadiusY = max(10, (h * 0.022f).toInt())
        val expectedX = (w * expectedRelX).toInt()
        val expectedY = (h * expectedRelY).toInt()
        val patchRadius = max(3, (min(w, h) * 0.0065f).toInt())
        val step = max(2, patchRadius / 2)
        var best: Marker? = null

        val xStart = max(patchRadius, expectedX - searchRadiusX)
        val xEnd = min(w - patchRadius - 1, expectedX + searchRadiusX)
        val yStart = max(patchRadius, expectedY - searchRadiusY)
        val yEnd = min(h - patchRadius - 1, expectedY + searchRadiusY)
        var y = yStart
        while (y <= yEnd) {
            var x = xStart
            while (x <= xEnd) {
                val score = darkRatio(bitmap, x, y, patchRadius, 85.0)
                if (best == null || score > best!!.score) best = Marker(x.toFloat(), y.toFloat(), score)
                x += step
            }
            y += step
        }
        return best?.takeIf { it.score >= 0.58 }
    }

    private fun sampleBubbleInterior(bitmap: Bitmap, relX: Float, relY: Float): Double {
        val cx = (bitmap.width * relX).toInt()
        val cy = (bitmap.height * relY).toInt()
        // Harf artık baloncuğun içindedir. Merkezdeki basılı harfi ölçüme katmamak için
        // iç merkezi atlayıp baloncuğun dolum halkasını örnekliyoruz.
        val outer = max(4, (bitmap.width * (7.0f / TestOpticalFormGeometry.pageWidthPt)).toInt())
        val inner = max(2, (bitmap.width * (2.6f / TestOpticalFormGeometry.pageWidthPt)).toInt())
        return darkAnnulusRatio(bitmap, cx, cy, inner, outer, 150.0)
    }

    private fun darkAnnulusRatio(bitmap: Bitmap, cx: Int, cy: Int, innerRadius: Int, outerRadius: Int, threshold: Double): Double {
        val left = max(0, cx - outerRadius)
        val right = min(bitmap.width - 1, cx + outerRadius)
        val top = max(0, cy - outerRadius)
        val bottom = min(bitmap.height - 1, cy + outerRadius)
        var dark = 0
        var total = 0
        val inner2 = innerRadius * innerRadius
        val outer2 = outerRadius * outerRadius
        for (y in top..bottom) {
            for (x in left..right) {
                val dx = x - cx
                val dy = y - cy
                val d2 = dx * dx + dy * dy
                if (d2 < inner2 || d2 > outer2) continue
                val pixel = bitmap.getPixel(x, y)
                val rr = (pixel shr 16) and 0xFF
                val gg = (pixel shr 8) and 0xFF
                val bb = pixel and 0xFF
                val lum = 0.299 * rr + 0.587 * gg + 0.114 * bb
                if (lum < threshold) dark++
                total++
            }
        }
        return if (total == 0) 0.0 else dark.toDouble() / total
    }

    private fun darkRatio(bitmap: Bitmap, cx: Int, cy: Int, radius: Int, threshold: Double): Double {
        val left = max(0, cx - radius)
        val right = min(bitmap.width - 1, cx + radius)
        val top = max(0, cy - radius)
        val bottom = min(bitmap.height - 1, cy + radius)
        var dark = 0
        var total = 0
        val r2 = radius * radius
        for (y in top..bottom) {
            for (x in left..right) {
                val dx = x - cx
                val dy = y - cy
                if (dx * dx + dy * dy > r2) continue
                val pixel = bitmap.getPixel(x, y)
                val rr = (pixel shr 16) and 0xFF
                val gg = (pixel shr 8) and 0xFF
                val bb = pixel and 0xFF
                val lum = 0.299 * rr + 0.587 * gg + 0.114 * bb
                if (lum < threshold) dark++
                total++
            }
        }
        return if (total == 0) 0.0 else dark.toDouble() / total
    }

    private fun rotate(source: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }
}
