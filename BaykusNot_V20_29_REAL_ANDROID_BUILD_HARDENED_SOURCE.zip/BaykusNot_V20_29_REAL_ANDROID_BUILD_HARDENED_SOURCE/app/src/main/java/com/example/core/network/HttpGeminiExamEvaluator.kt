package com.example.core.network

import android.content.Context
import com.example.core.model.ExamType
import com.example.core.model.FeedbackDetailLevel
import com.example.core.security.SecureApiKeyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class HttpGeminiExamEvaluator(
    private val okHttpClient: OkHttpClient,
    private val apiKeyStore: SecureApiKeyStore,
    private val context: Context? = null,
    private val sharedCacheManager: GeminiCacheManager? = null
) : ExamEvaluator {

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val cacheManager = sharedCacheManager ?: context?.let { GeminiCacheManager(it, okHttpClient) }

    override suspend fun evaluateStudent(input: ExamStudentEvaluationInput): ExamStudentEvaluationOutput {
        GeminiModelRegistry.requireEvaluationModelApproved(
            input.evaluationModelId ?: GeminiModelRegistry.evaluationModel
        )
        val firstPass = evaluateStudentSinglePass(
            input = input,
            thinkingLevel = "medium",
            allowAutoCache = true
        )
        return finalizeInitialEvaluation(input, firstPass)
    }

    /**
     * Completes the cheap Batch first pass with the same targeted second-check and
     * low-cost detailed-feedback stages used by standard evaluation.
     */
    suspend fun finalizeInitialEvaluation(
        input: ExamStudentEvaluationInput,
        firstPass: ExamStudentEvaluationOutput
    ): ExamStudentEvaluationOutput {
        GeminiModelRegistry.requireEvaluationModelApproved(
            input.evaluationModelId ?: GeminiModelRegistry.evaluationModel
        )
        if (!firstPass.isSuccess || input.examType == ExamType.MULTIPLE_CHOICE) return firstPass

        val suspicious = firstPass.questionEvaluations
            .filter(::needsIndependentSecondCheck)
            .take(MAX_SECOND_CHECKS_PER_PAPER)

        val mergedOutput = if (suspicious.isEmpty()) {
            firstPass
        } else {
            val merged = firstPass.questionEvaluations.associateBy { it.questionOrderIndex }.toMutableMap()
            var secondaryUsage = firstPass.secondaryUsage
            for (firstQuestion in suspicious) {
                val lockedQuestion = input.questions.firstOrNull { it.orderIndex == firstQuestion.questionOrderIndex } ?: continue
                val lockedRubrics = input.rubrics.filter { it.questionOrderIndex == firstQuestion.questionOrderIndex }
                val secondInput = input.copy(
                    questions = listOf(lockedQuestion),
                    rubrics = lockedRubrics,
                    targetQuestionOrderIndex = lockedQuestion.orderIndex,
                    // Keep the second read independent from any first-pass generated cache/output.
                    cachedContentResourceName = null
                )
                val secondPass = evaluateStudentSinglePass(
                    input = secondInput,
                    thinkingLevel = "high",
                    allowAutoCache = false
                )
                secondaryUsage += secondPass.usage + secondPass.secondaryUsage
                val secondQuestion = secondPass.questionEvaluations.singleOrNull()
                merged[firstQuestion.questionOrderIndex] = mergeIndependentChecks(firstQuestion, secondQuestion)
            }

            val finalQuestions = firstPass.questionEvaluations
                .map { merged[it.questionOrderIndex] ?: it }
                .sortedBy { it.questionOrderIndex }
            val avgConfidence = if (finalQuestions.isEmpty()) 0.0 else finalQuestions
                .map { (it.readingConfidence + it.evaluationConfidence) / 2.0 }
                .average()

            firstPass.copy(
                questionEvaluations = finalQuestions,
                totalScore = finalQuestions.sumOf { it.score },
                totalMaxScore = finalQuestions.sumOf { it.maxScore },
                overallConfidence = avgConfidence,
                needsReview = finalQuestions.any { it.needsReview } || avgConfidence < 0.75,
                usage = firstPass.usage,
                secondaryUsage = secondaryUsage
            )
        }

        // Detailed student-facing prose is intentionally generated only AFTER teacher approval.
        return mergedOutput
    }

    private suspend fun evaluateStudentSinglePass(
        input: ExamStudentEvaluationInput,
        thinkingLevel: String,
        allowAutoCache: Boolean
    ): ExamStudentEvaluationOutput {
        if (input.examType == ExamType.MULTIPLE_CHOICE) {
            return ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = "Test Sınavı Gemini ile değerlendirilmez. BaykuşNot Yerel Optik Okuma kullanılmalıdır."
            )
        }
        val promptCopy = EvaluationPromptPolicy.build(
            examType = input.examType,
            rubricAdherenceLevel = input.preferences.rubricAdherenceLevel,
            feedbackDetailLevel = input.preferences.feedbackDetailLevel,
            provideWritingAndPunctuationFeedback = input.preferences.provideWritingAndPunctuationFeedback
        )
        if (input.studentPages.isEmpty() || input.questions.isEmpty()) {
            return ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = "${promptCopy.submissionLabel.replaceFirstChar { it.uppercase() }} sayfası veya ${promptCopy.itemLabel.lowercase()} bulunamadı."
            )
        }

        val imageParts = try {
            withContext(Dispatchers.IO) {
                ExamImagePrivacyProcessor.prepare(input, jpegQuality = 95).map { prepared ->
                buildJsonObject {
                    put("inlineData", buildJsonObject {
                        put("mimeType", "image/jpeg")
                        put("data", prepared.base64Jpeg)
                    })
                    // Handwriting is the accuracy bottleneck; keep image detail high when the locked model supports it.
                    if (input.supportsHighMediaResolution) {
                        put("mediaResolution", buildJsonObject {
                            put("level", "MEDIA_RESOLUTION_HIGH")
                        })
                    }
                }
            }
        }
        } catch (e: ImagePreparationException) {
            return ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = e.message
            )
        }

        if (imageParts.isEmpty()) {
            return ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = "${promptCopy.submissionLabel.replaceFirstChar { it.uppercase() }} görselleri yüklenemedi."
            )
        }

        return try {
            apiKeyStore.useApiKey { apiKey ->
                if (apiKey.isBlank()) {
                    return@useApiKey ExamStudentEvaluationOutput(
                        studentPaperId = input.studentPaperId,
                        questionEvaluations = emptyList(),
                        spellingPunctuationFeedback = null,
                        spellingPunctuationDeduction = 0.0,
                        totalScore = 0.0,
                        totalMaxScore = 0.0,
                        overallConfidence = 0.0,
                        needsReview = true,
                        isSuccess = false,
                        errorMessage = "Gemini API anahtarı eksik veya geçersiz."
                    )
                }
                val systemInstructionText = promptCopy.systemInstruction

                // Check Explicit Prompt Caching. Question-by-question execution may inject
                // a cache built from the full locked item set so each per-item request
                // does not recreate a one-item cache.
                var cachedContentResourceName: String? = input.cachedContentResourceName
                if (allowAutoCache && input.supportsPromptCaching && cachedContentResourceName == null && cacheManager != null && cacheManager.shouldPerformCaching(input.questions, input.rubrics, systemInstructionText, input.preferences.usePromptCaching)) {
                    cachedContentResourceName = cacheManager.getOrCreateCache(
                        draftId = input.preferences.examDraftId,
                        questions = input.questions,
                        rubrics = input.rubrics,
                        systemInstructionText = systemInstructionText,
                        apiKey = apiKey,
                        examType = input.examType,
                        evaluationModelId = input.evaluationModelId ?: GeminiModelRegistry.evaluationModel
                    )
                }

                val userParts = buildJsonArray {
                    if (cachedContentResourceName == null) {
                        val questionsJsonArray = buildJsonArray {
                            input.questions.sortedBy { it.orderIndex }.forEach { q ->
                                add(buildJsonObject {
                                    put("questionOrderIndex", q.orderIndex)
                                    put("questionNumber", q.questionNumber)
                                    put("questionText", q.questionText)
                                    put("maxPoints", q.points)
                                })
                            }
                        }

                        val rubricsJsonArray = buildJsonArray {
                            input.rubrics.sortedBy { it.questionOrderIndex }.forEach { r ->
                                add(buildJsonObject {
                                    put("questionOrderIndex", r.questionOrderIndex)
                                    put("questionNumberSnapshot", r.questionNumberSnapshot)
                                    put("title", r.title)
                                    put("description", r.description)
                                    put("maxPoints", r.maxPoints)
                                    put("expectedAnswer", r.expectedAnswer)
                                    put("partialCreditGuidance", r.partialCreditGuidance)
                                    put("commonMistakes", r.commonMistakes)
                                })
                            }
                        }

                        val promptPayloadObj = buildJsonObject {
                            put("questions", questionsJsonArray)
                            put("rubrics", rubricsJsonArray)
                        }

                        add(buildJsonObject {
                            put("text", "${promptCopy.sharedContextTitle}:\n$promptPayloadObj")
                        })
                    }

                    imageParts.forEach { add(it) }

                    add(buildJsonObject {
                        val baseInstruction = if (input.targetQuestionOrderIndex != null) {
                            "${promptCopy.finalInstruction} Yalnızca questionOrderIndex=${input.targetQuestionOrderIndex} olan ${promptCopy.itemLabel.lowercase()} için değerlendirme üret. Başka ${promptCopy.itemPluralLabel.lowercase()} için çıktı üretme."
                        } else {
                            promptCopy.finalInstruction
                        }
                        val gradeRule = input.gradeLevel?.takeIf { it.isNotBlank() }?.let {
                            " Öğrenci düzeyi: $it. Yaş/sınıf düzeyini yalnız ifade beklentisini ve pedagojik dönüt dilini kalibre etmek için kullan; kilitli rubrik dışında yeni puan koşulu ekleme."
                        }.orEmpty()
                        put("text", baseInstruction + gradeRule)
                    })
                }

                val questionEvalSchema = buildJsonObject {
                    put("type", "OBJECT")
                    put("properties", buildJsonObject {
                        put("questionNumber", buildJsonObject { put("type", "STRING") })
                        put("questionOrderIndex", buildJsonObject { put("type", "INTEGER") })
                        put("readAnswerText", buildJsonObject { put("type", "STRING") })
                        put("interpretedMeaning", buildJsonObject { put("type", "STRING") })
                        put("gradingEvidence", buildJsonObject { put("type", "STRING") })
                        put("score", buildJsonObject { put("type", "NUMBER") })
                        put("maxScore", buildJsonObject { put("type", "NUMBER") })
                        put("strengths", stringArraySchema())
                        put("missingElements", stringArraySchema())
                        put("misconceptions", stringArraySchema())
                        put("nextSteps", stringArraySchema())
                        put("readingConfidence", buildJsonObject { put("type", "NUMBER") })
                        put("evaluationConfidence", buildJsonObject { put("type", "NUMBER") })
                        put("answerType", buildJsonObject { put("type", "STRING") })
                        put("needsReview", buildJsonObject { put("type", "BOOLEAN") })
                        put("reviewReason", buildJsonObject { put("type", "STRING") })
                    })
                    put("required", buildJsonArray {
                        add("questionNumber")
                        add("questionOrderIndex")
                        add("readAnswerText")
                        add("interpretedMeaning")
                        add("gradingEvidence")
                        add("score")
                        add("maxScore")
                        add("strengths")
                        add("missingElements")
                        add("misconceptions")
                        add("nextSteps")
                        add("readingConfidence")
                        add("evaluationConfidence")
                        add("answerType")
                        add("needsReview")
                    })
                }

                val topSchema = buildJsonObject {
                    put("type", "OBJECT")
                    put("properties", buildJsonObject {
                        put("questionEvaluations", buildJsonObject {
                            put("type", "ARRAY")
                            put("items", questionEvalSchema)
                        })
                        put("writingStrengths", stringArraySchema())
                        put("writingIssues", stringArraySchema())
                        put("writingNextSteps", stringArraySchema())
                        put("spellingPunctuationDeduction", buildJsonObject { put("type", "NUMBER") })
                        put("totalScore", buildJsonObject { put("type", "NUMBER") })
                        put("totalMaxScore", buildJsonObject { put("type", "NUMBER") })
                        put("overallConfidence", buildJsonObject { put("type", "NUMBER") })
                        put("needsReview", buildJsonObject { put("type", "BOOLEAN") })
                    })
                    put("required", buildJsonArray {
                        add("questionEvaluations")
                        add("writingStrengths")
                        add("writingIssues")
                        add("writingNextSteps")
                        add("totalScore")
                        add("totalMaxScore")
                        add("overallConfidence")
                        add("needsReview")
                    })
                }

                val generationConfig = buildJsonObject {
                    put("responseMimeType", "application/json")
                    put("responseSchema", topSchema)
                    if (input.supportsThinkingLevel) {
                        put("thinkingConfig", buildJsonObject {
                            put("thinkingLevel", thinkingLevel)
                        })
                    }
                }

                val requestBodyJson = buildJsonObject {
                    put("contents", buildJsonArray {
                        add(buildJsonObject {
                            put("role", "user")
                            put("parts", userParts)
                        })
                    })
                    if (cachedContentResourceName.isNullOrBlank()) {
                        put("systemInstruction", buildJsonObject {
                            put("parts", buildJsonArray {
                                add(buildJsonObject { put("text", systemInstructionText) })
                            })
                        })
                    }
                    put("generationConfig", generationConfig)
                    if (!cachedContentResourceName.isNullOrBlank()) {
                        put("cachedContent", cachedContentResourceName)
                    }
                    put("store", false)
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = requestBodyJson.toString().toRequestBody(mediaType)

                val baseUrl = GeminiModelRegistry.generateContentUrl(input.evaluationModelId ?: GeminiModelRegistry.evaluationModel)
                val request = Request.Builder()
                    .url(baseUrl)
                    .header("x-goog-api-key", apiKey)
                    .post(body)
                    .build()

                val response = withContext(Dispatchers.IO) {
                    okHttpClient.executeCancellable(request)
                }

                response.use { resp ->
                    if (!resp.isSuccessful) {
                        return@useApiKey ExamStudentEvaluationOutput(
                            studentPaperId = input.studentPaperId,
                            questionEvaluations = emptyList(),
                            spellingPunctuationFeedback = null,
                            spellingPunctuationDeduction = 0.0,
                            totalScore = 0.0,
                            totalMaxScore = 0.0,
                            overallConfidence = 0.0,
                            needsReview = true,
                            isSuccess = false,
                            errorMessage = "Gemini API Hatası (HTTP ${resp.code}): ${resp.message}"
                        )
                    }

                    val respBodyStr = resp.body?.string() ?: ""
                    val parsedOutput = parseGeminiResponse(respBodyStr, input)
                    parsedOutput
                }
            } ?: ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = "API anahtarı alınamadı veya doğrulanamadı."
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = emptyList(),
                spellingPunctuationFeedback = null,
                spellingPunctuationDeduction = 0.0,
                totalScore = 0.0,
                totalMaxScore = 0.0,
                overallConfidence = 0.0,
                needsReview = true,
                isSuccess = false,
                errorMessage = "İstek sırasında bir istisna oluştu: ${e.message}"
            )
        }
    }

    fun parseGeminiResponse(
        jsonStr: String,
        input: ExamStudentEvaluationInput
    ): ExamStudentEvaluationOutput {
        try {
            val promptCopy = EvaluationPromptPolicy.build(
                examType = input.examType,
                rubricAdherenceLevel = input.preferences.rubricAdherenceLevel,
                feedbackDetailLevel = input.preferences.feedbackDetailLevel,
                provideWritingAndPunctuationFeedback = input.preferences.provideWritingAndPunctuationFeedback
            )
            val itemLabel = promptCopy.itemLabel
            val itemPluralLabel = promptCopy.itemPluralLabel
            val rootObj = jsonParser.parseToJsonElement(jsonStr).jsonObject
            val usageObj = rootObj["usageMetadata"]?.jsonObject
            val modelStatusObj = rootObj["modelStatus"]?.jsonObject
            val usage = AiUsageMetadata(
                inputTokens = usageObj?.get("promptTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                cachedInputTokens = usageObj?.get("cachedContentTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                outputTokens = usageObj?.get("candidatesTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                thinkingTokens = usageObj?.get("thoughtsTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L,
                actualModelVersion = rootObj["modelVersion"]?.jsonPrimitive?.contentOrNull,
                responseId = rootObj["responseId"]?.jsonPrimitive?.contentOrNull,
                modelStatusStage = modelStatusObj?.get("modelStage")?.jsonPrimitive?.contentOrNull,
                modelRetirementTime = modelStatusObj?.get("retirementTime")?.jsonPrimitive?.contentOrNull,
                modelStatusMessage = modelStatusObj?.get("message")?.jsonPrimitive?.contentOrNull
            )

            var modelOutputText: String? = null

            val candidates = rootObj["candidates"]?.jsonArray
            if (candidates != null && candidates.isNotEmpty()) {
                val firstCand = candidates.firstOrNull()?.jsonObject
                val parts = firstCand?.get("content")?.jsonObject?.get("parts")?.jsonArray
                modelOutputText = parts?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
            }

            if (modelOutputText.isNullOrBlank()) {
                val steps = rootObj["steps"]?.jsonArray
                if (steps != null) {
                    for (step in steps) {
                        val stepObj = step.jsonObject
                        if (stepObj["type"]?.jsonPrimitive?.content == "model_output") {
                            val items = stepObj["items"]?.jsonArray ?: continue
                            for (item in items) {
                                val itemObj = item.jsonObject
                                if (itemObj["type"]?.jsonPrimitive?.content == "text") {
                                    modelOutputText = itemObj["text"]?.jsonPrimitive?.content
                                    if (!modelOutputText.isNullOrBlank()) break
                                }
                            }
                        }
                    }
                }
            }

            if (modelOutputText.isNullOrBlank()) {
                return failParse("Gemini yanıtından metin çıkarılamadı.", input.studentPaperId)
            }

            val dataObj = jsonParser.parseToJsonElement(modelOutputText).jsonObject
            val qEvalsArray = dataObj["questionEvaluations"]?.jsonArray ?: return failParse("$itemLabel değerlendirmeleri dizisi bulunamadı.", input.studentPaperId)

            val expectedQuestions = input.questions.sortedBy { it.orderIndex }
            if (input.targetQuestionOrderIndex != null) {
                if (expectedQuestions.size != 1 || expectedQuestions.single().orderIndex != input.targetQuestionOrderIndex) {
                    return failParse("Hedef ${itemLabel.lowercase()} isteği tek ve eşleşen bir kilitli madde içermiyor.", input.studentPaperId)
                }
            }

            // Requirement 6: Strict Question Count Validation
            if (qEvalsArray.size != expectedQuestions.size) {
                return failParse("AI çıktısındaki $itemLabel sayısı kilitli $itemPluralLabel setiyle uyuşmuyor (Beklenen: ${expectedQuestions.size}, Gelen: ${qEvalsArray.size}).", input.studentPaperId)
            }

            val questionOutputs = mutableListOf<QuestionEvaluationOutput>()
            var overallNeedsReview = false
            var confidenceSum = 0.0

            val expectedQuestionMapByNum = expectedQuestions.associateBy { it.questionNumber }
            val expectedQuestionMapByOrder = expectedQuestions.associateBy { it.orderIndex }
            val processedQuestions = mutableSetOf<Int>()

            for (item in qEvalsArray) {
                val qObj = item.jsonObject
                val qNum = qObj["questionNumber"]?.jsonPrimitive?.content ?: ""
                val qOrder = qObj["questionOrderIndex"]?.jsonPrimitive?.intOrNull ?: 0

                val qByNum = expectedQuestionMapByNum[qNum]
                val qByOrder = expectedQuestionMapByOrder[qOrder]

                // Requirement 6: Verification that both questionNumber AND questionOrderIndex match the exact same locked question
                if (qByNum == null || qByOrder == null || qByNum.orderIndex != qByOrder.orderIndex) {
                    return failParse("$itemLabel kimliği uyumsuzluğu ($qNum vs Sıra $qOrder). Çıktı reddedildi.", input.studentPaperId)
                }

                val targetQuestion = qByNum

                if (processedQuestions.contains(targetQuestion.orderIndex)) {
                    return failParse("AI çıktısında mükerrer (iki kez dönen) $itemLabel bulundu: $itemLabel ${targetQuestion.orderIndex}.", input.studentPaperId)
                }
                processedQuestions.add(targetQuestion.orderIndex)

                // Requirement 6: maxScore MUST match locked question points (SSOT)
                val maxScore = targetQuestion.points.toDouble()
                val rawMaxScore = qObj["maxScore"]?.jsonPrimitive?.doubleOrNull
                if (rawMaxScore != null && rawMaxScore != maxScore) {
                    return failParse("AI çıktısındaki maxScore ($rawMaxScore) kilitli $itemLabel puanı ($maxScore) ile uyuşmuyor.", input.studentPaperId)
                }

                // Requirement 7: Invalid Score handling (NO silent coerceIn clamping)
                val rawScore = qObj["score"]?.jsonPrimitive?.doubleOrNull
                if (rawScore == null || rawScore < 0.0 || rawScore > maxScore) {
                    return failParse("Geçersiz puan verildi: $rawScore ($itemLabel max puanı: $maxScore). Değerlendirme reddedildi.", input.studentPaperId)
                }
                val score = rawScore

                // Requirement 7: Confidence values - no arbitrary defaults or invalid ranges
                val rawRConf = qObj["readingConfidence"]?.jsonPrimitive?.doubleOrNull
                val rawEConf = qObj["evaluationConfidence"]?.jsonPrimitive?.doubleOrNull
                if (rawRConf == null || rawEConf == null || rawRConf !in 0.0..1.0 || rawEConf !in 0.0..1.0) {
                    return failParse("Geçersiz okuma/değerlendirme güven derecesi ($rawRConf, $rawEConf). Değerlendirme reddedildi.", input.studentPaperId)
                }
                val rConf = rawRConf
                val eConf = rawEConf

                // Requirement 8: Strict Answer Types (NORMAL, UNANSWERED, UNREADABLE, LOW_CONFIDENCE)
                val answerType = qObj["answerType"]?.jsonPrimitive?.content ?: ""
                val validAnswerTypes = setOf("NORMAL", "UNANSWERED", "UNREADABLE", "LOW_CONFIDENCE")
                if (answerType !in validAnswerTypes) {
                    return failParse("Geçersiz cevap türü döndürüldü: '$answerType'. Değerlendirme reddedildi.", input.studentPaperId)
                }

                var qNeedsReview = qObj["needsReview"]?.jsonPrimitive?.booleanOrNull ?: false
                var reviewReason = qObj["reviewReason"]?.jsonPrimitive?.content

                if (rConf < 0.65 || eConf < 0.65) {
                    qNeedsReview = true
                    if (reviewReason.isNullOrBlank()) {
                        reviewReason = "Düşük okuma/değerlendirme güveni (${String.format("%.2f", min(rConf, eConf))})"
                    }
                }

                if (answerType == "UNREADABLE") {
                    qNeedsReview = true
                    if (reviewReason.isNullOrBlank()) {
                        reviewReason = "El yazısı okunamadı veya anlaşılmadı."
                    }
                }

                if (answerType == "LOW_CONFIDENCE") {
                    qNeedsReview = true
                    if (reviewReason.isNullOrBlank()) {
                        reviewReason = "Değerlendirme güveni düşük."
                    }
                }

                if (qNeedsReview) {
                    overallNeedsReview = true
                }

                confidenceSum += (rConf + eConf) / 2.0

                questionOutputs.add(
                    QuestionEvaluationOutput(
                        questionNumber = targetQuestion.questionNumber,
                        questionOrderIndex = targetQuestion.orderIndex,
                        readAnswerText = qObj["readAnswerText"]?.jsonPrimitive?.content ?: "",
                        score = score,
                        maxScore = maxScore,
                        feedback = null,
                        readingConfidence = rConf,
                        evaluationConfidence = eConf,
                        answerType = answerType,
                        needsReview = qNeedsReview,
                        reviewReason = reviewReason,
                        interpretedMeaning = qObj["interpretedMeaning"]?.jsonPrimitive?.content,
                        gradingEvidence = qObj["gradingEvidence"]?.jsonPrimitive?.content,
                        strengths = parseStringArray(qObj, "strengths"),
                        missingElements = parseStringArray(qObj, "missingElements"),
                        misconceptions = parseStringArray(qObj, "misconceptions"),
                        nextSteps = parseStringArray(qObj, "nextSteps")
                    )
                )
            }

            if (processedQuestions.size != expectedQuestions.size) {
                return failParse("AI çıktısında kilitli $itemPluralLabel içinden bazıları eksik.", input.studentPaperId)
            }

            questionOutputs.sortBy { it.questionOrderIndex }

            val writingStrengths = parseStringArray(dataObj, "writingStrengths")
            val writingIssues = parseStringArray(dataObj, "writingIssues")
            val writingNextSteps = parseStringArray(dataObj, "writingNextSteps")
            val spellingDeduction = dataObj["spellingPunctuationDeduction"]?.jsonPrimitive?.doubleOrNull?.coerceAtLeast(0.0) ?: 0.0

            val calcQuestionSum = questionOutputs.sumOf { it.score }
            val calcTotalMax = expectedQuestions.sumOf { it.points.toDouble() }

            val avgConf = if (questionOutputs.isNotEmpty()) confidenceSum / questionOutputs.size else 1.0
            val needsReviewFinal = overallNeedsReview || (avgConf < 0.70) || (dataObj["needsReview"]?.jsonPrimitive?.booleanOrNull == true)

            return ExamStudentEvaluationOutput(
                studentPaperId = input.studentPaperId,
                questionEvaluations = questionOutputs,
                spellingPunctuationFeedback = null,
                writingStrengths = if (input.preferences.provideWritingAndPunctuationFeedback) writingStrengths else emptyList(),
                writingIssues = if (input.preferences.provideWritingAndPunctuationFeedback) writingIssues else emptyList(),
                writingNextSteps = if (input.preferences.provideWritingAndPunctuationFeedback) writingNextSteps else emptyList(),
                spellingPunctuationDeduction = spellingDeduction,
                totalScore = calcQuestionSum,
                totalMaxScore = calcTotalMax,
                overallConfidence = avgConf,
                needsReview = needsReviewFinal,
                isSuccess = true,
                errorMessage = null,
                usage = usage
            )
        } catch (e: Exception) {
            return failParse("Yanıt ayrıştırılamadı: ${e.message}", input.studentPaperId)
        }
    }

    private fun needsIndependentSecondCheck(q: QuestionEvaluationOutput): Boolean {
        if (q.answerType == "UNANSWERED") return false
        if (q.needsReview || q.answerType == "UNREADABLE" || q.answerType == "LOW_CONFIDENCE") return true
        if (q.readingConfidence < 0.82 || q.evaluationConfidence < 0.78) return true
        if (q.answerType == "NORMAL" && q.readAnswerText.isNotBlank() && q.score <= 0.0) return true
        if (q.maxScore > 0.0 && q.score / q.maxScore <= 0.20 && q.evaluationConfidence < 0.88) return true
        return false
    }

    private fun mergeIndependentChecks(
        first: QuestionEvaluationOutput,
        second: QuestionEvaluationOutput?
    ): QuestionEvaluationOutput {
        if (second == null) {
            return first.copy(
                needsReview = true,
                reviewReason = mergeReviewReason(first.reviewReason, "Bağımsız ikinci kontrol tamamlanamadı; öğretmen kontrolü gerekiyor.")
            )
        }

        val firstConfidence = (first.readingConfidence + first.evaluationConfidence) / 2.0
        val secondConfidence = (second.readingConfidence + second.evaluationConfidence) / 2.0
        val firstUncertain = first.answerType == "UNREADABLE" || first.answerType == "LOW_CONFIDENCE"
        val secondLooksCleaner = second.answerType == "NORMAL" && second.readingConfidence >= 0.78 && second.evaluationConfidence >= 0.75
        val chosen = when {
            firstUncertain && secondLooksCleaner -> second
            secondConfidence >= firstConfidence + 0.03 -> second
            else -> first
        }

        val materialScoreDifference = abs(first.score - second.score) > max(1.0, first.maxScore * 0.20)
        val stillUncertain = chosen.answerType == "UNREADABLE" ||
            chosen.answerType == "LOW_CONFIDENCE" ||
            chosen.readingConfidence < 0.78 ||
            chosen.evaluationConfidence < 0.75
        val mustReview = materialScoreDifference || stillUncertain
        val discrepancyReason = if (materialScoreDifference) {
            "Bağımsız ikinci kontrolde puan farkı oluştu (${first.score}/${first.maxScore} ve ${second.score}/${second.maxScore}); öğretmen kontrolü gerekiyor."
        } else null

        return chosen.copy(
            needsReview = mustReview,
            reviewReason = when {
                discrepancyReason != null -> mergeReviewReason(chosen.reviewReason, discrepancyReason)
                stillUncertain -> mergeReviewReason(chosen.reviewReason, "İkinci kontrolden sonra da okuma veya puanlama güveni yeterince yüksek değil.")
                else -> null
            }
        )
    }

    private fun mergeReviewReason(first: String?, second: String): String {
        return if (first.isNullOrBlank()) second else "$first $second"
    }

    private companion object {
        const val MAX_SECOND_CHECKS_PER_PAPER = 6
    }

    fun getCacheManager(): GeminiCacheManager? = cacheManager

    fun buildStudentRequestBody(
        input: ExamStudentEvaluationInput,
        cachedContentResourceName: String?
    ): String {
        require(input.examType != ExamType.MULTIPLE_CHOICE) {
            "Test Sınavı için Gemini istek gövdesi oluşturulamaz; Yerel Optik Okuma kullanılmalıdır."
        }
        val imageParts = ExamImagePrivacyProcessor.prepare(input, jpegQuality = 94).map { prepared ->
            buildJsonObject {
                put("inlineData", buildJsonObject {
                    put("mimeType", "image/jpeg")
                    put("data", prepared.base64Jpeg)
                })
                if (input.supportsHighMediaResolution) {
                    put("mediaResolution", buildJsonObject {
                        put("level", "MEDIA_RESOLUTION_HIGH")
                    })
                }
            }
        }
        require(imageParts.isNotEmpty()) {
            "Öğrenci kâğıdı görselleri güvenli biçimde hazırlanamadı; Batch isteği oluşturulmadı."
        }
        val promptCopy = EvaluationPromptPolicy.build(
            examType = input.examType,
            rubricAdherenceLevel = input.preferences.rubricAdherenceLevel,
            feedbackDetailLevel = input.preferences.feedbackDetailLevel,
            provideWritingAndPunctuationFeedback = input.preferences.provideWritingAndPunctuationFeedback
        )
        val systemInstructionText = promptCopy.systemInstruction

        val userParts = buildJsonArray {
            if (cachedContentResourceName.isNullOrBlank()) {
                val questionsJsonArray = buildJsonArray {
                    input.questions.sortedBy { it.orderIndex }.forEach { q ->
                        add(buildJsonObject {
                            put("questionOrderIndex", q.orderIndex)
                            put("questionNumber", q.questionNumber)
                            put("questionText", q.questionText)
                            put("maxPoints", q.points)
                        })
                    }
                }

                val rubricsJsonArray = buildJsonArray {
                    input.rubrics.sortedBy { it.questionOrderIndex }.forEach { r ->
                        add(buildJsonObject {
                            put("questionOrderIndex", r.questionOrderIndex)
                            put("questionNumberSnapshot", r.questionNumberSnapshot)
                            put("title", r.title)
                            put("description", r.description)
                            put("maxPoints", r.maxPoints)
                            put("expectedAnswer", r.expectedAnswer)
                            put("partialCreditGuidance", r.partialCreditGuidance)
                            put("commonMistakes", r.commonMistakes)
                        })
                    }
                }

                val promptPayloadObj = buildJsonObject {
                    put("questions", questionsJsonArray)
                    put("rubrics", rubricsJsonArray)
                }

                add(buildJsonObject {
                    put("text", "${promptCopy.sharedContextTitle}:\n$promptPayloadObj")
                })
            }

            imageParts.forEach { add(it) }

            add(buildJsonObject {
                val baseInstruction = if (input.targetQuestionOrderIndex != null) {
                    "${promptCopy.finalInstruction} Yalnızca questionOrderIndex=${input.targetQuestionOrderIndex} olan ${promptCopy.itemLabel.lowercase()} için değerlendirme üret. Başka ${promptCopy.itemPluralLabel.lowercase()} için çıktı üretme."
                } else {
                    promptCopy.finalInstruction
                }
                val gradeRule = input.gradeLevel?.takeIf { it.isNotBlank() }?.let {
                    " Öğrenci düzeyi: $it. Yaş/sınıf düzeyini yalnız ifade beklentisini ve pedagojik dönüt dilini kalibre etmek için kullan; kilitli rubrik dışında yeni puan koşulu ekleme."
                }.orEmpty()
                put("text", baseInstruction + gradeRule)
            })
        }

        val questionEvalSchema = buildJsonObject {
            put("type", "OBJECT")
            put("properties", buildJsonObject {
                put("questionNumber", buildJsonObject { put("type", "STRING") })
                put("questionOrderIndex", buildJsonObject { put("type", "INTEGER") })
                put("readAnswerText", buildJsonObject { put("type", "STRING") })
                put("interpretedMeaning", buildJsonObject { put("type", "STRING") })
                put("gradingEvidence", buildJsonObject { put("type", "STRING") })
                put("score", buildJsonObject { put("type", "NUMBER") })
                put("maxScore", buildJsonObject { put("type", "NUMBER") })
                put("strengths", stringArraySchema())
                put("missingElements", stringArraySchema())
                put("misconceptions", stringArraySchema())
                put("nextSteps", stringArraySchema())
                put("readingConfidence", buildJsonObject { put("type", "NUMBER") })
                put("evaluationConfidence", buildJsonObject { put("type", "NUMBER") })
                put("answerType", buildJsonObject { put("type", "STRING") })
                put("needsReview", buildJsonObject { put("type", "BOOLEAN") })
                put("reviewReason", buildJsonObject { put("type", "STRING") })
            })
            put("required", buildJsonArray {
                add("questionNumber")
                add("questionOrderIndex")
                add("readAnswerText")
                add("interpretedMeaning")
                add("gradingEvidence")
                add("score")
                add("maxScore")
                add("strengths")
                add("missingElements")
                add("misconceptions")
                add("nextSteps")
                add("readingConfidence")
                add("evaluationConfidence")
                add("answerType")
                add("needsReview")
            })
        }

        val topSchema = buildJsonObject {
            put("type", "OBJECT")
            put("properties", buildJsonObject {
                put("questionEvaluations", buildJsonObject {
                    put("type", "ARRAY")
                    put("items", questionEvalSchema)
                })
                put("writingStrengths", stringArraySchema())
                put("writingIssues", stringArraySchema())
                put("writingNextSteps", stringArraySchema())
                put("spellingPunctuationDeduction", buildJsonObject { put("type", "NUMBER") })
                put("totalScore", buildJsonObject { put("type", "NUMBER") })
                put("totalMaxScore", buildJsonObject { put("type", "NUMBER") })
                put("overallConfidence", buildJsonObject { put("type", "NUMBER") })
                put("needsReview", buildJsonObject { put("type", "BOOLEAN") })
            })
            put("required", buildJsonArray {
                add("questionEvaluations")
                add("writingStrengths")
                add("writingIssues")
                add("writingNextSteps")
                add("totalScore")
                add("totalMaxScore")
                add("overallConfidence")
                add("needsReview")
            })
        }

        val generationConfig = buildJsonObject {
            put("responseMimeType", "application/json")
            put("responseSchema", topSchema)
            if (input.supportsThinkingLevel) {
                put("thinkingConfig", buildJsonObject {
                    put("thinkingLevel", "medium")
                })
            }
        }

        val requestBodyJson = buildJsonObject {
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", userParts)
                })
            })
            if (cachedContentResourceName.isNullOrBlank()) {
                put("systemInstruction", buildJsonObject {
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", systemInstructionText) })
                    })
                })
            }
            put("generationConfig", generationConfig)
            if (!cachedContentResourceName.isNullOrBlank()) {
                put("cachedContent", cachedContentResourceName)
            }
            put("store", false)
        }

        return requestBodyJson.toString()
    }

    private fun stringArraySchema() = buildJsonObject {
        put("type", "ARRAY")
        put("items", buildJsonObject { put("type", "STRING") })
    }

    private fun parseStringArray(obj: kotlinx.serialization.json.JsonObject, key: String): List<String> =
        obj[key]?.jsonArray?.mapNotNull { it.jsonPrimitive.content.trim().takeIf(String::isNotBlank) }.orEmpty()

    private fun failParse(msg: String, studentPaperId: Long = 0L): ExamStudentEvaluationOutput {
        return ExamStudentEvaluationOutput(
            studentPaperId = studentPaperId,
            questionEvaluations = emptyList(),
            spellingPunctuationFeedback = null,
            spellingPunctuationDeduction = 0.0,
            totalScore = 0.0,
            totalMaxScore = 0.0,
            overallConfidence = 0.0,
            needsReview = true,
            isSuccess = false,
            errorMessage = msg
        )
    }

}

