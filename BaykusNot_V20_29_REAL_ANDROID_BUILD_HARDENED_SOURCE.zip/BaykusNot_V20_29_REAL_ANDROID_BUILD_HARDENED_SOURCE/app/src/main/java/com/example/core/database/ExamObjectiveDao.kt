package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamObjectiveDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObjectives(objectives: List<ExamObjectiveEntity>): List<Long>

    @Query("DELETE FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 0")
    suspend fun deleteApprovedObjectivesByDraftId(examDraftId: Long)

    @Transaction
    suspend fun replaceObjectivesForDraft(examDraftId: Long, objectives: List<ExamObjectiveEntity>) {
        deleteApprovedObjectivesByDraftId(examDraftId)
        insertObjectives(objectives.map { it.copy(isStaging = false) })
    }

    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 0 ORDER BY id ASC")
    fun observeApprovedObjectivesByDraftId(examDraftId: Long): Flow<List<ExamObjectiveEntity>>

    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 0 ORDER BY id ASC")
    suspend fun getApprovedObjectivesByDraftId(examDraftId: Long): List<ExamObjectiveEntity>

    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 1 ORDER BY id ASC")
    fun observeStagingObjectivesByDraftId(examDraftId: Long): Flow<List<ExamObjectiveEntity>>

    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 1 ORDER BY id ASC")
    suspend fun getStagingObjectivesByDraftId(examDraftId: Long): List<ExamObjectiveEntity>

    @Query("DELETE FROM exam_objective WHERE examDraftId = :examDraftId AND isStaging = 1")
    suspend fun deleteStagingObjectivesByDraftId(examDraftId: Long)

    @Transaction
    suspend fun replaceStagingObjectivesForDraft(examDraftId: Long, objectives: List<ExamObjectiveEntity>) {
        deleteStagingObjectivesByDraftId(examDraftId)
        insertObjectives(objectives.map { it.copy(isStaging = true) })
    }

    @Query("UPDATE exam_objective SET isStaging = 0 WHERE examDraftId = :examDraftId AND isStaging = 1")
    suspend fun approveStagingObjectives(examDraftId: Long)

    @Query("UPDATE exam_draft SET hasScenario = 1, isScenarioApproved = 1, isObjectiveMappingApproved = 0, isMismatchAccepted = 0 WHERE id = :draftId")
    suspend fun approveDraftScenario(draftId: Long)

    @Transaction
    suspend fun approveStagingObjectivesAndDraft(draftId: Long) {
        deleteApprovedObjectivesByDraftId(draftId)
        approveStagingObjectives(draftId)
        approveDraftScenario(draftId)
    }

    // For backwards compat inside codebase if there was an old observeObjectivesByDraftId without staging filter:
    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId ORDER BY id ASC")
    fun observeObjectivesByDraftId(examDraftId: Long): Flow<List<ExamObjectiveEntity>>
    
    @Query("SELECT * FROM exam_objective WHERE examDraftId = :examDraftId ORDER BY id ASC")
    suspend fun getObjectivesByDraftId(examDraftId: Long): List<ExamObjectiveEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestionObjectiveCrossRefs(refs: List<QuestionObjectiveCrossRef>)

    @Query("DELETE FROM question_objective_cross_ref WHERE questionId IN (SELECT id FROM exam_question WHERE examDraftId = :examDraftId)")
    suspend fun deleteQuestionObjectiveCrossRefsByDraftId(examDraftId: Long)

    @Query("UPDATE exam_draft SET isObjectiveMappingApproved = 0, isMismatchAccepted = 0, updatedAt = :updatedAt WHERE id = :examDraftId")
    suspend fun invalidateQuestionObjectiveMappingApproval(examDraftId: Long, updatedAt: Long): Int

    @Transaction
    suspend fun replaceQuestionObjectiveCrossRefsForDraft(examDraftId: Long, refs: List<QuestionObjectiveCrossRef>, updatedAt: Long) {
        if (invalidateQuestionObjectiveMappingApproval(examDraftId, updatedAt) != 1) {
            throw IllegalStateException("DRAFT_NOT_FOUND")
        }
        deleteQuestionObjectiveCrossRefsByDraftId(examDraftId)
        insertQuestionObjectiveCrossRefs(refs)
    }

    @Query("SELECT * FROM question_objective_cross_ref WHERE questionId IN (SELECT id FROM exam_question WHERE examDraftId = :examDraftId)")
    fun observeQuestionObjectiveCrossRefsByDraftId(examDraftId: Long): Flow<List<QuestionObjectiveCrossRef>>

    @Query("SELECT * FROM question_objective_cross_ref WHERE questionId IN (SELECT id FROM exam_question WHERE examDraftId = :examDraftId)")
    suspend fun getQuestionObjectiveCrossRefsByDraftId(examDraftId: Long): List<QuestionObjectiveCrossRef>
}
