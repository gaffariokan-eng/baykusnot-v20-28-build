package com.example.feature.workflow

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamEvaluationRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ListeningAnswerSheetGuidance
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamQuestionEvaluationEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.database.ExamStudentEvaluationEntity
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.database.ExamReviewRequestEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class StudentReviewItem(
    val paper: ExamStudentPaperEntity,
    val evaluation: ExamStudentEvaluationEntity?,
    val questionEvaluations: List<ExamQuestionEvaluationEntity>,
    val pages: List<ExamPaperPageEntity>,
    val reviewRequests: List<ExamReviewRequestEntity> = emptyList()
)

data class TeacherReviewUiState(
    val isLoading: Boolean = false,
    val students: List<StudentReviewItem> = emptyList(),
    val rubrics: List<ExamRubricCriterionEntity> = emptyList(),
    val questions: List<ExamQuestionEntity> = emptyList(),
    val layoutDensity: String = "AUTOMATIC",
    val lineOverrides: Map<Int, Int> = emptyMap(),
    val listeningGuidance: ListeningAnswerSheetGuidance? = null,
    val selectedStudentPaperId: Long? = null,
    val message: String? = null,
    val isConfirming: Boolean = false,
    val isSavingChanges: Boolean = false
)

class TeacherReviewViewModel(
    private val examDraftId: Long,
    private val evaluationRepository: ExamEvaluationRepository,
    private val paperUploadRepository: ExamPaperUploadRepository,
    private val questionRepository: ExamQuestionRepository,
    private val examType: ExamType = ExamType.WRITTEN
) : ViewModel() {

    private val _uiState = MutableStateFlow(TeacherReviewUiState(isLoading = true))
    val uiState: StateFlow<TeacherReviewUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun launchTrackedMutation(block: suspend () -> Unit) {
        val state = _uiState.value
        if (state.isSavingChanges || state.isConfirming) return
        _uiState.value = state.copy(isSavingChanges = true, message = null)
        viewModelScope.launch {
            try {
                block()
            } finally {
                _uiState.value = _uiState.value.copy(isSavingChanges = false)
            }
        }
    }

    fun loadData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, message = null)
            try {
                val papers = paperUploadRepository.getStudentPapersOnce(examDraftId)
                val evals = evaluationRepository.getStudentEvaluationsForExamOnce(examDraftId)
                val evalMap = evals.associateBy { it.studentPaperId }
                val rubrics = evaluationRepository.getRubricsOnce(examDraftId)
                val questions = questionRepository.getQuestionsEntitiesOnce(examDraftId)
                val qEvalsByPaper = evaluationRepository.getQuestionEvaluationsForExamOnce(examDraftId)
                    .groupBy { it.studentPaperId }
                val pagesByPaper = paperUploadRepository.getPagesForExamOnce(examDraftId)
                    .groupBy { it.studentPaperId }
                val reviewRequestsByPaper = evaluationRepository.getReviewRequestsForExam(examDraftId)
                    .groupBy { it.studentPaperId }

                val studentItems = papers.map { paper ->
                    StudentReviewItem(
                        paper = paper,
                        evaluation = evalMap[paper.id],
                        questionEvaluations = qEvalsByPaper[paper.id].orEmpty(),
                        pages = pagesByPaper[paper.id].orEmpty(),
                        reviewRequests = reviewRequestsByPaper[paper.id].orEmpty()
                    )
                }

                // Requirement 15: Sort by class/branch then numeric school number
                val sortedStudents = studentItems.sortedWith(
                    compareBy<StudentReviewItem> { it.paper.classLevel ?: "" }
                        .thenBy { it.paper.branch ?: "" }
                        .thenBy { it.paper.schoolNumber?.toIntOrNull() ?: Int.MAX_VALUE }
                        .thenBy { it.paper.studentSequenceIndex }
                )
                val density = paperUploadRepository.getLayoutDensity(examDraftId)
                val lineOverrides = paperUploadRepository.getLineOverrides(examDraftId)
                val listeningGuidance = paperUploadRepository.getAnswerSheetGuidance(examDraftId)

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    students = sortedStudents,
                    rubrics = rubrics,
                    questions = questions,
                    layoutDensity = density,
                    lineOverrides = lineOverrides,
                    listeningGuidance = listeningGuidance
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    message = "Veriler yüklenirken hata oluştu: ${e.message}"
                )
            }
        }
    }

    fun selectStudent(studentPaperId: Long?) {
        _uiState.value = _uiState.value.copy(selectedStudentPaperId = studentPaperId)
    }

    fun selectNextStudentNeedingReview() {
        if (examType != ExamType.MULTIPLE_CHOICE) return
        val state = _uiState.value
        val problemStudents = state.students.filter { student ->
            student.questionEvaluations.any { it.needsReview && !it.isResolved }
        }
        if (problemStudents.isEmpty()) {
            _uiState.value = state.copy(message = "Çözülmemiş test işaretlemesi kalmadı.")
            return
        }
        val current = state.selectedStudentPaperId
        val currentIndex = problemStudents.indexOfFirst { it.paper.id == current }
        val nextIndex = if (currentIndex < 0 || currentIndex + 1 >= problemStudents.size) 0 else currentIndex + 1
        _uiState.value = state.copy(
            selectedStudentPaperId = problemStudents[nextIndex].paper.id,
            message = null
        )
    }

    fun updateQuestionScore(questionEvalId: Long, newScoreText: String) {
        launchTrackedMutation {
            try {
                val currentStudents = _uiState.value.students
                var targetPaperId: Long? = null
                var targetQEval: ExamQuestionEvaluationEntity? = null

                for (student in currentStudents) {
                    val qEval = student.questionEvaluations.find { it.id == questionEvalId }
                    if (qEval != null) {
                        targetPaperId = student.paper.id
                        targetQEval = qEval
                        break
                    }
                }

                if (targetPaperId == null || targetQEval == null) return@launchTrackedMutation

                val parsedScore = newScoreText.toDoubleOrNull()
                if (parsedScore == null || parsedScore < 0.0 || parsedScore > targetQEval.maxScore) {
                    _uiState.value = _uiState.value.copy(
                        message = "Geçersiz puan! Puan 0.0 ile ${targetQEval.maxScore} arasında olmalıdır."
                    )
                    return@launchTrackedMutation
                }
                if (examType == ExamType.MULTIPLE_CHOICE &&
                    parsedScore != 0.0 && kotlin.math.abs(parsedScore - targetQEval.maxScore) > 0.0001
                ) {
                    _uiState.value = _uiState.value.copy(
                        message = "Test sorusunda kısmi puan kullanılamaz. Yalnız 0 veya ${targetQEval.maxScore} puan verebilirsiniz."
                    )
                    return@launchTrackedMutation
                }

                // One Room transaction: question score + recomputed total + approval/final-feedback invalidation.
                // A material change also clears the old AI pedagogical diagnosis for this question.
                evaluationRepository.applyTeacherScoreChange(
                    questionEvalId = questionEvalId,
                    score = parsedScore
                )

                _uiState.value = _uiState.value.copy(message = null)
                loadData()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(message = "Puan güncellenemedi: ${e.message}")
            }
        }
    }

    fun resolveMultipleChoiceAnswer(questionEvalId: Long, selectedChoice: String?) {
        if (examType != ExamType.MULTIPLE_CHOICE) return
        launchTrackedMutation {
            try {
                val state = _uiState.value
                val qEval = state.students.asSequence()
                    .flatMap { it.questionEvaluations.asSequence() }
                    .firstOrNull { it.id == questionEvalId } ?: return@launchTrackedMutation
                val expected = state.rubrics
                    .firstOrNull { it.questionOrderIndex == qEval.questionOrderIndex }
                    ?.expectedAnswer
                    ?.trim()
                    ?.uppercase()
                    ?.takeIf { it.isNotBlank() }
                    ?: run {
                        _uiState.value = state.copy(message = "Bu soru için kilitli cevap anahtarı bulunamadı.")
                        return@launchTrackedMutation
                    }
                evaluationRepository.resolveLocalMultipleChoiceAnswer(qEval, selectedChoice, expected)
                _uiState.value = _uiState.value.copy(message = null)
                loadData()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(message = "Test işaretlemesi güncellenemedi: ${e.message}")
            }
        }
    }

    fun resolveWithoutScoreChange(questionEvalId: Long) {
        launchTrackedMutation {
            try {
                val currentStudents = _uiState.value.students
                var targetQEval: ExamQuestionEvaluationEntity? = null
                for (student in currentStudents) {
                    val q = student.questionEvaluations.find { it.id == questionEvalId }
                    if (q != null) {
                        targetQEval = q
                        break
                    }
                }
                if (targetQEval == null) return@launchTrackedMutation

                evaluationRepository.updateQuestionEvaluationScore(
                    questionEvalId = questionEvalId,
                    score = targetQEval.score,
                    isTeacherModified = targetQEval.isTeacherModified,
                    isResolved = true
                )
                loadData()
            } catch (e: Exception) {
                val itemLabel = when (examType) {
                    ExamType.HOMEWORK -> "Görev/madde"
                    ExamType.READINESS -> "Hazırbulunuşluk sorusu"
                    else -> "Soru"
                }
                _uiState.value = _uiState.value.copy(message = "$itemLabel çözüldü olarak işaretlenemedi: ${e.message}")
            }
        }
    }

    fun recordStudentParentReviewRequest(studentPaperId: Long, reason: String) {
        launchTrackedMutation {
            runCatching {
                evaluationRepository.recordStudentParentReviewRequest(examDraftId, studentPaperId, reason)
            }.onSuccess {
                _uiState.value = _uiState.value.copy(message = "Yeniden inceleme talebi kaydedildi.")
                loadData()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(message = error.message ?: "Yeniden inceleme talebi kaydedilemedi.")
            }
        }
    }

    fun resolveStudentParentReviewRequest(requestId: Long) {
        launchTrackedMutation {
            runCatching {
                evaluationRepository.resolveStudentParentReviewRequest(
                    requestId,
                    "Öğretmen yeniden incelemeyi tamamladı; güncel puan ve açıklamalar kayıt altına alındı."
                )
            }.onSuccess {
                _uiState.value = _uiState.value.copy(message = "Yeniden inceleme talebi sonuçlandırıldı.")
                loadData()
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(message = error.message ?: "Yeniden inceleme talebi kapatılamadı.")
            }
        }
    }

    fun updateTeacherNote(studentPaperId: Long, note: String) {
        launchTrackedMutation {
            runCatching { evaluationRepository.updateTeacherNote(studentPaperId, note) }
                .onSuccess {
                    _uiState.value = _uiState.value.copy(message = "Öğretmen notu kaydedildi.")
                    loadData()
                }
                .onFailure { error ->
                    _uiState.value = _uiState.value.copy(message = error.message ?: "Öğretmen notu kaydedilemedi.")
                }
        }
    }

    fun confirmAllResults(onSuccess: () -> Unit) {
        if (_uiState.value.isConfirming || _uiState.value.isSavingChanges) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isConfirming = true, message = null)
            val result = try {
                evaluationRepository.validateAndConfirmAllResults(examDraftId)
            } catch (e: Exception) {
                Result.failure(e)
            }
            _uiState.value = _uiState.value.copy(isConfirming = false)
            if (result.isSuccess) {
                onSuccess()
            } else {
                _uiState.value = _uiState.value.copy(message = result.exceptionOrNull()?.message ?: "Sonuçlar onaylanamadı.")
            }
        }
    }

    class Factory(
        private val examDraftId: Long,
        private val evaluationRepository: ExamEvaluationRepository,
        private val paperUploadRepository: ExamPaperUploadRepository,
        private val questionRepository: ExamQuestionRepository,
        private val examType: ExamType = ExamType.WRITTEN
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TeacherReviewViewModel::class.java)) {
                return TeacherReviewViewModel(
                    examDraftId,
                    evaluationRepository,
                    paperUploadRepository,
                    questionRepository,
                    examType
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
