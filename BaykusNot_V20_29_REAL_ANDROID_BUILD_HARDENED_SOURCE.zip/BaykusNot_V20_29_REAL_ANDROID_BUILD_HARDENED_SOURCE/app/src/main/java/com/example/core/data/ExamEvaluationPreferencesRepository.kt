package com.example.core.data

import android.database.sqlite.SQLiteConstraintException
import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamEvaluationPreferencesDao
import com.example.core.database.ExamEvaluationPreferencesEntity
import com.example.core.model.EvaluationPreferences
import com.example.core.model.EvaluationMode
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ExamEvaluationPreferencesRepository(
    private val preferencesDao: ExamEvaluationPreferencesDao,
    private val examDraftDao: ExamDraftDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    fun observePreferences(
        examDraftId: Long
    ): Flow<ExamEvaluationPreferencesEntity?> =
        preferencesDao.observePreferences(examDraftId)

    suspend fun savePreferences(
        examDraftId: Long,
        preferences: EvaluationPreferences
    ): SaveEvaluationPreferencesResult =
        withContext(ioDispatcher) {
            val canonicalPreferences = canonicalTeacherMode(preferences)
            if (examDraftDao.getDraftByIdOnce(examDraftId) == null) {
                return@withContext SaveEvaluationPreferencesResult.ExamNotFound
            }

            val existing =
                preferencesDao.getPreferencesOnce(examDraftId)

            if (existing == null) {
                return@withContext createPreferences(
                    examDraftId = examDraftId,
                    preferences = canonicalPreferences
                )
            }

            if (existing.isLocked) {
                return@withContext SaveEvaluationPreferencesResult.Locked
            }

            val updatedAt = System.currentTimeMillis()

            val affectedRows =
                preferencesDao.updateUnlockedPreferences(
                    examDraftId = examDraftId,
                    expectedRevision = existing.revision,
                    evaluationMode =
                        canonicalPreferences.evaluationMode,
                    rubricAdherenceLevel =
                        canonicalPreferences.rubricAdherenceLevel,
                    feedbackDetailLevel =
                        canonicalPreferences.feedbackDetailLevel,
                    deductWritingAndPunctuationPoints =
                        canonicalPreferences
                            .writingAndPunctuation
                            .deductPoints,
                    hasExplicitWritingPunctuationPreference =
                        canonicalPreferences
                            .writingAndPunctuation
                            .hasExplicitPreference,
                    provideWritingAndPunctuationFeedback =
                        canonicalPreferences
                            .writingAndPunctuation
                            .provideFeedback,
                    modelQualityTier =
                        canonicalPreferences.modelQualityTier,
                    reportClass = canonicalPreferences.reportClass,
                    reportIndividual = canonicalPreferences.reportIndividual,
                    reportQuestion = canonicalPreferences.reportQuestion,
                    useBatchApi = canonicalPreferences.useBatchApi,
                    usePromptCaching = canonicalPreferences.usePromptCaching,
                    updatedAt = updatedAt
                )

            if (affectedRows == 1) {
                val updated =
                    preferencesDao.getPreferencesOnce(
                        examDraftId
                    )

                return@withContext when {
                    updated != null -> SaveEvaluationPreferencesResult.Updated(updated)
                    examDraftDao.getDraftByIdOnce(examDraftId) == null -> SaveEvaluationPreferencesResult.ExamNotFound
                    else -> SaveEvaluationPreferencesResult.ConcurrentModification
                }
            }

            val latest =
                preferencesDao.getPreferencesOnce(examDraftId)

            return@withContext when {
                latest?.isLocked == true -> SaveEvaluationPreferencesResult.Locked
                latest == null && examDraftDao.getDraftByIdOnce(examDraftId) == null -> SaveEvaluationPreferencesResult.ExamNotFound
                else -> SaveEvaluationPreferencesResult.ConcurrentModification
            }
        }

    suspend fun lockPreferences(
        examDraftId: Long
    ): LockEvaluationPreferencesResult =
        withContext(ioDispatcher) {
            val existing =
                preferencesDao.getPreferencesOnce(examDraftId)
                    ?: return@withContext LockEvaluationPreferencesResult.PreferencesNotFound

            if (existing.isLocked) {
                return@withContext LockEvaluationPreferencesResult.AlreadyLocked
            }

            val affectedRows =
                preferencesDao.lockPreferences(
                    examDraftId = examDraftId,
                    expectedRevision = existing.revision,
                    lockedAt = System.currentTimeMillis()
                )

            val latest =
                preferencesDao.getPreferencesOnce(examDraftId)

            return@withContext when {
                affectedRows == 1 && latest?.isLocked == true -> LockEvaluationPreferencesResult.Success(latest)
                latest == null -> LockEvaluationPreferencesResult.PreferencesNotFound
                latest.isLocked -> LockEvaluationPreferencesResult.AlreadyLocked
                else -> LockEvaluationPreferencesResult.ConcurrentModification
            }
        }

    suspend fun copyPreferences(
        sourceExamDraftId: Long,
        targetExamDraftId: Long
    ): CopyEvaluationPreferencesResult =
        withContext(ioDispatcher) {
            val source =
                preferencesDao.getPreferencesOnce(
                    sourceExamDraftId
                ) ?: return@withContext CopyEvaluationPreferencesResult.SourcePreferencesNotFound

            if (
                examDraftDao.getDraftByIdOnce(
                    targetExamDraftId
                ) == null
            ) {
                return@withContext CopyEvaluationPreferencesResult.TargetExamNotFound
            }

            if (
                preferencesDao.getPreferencesOnce(
                    targetExamDraftId
                ) != null
            ) {
                return@withContext CopyEvaluationPreferencesResult.TargetAlreadyHasPreferences
            }

            val now = System.currentTimeMillis()

            val copied =
                source.copy(
                    examDraftId = targetExamDraftId,
                    evaluationMode = EvaluationMode.PAPER_BY_PAPER,
                    rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
                    modelQualityTier = ModelQualityTier.STANDARD,
                    reportClass = true,
                    reportIndividual = true,
                    reportQuestion = true,
                    useBatchApi = false,
                    usePromptCaching = true,
                    hasExplicitWritingPunctuationPreference = true,
                    isLocked = false,
                    lockedAt = null,
                    revision = 1,
                    createdAt = now,
                    updatedAt = now
                )

            try {
                preferencesDao.insertPreferences(copied)
                return@withContext CopyEvaluationPreferencesResult.Success(copied)
            } catch (
                exception: SQLiteConstraintException
            ) {
                return@withContext when {
                    examDraftDao.getDraftByIdOnce(
                        targetExamDraftId
                    ) == null ->
                        CopyEvaluationPreferencesResult
                            .TargetExamNotFound

                    preferencesDao.getPreferencesOnce(
                        targetExamDraftId
                    ) != null ->
                        CopyEvaluationPreferencesResult
                            .TargetAlreadyHasPreferences

                    else ->
                        CopyEvaluationPreferencesResult
                            .ConcurrentModification
                }
            }
        }

    private suspend fun createPreferences(
        examDraftId: Long,
        preferences: EvaluationPreferences
    ): SaveEvaluationPreferencesResult {
        val now = System.currentTimeMillis()

        val entity =
            ExamEvaluationPreferencesEntity(
                examDraftId = examDraftId,
                evaluationMode =
                    preferences.evaluationMode,
                rubricAdherenceLevel =
                    preferences.rubricAdherenceLevel,
                feedbackDetailLevel =
                    preferences.feedbackDetailLevel,
                deductWritingAndPunctuationPoints =
                    preferences
                        .writingAndPunctuation
                        .deductPoints,
                hasExplicitWritingPunctuationPreference =
                    preferences
                        .writingAndPunctuation
                        .hasExplicitPreference,
                provideWritingAndPunctuationFeedback =
                    preferences
                        .writingAndPunctuation
                        .provideFeedback,
                modelQualityTier =
                    preferences.modelQualityTier,
                reportClass = preferences.reportClass,
                reportIndividual = preferences.reportIndividual,
                reportQuestion = preferences.reportQuestion,
                useBatchApi = preferences.useBatchApi,
                usePromptCaching = preferences.usePromptCaching,
                isLocked = false,
                lockedAt = null,
                revision = 1,
                createdAt = now,
                updatedAt = now
            )

        return try {
            preferencesDao.insertPreferences(entity)

            SaveEvaluationPreferencesResult.Created(
                entity
            )
        } catch (
            exception: SQLiteConstraintException
        ) {
            when {
                examDraftDao.getDraftByIdOnce(
                    examDraftId
                ) == null ->
                    SaveEvaluationPreferencesResult
                        .ExamNotFound

                else ->
                    SaveEvaluationPreferencesResult
                        .ConcurrentModification
            }
        }
    }

    suspend fun unlockPreferences(
        examDraftId: Long
    ): Boolean =
        withContext(ioDispatcher) {
            val affectedRows = preferencesDao.unlockPreferences(examDraftId, System.currentTimeMillis())
            affectedRows == 1
        }

    suspend fun ensureTeacherModeCanonical(examDraftId: Long): Boolean =
        withContext(ioDispatcher) {
            preferencesDao.canonicalizeTeacherMode(examDraftId, System.currentTimeMillis()) >= 0
        }

    private fun canonicalTeacherMode(preferences: EvaluationPreferences): EvaluationPreferences =
        preferences.copy(
            evaluationMode = EvaluationMode.PAPER_BY_PAPER,
            rubricAdherenceLevel = RubricAdherenceLevel.BALANCED,
            modelQualityTier = ModelQualityTier.STANDARD,
            reportClass = true,
            reportIndividual = true,
            reportQuestion = true,
            useBatchApi = false,
            usePromptCaching = true
        )

}
