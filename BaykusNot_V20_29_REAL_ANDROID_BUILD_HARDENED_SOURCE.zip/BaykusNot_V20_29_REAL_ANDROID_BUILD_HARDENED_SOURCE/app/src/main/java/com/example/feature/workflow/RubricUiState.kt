package com.example.feature.workflow

import com.example.core.model.ExamQuestion
import com.example.core.model.ExamRubricValidationIssue
import com.example.core.model.ExamType
import java.io.File

data class UploadedDocumentInfo(
    val fileName: String,
    val fileType: String,
    val pageCount: Int? = null,
    val sizeBytes: Long = 0L,
    val status: String = "SUCCESS", // "PREPARING", "READING", "READY_TO_MATCH", "SUCCESS", "ERROR"
    val statusMessage: String? = null
)

data class RubricUiState(
    val draftId: Long,
    val draftExists: Boolean = false,
    val examType: ExamType = ExamType.WRITTEN,
    val questions: List<ExamQuestion> = emptyList(),
    val editableCriteria: List<EditableExamRubricCriterion> = emptyList(),
    val calculatedPointsByQuestionOrder: Map<Int, Long> = emptyMap(),
    val validationIssues: List<ExamRubricValidationIssue> = emptyList(),
    val currentValidationIssues: List<ExamRubricValidationIssue> = emptyList(),
    val inputIssues: List<RubricInputIssue> = emptyList(),
    val canSave: Boolean = false,
    val canLock: Boolean = false,
    val canContinue: Boolean = false,
    val isLocked: Boolean = false,
    val lockedAt: Long? = null,
    val revision: Int = 0,
    val questionSetRevision: Int? = null,
    val rubricQuestionSetRevision: Int? = null,
    val deductWritingPunctuationPoints: Boolean? = null,
    val isLoading: Boolean = true,
    val isGenerating: Boolean = false,
    val isSaving: Boolean = false,
    val isLocking: Boolean = false,
    val isUnlocking: Boolean = false,
    val message: String? = null,
    val hasUnsavedChanges: Boolean = false,
    val evaluationSourceType: String = "AI_GENERATED_RUBRIC",
    val originalTeacherAnswerKey: String? = null,
    val originalTeacherRubric: String? = null,
    val elaboratedAnswerKey: String? = null,
    val elaboratedRubric: String? = null,
    val isAsIs: Boolean = false,
    val isMatching: Boolean = false,
    val answerKeyDocument: UploadedDocumentInfo? = null,
    val rubricDocument: UploadedDocumentInfo? = null,
    val isProcessingDocument: Boolean = false,
    val documentProcessingProgress: String? = null,
    val generatedPdfFile: File? = null,
    val isPdfUpToDate: Boolean = false,
    val pdfStaleTitle: String? = null,
    val pdfStaleSubtitle: String? = null,
    val isGeneratingPdf: Boolean = false,
    val pdfGenerationProgress: String? = null,
    val saveSuccessMessage: String? = null,
    val pdfPageCount: Int = 1,
    val selectedPreviewPageIndex: Int = 1
)
