package com.example.feature.workflow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.AndroidPdfSelectionResolver
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamListeningMaterialRepository
import com.example.core.data.ExamObjectiveRepository
import com.example.core.data.ExamQuestionExtractionDraftRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.ExamSourceDocumentRepository
import com.example.core.data.ExamQuestionExtractionCoordinator
import com.example.core.network.ExamQuestionObjectiveMatcher
import com.example.core.network.ExamScenarioExtractor

/**
 * Listening exams reuse the written-exam question extraction/review pipeline.
 * The only listening-specific step is choosing the listening source (audio OR text) before
 * arriving here. Question import, review, scoring, rubric and later stages stay shared.
 */
@Composable
internal fun ListeningQuestionSetupRoute(
    draftId: Long,
    examQuestionRepository: ExamQuestionRepository,
    examDraftRepository: ExamDraftRepository,
    examQuestionExtractionDraftRepository: ExamQuestionExtractionDraftRepository,
    objectiveRepository: ExamObjectiveRepository,
    matcher: ExamQuestionObjectiveMatcher,
    examRubricRepository: ExamRubricRepository,
    examListeningMaterialRepository: ExamListeningMaterialRepository,
    sourceDocumentRepository: ExamSourceDocumentRepository,
    coordinator: ExamQuestionExtractionCoordinator,
    scenarioExtractor: ExamScenarioExtractor,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val questionViewModel: QuestionPointsViewModel = viewModel(
        key = "question_points_$draftId",
        factory = QuestionPointsViewModel.Factory(
            draftId = draftId,
            examQuestionRepository = examQuestionRepository,
            examDraftRepository = examDraftRepository,
            examQuestionExtractionDraftRepository = examQuestionExtractionDraftRepository,
            objectiveRepository = objectiveRepository,
            matcher = matcher,
            examRubricRepository = examRubricRepository,
            examListeningMaterialRepository = examListeningMaterialRepository
        )
    )
    val questionState by questionViewModel.uiState.collectAsStateWithLifecycle()

    val uploadViewModel: UploadSourceViewModel = viewModel(
        key = "listening_question_source_$draftId",
        factory = UploadSourceViewModel.Factory(
            examDraftRepository = examDraftRepository,
            sourceDocumentRepository = sourceDocumentRepository,
            coordinator = coordinator,
            questionRepository = examQuestionRepository,
            objectiveRepository = objectiveRepository,
            scenarioExtractor = scenarioExtractor,
            draftId = draftId
        )
    )
    val resolver = remember(context) {
        AndroidPdfSelectionResolver(context.contentResolver)
    }

    var showImporter by rememberSaveable(draftId) { mutableStateOf(false) }
    var manualEntryChosen by rememberSaveable(draftId) { mutableStateOf(false) }

    LaunchedEffect(questionState.isLoading, questionState.editableQuestions.size, questionState.isLocked) {
        if (!questionState.isLoading && questionState.editableQuestions.isNotEmpty()) {
            showImporter = false
        } else if (!questionState.isLoading && questionState.editableQuestions.isEmpty() && !questionState.isLocked && !manualEntryChosen) {
            showImporter = true
        }
    }

    if (showImporter && !questionState.isLocked) {
        Column(modifier = modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Dinleme Sınavı Soruları",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Soruları dosyadan çıkarabilir veya elle girebilirsiniz.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(
                    onClick = {
                        manualEntryChosen = true
                        showImporter = false
                    }
                ) {
                    Text("Elle Gir")
                }
            }

            UploadSourceRoute(
                viewModel = uploadViewModel,
                pdfSelectionResolver = resolver,
                onContinue = {
                    questionViewModel.reloadQuestionSources()
                    manualEntryChosen = true
                    showImporter = false
                },
                copy = UploadSourceCopy(
                    title = "Soru Dosyasını Yükle",
                    description = "Öğrenciye vereceğiniz dinleme sınavı sorularını yükleyin. Sorular çıkarıldıktan sonra Yazılı Sınavdaki aynı soru/puan kontrol ekranına geçilir.",
                    emptyTitle = "Henüz soru dosyası yüklenmedi",
                    emptyDescription = "PDF, Word, JPEG, PNG, WebP veya yapıştırılmış metin kullanılabilir. (Maks. 50 MB)",
                    documentTypeLabel = "Soru Dosyası",
                    readyLabel = "Soru dosyası hazır",
                    unusableLabel = "Soru dosyası kullanılamıyor",
                    replaceLabel = "Soru Dosyasını Değiştir",
                    continueLabel = "Soruları Çıkar ve Kontrol Et"
                ),
                showScenarioSection = true,
                modifier = Modifier.weight(1f)
            )
        }
    } else {
        Column(modifier = modifier.fillMaxSize()) {
            if (!questionState.isLocked) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = { showImporter = true }
                    ) {
                        Text("Soruları Dosyadan Yükle")
                    }
                }
            }
            Box(modifier = Modifier.weight(1f)) {
                QuestionPointsRoute(
                    viewModel = questionViewModel,
                    onContinue = onContinue,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
