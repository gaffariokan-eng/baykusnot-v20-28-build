package com.example.feature.workflow

sealed interface QuestionPointsParseResult {

    data class Parsed(
        val points: Int
    ) : QuestionPointsParseResult

    data class Rejected(
        val code: QuestionPointsInputIssueCode
    ) : QuestionPointsParseResult
}

object QuestionPointsInputParser {

    private val POINTS_REGEX = Regex("^[+-]?[0-9]+$")

    fun parse(value: String): QuestionPointsParseResult {
        val normalized = value.trim()
        if (normalized.isEmpty()) {
            return QuestionPointsParseResult.Rejected(QuestionPointsInputIssueCode.BLANK_POINTS)
        }
        if (!POINTS_REGEX.matches(normalized)) {
            return QuestionPointsParseResult.Rejected(QuestionPointsInputIssueCode.INVALID_POINTS_FORMAT)
        }
        val parsedLong = normalized.toLongOrNull()
            ?: return QuestionPointsParseResult.Rejected(QuestionPointsInputIssueCode.POINTS_OUT_OF_RANGE)

        if (parsedLong < Int.MIN_VALUE.toLong() || parsedLong > Int.MAX_VALUE.toLong()) {
            return QuestionPointsParseResult.Rejected(QuestionPointsInputIssueCode.POINTS_OUT_OF_RANGE)
        }
        return QuestionPointsParseResult.Parsed(points = parsedLong.toInt())
    }
}
