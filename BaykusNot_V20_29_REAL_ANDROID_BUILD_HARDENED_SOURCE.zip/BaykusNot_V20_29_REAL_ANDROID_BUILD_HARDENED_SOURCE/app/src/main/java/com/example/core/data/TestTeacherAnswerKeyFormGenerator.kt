package com.example.core.data

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType
import com.example.core.model.MultipleChoiceOptionPolicy
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Generates the canonical BaykuşNot teacher answer-key optical form.
 * The question bubble coordinates intentionally match the student Test answer form so the
 * same fully-local OMR geometry can read both documents. No AI/API/network is involved.
 */
object TestTeacherAnswerKeyFormGenerator {
    const val FORM_VERSION = 2

    fun generate(
        context: Context,
        draft: ExamDraftEntity,
        questions: List<ExamQuestion>
    ): File {
        require(questions.isNotEmpty()) { "Öğretmen cevap anahtarı formu için en az bir soru gerekir." }
        val formToken = formToken(draft.id, questions)
        val entities = questions.sortedBy { it.orderIndex }.map { q ->
            ExamQuestionEntity(
                id = 0L,
                examDraftId = draft.id,
                orderIndex = q.orderIndex,
                questionNumber = q.questionNumber,
                normalizedQuestionNumber = q.questionNumber.trim(),
                questionText = q.questionText,
                points = q.points,
                createdAt = 0L,
                updatedAt = 0L
            )
        }
        val layouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
            questions = entities,
            rubricCriteria = emptyList(),
            examType = ExamType.MULTIPLE_CHOICE
        )
        require(layouts.isNotEmpty()) { "Öğretmen cevap anahtarı formu yerleşimi oluşturulamadı." }

        val outDir = File(context.cacheDir, "teacher_answer_key_forms").apply { mkdirs() }
        val file = File(outDir, "BaykusNot_Test_${draft.id}_Ogretmen_Cevap_Anahtari.pdf")
        val pdf = PdfDocument()
        try {
            layouts.forEach { layout ->
                val pageInfo = PdfDocument.PageInfo.Builder(
                    TestOpticalFormGeometry.pageWidthPt.toInt(),
                    TestOpticalFormGeometry.pageHeightPt.toInt(),
                    layout.pageIndex
                ).create()
                val page = pdf.startPage(pageInfo)
                drawPage(
                    canvas = page.canvas,
                    draft = draft,
                    layout = layout,
                    questions = entities,
                    formToken = formToken
                )
                pdf.finishPage(page)
            }
            FileOutputStream(file).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }
        return file
    }

    fun formToken(draftId: Long, questions: List<ExamQuestion>): String {
        val canonical = buildString {
            append("teacher-key-v2|").append(draftId).append('|')
            questions.sortedBy { it.orderIndex }.forEach { q ->
                append(q.orderIndex).append('|')
                    .append(q.questionNumber.trim()).append('|')
                    .append(q.questionText.trim()).append('|')
                    .append(q.points).append('\n')
            }
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(20)
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = 8.2f
        textAlign = Paint.Align.CENTER
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 8f
    }
    private val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 8.3f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = 7f
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        style = Paint.Style.STROKE
        strokeWidth = 0.8f
    }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 0.7f
    }
    private val optionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 8.5f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val markerPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }
    private val qrWhitePaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    private fun drawPage(
        canvas: Canvas,
        draft: ExamDraftEntity,
        layout: AnswerSheetPageLayout,
        questions: List<ExamQuestionEntity>,
        formToken: String
    ) {
        canvas.drawColor(Color.WHITE)
        drawRegistrationMarks(canvas)
        val qrContent = "AIEKSAM-TEACHER|V:$FORM_VERSION|E:${draft.id}|F:$formToken|P:${layout.pageIndex}|T:${layout.totalPages}"
        QrCodeGenerator.drawQrCode(canvas, qrContent, RectF(500f, 42f, 555f, 97f), markerPaint, qrWhitePaint)

        val pageWidth = TestOpticalFormGeometry.pageWidthPt
        val titleY = if (layout.pageIndex == 1) 49f else 55f
        canvas.drawText("BAYKUŞNOT — ÖĞRETMEN CEVAP ANAHTARI FORMU", pageWidth / 2f, titleY, titlePaint)
        canvas.drawText(
            "Form v$FORM_VERSION • Test #${draft.id} • ${layout.pageIndex}/${layout.totalPages}",
            pageWidth / 2f,
            titleY + 16f,
            subTitlePaint
        )

        if (layout.pageIndex == 1) {
            canvas.drawText(
                "${draft.courseName.ifBlank { "Ders" }} • ${questions.size} soru • ${draft.totalPoints} puan",
                pageWidth / 2f,
                83f,
                subTitlePaint
            )
            canvas.drawText(
                "Her soruda yalnız doğru seçeneği koyu işaretleyin; köşe karelerini kapatmayın.",
                pageWidth / 2f,
                96f,
                subTitlePaint
            )
        } else {
            canvas.drawText(
                "Devam sayfası • doğru seçeneği tek ve koyu işaretleyin.",
                pageWidth / 2f,
                87f,
                subTitlePaint
            )
        }

        layout.questions.forEach { box ->
            val left = 48f
            val right = 547f
            val top = box.topYPt
            val bottom = top + box.heightPt
            canvas.drawRoundRect(RectF(left, top, right, bottom), 3f, 3f, borderPaint)
            canvas.drawText("${box.questionNumber}. soru", left + 10f, top + 13f, boldPaint)
            canvas.drawText("${box.points} puan", right - 60f, top + 13f, smallPaint)

            val question = questions.firstOrNull { it.orderIndex == box.orderIndex }
            val labels = MultipleChoiceOptionPolicy.detectLabels(question?.questionText.orEmpty())
            val centerY = top + box.headerHeightPt + ((box.heightPt - box.headerHeightPt) / 2f)
            labels.forEachIndexed { index, label ->
                val cx = TestOpticalFormGeometry.optionCenterX(index)
                canvas.drawCircle(cx, centerY, TestOpticalFormGeometry.answerBubbleRadiusPt, bubblePaint)
                canvas.drawText(label, cx, centerY + 2.5f, optionPaint)
            }
        }

        canvas.drawText(
            "BaykuşNot yerel optik form • Yapay zekâ/API kullanılmaz • Sayfa ${layout.pageIndex}/${layout.totalPages}",
            pageWidth / 2f,
            824f,
            subTitlePaint
        )
    }

    private fun drawRegistrationMarks(canvas: Canvas) {
        TestOpticalFormGeometry.registrationCentersPt.forEach { (cx, cy) ->
            canvas.drawRect(cx - 6f, cy - 6f, cx + 6f, cy + 6f, markerPaint)
        }
    }
}
