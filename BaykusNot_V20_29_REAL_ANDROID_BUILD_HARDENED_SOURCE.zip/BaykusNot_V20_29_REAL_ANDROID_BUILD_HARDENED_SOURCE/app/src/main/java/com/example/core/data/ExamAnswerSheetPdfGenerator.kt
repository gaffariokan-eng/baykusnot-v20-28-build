package com.example.core.data

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.model.ExamType
import com.example.core.model.MultipleChoiceOptionPolicy
import java.io.File
import java.io.FileOutputStream

object ExamAnswerSheetPageRenderer {

    private val titlePaint = Paint().apply {
        color = Color.BLACK
        textSize = 9.5f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.BLACK
        textSize = 8f
        isAntiAlias = true
    }

    private val miniLabelPaint = Paint().apply {
        color = Color.BLACK
        textSize = 6.5f
        isAntiAlias = true
    }

    private val labelBoldPaint = Paint().apply {
        color = Color.BLACK
        textSize = 8f
        isFakeBoldText = true
        isAntiAlias = true
    }

    private val boxBorderPaint = Paint().apply {
        color = Color.DKGRAY
        style = Paint.Style.STROKE
        strokeWidth = 0.8f
        isAntiAlias = true
    }

    private val boxFillPaint = Paint().apply {
        color = Color.parseColor("#F1F5F9")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val guidelinePaint = Paint().apply {
        color = Color.parseColor("#CBD5E1")
        style = Paint.Style.STROKE
        strokeWidth = 0.6f
        pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        isAntiAlias = true
    }

    private val guidanceFillPaint = Paint().apply {
        color = Color.parseColor("#EEF2FF")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val guidanceTitlePaint = Paint().apply {
        color = Color.parseColor("#312E81")
        textSize = 7.5f
        isFakeBoldText = true
        isAntiAlias = true
    }

    private val guidanceTextPaint = Paint().apply {
        color = Color.parseColor("#1E293B")
        textSize = 7.2f
        isAntiAlias = true
    }

    private val footerPaint = Paint().apply {
        color = Color.GRAY
        textSize = 7.5f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val rightFooterPaint = Paint().apply {
        color = Color.GRAY
        textSize = 7.5f
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    private val qrSubPaint = Paint().apply {
        color = Color.BLACK
        textSize = 6.5f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val bubbleBorderPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 0.6f
        isAntiAlias = true
    }

    private val bubbleTextPaint = Paint().apply {
        color = Color.parseColor("#0F172A")
        textSize = 5.5f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val compactTestBubbleTextPaint = Paint().apply {
        color = Color.parseColor("#0F172A")
        textSize = 8.5f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val qrWhitePaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    private val qrBlackPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    internal fun detectMultipleChoiceLabels(questionText: String): List<String> =
        MultipleChoiceOptionPolicy.detectLabels(questionText)


    private fun drawAnswerSheetRegistrationMarks(canvas: Canvas) {
        val outer = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        val inner = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        val half = AnswerSheetRegistrationGeometry.markSizePt / 2f
        val innerHalf = half * 0.34f
        AnswerSheetRegistrationGeometry.registrationCentersPt.forEach { (cx, cy) ->
            canvas.drawRect(cx - half, cy - half, cx + half, cy + half, outer)
            canvas.drawRect(cx - innerHalf, cy - innerHalf, cx + innerHalf, cy + innerHalf, inner)
        }
    }

    private fun drawTestRegistrationMarks(canvas: Canvas) {
        val markPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        TestOpticalFormGeometry.registrationCentersPt.forEach { (cx, cy) ->
            canvas.drawRect(cx - 6f, cy - 6f, cx + 6f, cy + 6f, markPaint)
        }
    }

    fun drawPage(
        canvas: Canvas,
        pageLayout: AnswerSheetPageLayout,
        titleText: String,
        teachers: List<String>,
        totalPoints: Int,
        examDraftId: Long,
        formToken: String,
        studentIdx: Int = 1,
        examDateStr: String,
        listeningGuidance: ListeningAnswerSheetGuidance? = null,
        examType: ExamType = ExamType.WRITTEN
    ) {
        val marginX = 36f
        val contentWidth = 523f
        val rightX = marginX + contentWidth
        var currentY = 36f

        if (examType == ExamType.MULTIPLE_CHOICE) {
            drawTestRegistrationMarks(canvas)
            drawCompactTestPage(
                canvas = canvas,
                pageLayout = pageLayout,
                titleText = titleText,
                examDraftId = examDraftId,
                formToken = formToken,
                studentIdx = studentIdx,
                examDateStr = examDateStr
            )
            return
        }

        // Four unobtrusive fiducials allow reliable perspective correction before any
        // privacy crop or question-level second read.
        drawAnswerSheetRegistrationMarks(canvas)

        // Draw Top Exam Header Title
        canvas.drawText(titleText, 595f / 2f, currentY + 10f, titlePaint)
        currentY += 18f

        // QR Code Content (Non-PII Token)
        val qrContent = "AIEKSAM|V:4|E:$examDraftId|F:$formToken|S:$studentIdx|P:${pageLayout.pageIndex}|T:${pageLayout.totalPages}"

        if (pageLayout.pageIndex == 1) {
            // Draw Full Student Identity & Optical Coding Box
            val infoBoxHeight = 145f
            val infoRect = RectF(marginX, currentY, rightX, currentY + infoBoxHeight)
            canvas.drawRoundRect(infoRect, 4f, 4f, boxBorderPaint)

            // Far Right: QR Code (Pure Vector Drawing)
            val qrSize = 70f
            val qrLeft = rightX - qrSize - 8f
            val qrTop = currentY + 8f
            val qrRect = RectF(qrLeft, qrTop, qrLeft + qrSize, qrTop + qrSize)
            QrCodeGenerator.drawQrCode(canvas, qrContent, qrRect, qrBlackPaint, qrWhitePaint)
            canvas.drawText("Kâğıt Kodu #$studentIdx", qrLeft + qrSize / 2f, qrTop + qrSize + 10f, qrSubPaint)

            val fieldLeft = marginX + 10f
            
            // Ad Soyad - Expanded across the top left
            var fieldY = currentY + 18f
            canvas.drawText("Öğrenci Adı Soyadı:", fieldLeft, fieldY, labelBoldPaint)
            canvas.drawLine(fieldLeft + 85f, fieldY, qrLeft - 15f, fieldY, boxBorderPaint)

            // Sınıf Düzeyi Optik Kodlama
            fieldY += 24f
            canvas.drawText("Sınıf Düzeyi:", fieldLeft, fieldY, miniLabelPaint)
            var gradeX = fieldLeft + 52f
            val grades = listOf("5", "6", "7", "8", "9", "10", "11", "12")
            for (g in grades) {
                canvas.drawCircle(gradeX + 4f, fieldY - 2.5f, 4.5f, bubbleBorderPaint)
                canvas.drawText(g, gradeX + 4f, fieldY, bubbleTextPaint)
                gradeX += 12f
            }

            // Şube Optik Kodlama (29 Turkish letters in 2 compact balanced rows)
            fieldY += 18f
            canvas.drawText("Şube:", fieldLeft, fieldY, miniLabelPaint)
            var branchX = fieldLeft + 52f
            for (b in BranchConstants.CANONICAL_ROW1_BRANCHES) {
                canvas.drawCircle(branchX + 4f, fieldY - 2.5f, 4.2f, bubbleBorderPaint)
                canvas.drawText(b, branchX + 4f, fieldY, bubbleTextPaint)
                branchX += 11.5f
            }

            fieldY += 13f
            branchX = fieldLeft + 52f
            for (b in BranchConstants.CANONICAL_ROW2_BRANCHES) {
                canvas.drawCircle(branchX + 4f, fieldY - 2.5f, 4.2f, bubbleBorderPaint)
                canvas.drawText(b, branchX + 4f, fieldY, bubbleTextPaint)
                branchX += 11.5f
            }

            // Teacher, Date, Points
            fieldY += 24f
            val teachersText = if (teachers.isNotEmpty()) teachers.joinToString(", ") else "—"
            canvas.drawText("Öğretmen: $teachersText", fieldLeft, fieldY, textPaint)

            fieldY += 18f
            canvas.drawText("Sınav Tarihi: $examDateStr", fieldLeft, fieldY, textPaint)
            canvas.drawText("Toplam Puan: [      ] / $totalPoints", fieldLeft + 135f, fieldY, labelBoldPaint)

            // Okul No Kodlama Matrix - Placed to the left of QR
            val numMatrixLeft = qrLeft - 110f
            canvas.drawText("OKUL NO KODLAMA", numMatrixLeft, currentY + 36f, labelBoldPaint)

            // 4 Digit Boxes + 10 Row Bubbles
            var colX = numMatrixLeft
            for (col in 0..3) {
                // Top Digit Entry Box
                val topBoxRect = RectF(colX, currentY + 40f, colX + 18f, currentY + 52f)
                canvas.drawRect(topBoxRect, boxBorderPaint)

                // 10 Bubble Rows (0..9)
                var bubbleY = currentY + 57f
                for (digit in 0..9) {
                    val cx = colX + 9f
                    val cy = bubbleY + 3.5f
                    canvas.drawCircle(cx, cy, 3.5f, bubbleBorderPaint)
                    canvas.drawText(digit.toString(), cx, cy + 2f, bubbleTextPaint)
                    bubbleY += 8.2f
                }
                colX += 22f
            }

            // Listening Exam guidance is printed on the first page only. The packing engine
            // reserves the exact same height through ListeningAnswerSheetGuidance.
            if (listeningGuidance != null) {
                val guidanceTop = currentY + infoBoxHeight + 8f
                val guidanceRect = RectF(
                    marginX,
                    guidanceTop,
                    rightX,
                    guidanceTop + listeningGuidance.boxHeightPt
                )
                canvas.drawRoundRect(guidanceRect, 4f, 4f, guidanceFillPaint)
                canvas.drawRoundRect(guidanceRect, 4f, 4f, boxBorderPaint)
                canvas.drawText(
                    "DİNLEME SINAVI YÖNERGESİ",
                    marginX + 9f,
                    guidanceTop + 13f,
                    guidanceTitlePaint
                )
                var guidanceY = guidanceTop + 24f
                for (line in listeningGuidance.pdfLines) {
                    canvas.drawText(line, marginX + 9f, guidanceY, guidanceTextPaint)
                    guidanceY += 10f
                }
            }
        } else {
            // Subsequent Page Header
            val infoBoxHeight = 92f
            val infoRect = RectF(marginX, currentY, rightX, currentY + infoBoxHeight)
            canvas.drawRoundRect(infoRect, 4f, 4f, boxBorderPaint)

            val qrSize = 70f
            val qrLeft = rightX - qrSize - 8f
            val qrTop = currentY + 8f
            val qrRect = RectF(qrLeft, qrTop, qrLeft + qrSize, qrTop + qrSize)
            QrCodeGenerator.drawQrCode(canvas, qrContent, qrRect, qrBlackPaint, qrWhitePaint)
            canvas.drawText("Kâğıt Kodu #$studentIdx", qrLeft + qrSize / 2f, qrTop + qrSize + 10f, qrSubPaint)

            val fieldLeft = marginX + 10f
            
            // Öğrenci Adı Soyadı
            var fieldY = currentY + 22f
            canvas.drawText("Öğrenci Adı Soyadı:", fieldLeft, fieldY, labelBoldPaint)
            canvas.drawLine(fieldLeft + 85f, fieldY, qrLeft - 15f, fieldY, boxBorderPaint)

            // Sınıfı / Şubesi
            fieldY += 25f
            canvas.drawText("Sınıfı / Şubesi:", fieldLeft, fieldY, labelBoldPaint)
            canvas.drawLine(fieldLeft + 65f, fieldY, fieldLeft + 150f, fieldY, boxBorderPaint)
            
            // Okul No
            val okulNoX = fieldLeft + 170f
            canvas.drawText("Okul No:", okulNoX, fieldY, labelBoldPaint)
            canvas.drawLine(okulNoX + 40f, fieldY, qrLeft - 15f, fieldY, boxBorderPaint)
            
            // Sınav Tarihi
            fieldY += 25f
            canvas.drawText("Sınav Tarihi: $examDateStr", fieldLeft, fieldY, textPaint)
        }

        // Draw Questions assigned to this page using canonical topYPt
        for (qBox in pageLayout.questions) {
            val boxTopY = qBox.topYPt
            val headerHeight = qBox.headerHeightPt
            val lineHeight = qBox.lineHeightPt
            val answerBoxHeight = qBox.lineCount * lineHeight
            val totalBoxHeight = qBox.heightPt

            // Header Fill & Rectangle
            val headerRect = RectF(marginX, boxTopY, rightX, boxTopY + headerHeight)
            canvas.drawRect(headerRect, boxFillPaint)
            canvas.drawRect(headerRect, boxBorderPaint)

            // Header Text
            canvas.drawText(qBox.displayTitle, marginX + 8f, boxTopY + 13f, labelBoldPaint)

            // Answer Outer Box
            val bodyRect = RectF(marginX, boxTopY + headerHeight, rightX, boxTopY + totalBoxHeight)
            canvas.drawRect(bodyRect, boxBorderPaint)

            if (examType == ExamType.MULTIPLE_CHOICE) {
                val optionLabels = detectMultipleChoiceLabels(qBox.questionText)
                val centerY = bodyRect.centerY()
                canvas.drawText("İşaretle:", marginX + 8f, centerY + 2.5f, miniLabelPaint)
                optionLabels.forEachIndexed { index, label ->
                    val cx = TestOpticalFormGeometry.optionCenterX(index)
                    canvas.drawText(label, cx - 16f, centerY + 2.5f, bubbleTextPaint)
                    // Empty bubble: label stays outside so local OMR can sample the interior reliably.
                    canvas.drawCircle(cx, centerY, TestOpticalFormGeometry.answerBubbleRadiusPt, bubbleBorderPaint)
                }
            } else {
                // Draw Horizontal Handwriting Guidelines
                var lineY = boxTopY + headerHeight + lineHeight
                for (lineIdx in 1..qBox.lineCount) {
                    canvas.drawLine(marginX + 8f, lineY, rightX - 8f, lineY, guidelinePaint)
                    lineY += lineHeight
                }
            }
        }

        // Draw Footer
        val footerY = 810f
        canvas.drawLine(marginX, footerY - 10f, rightX, footerY - 10f, boxBorderPaint)
        canvas.drawText("Sayfa ${pageLayout.pageIndex} / ${pageLayout.totalPages}", 595f / 2f, footerY + 2f, footerPaint)
        canvas.drawText("Öğrenci #${studentIdx}", marginX, footerY + 2f, textPaint)
        canvas.drawText("BaykuşNot Optik Cevap Sistemi", rightX, footerY + 2f, rightFooterPaint)
    }

    private fun drawCompactTestPage(
        canvas: Canvas,
        pageLayout: AnswerSheetPageLayout,
        titleText: String,
        examDraftId: Long,
        formToken: String,
        studentIdx: Int,
        examDateStr: String
    ) {
        val left = 36f
        val right = 559f
        val qrContent = "AIEKSAM|V:4|E:$examDraftId|F:$formToken|S:$studentIdx|P:${pageLayout.pageIndex}|T:${pageLayout.totalPages}"
        canvas.drawText("BAYKUŞNOT • TEST CEVAP FORMU", 297.5f, 45f, titlePaint)
        canvas.drawText("${titleText.take(74)}", 297.5f, 58f, footerPaint)

        // 4'lü A4 yerleşiminde bile QR yaklaşık 13 mm kalır; telefon kamerası için güvenlidir.
        val qrSize = 72f
        val qrRect = RectF(right - qrSize, 55f, right, 55f + qrSize)
        QrCodeGenerator.drawQrCode(canvas, qrContent, qrRect, qrBlackPaint, qrWhitePaint)
        canvas.drawText("#$studentIdx", right - qrSize / 2f, 134f, qrSubPaint)

        canvas.drawText("Ad Soyad:", left, 78f, labelBoldPaint)
        canvas.drawLine(left + 47f, 78f, 330f, 78f, boxBorderPaint)
        canvas.drawText("Sınıf/Şube:", left, 98f, miniLabelPaint)
        canvas.drawLine(left + 50f, 98f, 165f, 98f, boxBorderPaint)
        canvas.drawText("Okul No:", 182f, 98f, miniLabelPaint)
        canvas.drawLine(222f, 98f, 330f, 98f, boxBorderPaint)
        canvas.drawText("Tarih: $examDateStr", left, 117f, miniLabelPaint)

        pageLayout.questions.forEach { qBox ->
            val top = qBox.topYPt
            val bottom = top + qBox.heightPt
            val centerY = (top + bottom) / 2f
            canvas.drawRoundRect(RectF(left, top, right, bottom), 2f, 2f, boxBorderPaint)
            canvas.drawText("${qBox.questionNumber}.", left + 8f, centerY + 3f, labelBoldPaint)
            val labels = detectMultipleChoiceLabels(qBox.questionText)
            labels.forEachIndexed { index, label ->
                val cx = TestOpticalFormGeometry.optionCenterX(index)
                canvas.drawCircle(cx, centerY, TestOpticalFormGeometry.answerBubbleRadiusPt, bubbleBorderPaint)
                canvas.drawText(label, cx, centerY + 3f, compactTestBubbleTextPaint)
            }
        }

        canvas.drawText(
            "Sayfa ${pageLayout.pageIndex}/${pageLayout.totalPages} • Küçük formu kesip öğrenciye verebilirsiniz.",
            297.5f,
            815f,
            footerPaint
        )
    }
}

object ExamAnswerSheetPdfGenerator {

    fun generateBatchPdf(
        context: Context,
        draft: ExamDraftEntity,
        questions: List<ExamQuestionEntity>,
        rubricCriteria: List<ExamRubricCriterionEntity> = emptyList(),
        studentCount: Int,
        densitySetting: String = "AUTOMATIC",
        lineOverrides: Map<Int, Int> = emptyMap(),
        listeningGuidance: ListeningAnswerSheetGuidance? = null,
        formToken: String,
        onProgress: ((currentStudent: Int, totalStudents: Int) -> Unit)? = null
    ): File {
        val outputDir = File(context.cacheDir, "answer_sheets")
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }

        // Clean up any stale temp files from previous incomplete attempts
        try {
            outputDir.listFiles { _, name -> name.endsWith(".tmp") }?.forEach { it.delete() }
        } catch (_: Exception) {}

        val targetFile = File(outputDir, "Sinav_${draft.id}_Cevap_Kagidi_Toplu.pdf")
        val tempFile = File(outputDir, "Sinav_${draft.id}_Cevap_Kagidi_Toplu.pdf.tmp")

        val pdfDocument = PdfDocument()

        try {
            val pageLayouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
                questions = questions,
                rubricCriteria = rubricCriteria,
                densitySetting = densitySetting,
                lineOverrides = lineOverrides,
                listeningGuidance = listeningGuidance,
                examType = draft.examType
            )
            val titleText = ExamAnswerSheetLayoutCalculator.buildAnswerSheetTitle(draft)
            val examDateStr = ExamAnswerSheetLayoutCalculator.formatExamDate(draft.examDate)

            var globalPageNumber = 1

            if (draft.examType == ExamType.MULTIPLE_CHOICE) {
                val formsPerSheet = when (densitySetting.uppercase()) {
                    "COMPACT" -> 4
                    "SPACIOUS" -> 1
                    else -> 2
                }
                data class FormJob(val student: Int, val layout: AnswerSheetPageLayout)
                val jobs = (1..studentCount).flatMap { student -> pageLayouts.map { FormJob(student, it) } }
                jobs.chunked(formsPerSheet).forEach { chunk ->
                    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, globalPageNumber).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)

                    chunk.forEachIndexed { slot, job ->
                        onProgress?.invoke(job.student, studentCount)
                        canvas.save()
                        when (formsPerSheet) {
                            1 -> Unit
                            2 -> {
                                // A5 yatay: mantıksal portre formu 90° döndürüp yarım A4'e sığdır.
                                val scale = 0.707f
                                val top = if (slot == 0) 0f else 421f
                                canvas.translate(595f, top)
                                canvas.scale(scale, scale)
                                canvas.rotate(90f)
                            }
                            else -> {
                                // 4 adet A6 portre form: 2x2 düzen.
                                val scale = 0.5f
                                val col = slot % 2
                                val row = slot / 2
                                canvas.translate(col * 297.5f, row * 421f)
                                canvas.scale(scale, scale)
                            }
                        }
                        ExamAnswerSheetPageRenderer.drawPage(
                            canvas = canvas,
                            pageLayout = job.layout,
                            titleText = titleText,
                            teachers = draft.teachers,
                            totalPoints = draft.totalPoints,
                            examDraftId = draft.id,
                            formToken = formToken,
                            studentIdx = job.student,
                            examDateStr = examDateStr,
                            listeningGuidance = null,
                            examType = draft.examType
                        )
                        canvas.restore()
                    }

                    val cutPaint = Paint().apply { color = Color.LTGRAY; strokeWidth = 0.8f }
                    if (formsPerSheet == 2) canvas.drawLine(0f, 421f, 595f, 421f, cutPaint)
                    if (formsPerSheet == 4) {
                        canvas.drawLine(297.5f, 0f, 297.5f, 842f, cutPaint)
                        canvas.drawLine(0f, 421f, 595f, 421f, cutPaint)
                    }
                    pdfDocument.finishPage(page)
                    globalPageNumber++
                }
            } else {
                for (studentIdx in 1..studentCount) {
                    onProgress?.invoke(studentIdx, studentCount)
                    for (pageLayout in pageLayouts) {
                        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, globalPageNumber).create()
                        val page = pdfDocument.startPage(pageInfo)
                        val canvas = page.canvas
                        ExamAnswerSheetPageRenderer.drawPage(
                            canvas = canvas,
                            pageLayout = pageLayout,
                            titleText = titleText,
                            teachers = draft.teachers,
                            totalPoints = draft.totalPoints,
                            examDraftId = draft.id,
                            formToken = formToken,
                            studentIdx = studentIdx,
                            examDateStr = examDateStr,
                            listeningGuidance = listeningGuidance,
                            examType = draft.examType
                        )
                        pdfDocument.finishPage(page)
                        globalPageNumber++
                    }
                }
            }

            FileOutputStream(tempFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            // Safely replace targetFile with tempFile
            if (targetFile.exists()) {
                targetFile.delete()
            }
            if (!tempFile.renameTo(targetFile)) {
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }

            return targetFile
        } catch (e: Throwable) {
            try {
                pdfDocument.close()
            } catch (_: Exception) {}

            if (tempFile.exists()) {
                try {
                    tempFile.delete()
                } catch (_: Exception) {}
            }

            throw IllegalStateException(
                "Toplu PDF oluşturulamadı. Cihazda yeterli boş alan olduğundan emin olup tekrar deneyin.",
                e
            )
        }
    }
}
