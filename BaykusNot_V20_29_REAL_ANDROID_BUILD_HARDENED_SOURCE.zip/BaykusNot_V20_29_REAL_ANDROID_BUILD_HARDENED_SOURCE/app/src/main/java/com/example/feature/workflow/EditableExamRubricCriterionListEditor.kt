package com.example.feature.workflow

object EditableExamRubricCriterionListEditor {

    fun addCriterion(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        questionOrderIndex: Int,
        questionNumberSnapshot: String
    ): List<EditableExamRubricCriterion> {
        require(localId > 0L) { "localId must be > 0" }
        require(questionOrderIndex > 0) { "questionOrderIndex must be > 0" }
        require(criteria.none { it.localId == localId }) { "Duplicate localId" }

        val maxPositiveOrderIndex = criteria
            .asSequence()
            .filter {
                it.questionOrderIndex == questionOrderIndex &&
                    it.criterionOrderIndex > 0
            }
            .maxOfOrNull { it.criterionOrderIndex }
            ?: 0

        require(maxPositiveOrderIndex != Int.MAX_VALUE) { "Criterion order overflow" }
        
        val newCriterion = EditableExamRubricCriterion(
            localId = localId,
            persistedId = 0L,
            questionOrderIndex = questionOrderIndex,
            questionNumberSnapshot = questionNumberSnapshot,
            criterionOrderIndex = maxPositiveOrderIndex + 1,
            title = "",
            description = "",
            maxPointsText = "",
            expectedAnswer = "",
            partialCreditGuidance = "",
            commonMistakes = ""
        )
        
        val lastIndex = criteria.indexOfLast { it.questionOrderIndex == questionOrderIndex }
        val mutable = criteria.toMutableList()
        if (lastIndex == -1) {
            mutable.add(newCriterion)
        } else {
            mutable.add(lastIndex + 1, newCriterion)
        }
        return mutable
    }

    fun removeCriterion(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        val mutable = criteria.filterNot { it.localId == localId }.toMutableList()
        return reindexQuestion(mutable, target.questionOrderIndex)
    }

    fun updateTitle(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.title == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(title = value) else it }
    }

    fun updateDescription(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.description == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(description = value) else it }
    }

    fun updateMaxPoints(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.maxPointsText == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(maxPointsText = value) else it }
    }

    fun updateExpectedAnswer(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.expectedAnswer == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(expectedAnswer = value) else it }
    }

    fun updatePartialCreditGuidance(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.partialCreditGuidance == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(partialCreditGuidance = value) else it }
    }

    fun updateCommonMistakes(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long,
        value: String
    ): List<EditableExamRubricCriterion> {
        val target = criteria.find { it.localId == localId } ?: return criteria
        if (target.commonMistakes == value) return criteria
        return criteria.map { if (it.localId == localId) it.copy(commonMistakes = value) else it }
    }

    fun moveCriterionUp(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long
    ): List<EditableExamRubricCriterion> {
        val targetIndex = criteria.indexOfFirst { it.localId == localId }
        if (targetIndex < 0) return criteria
        
        val target = criteria[targetIndex]
        val previousSameQuestionIndex = criteria.subList(0, targetIndex).indexOfLast { it.questionOrderIndex == target.questionOrderIndex }
        
        if (previousSameQuestionIndex == -1) return criteria
        
        val mutable = criteria.toMutableList()
        val temp = mutable[targetIndex]
        mutable[targetIndex] = mutable[previousSameQuestionIndex]
        mutable[previousSameQuestionIndex] = temp
        
        return reindexQuestion(mutable, target.questionOrderIndex)
    }

    fun moveCriterionDown(
        criteria: List<EditableExamRubricCriterion>,
        localId: Long
    ): List<EditableExamRubricCriterion> {
        val targetIndex = criteria.indexOfFirst { it.localId == localId }
        if (targetIndex < 0) return criteria
        
        val target = criteria[targetIndex]
        val nextSameQuestionRelativeIndex = criteria.subList(targetIndex + 1, criteria.size).indexOfFirst { it.questionOrderIndex == target.questionOrderIndex }
        
        if (nextSameQuestionRelativeIndex == -1) return criteria
        
        val nextSameQuestionIndex = targetIndex + 1 + nextSameQuestionRelativeIndex
        
        val mutable = criteria.toMutableList()
        val temp = mutable[targetIndex]
        mutable[targetIndex] = mutable[nextSameQuestionIndex]
        mutable[nextSameQuestionIndex] = temp
        
        return reindexQuestion(mutable, target.questionOrderIndex)
    }

    private fun reindexQuestion(
        criteria: List<EditableExamRubricCriterion>,
        questionOrderIndex: Int
    ): List<EditableExamRubricCriterion> {
        var currentIndex = 1
        return criteria.map {
            if (it.questionOrderIndex == questionOrderIndex) {
                it.copy(criterionOrderIndex = currentIndex++)
            } else {
                it
            }
        }
    }
}
