package com.example.core.network

import com.example.core.database.ExamObjectiveEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamType

sealed interface ExamQuestionObjectiveMatchingResult {
    data class Success(val mappings: Map<Long, List<Long>>) : ExamQuestionObjectiveMatchingResult
    data object MissingApiKey : ExamQuestionObjectiveMatchingResult
    data object Failure : ExamQuestionObjectiveMatchingResult
}

interface ExamQuestionObjectiveMatcher {
    suspend fun matchQuestionsToObjectives(
        questions: List<ExamQuestion>,
        objectives: List<ExamObjectiveEntity>,
        examType: ExamType = ExamType.WRITTEN
    ): ExamQuestionObjectiveMatchingResult

    suspend fun matchQuestionsToObjectivesForExam(
        examDraftId: Long,
        questions: List<ExamQuestion>,
        objectives: List<ExamObjectiveEntity>,
        examType: ExamType = ExamType.WRITTEN
    ): ExamQuestionObjectiveMatchingResult = matchQuestionsToObjectives(questions, objectives, examType)
}
