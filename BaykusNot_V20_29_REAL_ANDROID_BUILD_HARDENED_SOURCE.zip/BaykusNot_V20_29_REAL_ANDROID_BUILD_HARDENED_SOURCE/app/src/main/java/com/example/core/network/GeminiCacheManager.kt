package com.example.core.network

import com.example.core.security.BoundedInputReader
import android.content.Context
import android.util.AtomicFile
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.model.ExamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.security.MessageDigest

@Serializable
data class CacheRecord(
    val draftId: Long,
    val contentHash: String,
    val resourceName: String,
    val expireTimeMillis: Long,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val cachedTokenCount: Long = 0L,
    val deletedAtMillis: Long? = null,
    val cleanupStatus: String = "NONE",
    val cleanupLastError: String? = null,
    val cleanupUpdatedAtMillis: Long? = null
)

data class CacheCleanupResult(
    val matchedRecords: Int,
    val confirmedRemoteDeleted: Int,
    val pendingRemoteDeletion: Int
)

@Serializable
data class CacheStore(
    val records: List<CacheRecord> = emptyList()
)

class GeminiCacheManager(
    private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta/cachedContents"
) {
    private val jsonParser = Json { ignoreUnknownKeys = true; isLenient = true }
    private val file = File(context.filesDir, "gemini_prompt_caches.json")
    private val atomicFile = AtomicFile(file)
    private val maxLedgerBytes = 8 * 1024 * 1024

    private fun loadRecords(): List<CacheRecord> {
        val backup = File(file.path + ".bak")
        if (!file.exists() && !backup.exists()) return emptyList()
        return runCatching {
            atomicFile.openRead().use { input ->
                val bytes = BoundedInputReader.read(input, maxLedgerBytes, "Prompt-cache audit kaydı")
                jsonParser.decodeFromString<CacheStore>(String(bytes, Charsets.UTF_8)).records
            }
        }.getOrElse { error ->
            throw IllegalStateException(
                "Prompt-cache audit kaydı okunamadı; uzak cached-content kaynakları yok sayılmayacak.",
                error
            )
        }
    }

    private fun saveRecords(records: List<CacheRecord>) {
        file.parentFile?.mkdirs()
        val encoded = jsonParser.encodeToString(CacheStore.serializer(), CacheStore(records))
        require(encoded.toByteArray(Charsets.UTF_8).size.toLong() <= maxLedgerBytes) {
            "Prompt-cache audit kaydı güvenli boyut sınırını aşıyor."
        }
        jsonParser.decodeFromString<CacheStore>(encoded)
        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomicFile.startWrite()
            stream.write(encoded.toByteArray(Charsets.UTF_8))
            atomicFile.finishWrite(stream)
            stream = null
            val verified = atomicFile.openRead().use { input ->
                val bytes = BoundedInputReader.read(input, maxLedgerBytes, "Prompt-cache audit kaydı")
                jsonParser.decodeFromString<CacheStore>(String(bytes, Charsets.UTF_8)).records
            }
            check(verified == records) { "Prompt-cache audit kaydı yazma sonrası doğrulanamadı." }
        } catch (error: Throwable) {
            stream?.let { runCatching { atomicFile.failWrite(it) } }
            throw IllegalStateException("Prompt-cache audit kaydı crash-safe biçimde yazılamadı.", error)
        }
    }

    private fun calculateHash(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun shouldPerformCaching(
        questions: List<ExamQuestionEntity>,
        rubrics: List<ExamRubricCriterionEntity>,
        systemInstructionText: String,
        usePromptCachingPreference: Boolean
    ): Boolean {
        return usePromptCachingPreference && 
               (questions.isNotEmpty() || rubrics.isNotEmpty() || systemInstructionText.isNotEmpty())
    }

    suspend fun getOrCreateCache(
        draftId: Long,
        questions: List<ExamQuestionEntity>,
        rubrics: List<ExamRubricCriterionEntity>,
        systemInstructionText: String,
        apiKey: String,
        ttlSeconds: Int = 300,
        examType: ExamType = ExamType.WRITTEN,
        evaluationModelId: String = GeminiModelRegistry.evaluationModel
    ): String? = withContext(Dispatchers.IO) {
        GeminiModelRegistry.requireEvaluationModelApproved(evaluationModelId)
        val questionsJsonArray = buildJsonArray {
            questions.sortedBy { it.orderIndex }.forEach { q ->
                add(buildJsonObject {
                    put("questionOrderIndex", q.orderIndex)
                    put("questionNumber", q.questionNumber)
                    put("questionText", q.questionText)
                    put("maxPoints", q.points)
                })
            }
        }

        val rubricsJsonArray = buildJsonArray {
            rubrics.sortedBy { it.questionOrderIndex }.forEach { r ->
                add(buildJsonObject {
                    put("questionOrderIndex", r.questionOrderIndex)
                    put("questionNumberSnapshot", r.questionNumberSnapshot)
                    put("title", r.title)
                    put("description", r.description)
                    put("maxPoints", r.maxPoints)
                    put("expectedAnswer", r.expectedAnswer)
                    put("partialCreditGuidance", r.partialCreditGuidance)
                    put("commonMistakes", r.commonMistakes)
                })
            }
        }

        val contextPayload = buildJsonObject {
            put("questions", questionsJsonArray)
            put("rubrics", rubricsJsonArray)
        }.toString()

        val sharedTitle = when (examType) {
            ExamType.HOMEWORK -> "Ödev Görev/Maddeleri ve Onaylı Puanlama Rubriği (Ortak İçerik)"
            ExamType.READINESS -> "Hazırbulunuşluk Soruları ve Puanlama Rubriği (Ortak İçerik)"
            else -> "Sınav Soruları ve Puanlama Rubriği (Ortak İçerik)"
        }
        val sharedText = "$sharedTitle:\n$contextPayload"
        val contentHash = calculateHash("$evaluationModelId|$sharedText|$systemInstructionText")

        val now = System.currentTimeMillis()
        val allRecords = loadRecords()
        val currentRecords = allRecords.filter { it.deletedAtMillis == null && it.expireTimeMillis > now + 60_000L }
        val retainedHistory = allRecords.filter { it.deletedAtMillis != null || it.expireTimeMillis <= now + 60_000L }
            .filter { (it.deletedAtMillis ?: it.expireTimeMillis) > now - 90L * 24L * 60L * 60L * 1000L }

        val existing = currentRecords.find {
            it.draftId == draftId && it.contentHash == contentHash
        }

        if (existing != null) {
            // If the requested TTL is greater than the remaining time, patch the cache to extend its TTL
            val remainingTimeMillis = existing.expireTimeMillis - now
            if (remainingTimeMillis < (ttlSeconds * 1000L) - 60_000L) {
                val patchUrl = "https://generativelanguage.googleapis.com/v1beta/${existing.resourceName}?updateMask=ttl"
                val patchBodyJson = buildJsonObject {
                    put("ttl", "${ttlSeconds}s")
                }
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val request = Request.Builder()
                    .url(patchUrl)
                    .header("x-goog-api-key", apiKey)
                    .patch(patchBodyJson.toString().toRequestBody(mediaType))
                    .build()
                try {
                    val patchResponse = okHttpClient.executeCancellable(request)
                    patchResponse.use { resp ->
                        if (resp.isSuccessful) {
                            val updatedRecord = existing.copy(expireTimeMillis = now + (ttlSeconds * 1000L))
                            val updatedRecords = retainedHistory + currentRecords.filterNot { it.resourceName == existing.resourceName } + updatedRecord
                            saveRecords(updatedRecords)
                            return@withContext existing.resourceName
                        }
                    }
                } catch (error: CancellationException) {
                    throw error
                } catch (error: IllegalStateException) {
                    throw error
                } catch (_: Exception) {
                    // Fall through to recreate only for provider/network failures. Audit-ledger
                    // failures are never ignored because they could orphan a remote resource.
                }
            } else {
                return@withContext existing.resourceName
            }
        }

        val requestBodyJson = buildJsonObject {
            put("model", GeminiModelRegistry.modelResource(evaluationModelId))
            put("systemInstruction", buildJsonObject {
                put("parts", buildJsonArray {
                    add(buildJsonObject { put("text", systemInstructionText) })
                })
            })
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", sharedText) })
                    })
                })
            })
            put("ttl", "${ttlSeconds}s")
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val body = requestBodyJson.toString().toRequestBody(mediaType)
        val request = Request.Builder()
            .url(baseUrl)
            .header("x-goog-api-key", apiKey)
            .post(body)
            .build()

        try {
            val response = okHttpClient.executeCancellable(request)
            response.use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val bodyStr = resp.body?.string() ?: return@withContext null
                val jsonObj = jsonParser.parseToJsonElement(bodyStr).jsonObject
                val resourceName = jsonObj["name"]?.jsonPrimitive?.content ?: return@withContext null
                val createdAtMillis = jsonObj["createTime"]?.jsonPrimitive?.contentOrNull?.let { runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrNull() } ?: now
                val expireTimeMillis = jsonObj["expireTime"]?.jsonPrimitive?.contentOrNull?.let { runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrNull() } ?: (now + (ttlSeconds * 1000L))
                val cachedTokenCount = jsonObj["usageMetadata"]?.jsonObject?.get("totalTokenCount")?.jsonPrimitive?.content?.toLongOrNull() ?: 0L

                val newRecord = CacheRecord(
                    draftId = draftId,
                    contentHash = contentHash,
                    resourceName = resourceName,
                    expireTimeMillis = expireTimeMillis,
                    createdAtMillis = createdAtMillis,
                    cachedTokenCount = cachedTokenCount
                )

                val updatedRecords = retainedHistory + currentRecords.filterNot { it.draftId == draftId } + newRecord
                try {
                    saveRecords(updatedRecords)
                } catch (ledgerError: IllegalStateException) {
                    // The provider already created the cached-content resource. If we cannot
                    // durably record its id, immediately compensate by deleting it remotely.
                    // Never continue with an untracked provider resource.
                    val compensated = remoteDeleteCacheResource(resourceName, apiKey)
                    if (!compensated) {
                        throw IllegalStateException(
                            "Prompt cache oluşturuldu ancak audit kaydı yazılamadı ve uzak kaynak silinemedi; işlem durduruldu.",
                            ledgerError
                        )
                    }
                    throw IllegalStateException(
                        "Prompt cache audit kaydı yazılamadı; oluşturulan uzak kaynak güvenli biçimde geri alındı.",
                        ledgerError
                    )
                }

                return@withContext resourceName
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IllegalStateException) {
            throw e
        } catch (_: Exception) {
            return@withContext null
        }
    }

    private suspend fun remoteDeleteCacheResource(resourceName: String, apiKey: String): Boolean {
        val requestUrl = "https://generativelanguage.googleapis.com/v1beta/$resourceName"
        val request = Request.Builder()
            .url(requestUrl)
            .header("x-goog-api-key", apiKey)
            .delete()
            .build()
        return try {
            okHttpClient.executeCancellable(request).use { resp ->
                resp.isSuccessful || resp.code == 404
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteCache(resourceName: String, apiKey: String): Boolean = withContext(Dispatchers.IO) {
        val confirmed = remoteDeleteCacheResource(resourceName, apiKey)
        val now = System.currentTimeMillis()
        val currentRecords = loadRecords()
        val updatedRecords = currentRecords.map { record ->
            if (record.resourceName != resourceName) record
            else if (confirmed) {
                record.copy(
                    deletedAtMillis = record.deletedAtMillis ?: now,
                    cleanupStatus = "CONFIRMED_DELETED",
                    cleanupLastError = null,
                    cleanupUpdatedAtMillis = now
                )
            } else {
                record.copy(
                    cleanupStatus = "REMOTE_DELETE_PENDING",
                    cleanupLastError = "Cached-content kaynağı uzaktan silinemedi; yeniden denenecek.",
                    cleanupUpdatedAtMillis = now
                )
            }
        }
        saveRecords(updatedRecords)
        confirmed
    }

    suspend fun deleteCacheForDraft(draftId: Long, apiKey: String): CacheCleanupResult = withContext(Dispatchers.IO) {
        val recordsForDraft = loadRecords().filter {
            it.draftId == draftId && it.deletedAtMillis == null
        }
        var confirmed = 0
        var pending = 0
        for (record in recordsForDraft) {
            if (deleteCache(record.resourceName, apiKey)) confirmed++ else pending++
        }
        CacheCleanupResult(recordsForDraft.size, confirmed, pending)
    }

    suspend fun markDraftCacheCleanupPending(draftId: Long, reason: String): CacheCleanupResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val records = loadRecords()
        val target = records.filter { it.draftId == draftId && it.deletedAtMillis == null }
        if (target.isNotEmpty()) {
            saveRecords(records.map { record ->
                if (record.draftId == draftId && record.deletedAtMillis == null) {
                    record.copy(
                        cleanupStatus = "REMOTE_DELETE_PENDING",
                        cleanupLastError = reason,
                        cleanupUpdatedAtMillis = now
                    )
                } else record
            })
        }
        CacheCleanupResult(target.size, 0, target.size)
    }

    suspend fun retryPendingRemoteCleanup(apiKey: String): CacheCleanupResult = withContext(Dispatchers.IO) {
        val pendingRecords = loadRecords().filter {
            it.deletedAtMillis == null && it.cleanupStatus == "REMOTE_DELETE_PENDING"
        }
        var confirmed = 0
        var pending = 0
        for (record in pendingRecords) {
            if (deleteCache(record.resourceName, apiKey)) confirmed++ else pending++
        }
        CacheCleanupResult(pendingRecords.size, confirmed, pending)
    }

    fun countPendingForDraft(draftId: Long): Int = loadRecords().count {
        it.draftId == draftId && it.deletedAtMillis == null
    }

    fun getRemainingTimeForDraft(draftId: Long): Long {
        val now = System.currentTimeMillis()
        val record = loadRecords().find { it.draftId == draftId && it.deletedAtMillis == null && it.expireTimeMillis > now }
        if (record != null) return record.expireTimeMillis - now
        return 0L
    }

    /** Actual local cache lifetime cost: provider-reported cached tokens × real create→delete/expire hours. */
    fun storageCostUsdForDraft(draftId: Long, pricePerMillionTokenHourUsd: Double, nowMillis: Long = System.currentTimeMillis()): Double =
        loadRecords().filter { it.draftId == draftId && it.cachedTokenCount > 0 }.sumOf { record ->
            val end = minOf(record.deletedAtMillis ?: nowMillis, record.expireTimeMillis, nowMillis)
            val hours = ((end - record.createdAtMillis).coerceAtLeast(0L) / 3_600_000.0)
            (record.cachedTokenCount / 1_000_000.0) * hours * pricePerMillionTokenHourUsd.coerceAtLeast(0.0)
        }
}
