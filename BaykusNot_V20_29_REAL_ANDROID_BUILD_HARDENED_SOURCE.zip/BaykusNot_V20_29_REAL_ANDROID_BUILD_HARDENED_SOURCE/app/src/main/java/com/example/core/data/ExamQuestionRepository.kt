package com.example.core.data

import com.example.core.database.ExamDraftDao
import com.example.core.database.ExamQuestionDao
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamQuestionSetMetadataEntity
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.QuestionPointsValidator
import com.example.core.model.normalizeQuestionNumber
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlin.coroutines.cancellation.CancellationException

class ExamQuestionRepository(
    private val questionDao: ExamQuestionDao,
    private val examDraftDao: ExamDraftDao,
    private val nowProvider: () -> Long = System::currentTimeMillis
) {

    fun observeQuestions(examDraftId: Long): Flow<List<ExamQuestion>> {
        return questionDao.observeByExamDraftId(examDraftId)
            .map { entities -> entities.map(::mapToDomain) }
    }

    fun observeMetadata(examDraftId: Long): Flow<ExamQuestionSetMetadata?> {
        return questionDao.observeMetadataByExamDraftId(examDraftId)
            .map { it?.let(::mapToDomain) }
    }

    suspend fun getQuestionsOnce(examDraftId: Long): List<ExamQuestion> {
        return questionDao.getByExamDraftIdOnce(examDraftId)
            .map(::mapToDomain)
    }

    suspend fun getQuestionsEntitiesOnce(examDraftId: Long): List<ExamQuestionEntity> {
        return questionDao.getByExamDraftIdOnce(examDraftId)
    }

    suspend fun getMetadataOnce(examDraftId: Long): ExamQuestionSetMetadata? {
        return questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            ?.let(::mapToDomain)
    }

    suspend fun saveQuestions(
        examDraftId: Long,
        expectedRevision: Int,
        questions: List<ExamQuestion>
    ): SaveExamQuestionsResult {
        try {
            val draft = examDraftDao.getDraftByIdOnce(examDraftId)
                ?: return SaveExamQuestionsResult.DraftNotFound

            val validation = QuestionPointsValidator.validate(
                examDraftId = examDraftId,
                expectedTotalPoints = draft.totalPoints,
                questions = questions
            )

            val hasBlockingSaveIssue = validation.issues.any { issue ->
                issue.code != com.example.core.model.QuestionPointsValidationCode.EMPTY_QUESTION_LIST &&
                issue.code != com.example.core.model.QuestionPointsValidationCode.TOTAL_POINTS_MISMATCH
            }

            if (hasBlockingSaveIssue) {
                return SaveExamQuestionsResult.ValidationFailed(validation)
            }

            val currentMetadataEntity = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            val currentRevision = currentMetadataEntity?.revision ?: 0

            if (currentMetadataEntity?.isLocked == true) {
                return SaveExamQuestionsResult.Locked(currentRevision)
            }

            if (currentRevision != expectedRevision) {
                return SaveExamQuestionsResult.RevisionConflict(currentRevision)
            }

            val now = nowProvider()
            val entities = questions.map { q ->
                ExamQuestionEntity(
                    id = 0L,
                    examDraftId = examDraftId,
                    orderIndex = q.orderIndex,
                    questionNumber = q.questionNumber,
                    normalizedQuestionNumber = normalizeQuestionNumber(q.questionNumber),
                    questionText = q.questionText,
                    points = q.points,
                    createdAt = now,
                    updatedAt = now
                )
            }

            val success = questionDao.replaceQuestionsForDraft(
                examDraftId = examDraftId,
                questions = entities,
                expectedRevision = expectedRevision,
                updatedAt = now
            )

            if (!success) {
                val updatedMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                if (updatedMetadata?.isLocked == true) {
                     return SaveExamQuestionsResult.Locked(updatedMetadata.revision)
                }
                return SaveExamQuestionsResult.RevisionConflict(updatedMetadata?.revision ?: 0)
            }

            val savedMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?.let(::mapToDomain)!!

            return SaveExamQuestionsResult.Success(
                metadata = savedMetadata,
                validation = validation
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Throwable) {
            return SaveExamQuestionsResult.Failure(e)
        }
    }

    suspend fun lockQuestionSet(
        examDraftId: Long,
        expectedRevision: Int
    ): LockExamQuestionSetResult {
        try {
            val draft = examDraftDao.getDraftByIdOnce(examDraftId)
                ?: return LockExamQuestionSetResult.DraftNotFound

            val persistedQuestions = getQuestionsOnce(examDraftId)
            val validation = QuestionPointsValidator.validate(
                examDraftId = examDraftId,
                expectedTotalPoints = draft.totalPoints,
                questions = persistedQuestions
            )

            if (!validation.canLock) {
                return LockExamQuestionSetResult.ValidationFailed(validation)
            }

            val currentMetadataEntity = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return LockExamQuestionSetResult.MetadataMissing

            if (currentMetadataEntity.isLocked) {
                return LockExamQuestionSetResult.AlreadyLocked(currentMetadataEntity.revision)
            }

            if (currentMetadataEntity.revision != expectedRevision) {
                return LockExamQuestionSetResult.RevisionConflict(currentMetadataEntity.revision)
            }

            val now = nowProvider()
            val updatedCount = questionDao.lockQuestionSet(
                examDraftId = examDraftId,
                expectedRevision = expectedRevision,
                lockedAt = now
            )

            if (updatedCount == 0) {
                 val updatedMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                 if (updatedMetadata?.isLocked == true) {
                     return LockExamQuestionSetResult.AlreadyLocked(updatedMetadata.revision)
                 }
                 return LockExamQuestionSetResult.RevisionConflict(updatedMetadata?.revision ?: 0)
            }

            val finalMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?.let(::mapToDomain)!!

            return LockExamQuestionSetResult.Success(finalMetadata)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Throwable) {
            return LockExamQuestionSetResult.Failure(e)
        }
    }

    suspend fun invalidateUnlockedQuestionSet(examDraftId: Long): Boolean {
        try {
            val currentMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
            if (currentMetadata?.isLocked == true) return false
            val existingQuestions = questionDao.getByExamDraftIdOnce(examDraftId)
            if (existingQuestions.isEmpty()) return true
            val currentRevision = currentMetadata?.revision ?: 0
            return questionDao.replaceQuestionsForDraft(
                examDraftId = examDraftId,
                questions = emptyList(),
                expectedRevision = currentRevision,
                updatedAt = nowProvider()
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: Throwable) {
            return false
        }
    }

    suspend fun unlockQuestionSet(
        examDraftId: Long,
        expectedRevision: Int
    ): UnlockExamQuestionSetResult {
        try {
            val currentMetadataEntity = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?: return UnlockExamQuestionSetResult.MetadataMissing

            if (!currentMetadataEntity.isLocked) {
                return UnlockExamQuestionSetResult.AlreadyUnlocked(currentMetadataEntity.revision)
            }

            if (currentMetadataEntity.revision != expectedRevision) {
                return UnlockExamQuestionSetResult.RevisionConflict(currentMetadataEntity.revision)
            }

            val now = nowProvider()
            val updatedCount = questionDao.unlockQuestionSet(
                examDraftId = examDraftId,
                expectedRevision = expectedRevision,
                updatedAt = now
            )

            if (updatedCount == 0) {
                 val updatedMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                 if (updatedMetadata?.isLocked == false) {
                     return UnlockExamQuestionSetResult.AlreadyUnlocked(updatedMetadata.revision)
                 }
                 return UnlockExamQuestionSetResult.RevisionConflict(updatedMetadata?.revision ?: 0)
            }

            val finalMetadata = questionDao.getMetadataByExamDraftIdOnce(examDraftId)
                ?.let(::mapToDomain)!!

            return UnlockExamQuestionSetResult.Success(finalMetadata)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Throwable) {
            return UnlockExamQuestionSetResult.Failure(e)
        }
    }

    private fun mapToDomain(entity: ExamQuestionEntity): ExamQuestion {
        return ExamQuestion(
            id = entity.id,
            examDraftId = entity.examDraftId,
            orderIndex = entity.orderIndex,
            questionNumber = entity.questionNumber,
            questionText = entity.questionText,
            points = entity.points
        )
    }

    private fun mapToDomain(entity: ExamQuestionSetMetadataEntity): ExamQuestionSetMetadata {
        return ExamQuestionSetMetadata(
            examDraftId = entity.examDraftId,
            isLocked = entity.isLocked,
            lockedAt = entity.lockedAt,
            revision = entity.revision,
            createdAt = entity.createdAt,
            updatedAt = entity.updatedAt
        )
    }
}
