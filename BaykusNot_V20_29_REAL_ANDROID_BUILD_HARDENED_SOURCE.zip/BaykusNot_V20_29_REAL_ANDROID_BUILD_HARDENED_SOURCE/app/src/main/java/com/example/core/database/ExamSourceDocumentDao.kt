package com.example.core.database

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamSourceDocumentDao {

    @Query(
        """
        SELECT *
        FROM exam_source_document
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    fun observeByExamDraftId(
        examDraftId: Long
    ): Flow<ExamSourceDocumentEntity?>

    @Query(
        """
        SELECT *
        FROM exam_source_document
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    suspend fun getByExamDraftIdOnce(
        examDraftId: Long
    ): ExamSourceDocumentEntity?

    @Upsert
    suspend fun upsert(
        document: ExamSourceDocumentEntity
    )

    @Query(
        """
        DELETE FROM exam_source_document
        WHERE examDraftId = :examDraftId
        """
    )
    suspend fun deleteByExamDraftId(
        examDraftId: Long
    )
}
