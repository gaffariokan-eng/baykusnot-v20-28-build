package com.example.core.data

import com.example.core.network.ExamRubricGenerationResult
import com.example.core.network.ExamRubricGenerationValidationResult

sealed interface ExamRubricGenerationCoordinatorResult {

    data class PreflightBlocked(
        val result: ExamRubricGenerationPreflightResult
    ) : ExamRubricGenerationCoordinatorResult {
        init {
            require(
                result !is ExamRubricGenerationPreflightResult.Ready
            )
        }
    }

    data class GenerationFailed(
        val result: ExamRubricGenerationResult
    ) : ExamRubricGenerationCoordinatorResult {
        init {
            require(
                result !is ExamRubricGenerationResult.Generated
            )
        }
    }

    data class ValidationFailed(
        val result: ExamRubricGenerationValidationResult
    ) : ExamRubricGenerationCoordinatorResult {
        init {
            require(!result.isValid)
        }
    }

    data class SaveResult(
        val result: SaveExamRubricResult
    ) : ExamRubricGenerationCoordinatorResult
}
