package com.example.core.model

import com.example.R

enum class ExamType(
    val id: String,
    val displayNameRes: Int,
    val descriptionRes: Int,
    val isActive: Boolean
) {
    WRITTEN("WRITTEN", R.string.exam_type_written, R.string.exam_type_desc_written, true),
    LISTENING("LISTENING", R.string.exam_type_listening, R.string.exam_type_desc_listening, true),
    MULTIPLE_CHOICE("MULTIPLE_CHOICE", R.string.exam_type_multiple_choice, R.string.exam_type_desc_multiple_choice, true),
    HOMEWORK("HOMEWORK", R.string.exam_type_homework, R.string.exam_type_desc_homework, true),
    READINESS("READINESS", R.string.exam_type_readiness, R.string.exam_type_desc_readiness, true),
    MIXED("MIXED", R.string.exam_type_mixed, R.string.exam_type_not_available_yet, false)
}


/**
 * Human-facing exam labels used by shared PDF/workflow surfaces.
 * Keeps the shared written-exam pipeline type-aware without duplicating it.
 */
fun ExamType.documentExamNameUppercase(): String = when (this) {
    ExamType.WRITTEN -> "YAZILI SINAVI"
    ExamType.LISTENING -> "DİNLEME SINAVI"
    ExamType.MULTIPLE_CHOICE -> "TEST SINAVI"
    ExamType.HOMEWORK -> "ÖDEV KONTROLÜ"
    ExamType.READINESS -> "HAZIRBULUNUŞLUK SINAVI"
    ExamType.MIXED -> "SINAV"
}

fun ExamType.documentExamName(): String = when (this) {
    ExamType.WRITTEN -> "Yazılı Sınavı"
    ExamType.LISTENING -> "Dinleme Sınavı"
    ExamType.MULTIPLE_CHOICE -> "Test Sınavı"
    ExamType.HOMEWORK -> "Ödev Kontrolü"
    ExamType.READINESS -> "Hazırbulunuşluk Sınavı"
    ExamType.MIXED -> "Sınav"
}

fun ExamType.defaultWorkflowTitle(): String = when (this) {
    ExamType.WRITTEN -> "Yazılı Sınav Değerlendirme"
    ExamType.LISTENING -> "Dinleme Sınavı Değerlendirme"
    ExamType.MULTIPLE_CHOICE -> "Test Sınavı Değerlendirme"
    ExamType.HOMEWORK -> "Ödev Kontrolü"
    ExamType.READINESS -> "Hazırbulunuşluk Sınavı Değerlendirme"
    ExamType.MIXED -> "Sınav Değerlendirme"
}

fun ExamType.formatExamSequenceForDocument(rawSequence: String): String {
    val raw = rawSequence.trim()
    val upper = raw.uppercase(java.util.Locale.forLanguageTag("tr-TR"))
    val typeMarkerPresent = when (this) {
        ExamType.WRITTEN -> "YAZILI" in upper || "SINAV" in upper
        ExamType.LISTENING -> "DİNLEME" in upper || "DINLEME" in upper || "SINAV" in upper
        ExamType.MULTIPLE_CHOICE -> "TEST" in upper || "SINAV" in upper
        ExamType.HOMEWORK -> "ÖDEV" in upper || "ODEV" in upper || "KONTROL" in upper
        ExamType.READINESS -> "HAZIRBULUNUŞLUK" in upper || "HAZIRBULUNUSLUK" in upper || "SINAV" in upper
        ExamType.MIXED -> "SINAV" in upper
    }
    return when {
        raw.isBlank() -> "1. ${documentExamNameUppercase()}"
        typeMarkerPresent -> upper
        else -> "$raw. ${documentExamNameUppercase()}".uppercase(java.util.Locale.forLanguageTag("tr-TR"))
    }
}


/** Human-facing label for stage 2 in the shared workflow. */
fun ExamType.sourceStageLabel(): String = when (this) {
    ExamType.WRITTEN -> "Boş Sınav"
    ExamType.LISTENING -> "Dinleme Materyali"
    ExamType.HOMEWORK -> "Ödev Tanımı"
    ExamType.MULTIPLE_CHOICE -> "Cevap Anahtarı"
    ExamType.READINESS -> "Boş Hazırbulunuşluk Sınavı"
    ExamType.MIXED -> "Sınav Kaynağı"
}
