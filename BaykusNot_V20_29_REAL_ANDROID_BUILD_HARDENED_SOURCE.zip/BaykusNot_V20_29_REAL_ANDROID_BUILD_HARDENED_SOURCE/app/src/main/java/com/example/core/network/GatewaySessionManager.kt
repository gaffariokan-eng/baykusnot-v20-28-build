package com.example.core.network

import com.example.BuildConfig
import com.example.core.security.GatewayAuthTokenStore
import com.example.core.security.GatewayEnrollmentStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/**
 * Obtains and refreshes short-lived gateway access tokens using an institution-issued enrollment
 * credential. The enrollment credential is Keystore-encrypted on device and is never sent to
 * Gemini; only to the configured institution gateway session endpoint.
 *
 * Gateway contract:
 * POST <AI_GATEWAY_BASE_URL>/baykusnot/v1/session
 * Authorization: Enrollment <institution-issued-revocable-token>
 * Response: {"accessToken":"...", "expiresInSeconds":300}
 */
class GatewaySessionManager(
    private val bootstrapClient: OkHttpClient,
    private val enrollmentStore: GatewayEnrollmentStore,
    private val tokenStore: GatewayAuthTokenStore
) {
    private val mutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    suspend fun isEnrolled(): Boolean = enrollmentStore.hasEnrollment()

    suspend fun ensureValidSession(): String = mutex.withLock {
        val existing = tokenStore.bearerToken()
        if (existing != null) existing else refreshSessionLocked()
    }

    suspend fun enroll(value: String): String {
        val previousEnrollment = enrollmentStore.read()
        enrollmentStore.save(value)
        tokenStore.clear()
        return try {
            ensureValidSession()
        } catch (error: Throwable) {
            // Do not leave a failed enrollment looking valid on the next app start. If the teacher
            // was replacing a previously working credential, restore it; otherwise clear it.
            runCatching {
                if (previousEnrollment.isNullOrBlank()) enrollmentStore.clear()
                else enrollmentStore.save(previousEnrollment)
            }
            tokenStore.clear()
            throw error
        }
    }

    suspend fun clearEnrollment() {
        tokenStore.clear()
        enrollmentStore.clear()
    }

    private suspend fun refreshSessionLocked(): String = withContext(Dispatchers.IO) {
        val gateway = BuildConfig.AI_GATEWAY_BASE_URL.trim().trimEnd('/').toHttpUrlOrNull()
            ?: throw IllegalStateException("Güvenli AI gateway yapılandırılmamış.")
        if (!BuildConfig.ALLOW_DIRECT_GEMINI && gateway.scheme != "https") {
            throw IllegalStateException("Production AI gateway yalnız HTTPS üzerinden kullanılabilir.")
        }
        val enrollment = enrollmentStore.read()
            ?: throw IllegalStateException("Kurumsal gateway eşleştirmesi yapılmamış.")
        val sessionUrl = gateway.newBuilder()
            .encodedPath(gateway.encodedPath.trimEnd('/') + "/baykusnot/v1/session")
            .build()
        val body = "{\"client\":\"BaykusNot\",\"platform\":\"android\"}"
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(sessionUrl)
            .header("Authorization", "Enrollment $enrollment")
            .header("Cache-Control", "no-store")
            .post(body)
            .build()
        bootstrapClient.executeCancellable(request).use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Gateway oturumu alınamadı (HTTP ${response.code}).")
            }
            val root = json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
            val accessToken = root["accessToken"]?.jsonPrimitive?.content?.trim().orEmpty()
            val expiresIn = root["expiresInSeconds"]?.jsonPrimitive?.longOrNull ?: 300L
            require(accessToken.isNotBlank()) { "Gateway geçerli accessToken döndürmedi." }
            require(expiresIn in 60L..3600L) { "Gateway token süresi güvenli aralıkta değil." }
            val expiresAt = System.currentTimeMillis() + expiresIn * 1000L
            tokenStore.updateShortLivedToken(accessToken, expiresAt)
            accessToken
        }
    }
}
