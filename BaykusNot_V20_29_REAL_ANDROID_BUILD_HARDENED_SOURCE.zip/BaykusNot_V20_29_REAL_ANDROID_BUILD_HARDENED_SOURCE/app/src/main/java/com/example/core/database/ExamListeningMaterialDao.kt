package com.example.core.database

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamListeningMaterialDao {
    @Query(
        """
        SELECT * FROM exam_listening_material
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    fun observeByExamDraftId(examDraftId: Long): Flow<ExamListeningMaterialEntity?>

    @Query(
        """
        SELECT * FROM exam_listening_material
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    suspend fun getByExamDraftIdOnce(examDraftId: Long): ExamListeningMaterialEntity?

    @Upsert
    suspend fun upsert(material: ExamListeningMaterialEntity)

    @Query("DELETE FROM exam_listening_material WHERE examDraftId = :examDraftId")
    suspend fun deleteByExamDraftId(examDraftId: Long)
}
