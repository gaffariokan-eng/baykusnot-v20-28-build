package com.example.core.model

enum class ModelQualityTier(
    val displayName: String,
    val description: String
) {
    ECONOMY(
        displayName = "Ekonomik",
        description = "Daha düşük maliyetli ve hızlı değerlendirme."
    ),

    STANDARD(
        displayName = "Standart",
        description = "Maliyet ve değerlendirme kalitesi dengeli."
    ),

    DETAILED(
        displayName = "Ayrıntılı",
        description = "Daha kapsamlı değerlendirme ve ayrıntılı dönüt."
    )
}
