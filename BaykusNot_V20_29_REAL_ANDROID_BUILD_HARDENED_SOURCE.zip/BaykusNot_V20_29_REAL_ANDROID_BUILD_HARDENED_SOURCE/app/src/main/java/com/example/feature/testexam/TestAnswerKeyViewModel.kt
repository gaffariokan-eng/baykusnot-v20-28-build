package com.example.feature.testexam

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamRubricRepository
import com.example.core.data.ExamEvaluationRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.TestOpticalFormReader
import com.example.core.data.TestTeacherAnswerKeyFormGenerator
import com.example.core.data.LockExamQuestionSetResult
import com.example.core.data.LockExamRubricSetResult
import com.example.core.data.SaveExamQuestionsResult
import com.example.core.data.SaveExamRubricResult
import com.example.core.data.UnlockExamQuestionSetResult
import com.example.core.data.UnlockExamRubricSetResult
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.ExamRubricSetMetadata
import com.example.core.model.MultipleChoiceAnswerKeyTextParser
import com.example.core.model.MultipleChoiceOptionPolicy
import com.example.core.model.MultipleChoiceTestStructurePolicy
import com.example.core.model.OpticalChoiceStatus
import com.example.core.model.normalizeQuestionNumber
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val DEFAULT_TEST_QUESTION_COUNT = 20
private const val DEFAULT_TEST_OPTION_COUNT = 5

data class TestAnswerKeyItem(
    val question: ExamQuestion,
    val options: List<String>,
    val selectedChoice: String? = null
)

data class TestAnswerKeyUiState(
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val isLocked: Boolean = false,
    val totalPoints: Int = 0,
    val questionCount: Int = DEFAULT_TEST_QUESTION_COUNT,
    val questionCountText: String = DEFAULT_TEST_QUESTION_COUNT.toString(),
    val optionCount: Int = DEFAULT_TEST_OPTION_COUNT,
    val items: List<TestAnswerKeyItem> = emptyList(),
    val bulkText: String = "",
    val teacherFormFile: File? = null,
    val isGeneratingTeacherForm: Boolean = false,
    val isReadingTeacherForm: Boolean = false,
    val message: String? = null,
    val canContinue: Boolean = false
)

class TestAnswerKeyViewModel(
    private val draftId: Long,
    private val draftRepository: ExamDraftRepository,
    private val questionRepository: ExamQuestionRepository,
    private val rubricRepository: ExamRubricRepository,
    private val evaluationRepository: ExamEvaluationRepository,
    private val paperUploadRepository: ExamPaperUploadRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(TestAnswerKeyUiState())
    val uiState: StateFlow<TestAnswerKeyUiState> = _uiState.asStateFlow()

    init { refresh() }

    fun refresh(messageAfterLoad: String? = null) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, message = null)
            try {
                val draft = draftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Test taslağı bulunamadı.")
                val persistedQuestions = questionRepository.getQuestionsOnce(draftId).sortedBy { it.orderIndex }
                val questionMetadata = questionRepository.getMetadataOnce(draftId)
                val answerKeyMetadata = rubricRepository.getMetadataOnce(draftId)
                val criteria = rubricRepository.getCriteriaOnce(draftId)
                val choiceByOrder = criteria.associate {
                    it.questionOrderIndex to MultipleChoiceOptionPolicy.normalizeChoice(it.expectedAnswer)
                }

                val totalPoints = draft.totalPoints.coerceAtLeast(1)
                val questionCount = if (persistedQuestions.isNotEmpty()) {
                    persistedQuestions.size
                } else {
                    DEFAULT_TEST_QUESTION_COUNT.coerceAtMost(totalPoints).coerceAtLeast(1)
                }
                val optionCount = persistedQuestions.firstOrNull()?.let {
                    MultipleChoiceOptionPolicy.detectLabels(it.questionText).size
                }?.coerceIn(2, 8) ?: DEFAULT_TEST_OPTION_COUNT
                val questions = if (persistedQuestions.isNotEmpty()) {
                    persistedQuestions
                } else {
                    buildQuestions(questionCount, optionCount, totalPoints)
                }
                val bothLocked = questionMetadata?.isLocked == true && answerKeyMetadata?.isLocked == true
                val anyLocked = questionMetadata?.isLocked == true || answerKeyMetadata?.isLocked == true

                _uiState.value = TestAnswerKeyUiState(
                    isLoading = false,
                    isLocked = anyLocked,
                    totalPoints = totalPoints,
                    questionCount = questionCount,
                    questionCountText = questionCount.toString(),
                    optionCount = optionCount,
                    items = questions.map { q ->
                        TestAnswerKeyItem(
                            question = q,
                            options = optionLabels(optionCount),
                            selectedChoice = choiceByOrder[q.orderIndex]?.takeIf { it in optionLabels(optionCount) }
                        )
                    },
                    teacherFormFile = _uiState.value.teacherFormFile?.takeIf { it.exists() },
                    message = messageAfterLoad,
                    canContinue = bothLocked && questions.isNotEmpty() && questions.all { choiceByOrder[it.orderIndex] != null }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    message = e.message ?: "Cevap anahtarı yüklenemedi."
                )
            }
        }
    }

    fun updateQuestionCountText(text: String) {
        if (_uiState.value.isLocked) return
        val clean = text.filter { it.isDigit() }.take(3)
        val state = _uiState.value
        if (clean.isBlank()) {
            _uiState.value = state.copy(questionCountText = "", message = null)
            return
        }
        val value = clean.toIntOrNull() ?: return
        val maxAllowed = minOf(MultipleChoiceTestStructurePolicy.MAX_QUESTION_COUNT, state.totalPoints.coerceAtLeast(1))
        if (value !in 1..maxAllowed) {
            _uiState.value = state.copy(
                questionCountText = clean,
                message = "Soru sayısı 1 ile $maxAllowed arasında olmalıdır. Toplam puan her soruya en az 1 puan vermelidir."
            )
            return
        }
        rebuildStructure(questionCount = value, optionCount = state.optionCount, questionCountText = clean)
    }

    fun updateOptionCount(count: Int) {
        if (_uiState.value.isLocked || count !in 2..8) return
        rebuildStructure(
            questionCount = _uiState.value.questionCount,
            optionCount = count,
            questionCountText = _uiState.value.questionCountText
        )
    }

    private fun rebuildStructure(questionCount: Int, optionCount: Int, questionCountText: String) {
        val state = _uiState.value
        val oldChoiceByOrder = state.items.associate { it.question.orderIndex to it.selectedChoice }
        val questions = buildQuestions(questionCount, optionCount, state.totalPoints)
        val labels = optionLabels(optionCount)
        _uiState.value = state.copy(
            questionCount = questionCount,
            questionCountText = questionCountText,
            optionCount = optionCount,
            items = questions.map { q ->
                TestAnswerKeyItem(
                    question = q,
                    options = labels,
                    selectedChoice = oldChoiceByOrder[q.orderIndex]?.takeIf { it in labels }
                )
            },
            teacherFormFile = null,
            message = null,
            canContinue = false
        )
    }

    fun selectChoice(questionOrderIndex: Int, choice: String) {
        if (_uiState.value.isLocked) return
        _uiState.value = _uiState.value.copy(
            items = _uiState.value.items.map { item ->
                if (item.question.orderIndex == questionOrderIndex && choice in item.options) {
                    item.copy(selectedChoice = choice)
                } else item
            },
            message = null,
            canContinue = false
        )
    }

    fun updateBulkText(text: String) {
        if (_uiState.value.isLocked) return
        _uiState.value = _uiState.value.copy(bulkText = text, message = null)
    }

    fun applyBulkText(rawText: String = _uiState.value.bulkText) {
        if (_uiState.value.isLocked) return
        val parsed = MultipleChoiceAnswerKeyTextParser.parse(rawText)
        val updated = _uiState.value.items.map { item ->
            val normalizedNumber = normalizeQuestionNumber(item.question.questionNumber)
            val direct = parsed.answersByQuestionNumber[normalizedNumber]
                ?: parsed.answersByQuestionNumber[item.question.orderIndex.toString()]
            if (direct != null && direct in item.options) item.copy(selectedChoice = direct) else item
        }
        val appliedCount = updated.count { new ->
            val old = _uiState.value.items.first { it.question.orderIndex == new.question.orderIndex }
            new.selectedChoice != old.selectedChoice
        }
        val suffix = if (parsed.unparsedTokens.isEmpty()) "" else {
            " Okunamayan parçalar: ${parsed.unparsedTokens.take(5).joinToString(", ")}"
        }
        _uiState.value = _uiState.value.copy(
            items = updated,
            bulkText = rawText,
            message = "$appliedCount cevap uygulandı.$suffix",
            canContinue = false
        )
    }

    fun generateTeacherAnswerKeyForm(context: Context) {
        val snapshot = _uiState.value
        if (snapshot.isGeneratingTeacherForm || snapshot.isReadingTeacherForm || snapshot.items.isEmpty()) return
        if (snapshot.questionCountText.toIntOrNull() != snapshot.questionCount) {
            _uiState.value = snapshot.copy(message = "Önce geçerli soru sayısını kesinleştirin.")
            return
        }
        viewModelScope.launch {
            _uiState.value = snapshot.copy(isGeneratingTeacherForm = true, message = null)
            try {
                val draft = draftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Test taslağı bulunamadı.")
                val file = withContext(Dispatchers.IO) {
                    TestTeacherAnswerKeyFormGenerator.generate(
                        context = context.applicationContext,
                        draft = draft,
                        questions = snapshot.items.map { it.question }
                    )
                }
                _uiState.value = _uiState.value.copy(
                    isGeneratingTeacherForm = false,
                    teacherFormFile = file,
                    message = "Öğretmen cevap anahtarı formu hazır. Formu yazdırıp yalnız doğru seçenekleri işaretleyin; sonra fotoğraf/PDF olarak geri yükleyebilirsiniz."
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isGeneratingTeacherForm = false,
                    message = e.message ?: "Öğretmen cevap anahtarı formu oluşturulamadı."
                )
            }
        }
    }

    fun importTeacherAnswerKeyForms(context: Context, uris: List<Uri>) {
        val snapshot = _uiState.value
        if (snapshot.isLocked || snapshot.isGeneratingTeacherForm || snapshot.isReadingTeacherForm || uris.isEmpty()) return
        if (snapshot.items.isEmpty()) {
            _uiState.value = snapshot.copy(message = "Önce test soru sayısını ve seçenek yapısını belirleyin.")
            return
        }
        if (snapshot.questionCountText.toIntOrNull() != snapshot.questionCount) {
            _uiState.value = snapshot.copy(message = "Önce geçerli soru sayısını kesinleştirin.")
            return
        }
        viewModelScope.launch {
            _uiState.value = snapshot.copy(isReadingTeacherForm = true, message = "Öğretmen formu cihaz içinde optik olarak okunuyor...")
            val read = try {
                withContext(Dispatchers.IO) {
                    TestOpticalFormReader.readTeacherAnswerKey(
                        context = context.applicationContext,
                        uris = uris,
                        questions = snapshot.items.map { it.question }
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isReadingTeacherForm = false, message = "Öğretmen cevap anahtarı formu okunamadı: ${e.message ?: "Bilinmeyen hata"}")
                return@launch
            }
            if (read.errorMessage != null && read.questions.isEmpty()) {
                _uiState.value = _uiState.value.copy(isReadingTeacherForm = false, message = read.errorMessage, canContinue = false)
                return@launch
            }
            val byOrder = read.questions.associateBy { it.questionOrderIndex }
            var applied = 0
            val updated = snapshot.items.map { item ->
                val result = byOrder[item.question.orderIndex]
                if (result == null) {
                    item
                } else {
                    val choice = result.markedChoice
                    val nextChoice = if (result.status == OpticalChoiceStatus.MARKED && choice != null && choice in item.options) {
                        choice
                    } else {
                        null
                    }
                    if (nextChoice != item.selectedChoice) applied++
                    item.copy(selectedChoice = nextChoice)
                }
            }
            val blank = read.questions.count { it.status == OpticalChoiceStatus.BLANK }
            val multiple = read.questions.count { it.status == OpticalChoiceStatus.MULTIPLE }
            val ambiguous = read.questions.count { it.status == OpticalChoiceStatus.AMBIGUOUS }
            val unresolved = blank + multiple + ambiguous
            val registrationPercent = (read.registrationConfidence * 100.0).toInt().coerceIn(0, 100)
            val warning = read.errorMessage?.takeIf { it.isNotBlank() }?.let { " $it" }.orEmpty()
            val detail = if (unresolved == 0) {
                "Tüm cevaplar okundu. Kilitlemeden önce anahtarı ekranda kontrol edin."
            } else {
                "Çözülemeyen: $unresolved (boş $blank, çift $multiple, belirsiz $ambiguous). Bunları ekrandan tamamlayın."
            }
            _uiState.value = _uiState.value.copy(
                isReadingTeacherForm = false,
                items = updated,
                message = "$applied cevap/seçim optik forma göre güncellendi • hizalama %$registrationPercent. $detail$warning",
                canContinue = false
            )
        }
    }

    fun save() = persist(lockAfterSave = false)
    fun saveAndLock() = persist(lockAfterSave = true)

    private fun persist(lockAfterSave: Boolean) {
        val snapshot = _uiState.value
        if (snapshot.isSaving || snapshot.isLocked) return
        if (snapshot.questionCountText.toIntOrNull() != snapshot.questionCount || snapshot.items.size != snapshot.questionCount) {
            _uiState.value = snapshot.copy(message = "Geçerli bir soru sayısı girin.")
            return
        }
        val missing = snapshot.items.filter { it.selectedChoice == null }
        if (missing.isNotEmpty()) {
            _uiState.value = snapshot.copy(message = "${missing.size} soru için doğru seçenek seçilmedi.")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true, message = null)
            try {
                val draft = draftRepository.getDraftByIdOnce(draftId)
                    ?: throw IllegalStateException("Test taslağı bulunamadı.")
                val previousQuestions = questionRepository.getQuestionsOnce(draftId).sortedBy { it.orderIndex }
                val previousCriteria = rubricRepository.getCriteriaOnce(draftId)
                val newQuestions = snapshot.items.map { it.question }.sortedBy { it.orderIndex }
                val previousStructureFingerprint = previousQuestions.map {
                    listOf(it.orderIndex, it.questionNumber, it.questionText, it.points)
                }
                val newStructureFingerprint = newQuestions.map {
                    listOf(it.orderIndex, it.questionNumber, it.questionText, it.points)
                }
                val structureChanged = previousQuestions.isNotEmpty() && previousStructureFingerprint != newStructureFingerprint
                val oldKey = previousCriteria.associate {
                    it.questionOrderIndex to MultipleChoiceOptionPolicy.normalizeChoice(it.expectedAnswer.ifBlank { it.originalAnswerKey.orEmpty() })
                }
                val newKey = snapshot.items.associate { it.question.orderIndex to it.selectedChoice }
                val answerKeyChanged = previousCriteria.isNotEmpty() && oldKey != newKey

                if (snapshot.questionCount > draft.totalPoints) {
                    throw IllegalStateException("Toplam puan (${draft.totalPoints}), soru sayısından (${snapshot.questionCount}) küçük olamaz.")
                }

                var questionMeta = questionRepository.getMetadataOnce(draftId)
                if (questionMeta?.isLocked != true) {
                    val expectedRevision = questionMeta?.revision ?: 0
                    when (val savedQuestions = questionRepository.saveQuestions(
                        examDraftId = draftId,
                        expectedRevision = expectedRevision,
                        questions = newQuestions
                    )) {
                        is SaveExamQuestionsResult.Success -> questionMeta = savedQuestions.metadata
                        is SaveExamQuestionsResult.ValidationFailed -> throw IllegalStateException("Soru sayısı/puan dağılımı geçersiz.")
                        is SaveExamQuestionsResult.Locked -> throw IllegalStateException("Test soru yapısı kilitli. Önce kilidi açın.")
                        is SaveExamQuestionsResult.RevisionConflict -> throw IllegalStateException("Test soru yapısı başka bir işlemde değişti. Ekranı yenileyin.")
                        is SaveExamQuestionsResult.DraftNotFound -> throw IllegalStateException("Test taslağı bulunamadı.")
                        is SaveExamQuestionsResult.Failure -> throw savedQuestions.cause
                    }
                }

                if (lockAfterSave && questionMeta?.isLocked != true) {
                    when (val lockedQuestions = questionRepository.lockQuestionSet(draftId, questionMeta!!.revision)) {
                        is LockExamQuestionSetResult.Success -> questionMeta = lockedQuestions.metadata
                        is LockExamQuestionSetResult.AlreadyLocked -> questionMeta = questionRepository.getMetadataOnce(draftId)
                        is LockExamQuestionSetResult.ValidationFailed -> throw IllegalStateException("Soru puanlarının toplamı sınav toplam puanıyla uyuşmuyor.")
                        is LockExamQuestionSetResult.RevisionConflict -> throw IllegalStateException("Soru yapısı değişti. Ekranı yenileyin.")
                        is LockExamQuestionSetResult.DraftNotFound,
                        is LockExamQuestionSetResult.MetadataMissing -> throw IllegalStateException("Test soru yapısı kilitlenemedi.")
                        is LockExamQuestionSetResult.Failure -> throw lockedQuestions.cause
                    }
                }

                val effectiveQuestionMeta = questionMeta
                    ?: throw IllegalStateException("Test soru yapısı kaydedilemedi.")
                val currentAnswerMeta = rubricRepository.getMetadataOnce(draftId)
                val criteria = snapshot.items.map { item ->
                    ExamRubricCriterion(
                        examDraftId = draftId,
                        questionOrderIndex = item.question.orderIndex,
                        questionNumberSnapshot = item.question.questionNumber,
                        criterionOrderIndex = 1,
                        title = "Doğru Seçenek",
                        description = "Öğretmen tarafından belirlenen test cevap anahtarı.",
                        maxPoints = item.question.points,
                        expectedAnswer = item.selectedChoice!!,
                        partialCreditGuidance = "Kısmi puan yoktur. Doğru cevap tam puan, yanlış veya boş cevap 0 puandır.",
                        commonMistakes = "",
                        originalAnswerKey = item.selectedChoice
                    )
                }
                val keyText = snapshot.items.joinToString(" ") {
                    "${normalizeQuestionNumber(it.question.questionNumber)}-${it.selectedChoice}"
                }
                val merged = ExamRubricSetMetadata(
                    examDraftId = draftId,
                    questionSetRevision = effectiveQuestionMeta.revision,
                    isLocked = false,
                    lockedAt = null,
                    revision = currentAnswerMeta?.revision ?: 0,
                    createdAt = currentAnswerMeta?.createdAt ?: 0L,
                    updatedAt = currentAnswerMeta?.updatedAt ?: 0L,
                    evaluationSourceType = "TEACHER_TEST_ANSWER_KEY",
                    originalTeacherAnswerKey = keyText,
                    isAsIs = true
                )
                when (val saved = rubricRepository.saveRubric(
                    examDraftId = draftId,
                    expectedRevision = currentAnswerMeta?.revision ?: 0,
                    expectedQuestionSetRevision = effectiveQuestionMeta.revision,
                    criteria = criteria,
                    metadataToMerge = merged
                )) {
                    is SaveExamRubricResult.Success -> {
                        val resetMessage = when {
                            structureChanged -> {
                                evaluationRepository.resetEvaluationsForExam(draftId)
                                paperUploadRepository.clearAllPapers(draftId)
                                "Test soru/seçenek yapısı değişti. Eski öğrenci cevap formu yüklemeleri ve sonuçları güvenlik için temizlendi; güncel cevap formunu yeniden oluşturup yükleyin."
                            }
                            answerKeyChanged -> {
                                evaluationRepository.resetEvaluationsForExam(draftId)
                                "Cevap anahtarı değişti. Eski puanlamalar temizlendi; mevcut öğrenci formlarını Yerel Optik Okuma aşamasında yeniden okuyun."
                            }
                            else -> null
                        }
                        if (lockAfterSave) {
                            when (val locked = rubricRepository.lockRubricSet(draftId, saved.metadata.revision)) {
                                is LockExamRubricSetResult.Success,
                                is LockExamRubricSetResult.AlreadyLocked -> refresh(resetMessage ?: "Test yapısı ve cevap anahtarı kilitlendi.")
                                is LockExamRubricSetResult.ValidationFailed -> {
                                    _uiState.value = _uiState.value.copy(
                                        isSaving = false,
                                        message = "Cevap anahtarı doğrulanamadı. Tüm sorularda tek doğru seçenek bulunduğunu kontrol edin."
                                    )
                                }
                                else -> _uiState.value = _uiState.value.copy(
                                    isSaving = false,
                                    message = "Cevap anahtarı kilitlenemedi: $locked"
                                )
                            }
                        } else {
                            refresh(resetMessage ?: "Test yapısı ve cevap anahtarı kaydedildi.")
                        }
                    }
                    is SaveExamRubricResult.ValidationFailed -> _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        message = "Cevap anahtarı geçersiz. Doğru seçenekleri kontrol edin."
                    )
                    is SaveExamRubricResult.Locked -> refresh()
                    else -> _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        message = "Cevap anahtarı kaydedilemedi: $saved"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    message = e.message ?: "Test yapısı ve cevap anahtarı kaydedilemedi."
                )
            }
        }
    }

    fun unlock() {
        val snapshot = _uiState.value
        if (!snapshot.isLocked || snapshot.isSaving) return
        viewModelScope.launch {
            _uiState.value = snapshot.copy(isSaving = true, message = null)
            try {
                val answerMeta = rubricRepository.getMetadataOnce(draftId)
                if (answerMeta?.isLocked == true) {
                    when (rubricRepository.unlockRubricSet(draftId, answerMeta.revision)) {
                        is UnlockExamRubricSetResult.Success,
                        is UnlockExamRubricSetResult.AlreadyUnlocked -> Unit
                        else -> throw IllegalStateException("Cevap anahtarı kilidi açılamadı.")
                    }
                }
                val questionMeta = questionRepository.getMetadataOnce(draftId)
                if (questionMeta?.isLocked == true) {
                    when (questionRepository.unlockQuestionSet(draftId, questionMeta.revision)) {
                        is UnlockExamQuestionSetResult.Success,
                        is UnlockExamQuestionSetResult.AlreadyUnlocked -> Unit
                        else -> throw IllegalStateException("Test soru yapısı kilidi açılamadı.")
                    }
                }
                refresh()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    message = e.message ?: "Kilit açılamadı."
                )
            }
        }
    }

    private fun buildQuestions(questionCount: Int, optionCount: Int, totalPoints: Int): List<ExamQuestion> {
        if (questionCount <= 0 || totalPoints < questionCount) return emptyList()
        val labels = optionLabels(optionCount)
        val pointsByOrder = MultipleChoiceTestStructurePolicy.distributePoints(questionCount, totalPoints)
        if (pointsByOrder.size != questionCount) return emptyList()
        return (1..questionCount).map { number ->
            val points = pointsByOrder[number - 1]
            ExamQuestion(
                examDraftId = draftId,
                orderIndex = number,
                questionNumber = number.toString(),
                questionText = buildString {
                    append("Test sorusu $number")
                    labels.forEach { label -> append("\n$label) ") }
                },
                points = points
            )
        }
    }

    private fun optionLabels(count: Int): List<String> =
        MultipleChoiceTestStructurePolicy.optionLabels(count)

    class Factory(
        private val draftId: Long,
        private val draftRepository: ExamDraftRepository,
        private val questionRepository: ExamQuestionRepository,
        private val rubricRepository: ExamRubricRepository,
        private val evaluationRepository: ExamEvaluationRepository,
        private val paperUploadRepository: ExamPaperUploadRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            TestAnswerKeyViewModel(
                draftId,
                draftRepository,
                questionRepository,
                rubricRepository,
                evaluationRepository,
                paperUploadRepository
            ) as T
    }
}
