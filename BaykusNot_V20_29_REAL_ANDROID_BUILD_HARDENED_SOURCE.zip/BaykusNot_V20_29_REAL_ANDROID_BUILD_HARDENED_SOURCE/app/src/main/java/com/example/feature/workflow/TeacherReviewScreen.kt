package com.example.feature.workflow

import com.example.core.security.StudentImageCrypto
import com.example.core.network.ExamImagePrivacyProcessor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import java.io.File
import com.example.core.data.ExamEvaluationRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.data.ExamQuestionRepository
import com.example.core.data.ExamAnswerSheetLayoutCalculator
import com.example.core.database.ExamQuestionEntity
import com.example.core.database.ExamRubricCriterionEntity
import com.example.core.database.ExamQuestionEvaluationEntity
import com.example.core.model.ExamType
import com.example.core.data.ListeningAnswerSheetGuidance

@Composable
fun TeacherReviewRoute(
    draftId: Long,
    examType: ExamType = ExamType.WRITTEN,
    evaluationRepository: ExamEvaluationRepository,
    paperUploadRepository: ExamPaperUploadRepository,
    questionRepository: ExamQuestionRepository,
    onAdvanceToReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: TeacherReviewViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        key = "teacher_review_$draftId",
        factory = TeacherReviewViewModel.Factory(
            draftId,
            evaluationRepository,
            paperUploadRepository,
            questionRepository,
            examType
        )
    )
    val uiState by viewModel.uiState.collectAsState()

    TeacherReviewScreen(
        uiState = uiState,
        examType = examType,
        onSelectStudent = viewModel::selectStudent,
        onUpdateScore = viewModel::updateQuestionScore,
        onResolveWithoutScore = viewModel::resolveWithoutScoreChange,
        onResolveTestChoice = viewModel::resolveMultipleChoiceAnswer,
        onNextProblemStudent = viewModel::selectNextStudentNeedingReview,
        onRecordReviewRequest = viewModel::recordStudentParentReviewRequest,
        onResolveReviewRequest = viewModel::resolveStudentParentReviewRequest,
        onUpdateTeacherNote = viewModel::updateTeacherNote,
        onConfirmResults = { viewModel.confirmAllResults(onAdvanceToReports) },
        modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherReviewScreen(
    uiState: TeacherReviewUiState,
    examType: ExamType = ExamType.WRITTEN,
    onSelectStudent: (Long?) -> Unit,
    onUpdateScore: (Long, String) -> Unit,
    onResolveWithoutScore: (Long) -> Unit,
    onResolveTestChoice: (Long, String?) -> Unit,
    onNextProblemStudent: () -> Unit,
    onRecordReviewRequest: (Long, String) -> Unit,
    onResolveReviewRequest: (Long) -> Unit,
    onUpdateTeacherNote: (Long, String) -> Unit,
    onConfirmResults: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedStudent = uiState.students.find { it.paper.id == uiState.selectedStudentPaperId }
    val copy = submissionCopy(examType)

    Scaffold(
        modifier = modifier,
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (uiState.message != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = uiState.message,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }

                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (uiState.isSavingChanges) {
                            Text(
                                "Öğretmen düzeltmesi kaydediliyor…",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        Button(
                            onClick = onConfirmResults,
                            enabled = !uiState.isConfirming && !uiState.isSavingChanges && uiState.students.isNotEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            if (uiState.isConfirming) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Onaylanıyor ve dönütler hazırlanıyor...")
                            } else {
                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    when (examType) {
                                        ExamType.READINESS -> "Hazırbulunuşluk Sonuçlarını Onayla"
                                        ExamType.MULTIPLE_CHOICE -> "Test Sonuçlarını Onayla"
                                        else -> "Sonuçları Onayla"
                                    }
                                )
                            }
                        }
                        if (!uiState.isConfirming && !uiState.isSavingChanges && uiState.students.isNotEmpty()) {
                            Text(
                                text = when (examType) {
                                    ExamType.READINESS -> "Onaydan sonra bireysel ve sınıf hazırbulunuşluk görünümleri yeniden hesaplanır; öncelikli destek alanları raporlarda gösterilir."
                                    ExamType.MULTIPLE_CHOICE -> "Onaydan sonra Test Raporlarında doğru, yanlış, boş ve seçenek dağılımları hesaplanır."
                                    else -> "Onaydan sonra Raporlar aşamasına geçilir."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (uiState.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (uiState.students.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(copy.reviewEmptyText, style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                val totalStudents = uiState.students.size
                val fullyReadyCount = uiState.students.count { student ->
                    val unresolved = student.questionEvaluations.count { it.needsReview && !it.isResolved }
                    student.evaluation?.status != "ERROR" && unresolved == 0
                }
                val pendingReviewCount = totalStudents - fullyReadyCount
                val unresolvedProblematicCount = uiState.students.sumOf { s -> s.questionEvaluations.count { it.needsReview && !it.isResolved } }

                Column(modifier = Modifier.fillMaxSize()) {
                    // Summary Header Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = copy.reviewTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                            androidx.compose.foundation.layout.FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Toplam: $totalStudents", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                Text("Hazır: $fullyReadyCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                Text("İncelenecek: $pendingReviewCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                if (unresolvedProblematicCount > 0) {
                                    Text("${copy.unresolvedItemLabel}: $unresolvedProblematicCount", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("${copy.unresolvedItemLabel}: 0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = copy.reviewDescription,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(uiState.students) { studentItem ->
                            val eval = studentItem.evaluation
                            val unresolvedCount = studentItem.questionEvaluations.count { it.needsReview && !it.isResolved }
                            val hasError = eval?.status == "ERROR"

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectStudent(studentItem.paper.id) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (hasError)
                                        MaterialTheme.colorScheme.errorContainer
                                    else if (unresolvedCount > 0)
                                        MaterialTheme.colorScheme.secondaryContainer
                                    else
                                        MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = studentItem.paper.studentName ?: "Öğrenci #${studentItem.paper.studentSequenceIndex}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Okul No: ${studentItem.paper.schoolNumber ?: "—"} | Sınıf: ${studentItem.paper.classLevel ?: "—"}/${studentItem.paper.branch ?: "—"}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            val scoreText = eval?.let { "${it.totalScore} / ${it.totalMaxScore} Puan" } ?: "Değerlendirilmedi"
                                            Text(
                                                text = scoreText,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            if (eval?.isTeacherApproved == true) {
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Badge(containerColor = MaterialTheme.colorScheme.tertiary) {
                                                    Text("Onaylandı", modifier = Modifier.padding(horizontal = 4.dp), color = MaterialTheme.colorScheme.onTertiary)
                                                }
                                            }
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        if (hasError) {
                                            Badge(containerColor = MaterialTheme.colorScheme.error) {
                                                Text("HATA", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onError)
                                            }
                                        } else if (unresolvedCount > 0) {
                                            Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                                Text("$unresolvedCount İnceleme", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onSecondary)
                                            }
                                        } else {
                                            Badge(containerColor = MaterialTheme.colorScheme.tertiary) {
                                                Text("Hazır", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onTertiary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Student Detail Dialog for Review & Score Adjustment
            if (selectedStudent != null) {
                StudentReviewDetailDialog(
                    studentItem = selectedStudent,
                    questions = uiState.questions,
                    rubrics = uiState.rubrics,
                    layoutDensity = uiState.layoutDensity,
                    lineOverrides = uiState.lineOverrides,
                    listeningGuidance = uiState.listeningGuidance,
                    examType = examType,
                    onDismiss = { onSelectStudent(null) },
                    onUpdateScore = onUpdateScore,
                    onResolveWithoutScore = onResolveWithoutScore,
                    onResolveTestChoice = onResolveTestChoice,
                    onNextProblemStudent = onNextProblemStudent,
                    onRecordReviewRequest = onRecordReviewRequest,
                    onResolveReviewRequest = onResolveReviewRequest,
                    onUpdateTeacherNote = onUpdateTeacherNote
                )
            }
        }
    }
}

@Composable
fun StudentReviewDetailDialog(
    studentItem: StudentReviewItem,
    questions: List<ExamQuestionEntity>,
    rubrics: List<ExamRubricCriterionEntity>,
    layoutDensity: String = "AUTOMATIC",
    lineOverrides: Map<Int, Int> = emptyMap(),
    listeningGuidance: ListeningAnswerSheetGuidance? = null,
    examType: ExamType = ExamType.WRITTEN,
    onDismiss: () -> Unit,
    onUpdateScore: (Long, String) -> Unit,
    onResolveWithoutScore: (Long) -> Unit,
    onResolveTestChoice: (Long, String?) -> Unit,
    onNextProblemStudent: () -> Unit,
    onRecordReviewRequest: (Long, String) -> Unit,
    onResolveReviewRequest: (Long) -> Unit,
    onUpdateTeacherNote: (Long, String) -> Unit
) {
    val copy = submissionCopy(examType)
    var reviewReason by remember(studentItem.paper.id) { mutableStateOf("") }
    var teacherNote by remember(studentItem.paper.id, studentItem.evaluation?.teacherNote) {
        mutableStateOf(studentItem.evaluation?.teacherNote.orEmpty())
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.95f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = studentItem.paper.studentName ?: "Öğrenci İncelemesi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "No: ${studentItem.paper.schoolNumber ?: "—"} | Sınıf: ${studentItem.paper.classLevel ?: "—"}/${studentItem.paper.branch ?: "—"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                if (examType == ExamType.MULTIPLE_CHOICE) {
                    OutlinedButton(
                        onClick = onNextProblemStudent,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Sonraki Sorunlu Öğrenci")
                    }
                }

                if (!studentItem.evaluation?.spellingPunctuationFeedback.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Yazım/Noktalama Genel Dönütü: ${studentItem.evaluation?.spellingPunctuationFeedback}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Öğretmen Notu", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "Bu alan öğretmenin kendi kısa notudur; AI dönütünden ayrı saklanır ve öğrenci raporunda ayrı gösterilir.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = teacherNote,
                            onValueChange = { if (it.length <= 500) teacherNote = it },
                            label = { Text("Kısa öğretmen notu") },
                            supportingText = { Text("${teacherNote.length}/500") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            maxLines = 5
                        )
                        OutlinedButton(
                            onClick = { onUpdateTeacherNote(studentItem.paper.id, teacherNote) },
                            enabled = teacherNote.trim() != studentItem.evaluation?.teacherNote.orEmpty().trim(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Öğretmen Notunu Kaydet") }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Öğrenci / Veli Yeniden İnceleme", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "Değerlendirmeye ilişkin öğrenci/veli talebini ve öğretmenin yeniden inceleme sonucunu kaydeder. Resmî etik ihlal başvurusu YAZEK/okul sürecinde ayrıca yürütülür.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        studentItem.reviewRequests.take(3).forEach { request ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (request.status == "OPEN") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer
                            ) {
                                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(if (request.status == "OPEN") "Açık Talep" else "Sonuçlandırıldı", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Text(request.reason, style = MaterialTheme.typography.bodySmall)
                                    Text("İlk puan: ${request.scoreBefore ?: "—"} • Son puan: ${request.scoreAfter ?: "—"}", style = MaterialTheme.typography.labelSmall)
                                    if (request.status == "OPEN") {
                                        TextButton(onClick = { onResolveReviewRequest(request.id) }) {
                                            Text("Yeniden İncelemeyi Tamamlandı İşaretle")
                                        }
                                    }
                                }
                            }
                        }
                        OutlinedTextField(
                            value = reviewReason,
                            onValueChange = { reviewReason = it },
                            label = { Text("Talep gerekçesi") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                        OutlinedButton(
                            onClick = {
                                onRecordReviewRequest(studentItem.paper.id, reviewReason)
                                reviewReason = ""
                            },
                            enabled = reviewReason.trim().length >= 3,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Yeniden İnceleme Talebini Kaydet") }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Question Evaluations List with Cropped Answer Area Viewer
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val reviewQuestionEvaluations = if (examType == ExamType.MULTIPLE_CHOICE) {
                        studentItem.questionEvaluations.sortedWith(
                            compareBy<ExamQuestionEvaluationEntity> { !(it.needsReview && !it.isResolved) }
                                .thenBy { it.questionOrderIndex }
                        )
                    } else studentItem.questionEvaluations

                    items(reviewQuestionEvaluations) { qEval ->
                        var scoreInput by remember(qEval.id, qEval.score) { mutableStateOf(qEval.score.toString()) }
                        val matchedQuestion = questions.find { it.orderIndex == qEval.questionOrderIndex }
                        val matchedRubric = rubrics.filter { it.questionOrderIndex == qEval.questionOrderIndex }

                        // Crop coordinates calculation using ExamAnswerSheetLayoutCalculator, canonical layoutDensity, and lineOverrides
                        val cropBounds = remember(qEval, questions, rubrics, layoutDensity, lineOverrides, listeningGuidance) {
                            try {
                                val dbQuestions = questions.map { q ->
                                    ExamQuestionEntity(
                                        id = q.id,
                                        examDraftId = q.examDraftId,
                                        orderIndex = q.orderIndex,
                                        questionNumber = q.questionNumber,
                                        normalizedQuestionNumber = q.questionNumber.trim().uppercase(),
                                        questionText = q.questionText,
                                        points = q.points,
                                        createdAt = 0L,
                                        updatedAt = 0L
                                    )
                                }
                                val pageLayouts = ExamAnswerSheetLayoutCalculator.paginateQuestions(
                                    dbQuestions,
                                    rubrics,
                                    densitySetting = layoutDensity,
                                    lineOverrides = lineOverrides,
                                    listeningGuidance = listeningGuidance,
                                    examType = examType
                                )
                                ExamAnswerSheetLayoutCalculator.getQuestionCropBounds(pageLayouts, qEval.questionOrderIndex)
                            } catch (_: Exception) {
                                null
                            }
                        }

                        val cropSegments = cropBounds?.segments ?: emptyList()
                        val sortedPages = remember(studentItem.pages) { studentItem.pages.sortedBy { it.pageIndex } }
                        
                        // 0 = Cropped answer area (all segments), 1..N = full page N
                        var selectedViewMode by remember(qEval.id) { mutableIntStateOf(0) }

                        val croppedBitmaps = remember(cropSegments, sortedPages) {
                            cropSegments.mapNotNull { segment ->
                                val page = sortedPages.find { it.pageIndex == segment.pageIndex } ?: return@mapNotNull null
                                val file = File(page.imagePath)
                                if (!file.exists()) return@mapNotNull null
                                val cropped = ExamImagePrivacyProcessor.prepareQuestionPreview(
                                    imagePath = file.absolutePath,
                                    topPt = segment.topYPt,
                                    bottomPt = segment.bottomYPt
                                ) ?: return@mapNotNull null
                                Triple(segment, page, cropped)
                            }
                        }

                        val selectedFullPage = if (selectedViewMode > 0) sortedPages.find { it.pageIndex == selectedViewMode } else null
                        val fullPageBitmap = remember(selectedFullPage) {
                            selectedFullPage?.imagePath?.let { path ->
                                val f = File(path)
                                if (f.exists()) ExamImagePrivacyProcessor.prepareFullPagePreview(f.absolutePath) else null
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (qEval.needsReview && !qEval.isResolved)
                                    MaterialTheme.colorScheme.secondaryContainer
                                else
                                    MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${copy.itemLabel} ${qEval.questionOrderIndex} (${qEval.questionNumber}) — Max: ${qEval.maxScore} Puan",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (qEval.needsReview && !qEval.isResolved) {
                                        Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                            Text("İnceleme Gerekli", modifier = Modifier.padding(horizontal = 4.dp), color = MaterialTheme.colorScheme.onSecondary)
                                        }
                                    } else {
                                        Badge(containerColor = MaterialTheme.colorScheme.tertiary) {
                                            Text("Çözüldü", modifier = Modifier.padding(horizontal = 4.dp), color = MaterialTheme.colorScheme.onTertiary)
                                        }
                                    }
                                }

                                if (matchedQuestion != null && matchedQuestion.questionText.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${copy.itemLabel} Metni: ${matchedQuestion.questionText}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (matchedRubric.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    var expandedRubric by remember { mutableStateOf(false) }
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().clickable { expandedRubric = !expandedRubric },
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (examType == ExamType.MULTIPLE_CHOICE) "Cevap Anahtarı (Genişletmek için tıklayın)" else "Rubrik Kriterleri (Genişletmek için tıklayın)",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (expandedRubric) "Gizle" else "Göster",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        if (expandedRubric) {
                                            matchedRubric.forEach { rubric ->
                                                Card(
                                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                                ) {
                                                    Column(modifier = Modifier.padding(8.dp)) {
                                                        Text("${rubric.title} (${rubric.maxPoints}p)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                                        Text(rubric.description, style = MaterialTheme.typography.bodySmall)
                                                        Text("Beklenen: ${rubric.expectedAnswer}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                                        if (rubric.partialCreditGuidance.isNotBlank()) {
                                                            Text("Kısmi: ${rubric.partialCreditGuidance}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            Text(
                                                text = matchedRubric.joinToString(" | ") { "${it.title} (${it.maxPoints}p)" },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                maxLines = 1,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // Question Answer Area Image Preview
                                if (sortedPages.isNotEmpty()) {
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (selectedViewMode == 0) "${copy.answerAreaLabel} (${croppedBitmaps.size} Parça)" else "${copy.fullDocumentLabel} — Sayfa $selectedViewMode / ${sortedPages.size}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                FilterChip(
                                                    selected = selectedViewMode == 0,
                                                    onClick = { selectedViewMode = 0 },
                                                    label = {
                                                        Text(when (examType) {
                                                            ExamType.HOMEWORK -> "Teslim/Yanıt"
                                                            ExamType.MULTIPLE_CHOICE -> "İşaretleme"
                                                            else -> "Cevap"
                                                        })
                                                    },
                                                    modifier = Modifier.height(32.dp)
                                                )
                                                sortedPages.forEach { p ->
                                                    FilterChip(
                                                        selected = selectedViewMode == p.pageIndex,
                                                        onClick = { selectedViewMode = p.pageIndex },
                                                        label = { Text("S${p.pageIndex}") },
                                                        modifier = Modifier.height(32.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        if (selectedViewMode == 0) {
                                            if (croppedBitmaps.isNotEmpty()) {
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    croppedBitmaps.forEach { (segment, _, bitmap) ->
                                                        Column {
                                                            if (croppedBitmaps.size > 1) {
                                                                Text(
                                                                    text = "Sayfa ${segment.pageIndex} — ${if (examType == ExamType.HOMEWORK) {
                                                                        if (segment.isContinuation) "Görev/Madde ${qEval.questionOrderIndex} (Devam)" else "Görev/Madde ${qEval.questionOrderIndex}"
                                                                    } else {
                                                                        if (segment.isContinuation) "Cevap ${qEval.questionOrderIndex} (Devam)" else "Cevap ${qEval.questionOrderIndex}"
                                                                    }}",
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = MaterialTheme.colorScheme.primary,
                                                                    fontWeight = FontWeight.Bold,
                                                                    modifier = Modifier.padding(bottom = 2.dp)
                                                                )
                                                            }
                                                            Card(
                                                                modifier = Modifier
                                                                    .fillMaxWidth()
                                                                    .heightIn(max = 180.dp)
                                                            ) {
                                                                Image(
                                                                    bitmap = bitmap.asImageBitmap(),
                                                                    contentDescription = "${copy.answerAreaLabel} görseli",
                                                                    modifier = Modifier.fillMaxSize(),
                                                                    contentScale = ContentScale.Fit
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else if (fullPageBitmap != null) {
                                            Card(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(200.dp)
                                            ) {
                                                Image(
                                                    bitmap = fullPageBitmap.asImageBitmap(),
                                                    contentDescription = "Tüm Sayfa Görseli",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Fit
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                }

                                // AI Evaluation details
                                Text(
                                    text = if (qEval.answerType == "MANUAL") {
                                        "AI kullanılmadan manuel öğretmen değerlendirmesi • Azami puan: ${qEval.maxScore}"
                                    } else {
                                        "${if (examType == ExamType.MULTIPLE_CHOICE) "Sistem İlk Puanı" else "AI İlk Puanı"}: ${qEval.originalScore} Puan | ${when (examType) { ExamType.HOMEWORK -> "Teslim/Yanıt Türü"; ExamType.MULTIPLE_CHOICE -> "İşaretleme Durumu"; else -> "Cevap Türü" }}: ${qEval.answerType} | Okuma Güveni: %${(qEval.readingConfidence * 100).toInt()} | ${if (examType == ExamType.MULTIPLE_CHOICE) "Deterministik Puanlama: Aktif" else "Değerlendirme Güveni: %${(qEval.evaluationConfidence * 100).toInt()}"}"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = when (examType) {
                                        ExamType.HOMEWORK -> "Okunan/Algılanan Teslim İçeriği: \"${qEval.readAnswerText.ifBlank { "İçerik yok" }}\""
                                        ExamType.MULTIPLE_CHOICE -> "İşaretlenen Seçenek: ${qEval.readAnswerText.ifBlank { "Belirlenemedi / boş" }}"
                                        else -> "Okunan Cevap: \"${qEval.readAnswerText.ifBlank { "Metin yok" }}\""
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (examType != ExamType.MULTIPLE_CHOICE && !qEval.interpretedMeaning.isNullOrBlank()) {
                                    Text(
                                        text = "AI'ın cevaptan çıkardığı anlam: ${qEval.interpretedMeaning}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (examType != ExamType.MULTIPLE_CHOICE && !qEval.gradingEvidence.isNullOrBlank()) {
                                    Text(
                                        text = "Puanlama kanıtı / rubrik dayanağı: ${qEval.gradingEvidence}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (!qEval.feedback.isNullOrBlank()) {
                                    Text(
                                        text = if (examType == ExamType.MULTIPLE_CHOICE) "Sistem Sonucu: ${qEval.feedback}" else "AI Dönüt: ${qEval.feedback}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (examType == ExamType.READINESS) {
                                    Text(
                                        text = "Bu sorudaki nihai öğretmen puanı, öğrencinin ve sınıfın ilgili ön koşul bilgi/beceri görünümünü yeniden hesaplar.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (examType == ExamType.READINESS && qEval.isTeacherModified) {
                                    Text(
                                        text = "Öğretmen düzeltmesi tanılayıcı sonuca yansıtılacak; rapor öğrenciyi kalıcı bir başarı etiketiyle sınıflandırmayacaktır.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (!qEval.reviewReason.isNullOrBlank()) {
                                    Text(
                                        text = "İnceleme Nedeni: ${qEval.reviewReason}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.secondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                if (examType == ExamType.MULTIPLE_CHOICE) {
                                    val optionLabels = remember(matchedQuestion?.questionText) {
                                        com.example.core.model.MultipleChoiceOptionPolicy.detectLabels(matchedQuestion?.questionText.orEmpty())
                                    }
                                    Text(
                                        text = "Hızlı Düzeltme — öğrencinin gerçek işaretini seçin",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                                    androidx.compose.foundation.layout.FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        optionLabels.forEach { label ->
                                            FilterChip(
                                                selected = qEval.readAnswerText.trim().equals(label, ignoreCase = true) && qEval.isResolved,
                                                onClick = { onResolveTestChoice(qEval.id, label) },
                                                label = { Text(label) }
                                            )
                                        }
                                        FilterChip(
                                            selected = qEval.answerType == "UNANSWERED" && qEval.isResolved,
                                            onClick = { onResolveTestChoice(qEval.id, null) },
                                            label = { Text("Boş") }
                                        )
                                    }
                                    Text(
                                        text = "Seçim kaydedildiğinde BaykuşNot cevap anahtarıyla yeniden karşılaştırır; puan otomatik olarak 0 veya ${qEval.maxScore} olur.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = scoreInput,
                                            onValueChange = { scoreInput = it },
                                            label = { Text("Puan (0 — ${qEval.maxScore})") },
                                            singleLine = true,
                                            modifier = Modifier
                                                .width(110.dp)
                                                .height(56.dp)
                                        )

                                        @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                                        androidx.compose.foundation.layout.FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.padding(start = 8.dp)
                                        ) {
                                            if (qEval.needsReview && !qEval.isResolved) {
                                                OutlinedButton(
                                                    onClick = { onResolveWithoutScore(qEval.id) },
                                                    modifier = Modifier.height(40.dp)
                                                ) {
                                                    Text("Olduğu Gibi Onayla")
                                                }
                                            }
                                            Button(
                                                onClick = { onUpdateScore(qEval.id, scoreInput) },
                                                modifier = Modifier.height(40.dp)
                                            ) {
                                                Text("Puanı Kaydet")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
