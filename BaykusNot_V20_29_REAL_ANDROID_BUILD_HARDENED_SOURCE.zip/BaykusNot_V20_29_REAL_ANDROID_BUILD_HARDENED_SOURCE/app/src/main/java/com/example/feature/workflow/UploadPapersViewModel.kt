package com.example.feature.workflow

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamAnswerSheetRepository
import com.example.core.data.ExamPaperUploadRepository
import com.example.core.database.ExamPaperPageEntity
import com.example.core.database.ExamStudentPaperEntity
import com.example.core.model.ExamType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File

class UploadPapersViewModel(
    private val examPaperUploadRepository: ExamPaperUploadRepository,
    private val examAnswerSheetRepository: ExamAnswerSheetRepository,
    private val examDraftId: Long,
    private val examType: ExamType = ExamType.WRITTEN
) : ViewModel() {

    private val _uiState = MutableStateFlow(UploadPapersUiState())
    val uiState: StateFlow<UploadPapersUiState> = _uiState.asStateFlow()

    private fun readinessOr(defaultText: String, readinessText: String): String =
        if (examType == ExamType.READINESS) readinessText else defaultText

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            try {
                val recovery = examPaperUploadRepository.recoverInterruptedImport(examDraftId, examType)
                if (recovery.isFailure) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Önceki yarım kâğıt aktarımı güvenli biçimde toparlanamadı: ${recovery.exceptionOrNull()?.message ?: "Bilinmeyen hata"}"
                    )
                    return@launch
                }
                val config = examAnswerSheetRepository.getConfig(examDraftId)
                val isHomework = examType == ExamType.HOMEWORK
                val expectedCount = config?.studentCount ?: 20
                val actualTotalPages = if (isHomework) 1 else examPaperUploadRepository.getActualTotalPages(examDraftId)
                _uiState.value = _uiState.value.copy(
                    isHomework = isHomework,
                    hasFixedExpectedStudentCount = !isHomework,
                    expectedStudentCount = expectedCount,
                    studentAssignmentCapacity = if (isHomework) 500 else expectedCount,
                    configuredTotalPages = actualTotalPages
                )
                combine(
                    examPaperUploadRepository.getStudentPapers(examDraftId),
                    examPaperUploadRepository.getPages(examDraftId)
                ) { papers, pages -> Pair(papers, pages) }
                    .collect { (papers, pages) ->
                        _uiState.value = _uiState.value.copy(isLoading = false, studentPapers = papers, pages = pages)
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isProcessing = false,
                    processingMessage = null,
                    errorMessage = "Öğrenci kâğıdı verileri yüklenemedi: ${e.message ?: "Bilinmeyen hata"}"
                )
            }
        }
    }

    fun setFilter(filter: UploadPapersFilter) {
        _uiState.value = _uiState.value.copy(selectedFilter = filter)
    }

    fun processBatchPdf(context: Context, pdfUri: Uri) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(
            isProcessing = true,
            processingMessage = if (examType == ExamType.HOMEWORK)
                "Ödev PDF'i işleniyor; sayfalar öğrenci eşleştirmesi için hazırlanıyor..."
            else
                readinessOr(
                    defaultText = "Toplu PDF işleniyor, sayfalar taranıyor...",
                    readinessText = "Hazırbulunuşluk cevap kâğıtları işleniyor; sayfalar ve karekodlar doğrulanıyor..."
                )
        )

        viewModelScope.launch {
            try {
                val result = examPaperUploadRepository.processBatchPdf(context, examDraftId, pdfUri, examType)
                result.fold(
                    onSuccess = { count ->
                        _uiState.value = _uiState.value.copy(
                            successMessage = if (examType == ExamType.HOMEWORK)
                                "Ödev PDF'i işlendi ($count sayfa eklendi). Sayfaları ilgili öğrencilere bağlayın."
                            else
                                readinessOr(
                                    defaultText = "Toplu PDF başarıyla işlendi ($count sayfa eklendi).",
                                    readinessText = "Hazırbulunuşluk cevap kâğıtları işlendi ($count sayfa eklendi)."
                                )
                        )
                    },
                    onFailure = { error ->
                        _uiState.value = _uiState.value.copy(errorMessage = "PDF işleme hatası: ${error.message}")
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "PDF işleme hatası: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun processImages(context: Context, imageUris: List<Uri>) {
        if (_uiState.value.isProcessing) return
        if (imageUris.isEmpty()) return
        _uiState.value = _uiState.value.copy(
            isProcessing = true,
            processingMessage = if (examType == ExamType.HOMEWORK)
                "Ödev fotoğrafları okunabilirlik için kontrol ediliyor..."
            else
                readinessOr(
                    defaultText = "Fotoğraflar taranıyor ve karekodlar doğrulanıyor...",
                    readinessText = "Hazırbulunuşluk kâğıdı fotoğrafları taranıyor ve karekodlar doğrulanıyor..."
                )
        )

        viewModelScope.launch {
            try {
                val result = examPaperUploadRepository.processImageFiles(context, examDraftId, imageUris, examType)
                result.fold(
                    onSuccess = { count ->
                        _uiState.value = _uiState.value.copy(
                            successMessage = if (examType == ExamType.HOMEWORK)
                                "$count ödev sayfası eklendi. Sayfaları ilgili öğrencilere bağlayın."
                            else
                                readinessOr(
                                    defaultText = "$count sayfa fotoğrafı eklendi ve doğrulandı.",
                                    readinessText = "$count hazırbulunuşluk cevap kâğıdı sayfası eklendi ve doğrulandı."
                                )
                        )
                    },
                    onFailure = { error ->
                        _uiState.value = _uiState.value.copy(errorMessage = "Fotoğraf işleme hatası: ${error.message}")
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Fotoğraf işleme hatası: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun processCameraCapture(imageFile: File) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(
            isProcessing = true,
            processingMessage = if (examType == ExamType.HOMEWORK)
                "Ödev sayfası okunabilirlik için kontrol ediliyor..."
            else
                readinessOr(
                    defaultText = "Kamera çekimi taranıyor...",
                    readinessText = "Hazırbulunuşluk cevap kâğıdı kamera çekimi taranıyor..."
                )
        )

        viewModelScope.launch {
            try {
                val result = examPaperUploadRepository.processCameraImageFile(examDraftId, imageFile, examType)
                result.fold(
                    onSuccess = {
                        _uiState.value = _uiState.value.copy(
                            successMessage = if (examType == ExamType.HOMEWORK)
                                "Ödev sayfası eklendi. İlgili öğrenci teslimine bağlayın."
                            else
                                readinessOr(
                                    defaultText = "Çekilen sayfa başarıyla eklendi.",
                                    readinessText = "Hazırbulunuşluk cevap kâğıdı sayfası başarıyla eklendi."
                                )
                        )
                    },
                    onFailure = { error ->
                        _uiState.value = _uiState.value.copy(errorMessage = "Kamera çekimi okunamadı: ${error.message}")
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Kamera çekimi okunamadı: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun openPagePreview(page: ExamPaperPageEntity) {
        _uiState.value = _uiState.value.copy(previewingPage = page)
    }

    fun closePagePreview() {
        _uiState.value = _uiState.value.copy(previewingPage = null)
    }

    fun deletePage(pageId: Long) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(isProcessing = true, processingMessage = "Sayfa siliniyor...", errorMessage = null)
        viewModelScope.launch {
            try {
                examPaperUploadRepository.deletePage(pageId, examDraftId, examType)
                if (_uiState.value.previewingPage?.id == pageId) _uiState.value = _uiState.value.copy(previewingPage = null)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Sayfa silinemedi: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun openEditPaper(paper: ExamStudentPaperEntity) {
        _uiState.value = _uiState.value.copy(editingPaper = paper)
    }

    fun closeEditPaper() {
        _uiState.value = _uiState.value.copy(editingPaper = null)
    }

    fun savePaperDetails(
        paperId: Long,
        studentName: String?,
        classLevel: String?,
        branch: String?,
        schoolNumber: String?
    ) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(isProcessing = true, processingMessage = "Öğrenci bilgileri kaydediliyor...", errorMessage = null)
        viewModelScope.launch {
            try {
                examPaperUploadRepository.updateStudentPaperDetails(paperId, studentName, classLevel, branch, schoolNumber, examType)
                _uiState.value = _uiState.value.copy(editingPaper = null)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci bilgileri kaydedilemedi: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun openReassignPage(page: ExamPaperPageEntity) {
        _uiState.value = _uiState.value.copy(reassigningPage = page)
    }

    fun closeReassignPage() {
        _uiState.value = _uiState.value.copy(reassigningPage = null)
    }

    fun reassignPageToPaper(pageId: Long, targetStudentSeq: Int, targetPageIndex: Int) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(isProcessing = true, processingMessage = "Sayfa eşleştirmesi kaydediliyor...", errorMessage = null)
        viewModelScope.launch {
            try {
                examPaperUploadRepository.reassignPage(pageId, targetStudentSeq, targetPageIndex, examDraftId, examType)
                val assignedPaper = if (examType == ExamType.HOMEWORK) {
                    examPaperUploadRepository.getStudentPapersOnce(examDraftId).firstOrNull { it.studentSequenceIndex == targetStudentSeq }
                } else null
                val needsIdentityConfirmation = assignedPaper != null &&
                    !com.example.core.data.validateStudentIdentity(assignedPaper.classLevel, assignedPaper.branch, assignedPaper.schoolNumber).isValid
                _uiState.value = _uiState.value.copy(
                    reassigningPage = null,
                    editingPaper = if (needsIdentityConfirmation) assignedPaper else _uiState.value.editingPaper,
                    successMessage = if (needsIdentityConfirmation) "Ödev sayfası öğrenciye bağlandı. Şimdi öğrenci kimlik bilgilerini doğrulayın." else _uiState.value.successMessage
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Sayfa yeniden eşleştirilemedi: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun deleteStudentPaperSet(paperId: Long) {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(isProcessing = true, processingMessage = "Öğrenci kâğıt seti siliniyor...", errorMessage = null)
        viewModelScope.launch {
            try {
                examPaperUploadRepository.deleteStudentPaper(paperId, examDraftId, examType)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Öğrenci kâğıt seti silinemedi: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun clearAll() {
        if (_uiState.value.isProcessing) return
        _uiState.value = _uiState.value.copy(isProcessing = true, processingMessage = "Yüklenen sayfalar temizleniyor...", errorMessage = null)
        viewModelScope.launch {
            try {
                examPaperUploadRepository.clearAllPapers(examDraftId)
                _uiState.value = _uiState.value.copy(successMessage = "Bütün yüklenen sayfalar temizlendi.")
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = "Yüklenen sayfalar temizlenemedi: ${e.message ?: "Bilinmeyen hata"}")
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false, processingMessage = null)
            }
        }
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }

    class Factory(
        private val examPaperUploadRepository: ExamPaperUploadRepository,
        private val examAnswerSheetRepository: ExamAnswerSheetRepository,
        private val examDraftId: Long,
        private val examType: ExamType = ExamType.WRITTEN
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(UploadPapersViewModel::class.java)) {
                return UploadPapersViewModel(
                    examPaperUploadRepository,
                    examAnswerSheetRepository,
                    examDraftId,
                    examType
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
