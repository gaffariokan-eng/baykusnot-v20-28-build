package com.example.core.model

enum class RubricAdherenceLevel(
    val displayName: String,
    val description: String
) {
    STRICT(
        displayName = "Katı",
        description =
            "Değerlendirme rubrikteki ölçütlere sıkı biçimde bağlı yapılır."
    ),

    BALANCED(
        displayName = "Dengeli",
        description =
            "Rubrik temel alınır; anlamca eşdeğer doğru cevaplar kabul edilir."
    ),

    FLEXIBLE(
        displayName = "Esnek",
        description =
            "Rubrik yol gösterir; doğru alternatif açıklamalar daha geniş değerlendirilir."
    )
}
