package com.example.feature.testexam

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun TestOpticalReadingScreen(
    viewModel: TestOpticalReadingViewModel,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Yerel Optik Okuma", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Bu işlem yapay zekâ, API anahtarı veya internet kullanmaz. BaykuşNot cevap formundaki baloncukları cihaz üzerinde okur ve kilitli cevap anahtarıyla karşılaştırır.")
        }
        if (state.isLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        state.message?.let { msg ->
            item {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    tonalElevation = 1.dp
                ) {
                    Text(msg, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
        }
        state.progressText?.let { text ->
            item {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text(text)
            }
        }
        item {
            val completed = state.items.count { it.status == "COMPLETED" }
            val review = state.items.count { it.status == "NEEDS_REVIEW" }
            val errors = state.items.count { it.status == "ERROR" }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Optik Okuma Özeti", fontWeight = FontWeight.Bold)
                    Text("Toplam ${state.items.size} form • Okundu $completed • İnceleme $review • Hata $errors")
                    if (review > 0) {
                        Text("Belirsiz formlar öğretmen incelemesinde üst sıraya alınır; yalnız sorunlu işaretleri düzeltmeniz yeterlidir.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = viewModel::startLocalReading,
                enabled = !state.isReading && state.items.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.isReading) "Optik Okuma Sürüyor" else "Tüm Formları Optik Oku")
            }
        }
        val orderedItems = state.items.sortedWith(
            compareBy<TestOpticalPaperItem> {
                when (it.status) {
                    "ERROR" -> 0
                    "NEEDS_REVIEW" -> 1
                    "WAITING" -> 2
                    else -> 3
                }
            }.thenBy { it.studentSequence }
        )
        items(orderedItems, key = { it.paperId }) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.studentLabel, fontWeight = FontWeight.SemiBold)
                    val statusText = when (item.status) {
                        "COMPLETED" -> "Okundu"
                        "NEEDS_REVIEW" -> "Öğretmen kontrolü gerekli"
                        "ERROR" -> "Hata"
                        else -> "Bekliyor"
                    }
                    Text(statusText)
                    item.scoreText?.let { Text("Puan: $it") }
                    item.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        item {
            Button(
                onClick = onContinue,
                enabled = state.canContinue && !state.isReading,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Öğretmen İncelemesine Geç") }
            Spacer(Modifier.height(24.dp))
        }
    }
}
