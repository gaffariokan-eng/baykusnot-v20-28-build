package com.example.core.network

import com.example.core.model.ExamType

sealed interface ExamExtractionInput {

    data class Text(
        val text: String
    ) : ExamExtractionInput

    sealed interface WordPart {
        data class TextPart(val text: String) : WordPart
        data class ImagePart(val image: ExamExtractionImage) : WordPart
    }

    data class WordExtracted(
        val parts: List<WordPart>
    ) : ExamExtractionInput {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as WordExtracted
            return parts == other.parts
        }
        override fun hashCode(): Int {
            return parts.hashCode()
        }
    }

    data class Pdf(
        val bytes: ByteArray
    ) : ExamExtractionInput {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as Pdf
            return bytes.contentEquals(other.bytes)
        }

        override fun hashCode(): Int {
            return bytes.contentHashCode()
        }
    }

    data class Images(
        val images: List<ExamExtractionImage>
    ) : ExamExtractionInput
}

data class ExamExtractionImage(
    val bytes: ByteArray,
    val mimeType: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as ExamExtractionImage
        if (!bytes.contentEquals(other.bytes)) return false
        if (mimeType != other.mimeType) return false
        return true
    }

    override fun hashCode(): Int {
        var result = bytes.contentHashCode()
        result = 31 * result + mimeType.hashCode()
        return result
    }
}

data class ExtractedExamQuestion(
    val questionNumber: String,
    val questionText: String,
    val points: Int?
)

sealed interface ExamQuestionExtractionResult {
    data class Complete(
        val questions: List<ExtractedExamQuestion>
    ) : ExamQuestionExtractionResult

    data class IncompleteExtraction(
        val questions: List<ExtractedExamQuestion>
    ) : ExamQuestionExtractionResult

    data object MissingApiKey : ExamQuestionExtractionResult
    data object InvalidInput : ExamQuestionExtractionResult
    data object NetworkFailure : ExamQuestionExtractionResult
    data object Unauthorized : ExamQuestionExtractionResult
    data object RateLimited : ExamQuestionExtractionResult
    data object ServiceUnavailable : ExamQuestionExtractionResult
    data object MalformedResponse : ExamQuestionExtractionResult
    data object NoQuestionsFound : ExamQuestionExtractionResult
    data object UnexpectedFailure : ExamQuestionExtractionResult
}

interface ExamQuestionExtractor {
    suspend fun extract(
        input: ExamExtractionInput
    ): ExamQuestionExtractionResult

    /**
     * Type-aware extraction entry point. Existing test fakes and non-type-aware
     * implementations may keep implementing the one-argument method; HOMEWORK
     * capable implementations override this overload.
     */
    suspend fun extract(
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamQuestionExtractionResult = extract(input)

    /** Audited authoring entry point. Implementations should bind usage to this exam when supported. */
    suspend fun extractForExam(
        examDraftId: Long,
        input: ExamExtractionInput,
        examType: ExamType
    ): ExamQuestionExtractionResult = extract(input, examType)
}
