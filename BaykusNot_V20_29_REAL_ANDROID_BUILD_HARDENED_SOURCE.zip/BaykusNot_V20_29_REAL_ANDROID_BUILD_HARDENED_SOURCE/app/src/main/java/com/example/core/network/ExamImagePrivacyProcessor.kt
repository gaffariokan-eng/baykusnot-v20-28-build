package com.example.core.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.core.security.StudentImageCrypto
import com.example.core.security.StudentImageIntegrityException
import com.example.core.security.StudentImageKeyRecoveryRequiredException
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import com.example.core.data.AnswerSheetRegistrationGeometry
import com.example.core.data.ExamAnswerSheetLayoutCalculator
import com.example.core.model.ExamType
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * On-device privacy and geometry gate for student-page images.
 *
 * New BaykuşNot answer sheets contain four fiducials. They are detected locally and used
 * to rectify phone photos to canonical A4 coordinates before identity removal or a targeted
 * second read. Gemini never receives the original full photo.
 *
 * Legacy pages without fiducials are handled conservatively: identity-bearing header bands
 * are removed, but question-coordinate cropping is deliberately disabled because a skewed
 * legacy photo must never be treated as geometrically trustworthy.
 */
open class ImagePreparationException(message: String, cause: Throwable? = null) : IllegalStateException(message, cause)
class PrivacyAlignmentException(message: String) : ImagePreparationException(message)

object ExamImagePrivacyProcessor {
    private const val PAGE_WIDTH_PT = AnswerSheetRegistrationGeometry.pageWidthPt
    private const val PAGE_HEIGHT_PT = AnswerSheetRegistrationGeometry.pageHeightPt
    private const val SAFE_LEFT_PT = 28f
    private const val SAFE_RIGHT_PT = 567f
    private const val CROP_PADDING_PT = 5f
    private const val MAX_RECTIFIED_WIDTH_PX = 2400

    data class PreparedImage(
        val pageIndex: Int,
        val base64Jpeg: String,
        val targetedQuestionCrop: Boolean,
        val geometryAligned: Boolean
    )

    private data class MarkerCandidate(val x: Float, val y: Float, val score: Double)
    private data class RectifiedPage(val bitmap: Bitmap, val confidence: Double)

    private fun requiresStrictAlignment(page: com.example.core.database.ExamPaperPageEntity): Boolean {
        val raw = page.qrRawContent.orEmpty()
        // Only a positively identified legacy BaykuşNot QR may use the conservative legacy crop.
        // Unknown/unreadable QR pages fail closed because they could be a modern form whose identity
        // header cannot be proven removed without fiducial rectification.
        if (raw.isBlank()) return true
        val version = Regex("(?:^|\\|)V:(\\d+)(?:\\||$)").find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()
        return version != null && version >= 3
    }

    private fun alignmentFailure(pageIndex: Int): PrivacyAlignmentException =
        PrivacyAlignmentException("Sayfa $pageIndex güvenli biçimde hizalanamadı. Öğrenci kimliği dış yapay zekâya gönderilmemesi için bu kâğıt değerlendirmeye gönderilmedi. Lütfen sayfayı düz, tam kadraj ve dört köşe işareti görünür şekilde yeniden çekin.")

    /** Same canonical geometry used by AI; safe for teacher preview. */
    fun prepareFullPagePreview(imagePath: String): Bitmap? {
        val source = decodePortrait(imagePath) ?: return null
        val aligned = rectifyByRegistrationMarks(source)
        if (aligned != null) {
            if (source !== aligned.bitmap) source.recycleSafely()
            return aligned.bitmap
        }
        return source
    }

    /** Returns null instead of showing a misleading question crop when canonical alignment fails. */
    fun prepareQuestionPreview(imagePath: String, topPt: Float, bottomPt: Float): Bitmap? {
        val source = decodePortrait(imagePath) ?: return null
        try {
            val aligned = rectifyByRegistrationMarks(source) ?: return null
            try {
                return cropByPoints(
                    aligned.bitmap,
                    SAFE_LEFT_PT,
                    topPt - CROP_PADDING_PT,
                    SAFE_RIGHT_PT,
                    bottomPt + CROP_PADDING_PT
                )
            } finally {
                aligned.bitmap.recycleSafely()
            }
        } finally {
            source.recycleSafely()
        }
    }

    fun prepare(
        input: ExamStudentEvaluationInput,
        targetQuestionOrderIndex: Int? = input.targetQuestionOrderIndex,
        jpegQuality: Int = 94
    ): List<PreparedImage> {
        val sortedPages = input.studentPages.sortedBy { it.pageIndex }
        if (sortedPages.isEmpty()) return emptyList()

        // Homework can be an arbitrary external document. Every declared page must survive
        // decrypt/decode + privacy masking. A single missing page blocks evaluation.
        if (input.examType == ExamType.HOMEWORK) {
            val prepared = mutableListOf<PreparedImage>()
            for (page in sortedPages) {
                val source = decodePortraitStrict(page.imagePath, page.pageIndex)
                try {
                    val masked = applyPrivacyMasks(source, input.privacyMasksByPageId[page.id].orEmpty())
                    try {
                        val privacyCrop = cropByRatios(masked, 0.035f, 0.17f, 0.965f, 0.985f)
                        try {
                            prepared += PreparedImage(
                                pageIndex = page.pageIndex,
                                base64Jpeg = encode(privacyCrop, jpegQuality),
                                targetedQuestionCrop = false,
                                geometryAligned = false
                            )
                        } finally {
                            if (privacyCrop !== masked) privacyCrop.recycleSafely()
                        }
                    } finally {
                        if (masked !== source) masked.recycleSafely()
                    }
                } finally {
                    source.recycleSafely()
                }
            }
            verifyFullPageCoverage(sortedPages.map { it.pageIndex }, prepared)
            return prepared
        }

        val layoutsByPage = input.pageLayouts.associateBy { it.pageIndex }
        val byPage = sortedPages.associateBy { it.pageIndex }

        // Targeted second read: every segment needed for that locked question must exist and decode.
        if (targetQuestionOrderIndex != null && input.pageLayouts.isNotEmpty()) {
            val bounds = ExamAnswerSheetLayoutCalculator.getQuestionCropBounds(
                input.pageLayouts,
                targetQuestionOrderIndex
            )
            if (bounds != null) {
                val targeted = mutableListOf<PreparedImage>()
                var everyNeededPageAligned = true
                for (segment in bounds.segments) {
                    val page = byPage[segment.pageIndex]
                        ?: throw ImagePreparationException("Hedef sorunun ${segment.pageIndex}. sayfası bulunamadı; ikinci değerlendirme yapılmadı.")
                    val source = decodePortraitStrict(page.imagePath, page.pageIndex)
                    try {
                        val aligned = rectifyByRegistrationMarks(source)
                        if (aligned == null) {
                            if (requiresStrictAlignment(page)) throw alignmentFailure(page.pageIndex)
                            everyNeededPageAligned = false
                            continue
                        }
                        try {
                            val crop = cropByPoints(
                                source = aligned.bitmap,
                                topPt = segment.topYPt - CROP_PADDING_PT,
                                bottomPt = segment.bottomYPt + CROP_PADDING_PT,
                                leftPt = SAFE_LEFT_PT,
                                rightPt = SAFE_RIGHT_PT
                            )
                            try {
                                targeted += PreparedImage(
                                    pageIndex = segment.pageIndex,
                                    base64Jpeg = encode(crop, jpegQuality),
                                    targetedQuestionCrop = true,
                                    geometryAligned = true
                                )
                            } finally {
                                if (crop !== aligned.bitmap) crop.recycleSafely()
                            }
                        } finally {
                            aligned.bitmap.recycleSafely()
                        }
                    } finally {
                        source.recycleSafely()
                    }
                }
                if (targeted.isNotEmpty() && everyNeededPageAligned && targeted.size == bounds.segments.size) {
                    return targeted
                }
                // Alignment fallback is permitted; decode/page-loss fallback is not.
            }
        }

        if (input.pageLayouts.isNotEmpty()) {
            val prepared = mutableListOf<PreparedImage>()
            for (page in sortedPages) {
                val source = decodePortraitStrict(page.imagePath, page.pageIndex)
                try {
                    val layout = layoutsByPage[page.pageIndex]
                    if (layout == null) {
                        if (requiresStrictAlignment(page) || !input.allowLegacyPrivacyCrop) throw alignmentFailure(page.pageIndex)
                        prepared += legacyPrivacyCrop(source, page.pageIndex, jpegQuality)
                        continue
                    }
                    val aligned = rectifyByRegistrationMarks(source)
                    if (aligned != null) {
                        try {
                            val top = layout.questions.minOfOrNull { it.topYPt }
                                ?: throw ImagePreparationException("Sayfa ${page.pageIndex} için soru yerleşimi boş; değerlendirme yapılmadı.")
                            val bottom = layout.questions.maxOfOrNull { it.topYPt + it.heightPt }
                                ?: throw ImagePreparationException("Sayfa ${page.pageIndex} için soru yerleşimi boş; değerlendirme yapılmadı.")
                            val crop = cropByPoints(
                                source = aligned.bitmap,
                                topPt = top - CROP_PADDING_PT,
                                bottomPt = bottom + CROP_PADDING_PT,
                                leftPt = SAFE_LEFT_PT,
                                rightPt = SAFE_RIGHT_PT
                            )
                            try {
                                prepared += PreparedImage(
                                    pageIndex = page.pageIndex,
                                    base64Jpeg = encode(crop, jpegQuality),
                                    targetedQuestionCrop = false,
                                    geometryAligned = true
                                )
                            } finally {
                                if (crop !== aligned.bitmap) crop.recycleSafely()
                            }
                        } finally {
                            aligned.bitmap.recycleSafely()
                        }
                    } else {
                        if (requiresStrictAlignment(page) || !input.allowLegacyPrivacyCrop) throw alignmentFailure(page.pageIndex)
                        prepared += legacyPrivacyCrop(source, page.pageIndex, jpegQuality)
                    }
                } finally {
                    source.recycleSafely()
                }
            }
            verifyFullPageCoverage(sortedPages.map { it.pageIndex }, prepared)
            return prepared
        }

        // Last-resort legacy privacy fallback: every declared page still must be readable.
        val prepared = mutableListOf<PreparedImage>()
        for (page in sortedPages) {
            if (requiresStrictAlignment(page) || !input.allowLegacyPrivacyCrop) throw alignmentFailure(page.pageIndex)
            val source = decodePortraitStrict(page.imagePath, page.pageIndex)
            try {
                prepared += legacyPrivacyCrop(source, page.pageIndex, jpegQuality)
            } finally {
                source.recycleSafely()
            }
        }
        verifyFullPageCoverage(sortedPages.map { it.pageIndex }, prepared)
        return prepared
    }

    private fun verifyFullPageCoverage(expected: List<Int>, prepared: List<PreparedImage>) {
        val actual = prepared.map { it.pageIndex }
        if (actual.size != expected.size || actual.sorted() != expected.sorted()) {
            val missing = expected.filterNot { actual.contains(it) }
            throw ImagePreparationException(
                "Öğrenci kâğıdının tüm sayfaları güvenli biçimde hazırlanamadı" +
                    (if (missing.isNotEmpty()) ": eksik sayfa ${missing.joinToString()}" else "") +
                    ". Bu öğrenci için AI değerlendirmesi yapılmadı."
            )
        }
    }

    /** Local preview of the exact conservative legacy crop that would be sent to AI. */
    fun prepareLegacyPrivacyPreview(imagePath: String, pageIndex: Int): Bitmap? {
        val source = decodePortrait(imagePath) ?: return null
        return try {
            val topRatio = if (pageIndex <= 1) 0.29f else 0.205f
            val crop = cropByRatios(source, 0.045f, topRatio, 0.955f, 0.975f)
            if (crop === source) source.copy(source.config ?: Bitmap.Config.ARGB_8888, false) else crop
        } finally {
            source.recycleSafely()
        }
    }

    private fun applyPrivacyMasks(source: Bitmap, masks: List<com.example.core.security.PrivacyMaskRect>): Bitmap {
        if (masks.isEmpty()) return source
        val output = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val paint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        masks.forEach { mask ->
            val m = mask.normalized()
            canvas.drawRect(
                m.left * output.width,
                m.top * output.height,
                m.right * output.width,
                m.bottom * output.height,
                paint
            )
        }
        return output
    }

    private fun legacyPrivacyCrop(source: Bitmap, pageIndex: Int, jpegQuality: Int): PreparedImage {
        val topRatio = if (pageIndex <= 1) 0.29f else 0.205f
        val crop = cropByRatios(source, 0.045f, topRatio, 0.955f, 0.975f)
        return try {
            PreparedImage(
                pageIndex = pageIndex,
                base64Jpeg = encode(crop, jpegQuality),
                targetedQuestionCrop = false,
                geometryAligned = false
            )
        } finally {
            if (crop !== source) crop.recycleSafely()
        }
    }

    private fun decodePortrait(path: String): Bitmap? = runCatching { decodePortraitStrict(path, null) }.getOrNull()

    private fun decodePortraitStrict(path: String, pageIndex: Int?): Bitmap {
        val prefix = pageIndex?.let { "Sayfa $it" } ?: "Öğrenci görüntüsü"
        val file = File(path)
        if (!file.exists() || !file.isFile) {
            throw ImagePreparationException("$prefix bulunamadı; değerlendirme yapılmadı.")
        }
        val bitmap = try {
            StudentImageCrypto.decodeBitmapStrict(file.absolutePath)
        } catch (e: StudentImageKeyRecoveryRequiredException) {
            throw ImagePreparationException("$prefix şifreleme anahtarıyla açılamadı; değerlendirme yapılmadı.", e)
        } catch (e: StudentImageIntegrityException) {
            throw ImagePreparationException("$prefix güvenli biçimde okunamadı; değerlendirme yapılmadı.", e)
        } catch (e: Throwable) {
            throw ImagePreparationException("$prefix hazırlanırken güvenlik hatası oluştu; değerlendirme yapılmadı.", e)
        }
        if (bitmap.height >= bitmap.width) return bitmap
        return try {
            val matrix = Matrix().apply { postRotate(90f) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } finally {
            bitmap.recycleSafely()
        }
    }

    /** Detect four dense corner fiducials and perspective-warp to canonical A4 geometry. */
    private fun rectifyByRegistrationMarks(source: Bitmap): RectifiedPage? {
        if (source.width < 500 || source.height < 700) return null

        val sampleWidth = min(900, source.width)
        val sampleHeight = max(1, (source.height.toDouble() * sampleWidth / source.width).roundToInt())
        val sample = if (sampleWidth == source.width) source else Bitmap.createScaledBitmap(source, sampleWidth, sampleHeight, true)
        try {
            val integral = buildDarknessIntegral(sample)
            val tl = findMarker(integral, sample.width, sample.height, Corner.TOP_LEFT) ?: return null
            val tr = findMarker(integral, sample.width, sample.height, Corner.TOP_RIGHT) ?: return null
            val br = findMarker(integral, sample.width, sample.height, Corner.BOTTOM_RIGHT) ?: return null
            val bl = findMarker(integral, sample.width, sample.height, Corner.BOTTOM_LEFT) ?: return null

            val minScore = min(min(tl.score, tr.score), min(br.score, bl.score))
            if (minScore < 78.0) return null

            // Basic geometry sanity checks prevent text/QR false positives.
            if (!(tl.x < tr.x && bl.x < br.x && tl.y < bl.y && tr.y < br.y)) return null
            val topSpan = tr.x - tl.x
            val bottomSpan = br.x - bl.x
            val leftSpan = bl.y - tl.y
            val rightSpan = br.y - tr.y
            if (topSpan < sample.width * 0.55f || bottomSpan < sample.width * 0.55f) return null
            if (leftSpan < sample.height * 0.60f || rightSpan < sample.height * 0.60f) return null
            if (abs(topSpan - bottomSpan) > sample.width * 0.28f) return null
            if (abs(leftSpan - rightSpan) > sample.height * 0.28f) return null

            val scaleX = source.width.toFloat() / sample.width.toFloat()
            val scaleY = source.height.toFloat() / sample.height.toFloat()
            val srcPts = floatArrayOf(
                tl.x * scaleX, tl.y * scaleY,
                tr.x * scaleX, tr.y * scaleY,
                br.x * scaleX, br.y * scaleY,
                bl.x * scaleX, bl.y * scaleY
            )

            val targetWidth = min(source.width, MAX_RECTIFIED_WIDTH_PX).coerceAtLeast(1000)
            val targetHeight = (targetWidth * PAGE_HEIGHT_PT / PAGE_WIDTH_PT).roundToInt()
            val dstPts = FloatArray(8)
            AnswerSheetRegistrationGeometry.registrationCentersPt.forEachIndexed { index, (xPt, yPt) ->
                dstPts[index * 2] = xPt / PAGE_WIDTH_PT * targetWidth
                dstPts[index * 2 + 1] = yPt / PAGE_HEIGHT_PT * targetHeight
            }

            val transform = Matrix()
            if (!transform.setPolyToPoly(srcPts, 0, dstPts, 0, 4)) return null
            val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            output.eraseColor(Color.WHITE)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(source, transform, paint)

            val confidence = (minScore / 255.0).coerceIn(0.0, 1.0)
            return RectifiedPage(output, confidence)
        } finally {
            if (sample !== source) sample.recycleSafely()
        }
    }

    private enum class Corner { TOP_LEFT, TOP_RIGHT, BOTTOM_RIGHT, BOTTOM_LEFT }

    /** Integral image of per-pixel darkness (0 white .. 255 black). */
    private fun buildDarknessIntegral(bitmap: Bitmap): LongArray {
        val w = bitmap.width
        val h = bitmap.height
        val out = LongArray((w + 1) * (h + 1))
        val pixels = IntArray(w)
        for (y in 0 until h) {
            bitmap.getPixels(pixels, 0, w, 0, y, w, 1)
            var rowSum = 0L
            for (x in 0 until w) {
                val c = pixels[x]
                val gray = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
                rowSum += (255 - gray)
                val idx = (y + 1) * (w + 1) + (x + 1)
                out[idx] = out[y * (w + 1) + (x + 1)] + rowSum
            }
        }
        return out
    }

    private fun findMarker(integral: LongArray, w: Int, h: Int, corner: Corner): MarkerCandidate? {
        val xRange = when (corner) {
            Corner.TOP_LEFT, Corner.BOTTOM_LEFT -> 0 until max(1, (w * 0.08f).roundToInt())
            Corner.TOP_RIGHT, Corner.BOTTOM_RIGHT -> min(w - 1, (w * 0.92f).roundToInt()) until w
        }
        val yRange = when (corner) {
            Corner.TOP_LEFT, Corner.TOP_RIGHT -> 0 until max(1, (h * 0.060f).roundToInt())
            Corner.BOTTOM_LEFT, Corner.BOTTOM_RIGHT -> min(h - 1, (h * 0.940f).roundToInt()) until h
        }

        var best: MarkerCandidate? = null
        val nominal = (w * (AnswerSheetRegistrationGeometry.markSizePt / PAGE_WIDTH_PT)).roundToInt()
        val sizes = listOf(
            (nominal * 0.70f).roundToInt(),
            nominal,
            (nominal * 1.30f).roundToInt()
        ).map { it.coerceIn(8, max(9, w / 16)) }.distinct()

        for (size in sizes) {
            val step = max(2, size / 5)
            var y = yRange.first
            while (y + size <= yRange.last + 1) {
                var x = xRange.first
                while (x + size <= xRange.last + 1) {
                    val sum = rectSum(integral, w, x, y, x + size, y + size)
                    val avg = sum.toDouble() / (size * size)
                    // Ring fiducial is still much denser than ordinary text strokes.
                    if (best == null || avg > best!!.score) {
                        best = MarkerCandidate(x + size / 2f, y + size / 2f, avg)
                    }
                    x += step
                }
                y += step
            }
        }
        return best
    }

    private fun rectSum(integral: LongArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int): Long {
        val stride = w + 1
        return integral[y1 * stride + x1] - integral[y0 * stride + x1] -
            integral[y1 * stride + x0] + integral[y0 * stride + x0]
    }

    private fun cropByPoints(
        source: Bitmap,
        leftPt: Float,
        topPt: Float,
        rightPt: Float,
        bottomPt: Float
    ): Bitmap = cropByRatios(
        source,
        leftPt / PAGE_WIDTH_PT,
        topPt / PAGE_HEIGHT_PT,
        rightPt / PAGE_WIDTH_PT,
        bottomPt / PAGE_HEIGHT_PT
    )

    private fun cropByRatios(
        source: Bitmap,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float
    ): Bitmap {
        val left = (source.width * leftRatio.coerceIn(0f, 0.98f)).roundToInt().coerceIn(0, source.width - 1)
        val top = (source.height * topRatio.coerceIn(0f, 0.98f)).roundToInt().coerceIn(0, source.height - 1)
        val right = (source.width * rightRatio.coerceIn(0.02f, 1f)).roundToInt().coerceIn(left + 1, source.width)
        val bottom = (source.height * bottomRatio.coerceIn(0.02f, 1f)).roundToInt().coerceIn(top + 1, source.height)
        return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    }

    private fun encode(bitmap: Bitmap, quality: Int): String {
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(80, 100), bos)
        return Base64.getEncoder().encodeToString(bos.toByteArray())
    }

    private fun Bitmap.recycleSafely() {
        if (!isRecycled) recycle()
    }
}
