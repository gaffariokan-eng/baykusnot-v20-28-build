package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Durable intent/checkpoint for a long-running AI evaluation.
 *
 * Student-level results are already committed transactionally; this row only records whether a
 * user-requested run should be resumed after process death. PAUSED and ERROR never auto-resume.
 */
@Entity(
    tableName = "exam_evaluation_run_state",
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ExamEvaluationRunStateEntity(
    @PrimaryKey val examDraftId: Long,
    val requestedMode: String = "AUTO",
    val status: String = "RUNNING",
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val lastError: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
