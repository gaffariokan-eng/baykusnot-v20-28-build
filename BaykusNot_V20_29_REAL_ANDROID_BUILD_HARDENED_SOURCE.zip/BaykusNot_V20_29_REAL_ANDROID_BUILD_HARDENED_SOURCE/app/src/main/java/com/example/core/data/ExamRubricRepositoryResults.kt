package com.example.core.data

import com.example.core.model.ExamRubricSetMetadata
import com.example.core.model.ExamRubricValidationResult

sealed interface SaveExamRubricResult {

    data class Success(
        val metadata: ExamRubricSetMetadata,
        val validation: ExamRubricValidationResult
    ) : SaveExamRubricResult

    data object DraftNotFound : SaveExamRubricResult

    data object QuestionSetMetadataMissing : SaveExamRubricResult

    data class ValidationFailed(
        val validation: ExamRubricValidationResult
    ) : SaveExamRubricResult

    data class Locked(
        val currentRevision: Int
    ) : SaveExamRubricResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : SaveExamRubricResult

    data object StateConflict : SaveExamRubricResult

    data class Failure(
        val cause: Throwable
    ) : SaveExamRubricResult
}

sealed interface LockExamRubricSetResult {

    data class Success(
        val metadata: ExamRubricSetMetadata
    ) : LockExamRubricSetResult

    data object DraftNotFound : LockExamRubricSetResult

    data object MetadataMissing : LockExamRubricSetResult

    data object QuestionSetMetadataMissing : LockExamRubricSetResult

    data class ValidationFailed(
        val validation: ExamRubricValidationResult
    ) : LockExamRubricSetResult

    data class AlreadyLocked(
        val currentRevision: Int
    ) : LockExamRubricSetResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : LockExamRubricSetResult

    data object StateConflict : LockExamRubricSetResult

    data class Failure(
        val cause: Throwable
    ) : LockExamRubricSetResult
}

sealed interface UnlockExamRubricSetResult {

    data class Success(
        val metadata: ExamRubricSetMetadata
    ) : UnlockExamRubricSetResult

    data object MetadataMissing : UnlockExamRubricSetResult

    data class AlreadyUnlocked(
        val currentRevision: Int
    ) : UnlockExamRubricSetResult

    data class RevisionConflict(
        val currentRevision: Int
    ) : UnlockExamRubricSetResult

    data object StateConflict : UnlockExamRubricSetResult

    data class Failure(
        val cause: Throwable
    ) : UnlockExamRubricSetResult
}
