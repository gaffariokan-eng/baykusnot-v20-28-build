package com.example.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "exam_question_extraction_draft",
    primaryKeys = ["examDraftId", "orderIndex"],
    foreignKeys = [
        ForeignKey(
            entity = ExamDraftEntity::class,
            parentColumns = ["id"],
            childColumns = ["examDraftId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["examDraftId"])
    ]
)
data class ExamQuestionExtractionDraftEntity(
    val examDraftId: Long,
    val sourceFingerprint: String,
    val orderIndex: Int,
    val rawQuestionNumber: String,
    val rawQuestionText: String,
    val rawPoints: Int?
)
