package com.example.core.data

import java.io.InputStream

data class SelectedPdfSource(
    val originalUri: String,
    val displayName: String,
    val mimeType: String,
    val declaredSizeBytes: Long?,
    val openInputStream: () -> InputStream?,
    /** Optional ownership hook for temporary selections created by the UI. Idempotent. */
    val cleanup: () -> Unit = {}
)
