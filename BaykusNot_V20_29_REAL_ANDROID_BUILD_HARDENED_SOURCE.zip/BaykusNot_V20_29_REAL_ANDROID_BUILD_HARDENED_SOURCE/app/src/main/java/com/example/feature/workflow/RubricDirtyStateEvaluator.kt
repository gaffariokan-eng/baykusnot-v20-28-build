package com.example.feature.workflow

import com.example.core.model.ExamRubricCriterion

object RubricDirtyStateEvaluator {

    fun hasUnsavedChanges(
        editableCriteria: List<EditableExamRubricCriterion>,
        persistedCriteria: List<ExamRubricCriterion>
    ): Boolean {
        if (editableCriteria.size != persistedCriteria.size) {
            return true
        }

        for (i in editableCriteria.indices) {
            val editable = editableCriteria[i]
            val persisted = persistedCriteria[i]

            if (editable.questionOrderIndex != persisted.questionOrderIndex) return true
            if (editable.questionNumberSnapshot != persisted.questionNumberSnapshot) return true
            if (editable.criterionOrderIndex != persisted.criterionOrderIndex) return true
            if (editable.title != persisted.title) return true
            if (editable.description != persisted.description) return true
            if (editable.expectedAnswer != persisted.expectedAnswer) return true
            if (editable.partialCreditGuidance != persisted.partialCreditGuidance) return true
            if (editable.commonMistakes != persisted.commonMistakes) return true

            when (val parseResult = RubricMaxPointsInputParser.parse(editable.maxPointsText)) {
                is RubricMaxPointsParseResult.Rejected -> return true
                is RubricMaxPointsParseResult.Parsed -> {
                    if (parseResult.maxPoints != persisted.maxPoints) {
                        return true
                    }
                }
            }
        }

        return false
    }
}
