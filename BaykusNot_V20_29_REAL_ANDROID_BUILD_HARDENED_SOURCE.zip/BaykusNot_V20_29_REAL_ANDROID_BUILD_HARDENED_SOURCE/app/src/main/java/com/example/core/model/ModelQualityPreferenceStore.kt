package com.example.core.model

import kotlinx.coroutines.flow.Flow

interface ModelQualityPreferenceStore {
    val selectedTier: Flow<ModelQualityTier>

    suspend fun setSelectedTier(tier: ModelQualityTier)
}
