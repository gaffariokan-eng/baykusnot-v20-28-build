package com.example.feature.workflow

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.core.database.ExamDraftEntity
import com.example.core.data.ExamAnswerSheetLayoutCalculator
import com.example.core.model.ExamType
import com.example.core.model.formatExamSequenceForDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object ReportsPdfGenerator {

    private const val TEMP_REPORT_MAX_AGE_MS = 24L * 60L * 60L * 1000L

    private fun reportCacheDir(context: Context): File = File(context.cacheDir, "reports").apply { mkdirs() }

    fun cleanupTemporaryReports(context: Context, maxAgeMs: Long = TEMP_REPORT_MAX_AGE_MS): Boolean {
        val cutoff = System.currentTimeMillis() - maxAgeMs
        var complete = true
        reportCacheDir(context).listFiles()?.forEach { file ->
            if (file.isFile && file.lastModified() < cutoff) {
                val deleted = runCatching { file.delete() || !file.exists() }.getOrDefault(false)
                if (!deleted) complete = false
            }
        }
        return complete
    }

    fun deleteTemporaryReport(file: File?) {
        if (file == null) return
        runCatching { file.delete() }
    }

    private fun temporaryPdf(context: Context, examDraftId: Long?, kind: String): File {
        cleanupTemporaryReports(context)
        val safeKind = sanitizeFilename(kind).ifBlank { "Rapor" }.take(32)
        val examPrefix = examDraftId?.takeIf { it > 0L }?.let { "Exam_${it}_" }.orEmpty()
        return File(reportCacheDir(context), "BaykusNot_${examPrefix}${safeKind}_${UUID.randomUUID()}.pdf")
    }

    fun deleteTemporaryReportsForExam(context: Context, examDraftId: Long): Int {
        if (examDraftId <= 0L) return 0
        val prefix = "BaykusNot_Exam_${examDraftId}_"
        var deleted = 0
        reportCacheDir(context).listFiles()?.filter { it.isFile && it.name.startsWith(prefix) }?.forEach { file ->
            if (runCatching { file.delete() }.getOrDefault(false)) deleted++
        }
        return deleted
    }

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_X = 40f
    private const val MARGIN_Y = 40f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (2 * MARGIN_X)

    private val titlePaint = Paint().apply {
        color = Color.BLACK
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val headerPaint = Paint().apply {
        color = Color.BLACK
        textSize = 14f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val textPaint = Paint().apply {
        color = Color.BLACK
        textSize = 12f
    }

    private val smallTextPaint = Paint().apply {
        color = Color.DKGRAY
        textSize = 10f
    }

    private val linePaint = Paint().apply {
        color = Color.LTGRAY
        strokeWidth = 1f
    }

    private class PdfWriter(val document: PdfDocument) {
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var currentY = MARGIN_Y

        fun checkPageBreak(requiredHeight: Float) {
            if (currentY + requiredHeight > PAGE_HEIGHT - MARGIN_Y) {
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                currentY = MARGIN_Y
            }
        }
        
        fun forceNewPage() {
            if (currentY > MARGIN_Y) {
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                currentY = MARGIN_Y
            }
        }

        fun drawMultilineText(text: String, paint: Paint, width: Float = CONTENT_WIDTH, startX: Float = MARGIN_X) {
            val words = text.split(" ")
            var line = ""
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                val measure = paint.measureText(testLine)
                if (measure > width) {
                    if (line.isEmpty()) {
                        var remainingWord = word
                        while (remainingWord.isNotEmpty()) {
                            val count = paint.breakText(remainingWord, true, width, null)
                            val chunk = remainingWord.substring(0, count)
                            checkPageBreak(paint.textSize * 1.5f)
                            canvas.drawText(chunk, startX, currentY, paint)
                            currentY += paint.textSize * 1.5f
                            remainingWord = remainingWord.substring(count)
                        }
                    } else {
                        checkPageBreak(paint.textSize * 1.5f)
                        canvas.drawText(line, startX, currentY, paint)
                        currentY += paint.textSize * 1.5f
                        line = word
                    }
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                checkPageBreak(paint.textSize * 1.5f)
                canvas.drawText(line, startX, currentY, paint)
                currentY += paint.textSize * 1.5f
            }
        }

        fun drawCenteredTitle(text: String, paint: Paint = titlePaint, width: Float = CONTENT_WIDTH) {
            val words = text.split(" ")
            var line = ""
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                val measure = paint.measureText(testLine)
                if (measure > width) {
                    if (line.isNotEmpty()) {
                        checkPageBreak(paint.textSize * 1.3f)
                        canvas.drawText(line, PAGE_WIDTH / 2f, currentY, paint)
                        currentY += paint.textSize * 1.3f
                        line = word
                    } else {
                        checkPageBreak(paint.textSize * 1.3f)
                        canvas.drawText(word, PAGE_WIDTH / 2f, currentY, paint)
                        currentY += paint.textSize * 1.3f
                        line = ""
                    }
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                checkPageBreak(paint.textSize * 1.3f)
                canvas.drawText(line, PAGE_WIDTH / 2f, currentY, paint)
                currentY += paint.textSize * 1.3f
            }
        }

        fun drawExamHeader(draft: ExamDraftEntity?, title: String) {
            checkPageBreak(40f)
            canvas.drawText(title, PAGE_WIDTH / 2f, currentY, titlePaint)
            currentY += 25f

            if (draft != null) {
                drawMultilineText("Kurum: ${draft.institutionName}", textPaint)
                drawMultilineText("Ders: ${draft.courseName} (${draft.academicYear} - ${draft.term})", textPaint)
                val copy = reportCopy(draft.examType)
                val documentLabel = when (draft.examType) {
                    ExamType.HOMEWORK -> "Ödev"
                    ExamType.READINESS -> "Hazırbulunuşluk Sınavı"
                    else -> "Sınav"
                }
                drawMultilineText("$documentLabel: ${draft.examType.formatExamSequenceForDocument(draft.examSequenceNumber)}", textPaint)
                val dateStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(draft.examDate))
                drawMultilineText("Tarih: $dateStr | Öğretmen(ler): ${draft.teachers.joinToString(", ")}", textPaint)
                drawMultilineText("${copy.totalPointsLabel}: ${draft.totalPoints}", textPaint)
                currentY += 15f
            }
        }

        fun calculateMultilineTextHeight(text: String, paint: Paint, width: Float): Float {
            val words = text.split(" ")
            var line = ""
            var lineCount = 0
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                val measure = paint.measureText(testLine)
                if (measure > width) {
                    if (line.isNotEmpty()) {
                        lineCount++
                        line = word
                    } else {
                        var remaining = word
                        while (remaining.isNotEmpty()) {
                            val count = paint.breakText(remaining, true, width, null)
                            lineCount++
                            remaining = remaining.substring(count)
                        }
                        line = ""
                    }
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                lineCount++
            }
            return lineCount * (paint.textSize * 1.5f)
        }

        fun drawQuestionFeedbackCard(qs: IndividualQuestionScore, itemLabel: String = "Soru") {
            val innerWidth = CONTENT_WIDTH - 20f
            val formatScore = { v: Double -> if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v) }
            val scoreStr = "${formatScore(qs.score)} / ${formatScore(qs.maxScore)} Puan"

            val feedbackText = qs.feedback?.trim() ?: ""
            val hasFeedback = feedbackText.isNotEmpty()
            val textHeight = if (hasFeedback) calculateMultilineTextHeight(feedbackText, smallTextPaint, innerWidth) else 0f

            val cardHeight = 10f + 16f + (if (hasFeedback) 6f + textHeight else 0f) + 10f

            checkPageBreak(cardHeight + 6f)

            val ratio = if (qs.maxScore > 0.0) (qs.score / qs.maxScore) else 0.0
            val isUnreadable = qs.answerType == "UNREADABLE" || feedbackText.contains("okunamadı", ignoreCase = true)

            val (bgColor, borderColor, badgeBgColor) = when {
                isUnreadable -> Triple(Color.rgb(245, 245, 248), Color.rgb(215, 218, 225), Color.rgb(230, 232, 240))
                ratio >= 0.75 -> Triple(Color.rgb(242, 249, 244), Color.rgb(195, 230, 202), Color.rgb(215, 242, 222))
                ratio > 0.0 -> Triple(Color.rgb(255, 252, 245), Color.rgb(255, 230, 190), Color.rgb(255, 240, 210))
                else -> Triple(Color.rgb(250, 250, 252), Color.rgb(225, 225, 230), Color.rgb(235, 235, 240))
            }

            val cardRect = RectF(MARGIN_X, currentY, PAGE_WIDTH - MARGIN_X, currentY + cardHeight)

            val bgPaint = Paint().apply {
                color = bgColor
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = borderColor
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            canvas.drawRoundRect(cardRect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(cardRect, 6f, 6f, borderPaint)

            val cardTop = currentY
            val contentLeft = MARGIN_X + 10f
            val contentRight = PAGE_WIDTH - MARGIN_X - 10f
            val headerY = cardTop + 18f

            canvas.drawText("$itemLabel ${qs.questionNumber}", contentLeft, headerY, headerPaint)

            val badgeWidth = smallTextPaint.measureText(scoreStr) + 12f
            val badgeRect = RectF(contentRight - badgeWidth, headerY - 12f, contentRight, headerY + 4f)

            val badgeBgPaint = Paint().apply {
                color = badgeBgColor
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(badgeRect, 4f, 4f, badgeBgPaint)

            val badgeTextPaint = Paint(smallTextPaint).apply {
                color = Color.BLACK
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(scoreStr, badgeRect.centerX(), headerY, badgeTextPaint)

            if (hasFeedback) {
                currentY = headerY + 12f
                drawMultilineText(feedbackText, smallTextPaint, innerWidth, contentLeft)
            }

            currentY = cardTop + cardHeight + 8f
        }

        fun drawSpellingFeedbackCard(feedbackText: String, deduction: Double?) {
            val innerWidth = CONTENT_WIDTH - 20f
            val formatScore = { v: Double -> if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v) }
            val deductionText = if ((deduction ?: 0.0) > 0.0) " (Kesinti: -${formatScore(deduction!!)} Puan)" else ""
            val titleText = "Yazım ve Noktalama$deductionText"

            val textHeight = calculateMultilineTextHeight(feedbackText, smallTextPaint, innerWidth)
            val cardHeight = 10f + 16f + 6f + textHeight + 10f

            checkPageBreak(cardHeight + 6f)

            val cardRect = RectF(MARGIN_X, currentY, PAGE_WIDTH - MARGIN_X, currentY + cardHeight)

            val bgPaint = Paint().apply {
                color = Color.rgb(246, 248, 252)
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = Color.rgb(215, 222, 235)
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            canvas.drawRoundRect(cardRect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(cardRect, 6f, 6f, borderPaint)

            val cardTop = currentY
            val contentLeft = MARGIN_X + 10f
            val headerY = cardTop + 18f

            canvas.drawText(titleText, contentLeft, headerY, headerPaint)
            currentY = headerY + 12f
            drawMultilineText(feedbackText, smallTextPaint, innerWidth, contentLeft)

            currentY = cardTop + cardHeight + 12f
        }
        
        fun finish() {
            document.finishPage(page)
        }
    }
    
    private fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[^a-zA-Z0-9_\\-\\.]"), "_")
    }

    fun generateClassReportPdf(context: Context, draft: ExamDraftEntity?, group: ClassReportData): File {
        val pdfDocument = PdfDocument()
        val writer = PdfWriter(pdfDocument)
        val copy = reportCopy(draft?.examType ?: ExamType.WRITTEN)

        writer.drawExamHeader(draft, copy.classPdfTitle)

        writer.checkPageBreak(30f)
        writer.canvas.drawText("Sınıf/Şube: ${group.classAndBranch}", MARGIN_X, writer.currentY, headerPaint)
        writer.currentY += 20f
        writer.drawMultilineText("Öğrenci Sayısı: ${group.studentCount} | Ortalama: ${String.format("%.1f", group.classAverage)} | Maks: ${group.maxScore} | Min: ${group.minScore}", textPaint)
        if (draft?.examType == ExamType.MULTIPLE_CHOICE) {
            writer.drawMultilineText(
                "Öğrenci başına ortalama — Doğru: ${String.format("%.1f", group.testAverageCorrect)} | Yanlış: ${String.format("%.1f", group.testAverageWrong)} | Boş: ${String.format("%.1f", group.testAverageBlank)}",
                smallTextPaint
            )
        }
        
        writer.checkPageBreak(15f)
        writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
        writer.currentY += 15f

        if (group.prioritySupportObjectives.isNotEmpty() && copy.prioritySupportTitle != null) {
            writer.checkPageBreak(40f)
            writer.canvas.drawText(copy.prioritySupportTitle, MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 18f
            copy.prioritySupportDescription?.let { description ->
                writer.drawMultilineText(description, smallTextPaint)
                writer.currentY += 6f
            }
            group.prioritySupportObjectives.forEachIndexed { index, obj ->
                writer.checkPageBreak(42f)
                val code = obj.objectiveCode ?: copy.objectiveDefaultLabel
                writer.drawMultilineText("${index + 1}. $code — ${obj.objectiveText}", textPaint)
                writer.drawMultilineText(
                    "Desteğe ihtiyaç gösteren: ${obj.supportStudentCount}/${obj.measuredStudentCount} öğrenci (%${String.format("%.0f", obj.supportRatePercentage)}) | Sınıf karşılanma: %${String.format("%.1f", obj.successPercentage)}",
                    smallTextPaint
                )
                writer.currentY += 6f
            }
            writer.checkPageBreak(15f)
            writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
            writer.currentY += 15f
        }

        if (group.classObjectiveScores.isNotEmpty()) {
            writer.checkPageBreak(30f)
            writer.canvas.drawText(copy.classObjectiveTitle, MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 20f
            group.classObjectiveScores.forEach { obj ->
                writer.checkPageBreak(35f)
                val code = obj.objectiveCode ?: copy.objectiveDefaultLabel
                val scoreTxt = if (obj.questionCount == 0) "Ölçülmedi" else "%${String.format("%.1f", obj.successPercentage)}"
                val scoreW = textPaint.measureText(scoreTxt)
                writer.canvas.drawText(scoreTxt, PAGE_WIDTH - MARGIN_X - scoreW, writer.currentY, headerPaint)
                writer.drawMultilineText("$code (${obj.questionCount} ${copy.itemLabel}): ${obj.objectiveText}", textPaint, CONTENT_WIDTH - scoreW - 10f)
                writer.drawMultilineText("Düzey: ${obj.level}", smallTextPaint)
                writer.currentY += 10f
            }
            writer.checkPageBreak(15f)
            writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
            writer.currentY += 15f
        }
        val sortedStudents = group.students.sortedBy { 
            it.studentNumber.filter { char -> char.isDigit() }.toIntOrNull() ?: 0 
        }

        sortedStudents.forEach { student ->
            writer.checkPageBreak(25f)
            val startY = writer.currentY
            val scoreText = "${student.totalScore} / ${student.totalMaxScore}"
            val scoreWidth = textPaint.measureText(scoreText)
            val maxNameWidth = CONTENT_WIDTH - scoreWidth - 10f
            
            writer.canvas.drawText(scoreText, PAGE_WIDTH - MARGIN_X - scoreWidth, startY, textPaint)
            writer.drawMultilineText("${student.studentNumber} - ${student.studentName}", textPaint, maxNameWidth, MARGIN_X)
            writer.currentY += 5f
        }

        writer.finish()

        val pdfFile = temporaryPdf(context, draft?.id, "Sinif_Raporu")

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return pdfFile
    }

    private fun drawIndividualReportContent(writer: PdfWriter, draft: ExamDraftEntity?, ind: IndividualReportData) {
        val copy = reportCopy(draft?.examType ?: ExamType.WRITTEN)
        val reportTitle = if (draft != null) {
            ExamAnswerSheetLayoutCalculator.buildIndividualReportTitle(draft)
        } else {
            "BİREYSEL ÖĞRENCİ RAPORU"
        }

        writer.checkPageBreak(40f)
        writer.drawCenteredTitle(reportTitle)
        writer.currentY += 10f

        if (draft != null) {
            val dateStr = ExamAnswerSheetLayoutCalculator.formatExamDate(draft.examDate)
            val teachersStr = if (draft.teachers.isNotEmpty()) " | Öğretmen(ler): ${draft.teachers.joinToString(", ")}" else ""
            writer.drawMultilineText("${copy.dateLabel}: $dateStr$teachersStr", smallTextPaint)
            writer.currentY += 5f
        }

        writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
        writer.currentY += 15f

        writer.checkPageBreak(50f)
        writer.drawMultilineText("Öğrenci: ${ind.studentNumber} - ${ind.studentName} (${ind.classAndBranch})", headerPaint)
        writer.currentY += 5f
        val formatScore = { v: Double -> if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v) }
        writer.canvas.drawText("Toplam Puan: ${formatScore(ind.totalScore)} / ${formatScore(ind.totalMaxScore)}", MARGIN_X, writer.currentY, headerPaint)
        writer.currentY += 18f
        if (draft?.examType == ExamType.MULTIPLE_CHOICE) {
            writer.drawMultilineText("Doğru: ${ind.testCorrectCount} | Yanlış: ${ind.testWrongCount} | Boş: ${ind.testBlankCount}", textPaint)
            writer.currentY += 7f
        }

        if (ind.prioritySupportObjectives.isNotEmpty() && copy.individualSupportTitle != null) {
            writer.checkPageBreak(35f)
            writer.canvas.drawText(copy.individualSupportTitle, MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 18f
            ind.prioritySupportObjectives.forEachIndexed { index, obj ->
                writer.checkPageBreak(32f)
                val code = obj.objectiveCode ?: copy.objectiveDefaultLabel
                writer.drawMultilineText("${index + 1}. $code — ${obj.objectiveText}", textPaint)
                writer.drawMultilineText("Karşılanma: %${String.format("%.1f", obj.successPercentage)} — ${obj.level}", smallTextPaint)
                writer.currentY += 5f
            }
            writer.drawMultilineText("Bu sıralama not veya başarı sınırı değildir; konu/üniteye başlamadan önce desteklenebilecek alanları gösterir.", smallTextPaint)
            writer.currentY += 10f
        }

        if (ind.objectiveScores.isNotEmpty()) {
            writer.checkPageBreak(30f)
            writer.canvas.drawText(copy.individualObjectiveTitle, MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 20f
            ind.objectiveScores.forEach { obj ->
                writer.checkPageBreak(35f)
                val code = obj.objectiveCode ?: copy.objectiveDefaultLabel
                val scoreTxt = if (obj.questionCount == 0) "Ölçülmedi" else "%${String.format("%.1f", obj.successPercentage)}"
                val scoreW = textPaint.measureText(scoreTxt)
                writer.canvas.drawText(scoreTxt, PAGE_WIDTH - MARGIN_X - scoreW, writer.currentY, headerPaint)
                writer.drawMultilineText("$code (${obj.questionCount} ${copy.itemLabel}): ${obj.objectiveText}", textPaint, CONTENT_WIDTH - scoreW - 10f)
                writer.drawMultilineText("Düzey: ${obj.level}", smallTextPaint)
                writer.currentY += 10f
            }
            writer.checkPageBreak(15f)
            writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
            writer.currentY += 15f
        }

        if (ind.questionScores.isNotEmpty()) {
            writer.checkPageBreak(25f)
            writer.canvas.drawText(copy.itemFeedbackTitle, MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 15f

            ind.questionScores.forEach { qs ->
                writer.drawQuestionFeedbackCard(qs, copy.itemLabel)
            }
            writer.currentY += 5f
        }

        if (!ind.teacherNote.isNullOrBlank()) {
            writer.checkPageBreak(55f)
            writer.canvas.drawText("Öğretmen Notu", MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 16f
            writer.drawMultilineText(ind.teacherNote, textPaint)
            writer.currentY += 10f
        }

        if (!ind.overallFeedback.isNullOrBlank()) {
            writer.checkPageBreak(55f)
            writer.canvas.drawText("Genel Değerlendirme", MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 16f
            writer.drawMultilineText(ind.overallFeedback, textPaint)
            writer.currentY += 10f
        }

        if (!ind.spellingPunctuationFeedback.isNullOrBlank()) {
            writer.drawSpellingFeedbackCard(ind.spellingPunctuationFeedback, ind.spellingPunctuationDeduction)
        }

        writer.checkPageBreak(58f)
        val aiNotice = ind.aiDisclosure.ifBlank {
            "Bu rapor BaykuşNot değerlendirme akışıyla hazırlanmıştır; nihai akademik karar öğretmene aittir."
        }
        writer.drawMultilineText(aiNotice, smallTextPaint)
        writer.currentY += 6f
        writer.drawMultilineText("Gerekirse yeniden inceleme notu: ............................................................", smallTextPaint)
        writer.currentY += 8f

        // The original answer paper remains the physical primary record.
        // Individual feedback PDFs intentionally do not reprint page images, avoiding
        // unnecessary toner/paper and duplicate personal-data copies.

    }

    fun generateIndividualReportPdf(context: Context, draft: ExamDraftEntity?, ind: IndividualReportData): File {
        val pdfDocument = PdfDocument()
        val writer = PdfWriter(pdfDocument)
        drawIndividualReportContent(writer, draft, ind)
        writer.finish()

        val pdfFile = temporaryPdf(context, draft?.id, "Bireysel_Rapor")

        FileOutputStream(pdfFile).use { out -> pdfDocument.writeTo(out) }
        pdfDocument.close()
        return pdfFile
    }

    fun generateQuestionReportPdf(context: Context, draft: ExamDraftEntity?, questionReports: List<QuestionReportData>): File {
        val pdfDocument = PdfDocument()
        val writer = PdfWriter(pdfDocument)
        val copy = reportCopy(draft?.examType ?: ExamType.WRITTEN)

        writer.drawExamHeader(draft, copy.itemPdfTitle)

        questionReports.forEach { qr ->
            writer.checkPageBreak(80f)
            writer.canvas.drawText("${copy.itemLabel} ${qr.questionNumber} (Maks: ${qr.maxScore} Puan)", MARGIN_X, writer.currentY, headerPaint)
            writer.currentY += 15f
            
            writer.drawMultilineText(qr.questionText, textPaint)
            writer.currentY += 10f
            
            writer.drawMultilineText("Öğrenci: ${qr.studentCount} | Ort: ${String.format("%.1f", qr.averageScore)} | ${copy.successLabel}: %${String.format("%.1f", qr.successPercentage)}", textPaint)
            if (draft?.examType == ExamType.MULTIPLE_CHOICE) {
                writer.drawMultilineText(
                    "Doğru: ${qr.correctCount} | Yanlış: ${qr.wrongCount} | Boş: ${qr.blankCount}" +
                        (qr.correctChoice?.let { " | Anahtar: $it" } ?: ""),
                    smallTextPaint
                )
                if (qr.choiceDistribution.isNotEmpty()) {
                    writer.drawMultilineText(
                        "Seçenek dağılımı: " + qr.choiceDistribution.entries.joinToString("   ") { "${it.key}: ${it.value}" },
                        smallTextPaint
                    )
                }
            }
            writer.currentY += 5f
            
            if (qr.objectives.isNotEmpty()) {
                writer.checkPageBreak(30f)
                writer.canvas.drawText("${copy.objectivePluralLabel}:", MARGIN_X, writer.currentY, smallTextPaint)
                writer.currentY += 12f
                qr.objectives.forEach { obj ->
                    val codeText = if (!obj.objectiveCode.isNullOrBlank()) "${obj.objectiveCode} " else ""
                    writer.checkPageBreak(25f)
                    writer.drawMultilineText("- $codeText${obj.objectiveText}", smallTextPaint)
                }
                writer.currentY += 5f
            }
            
            writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, linePaint)
            writer.currentY += 15f

            qr.students.forEach { std ->
                writer.checkPageBreak(25f)
                val startY = writer.currentY
                val scoreText = "${std.score} / ${std.maxScore}"
                val scoreWidth = smallTextPaint.measureText(scoreText)
                val maxNameWidth = CONTENT_WIDTH - scoreWidth - 10f
                
                writer.canvas.drawText(scoreText, PAGE_WIDTH - MARGIN_X - scoreWidth, startY, smallTextPaint)
                writer.drawMultilineText("${std.classAndBranch} - ${std.studentNumber} ${std.studentName}", smallTextPaint, maxNameWidth, MARGIN_X)
                writer.currentY += 5f
            }
            writer.currentY += 20f
        }
        
        writer.finish()

        val pdfFile = temporaryPdf(context, draft?.id, copy.itemAnalysisFileSuffix)

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return pdfFile
    }

    fun generateAllIndividualReportsPdf(context: Context, draft: ExamDraftEntity?, reports: List<IndividualReportData>): File {
        require(reports.isNotEmpty()) { "Bireysel öğrenci raporu bulunamadı." }
        val output = temporaryPdf(context, draft?.id, "Tum_Ogrenci_Donutleri")
        val document = PdfDocument()
        val writer = PdfWriter(document)
        try {
            reports.forEachIndexed { index, report ->
                if (index > 0) writer.forceNewPage()
                drawIndividualReportContent(writer, draft, report)
            }
            writer.finish()
            FileOutputStream(output).use { document.writeTo(it) }
        } finally {
            document.close()
        }
        return output
    }
}
