package com.example.feature.readiness

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.core.data.PdfSelectionResolver
import com.example.feature.workflow.DEFAULT_SOURCE_MIME_TYPES
import com.example.feature.workflow.UploadSourceCopy
import com.example.feature.workflow.UploadSourceRoute
import com.example.feature.workflow.UploadSourceViewModel

/**
 * Hazırbulunuşluk uses the proven written-exam source pipeline, but the teacher-facing
 * language stays diagnostic and type-aware. Scenario/kazanım import remains available.
 */
internal val ReadinessSourceCopy = UploadSourceCopy(
    title = "Boş Hazırbulunuşluk Sınavı",
    description = "Öğrencilerin konu/ünite öncesi mevcut bilgi ve becerilerini ölçmek için hazırladığınız boş hazırbulunuşluk sınavını yükleyin. Sistem soruları ve varsa puanları çıkarır; sonraki adımda siz kontrol edersiniz.",
    emptyTitle = "Henüz hazırbulunuşluk sınavı yüklenmedi",
    emptyDescription = "PDF, Word, JPEG, PNG ve WebP dosyaları desteklenir. İsterseniz sınav metnini doğrudan yapıştırabilirsiniz. (Maks. 50 MB)",
    documentTypeLabel = "Hazırbulunuşluk Sınavı",
    readyLabel = "Hazırbulunuşluk sınavı hazır",
    unusableLabel = "Hazırbulunuşluk sınavı kullanılamıyor",
    replaceLabel = "Sınavı Değiştir",
    continueLabel = "Soruları Çıkar ve Kontrol Et"
)

@Composable
fun ReadinessSourceRoute(
    viewModel: UploadSourceViewModel,
    pdfSelectionResolver: PdfSelectionResolver,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    UploadSourceRoute(
        viewModel = viewModel,
        pdfSelectionResolver = pdfSelectionResolver,
        onContinue = onContinue,
        copy = ReadinessSourceCopy,
        showScenarioSection = true,
        allowedSourceMimeTypes = DEFAULT_SOURCE_MIME_TYPES,
        modifier = modifier
    )
}
