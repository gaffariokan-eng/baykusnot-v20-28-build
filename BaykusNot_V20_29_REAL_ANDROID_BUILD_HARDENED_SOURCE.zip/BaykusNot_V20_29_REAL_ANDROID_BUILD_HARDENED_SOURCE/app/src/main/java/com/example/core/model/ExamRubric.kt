package com.example.core.model

data class ExamRubricCriterion(
    val id: Long = 0L,
    val examDraftId: Long,
    val questionOrderIndex: Int,
    val questionNumberSnapshot: String,
    val criterionOrderIndex: Int,
    val title: String,
    val description: String,
    val maxPoints: Int,
    val expectedAnswer: String,
    val partialCreditGuidance: String = "",
    val commonMistakes: String = "",
    val originalAnswerKey: String? = null,
    val originalRubric: String? = null
)

data class ExamRubricSetMetadata(
    val examDraftId: Long,
    val questionSetRevision: Int,
    val isLocked: Boolean,
    val lockedAt: Long?,
    val revision: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val evaluationSourceType: String = "AI_GENERATED_RUBRIC",
    val originalTeacherAnswerKey: String? = null,
    val originalTeacherRubric: String? = null,
    val elaboratedAnswerKey: String? = null,
    val elaboratedRubric: String? = null,
    val isAsIs: Boolean = false
)
