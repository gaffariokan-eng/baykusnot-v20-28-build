package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.core.model.EvaluationMode
import com.example.core.model.FeedbackDetailLevel
import com.example.core.model.ModelQualityTier
import com.example.core.model.RubricAdherenceLevel
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamEvaluationPreferencesDao {

    @Query(
        """
        SELECT *
        FROM exam_evaluation_preferences
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    fun observePreferences(
        examDraftId: Long
    ): Flow<ExamEvaluationPreferencesEntity?>

    @Query(
        """
        SELECT *
        FROM exam_evaluation_preferences
        WHERE examDraftId = :examDraftId
        LIMIT 1
        """
    )
    suspend fun getPreferencesOnce(
        examDraftId: Long
    ): ExamEvaluationPreferencesEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPreferences(
        preferences: ExamEvaluationPreferencesEntity
    )

    @Query(
        """
        UPDATE exam_evaluation_preferences
        SET
            evaluationMode = :evaluationMode,
            rubricAdherenceLevel = :rubricAdherenceLevel,
            feedbackDetailLevel = :feedbackDetailLevel,
            deductWritingAndPunctuationPoints =
                :deductWritingAndPunctuationPoints,

            hasExplicitWritingPunctuationPreference =
                :hasExplicitWritingPunctuationPreference,

            provideWritingAndPunctuationFeedback =
                :provideWritingAndPunctuationFeedback,
            modelQualityTier = :modelQualityTier,
            reportClass = :reportClass,
            reportIndividual = :reportIndividual,
            reportQuestion = :reportQuestion,
            useBatchApi = :useBatchApi,
            usePromptCaching = :usePromptCaching,
            revision = revision + 1,
            updatedAt = :updatedAt
        WHERE examDraftId = :examDraftId
          AND isLocked = 0
          AND revision = :expectedRevision
        """
    )
    suspend fun updateUnlockedPreferences(
        examDraftId: Long,
        expectedRevision: Int,
        evaluationMode: EvaluationMode,
        rubricAdherenceLevel: RubricAdherenceLevel,
        feedbackDetailLevel: FeedbackDetailLevel,
        deductWritingAndPunctuationPoints: Boolean,
        hasExplicitWritingPunctuationPreference: Boolean,
        provideWritingAndPunctuationFeedback: Boolean,
        modelQualityTier: ModelQualityTier,
        reportClass: Boolean,
        reportIndividual: Boolean,
        reportQuestion: Boolean,
        useBatchApi: Boolean,
        usePromptCaching: Boolean,
        updatedAt: Long
    ): Int

    @Query(
        """
        UPDATE exam_evaluation_preferences
        SET
            isLocked = 1,
            lockedAt = :lockedAt,
            revision = revision + 1,
            updatedAt = :lockedAt
        WHERE examDraftId = :examDraftId
          AND isLocked = 0
          AND revision = :expectedRevision
        """
    )
    suspend fun lockPreferences(
        examDraftId: Long,
        expectedRevision: Int,
        lockedAt: Long
    ): Int

    @Query(
        """
        UPDATE exam_evaluation_preferences
        SET
            isLocked = 0,
            lockedAt = NULL,
            revision = revision + 1,
            updatedAt = :unlockedAt
        WHERE examDraftId = :examDraftId
          AND isLocked = 1
        """
    )
    suspend fun unlockPreferences(
        examDraftId: Long,
        unlockedAt: Long
    ): Int
    @Query(
        """
        UPDATE exam_evaluation_preferences
        SET evaluationMode = 'PAPER_BY_PAPER',
            rubricAdherenceLevel = 'BALANCED',
            modelQualityTier = 'STANDARD',
            reportClass = 1,
            reportIndividual = 1,
            reportQuestion = 1,
            useBatchApi = 0,
            usePromptCaching = 1,
            revision = revision + 1,
            updatedAt = :updatedAt
        WHERE examDraftId = :examDraftId
          AND (evaluationMode != 'PAPER_BY_PAPER'
            OR rubricAdherenceLevel != 'BALANCED'
            OR modelQualityTier != 'STANDARD'
            OR reportClass != 1
            OR reportIndividual != 1
            OR reportQuestion != 1
            OR useBatchApi != 0
            OR usePromptCaching != 1)
        """
    )
    suspend fun canonicalizeTeacherMode(examDraftId: Long, updatedAt: Long): Int


}
