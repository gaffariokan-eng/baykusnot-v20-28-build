package com.example.core.network

sealed interface ConnectionTestResult {
    data object Success : ConnectionTestResult
    data object InvalidApiKey : ConnectionTestResult
    data object RateLimited : ConnectionTestResult
    data object NoInternet : ConnectionTestResult
    data object ServiceUnavailable : ConnectionTestResult
    data object UnexpectedError : ConnectionTestResult
}

interface GeminiConnectionTester {
    suspend fun testConnection(apiKey: String): ConnectionTestResult
}
