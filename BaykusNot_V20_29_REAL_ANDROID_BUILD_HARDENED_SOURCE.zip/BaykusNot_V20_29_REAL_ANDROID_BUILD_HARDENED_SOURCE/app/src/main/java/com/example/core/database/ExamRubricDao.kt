package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamRubricDao {

    @Query("SELECT * FROM exam_rubric_set_metadata WHERE examDraftId = :examDraftId")
    fun observeMetadataByExamDraftId(
        examDraftId: Long
    ): Flow<ExamRubricSetMetadataEntity?>

    @Query("SELECT * FROM exam_rubric_set_metadata WHERE examDraftId = :examDraftId")
    suspend fun getMetadataByExamDraftIdOnce(
        examDraftId: Long
    ): ExamRubricSetMetadataEntity?

    @Query("SELECT * FROM exam_rubric_criterion WHERE examDraftId = :examDraftId ORDER BY questionOrderIndex ASC, criterionOrderIndex ASC, id ASC")
    fun observeCriteriaByExamDraftId(
        examDraftId: Long
    ): Flow<List<ExamRubricCriterionEntity>>

    @Query("SELECT * FROM exam_rubric_criterion WHERE examDraftId = :examDraftId ORDER BY questionOrderIndex ASC, criterionOrderIndex ASC, id ASC")
    suspend fun getCriteriaByExamDraftIdOnce(
        examDraftId: Long
    ): List<ExamRubricCriterionEntity>

    @Upsert
    suspend fun upsertMetadata(
        metadata: ExamRubricSetMetadataEntity
    )

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCriteria(
        criteria: List<ExamRubricCriterionEntity>
    ): List<Long>

    @Query("DELETE FROM exam_rubric_criterion WHERE examDraftId = :examDraftId")
    suspend fun deleteCriteriaByExamDraftId(
        examDraftId: Long
    ): Int

    @Query("DELETE FROM exam_rubric_set_metadata WHERE examDraftId = :examDraftId")
    suspend fun deleteMetadataByExamDraftId(
        examDraftId: Long
    ): Int

    @Transaction
    suspend fun replaceRubricForDraft(
        metadata: ExamRubricSetMetadataEntity,
        criteria: List<ExamRubricCriterionEntity>
    ) {
        deleteCriteriaByExamDraftId(metadata.examDraftId)
        upsertMetadata(metadata)
        if (criteria.isNotEmpty()) {
            insertCriteria(criteria)
        }
    }

    @Query(
        """
        UPDATE exam_rubric_set_metadata 
        SET isLocked = 1, lockedAt = :lockedAt, revision = revision + 1, updatedAt = :updatedAt 
        WHERE examDraftId = :examDraftId AND revision = :expectedRevision AND isLocked = 0
        """
    )
    suspend fun lockRubricSet(
        examDraftId: Long,
        expectedRevision: Int,
        lockedAt: Long,
        updatedAt: Long
    ): Int

    @Query(
        """
        UPDATE exam_rubric_set_metadata 
        SET isLocked = 0, lockedAt = NULL, revision = revision + 1, updatedAt = :updatedAt 
        WHERE examDraftId = :examDraftId AND revision = :expectedRevision AND isLocked = 1
        """
    )
    suspend fun unlockRubricSet(
        examDraftId: Long,
        expectedRevision: Int,
        updatedAt: Long
    ): Int

    @Query(
        """
        UPDATE exam_rubric_set_metadata
        SET
            isLocked = 1,
            lockedAt = :lockedAt,
            revision = revision + 1,
            updatedAt = :updatedAt
        WHERE
            examDraftId = :examDraftId
            AND revision = :expectedRubricRevision
            AND isLocked = 0
            AND questionSetRevision = :expectedQuestionSetRevision
            AND EXISTS (
                SELECT 1
                FROM exam_question_set_metadata
                WHERE
                    examDraftId = :examDraftId
                    AND revision = :expectedQuestionSetRevision
                    AND isLocked = 1
            )
        """
    )
    suspend fun lockRubricSetIfQuestionSetCurrent(
        examDraftId: Long,
        expectedRubricRevision: Int,
        expectedQuestionSetRevision: Int,
        lockedAt: Long,
        updatedAt: Long
    ): Int

    @Query(
        """
        INSERT OR IGNORE INTO exam_rubric_set_metadata (
            examDraftId, questionSetRevision, isLocked, lockedAt, revision, createdAt, updatedAt,
            evaluationSourceType, originalTeacherAnswerKey, originalTeacherRubric,
            elaboratedAnswerKey, elaboratedRubric, isAsIs
        )
        SELECT
            :examDraftId, :questionSetRevision, 0, NULL, 1, :createdAt, :updatedAt,
            :evaluationSourceType, :originalTeacherAnswerKey, :originalTeacherRubric,
            :elaboratedAnswerKey, :elaboratedRubric, :isAsIs
        WHERE NOT EXISTS (
            SELECT 1 FROM exam_rubric_set_metadata WHERE examDraftId = :examDraftId
        ) AND EXISTS (
            SELECT 1 FROM exam_question_set_metadata 
            WHERE examDraftId = :examDraftId AND revision = :questionSetRevision AND isLocked = 1
        )
        """
    )
    suspend fun insertInitialMetadataIfQuestionSetCurrent(
        examDraftId: Long,
        questionSetRevision: Int,
        createdAt: Long,
        updatedAt: Long,
        evaluationSourceType: String = "AI_GENERATED_RUBRIC",
        originalTeacherAnswerKey: String? = null,
        originalTeacherRubric: String? = null,
        elaboratedAnswerKey: String? = null,
        elaboratedRubric: String? = null,
        isAsIs: Boolean = false
    ): Long

    @Query(
        """
        UPDATE exam_rubric_set_metadata 
        SET
            questionSetRevision = :questionSetRevision,
            revision = revision + 1,
            updatedAt = :updatedAt,
            evaluationSourceType = :evaluationSourceType,
            originalTeacherAnswerKey = :originalTeacherAnswerKey,
            originalTeacherRubric = :originalTeacherRubric,
            elaboratedAnswerKey = :elaboratedAnswerKey,
            elaboratedRubric = :elaboratedRubric,
            isAsIs = :isAsIs
        WHERE examDraftId = :examDraftId AND revision = :expectedRubricRevision AND isLocked = 0
        AND EXISTS (
            SELECT 1 FROM exam_question_set_metadata 
            WHERE examDraftId = :examDraftId AND revision = :questionSetRevision AND isLocked = 1
        )
        """
    )
    suspend fun updateMetadataForSaveIfCurrent(
        examDraftId: Long,
        expectedRubricRevision: Int,
        questionSetRevision: Int,
        updatedAt: Long,
        evaluationSourceType: String = "AI_GENERATED_RUBRIC",
        originalTeacherAnswerKey: String? = null,
        originalTeacherRubric: String? = null,
        elaboratedAnswerKey: String? = null,
        elaboratedRubric: String? = null,
        isAsIs: Boolean = false
    ): Int

    @Transaction
    suspend fun replaceRubricForDraftIfCurrent(
        metadata: ExamRubricSetMetadataEntity,
        expectedRubricRevision: Int,
        criteria: List<ExamRubricCriterionEntity>
    ): Int {
        if (expectedRubricRevision < 0) return 0
        
        val success = if (expectedRubricRevision == 0) {
            val rowId = insertInitialMetadataIfQuestionSetCurrent(
                examDraftId = metadata.examDraftId,
                questionSetRevision = metadata.questionSetRevision,
                createdAt = metadata.createdAt,
                updatedAt = metadata.updatedAt,
                evaluationSourceType = metadata.evaluationSourceType,
                originalTeacherAnswerKey = metadata.originalTeacherAnswerKey,
                originalTeacherRubric = metadata.originalTeacherRubric,
                elaboratedAnswerKey = metadata.elaboratedAnswerKey,
                elaboratedRubric = metadata.elaboratedRubric,
                isAsIs = metadata.isAsIs
            )
            rowId != -1L && rowId != 0L
        } else {
            val rows = updateMetadataForSaveIfCurrent(
                examDraftId = metadata.examDraftId,
                expectedRubricRevision = expectedRubricRevision,
                questionSetRevision = metadata.questionSetRevision,
                updatedAt = metadata.updatedAt,
                evaluationSourceType = metadata.evaluationSourceType,
                originalTeacherAnswerKey = metadata.originalTeacherAnswerKey,
                originalTeacherRubric = metadata.originalTeacherRubric,
                elaboratedAnswerKey = metadata.elaboratedAnswerKey,
                elaboratedRubric = metadata.elaboratedRubric,
                isAsIs = metadata.isAsIs
            )
            rows == 1
        }
        
        if (!success) return 0
        
        deleteCriteriaByExamDraftId(metadata.examDraftId)
        if (criteria.isNotEmpty()) {
            insertCriteria(criteria)
        }
        return 1
    }
}
