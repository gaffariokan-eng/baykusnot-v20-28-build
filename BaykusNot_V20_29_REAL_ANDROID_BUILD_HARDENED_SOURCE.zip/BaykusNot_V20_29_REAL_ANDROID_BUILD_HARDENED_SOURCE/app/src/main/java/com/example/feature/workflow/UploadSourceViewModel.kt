package com.example.feature.workflow

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.data.ExamDraftRepository
import com.example.core.data.ExamSourceDocumentRepository
import com.example.core.data.ExamSourceImportFailure
import com.example.core.data.ExamSourceImportResult
import com.example.core.database.ExamSourceDocumentEntity
import com.example.core.data.ExamQuestionExtractionCoordinator
import com.example.core.data.ExamQuestionExtractionCoordinatorResult
import com.example.core.network.ExamExtractionInput
import com.example.core.model.ExamType
import com.example.core.model.WorkflowStage
import java.io.InputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UploadSourceUiState(
    val isLoading: Boolean = true,
    val draftExists: Boolean? = null,
    val document: ExamSourceDocumentEntity? = null,
    val isDocumentUsable: Boolean = false,
    val isImporting: Boolean = false,
    val isRemoving: Boolean = false,
    val isExtracting: Boolean = false,
    val scenarioObjectives: List<com.example.core.database.ExamObjectiveEntity>? = null,
    val extractedScenarioPreview: List<com.example.core.database.ExamObjectiveEntity>? = null,
    val isExtractingScenario: Boolean = false,
    val requiresQuestionReset: Boolean = false,
    val draft: com.example.core.database.ExamDraftEntity? = null,
    val message: String? = null
)

class UploadSourceViewModel(
    private val examDraftRepository: ExamDraftRepository,
    private val sourceDocumentRepository: ExamSourceDocumentRepository,
    private val coordinator: ExamQuestionExtractionCoordinator,
    private val questionRepository: com.example.core.data.ExamQuestionRepository,
    private val objectiveRepository: com.example.core.data.ExamObjectiveRepository,
    private val scenarioExtractor: com.example.core.network.ExamScenarioExtractor,
    private val draftId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(UploadSourceUiState())
    val uiState: StateFlow<UploadSourceUiState> = _uiState.asStateFlow()
    private var questionExtractionJob: Job? = null
    private var scenarioExtractionJob: Job? = null
    private var sourceImportJob: Job? = null

    fun cancelActiveAuthoringWork() {
        questionExtractionJob?.cancel()
        scenarioExtractionJob?.cancel()
        sourceImportJob?.cancel()
    }

    init {
        viewModelScope.launch {
            try {
                val draft = examDraftRepository.getDraftByIdOnce(draftId)
                if (draft == null) {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            draftExists = false,
                            document = null,
                            isDocumentUsable = false,
                            isImporting = false,
                            isRemoving = false,
                            message = if (_uiState.value.draft?.examType == ExamType.HOMEWORK) "Ödev kontrolü taslağı bulunamadı." else "Sınav taslağı bulunamadı."
                        )
                    }
                } else {
                    _uiState.update { it.copy(draftExists = true) }
                    viewModelScope.launch {
                        examDraftRepository.getDraftById(draftId).collect { draft ->
                            if (draft?.currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE) {
                                cancelActiveAuthoringWork()
                            }
                            _uiState.update { it.copy(draft = draft) }
                        }
                    }
                    viewModelScope.launch {
                        objectiveRepository.observeApprovedObjectivesByDraftId(draftId).collect { obs ->
                            _uiState.update { it.copy(scenarioObjectives = obs) }
                        }
                    }
                    viewModelScope.launch {
                        objectiveRepository.observeStagingObjectivesByDraftId(draftId).collect { obs ->
                            _uiState.update { it.copy(extractedScenarioPreview = obs) }
                        }
                    }
                    var firstEmission = true
                    sourceDocumentRepository.observeByExamDraftId(draftId)
                        .catch { 
                            _uiState.update { state ->
                                state.copy(
                                    isLoading = false,
                                    draftExists = true,
                                    isDocumentUsable = false,
                                    message = "Kaynak dosyası okunamadı."
                                )
                            }
                        }
                        .collect { document ->
                            val usable = if (document != null) {
                                sourceDocumentRepository.isUsable(document)
                            } else {
                                false
                            }
                            _uiState.update {
                                it.copy(
                                    document = document,
                                    isDocumentUsable = usable,
                                    isLoading = if (firstEmission) false else it.isLoading
                                )
                            }
                            firstEmission = false
                        }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        draftExists = true,
                        isDocumentUsable = false,
                        message = "Kaynak dosyası okunamadı."
                    )
                }
            }
        }
    }

    fun importDocument(
        originalUri: String?,
        displayName: String,
        mimeType: String,
        declaredSizeBytes: Long?,
        openInputStream: () -> InputStream?,
        onFinished: (() -> Unit)? = null
    ) {
        if (uiState.value.isLoading || uiState.value.draftExists != true || uiState.value.isImporting || uiState.value.isRemoving || uiState.value.isExtracting) {
            onFinished?.invoke()
            return
        }

        _uiState.update { it.copy(isImporting = true, message = null) }

        val job = viewModelScope.launch {
            try {
                val previousFingerprint = uiState.value.document?.sha256
                val result = sourceDocumentRepository.importDocument(
                    examDraftId = draftId,
                    originalUri = originalUri,
                    displayName = displayName,
                    mimeType = mimeType,
                    declaredSizeBytes = declaredSizeBytes,
                    openInputStream = openInputStream
                )

                when (result) {
                    is ExamSourceImportResult.Success -> {
                        val usable = sourceDocumentRepository.isUsable(result.document)
                        val sourceChanged = when {
                            previousFingerprint == null -> !result.reusedExisting
                            else -> previousFingerprint != result.document.sha256
                        }
                        val resetOk = if (sourceChanged) questionRepository.invalidateUnlockedQuestionSet(draftId) else true
                        val msg = when {
                            !resetOk -> "Kaynak değişti ancak eski soru yapısı güvenli biçimde geçersizleştirilemedi. Soruları çıkarmadan önce yeniden deneyin."
                            result.reusedExisting -> "Bu dosya zaten yüklenmiş."
                            result.replacedExisting -> "Dosya değiştirildi."
                            else -> "Dosya yüklendi."
                        }
                        _uiState.update {
                            it.copy(
                                document = result.document,
                                isDocumentUsable = usable,
                                requiresQuestionReset = sourceChanged && !resetOk,
                                isImporting = false,
                                message = msg
                            )
                        }
                    }
                    is ExamSourceImportResult.Failure -> {
                        if (result.reason == ExamSourceImportFailure.DRAFT_NOT_FOUND) {
                            _uiState.update {
                                it.copy(
                                    isLoading = false,
                                    draftExists = false,
                                    document = null,
                                    isDocumentUsable = false,
                                    isImporting = false,
                                    isRemoving = false,
                                    message = if (_uiState.value.draft?.examType == ExamType.HOMEWORK) "Ödev kontrolü taslağı bulunamadı." else "Sınav taslağı bulunamadı."
                                )
                            }
                        } else {
                            _uiState.update {
                                it.copy(
                                    isImporting = false,
                                    message = messageFor(result.reason)
                                )
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        message = "Beklenmeyen bir hata oluştu."
                    )
                }
            }
        }
        sourceImportJob = job
        job.invokeOnCompletion {
            if (sourceImportJob === job) sourceImportJob = null
            onFinished?.invoke()
            _uiState.update { it.copy(isImporting = false) }
        }
    }

    fun removeSource() {
        if (uiState.value.isLoading || uiState.value.draftExists != true || uiState.value.isImporting || uiState.value.isRemoving || uiState.value.isExtracting || uiState.value.document == null) {
            return
        }

        _uiState.update { it.copy(isRemoving = true, message = null) }

        viewModelScope.launch {
            try {
                if (!questionRepository.invalidateUnlockedQuestionSet(draftId)) {
                    _uiState.update { it.copy(isRemoving = false, message = "Eski soru yapısı güvenli biçimde geçersizleştirilemediği için kaynak kaldırılmadı.") }
                    return@launch
                }
                val success = sourceDocumentRepository.removeByExamDraftId(draftId)
                if (success) {
                    val draft = examDraftRepository.getDraftByIdOnce(draftId)
                    if (draft == null) {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                draftExists = false,
                                document = null,
                                isDocumentUsable = false,
                                isImporting = false,
                                isRemoving = false,
                                message = if (_uiState.value.draft?.examType == ExamType.HOMEWORK) "Ödev kontrolü taslağı bulunamadı." else "Sınav taslağı bulunamadı."
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                document = null,
                                isDocumentUsable = false,
                                isRemoving = false,
                                message = "Kaynak kaldırıldı."
                            )
                        }
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isRemoving = false,
                            message = "Kaynak kaldırılamadı."
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isRemoving = false,
                        message = "Kaynak kaldırılamadı."
                    )
                }
            }
        }
    }

    fun extractQuestions(
        onReviewableResult: () -> Unit
    ) {
        val state = uiState.value
        if (state.isLoading || state.draftExists != true || state.document == null || !state.isDocumentUsable || state.isImporting || state.isRemoving || state.isExtracting) {
            return
        }

        _uiState.update { it.copy(isExtracting = true, message = null) }

        val job = viewModelScope.launch {
            val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
            if (latestDraft?.currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE) {
                _uiState.update { it.copy(message = "Soru çıkarma yalnız Kaynak Yükleme aşamasında yapılabilir.") }
                return@launch
            }
            if (uiState.value.requiresQuestionReset) {
                if (!questionRepository.invalidateUnlockedQuestionSet(draftId)) {
                    _uiState.update { it.copy(isExtracting = false, message = "Eski soru yapısı güvenli biçimde geçersizleştirilemedi. Sorular çıkarılmadı.") }
                    return@launch
                }
                _uiState.update { it.copy(requiresQuestionReset = false) }
            }
            val document = uiState.value.document
            if (document == null || !sourceDocumentRepository.isUsable(document)) {
                _uiState.update {
                    it.copy(
                        isExtracting = false,
                        message = "Kaynak okunamadı."
                    )
                }
                return@launch
            }

            val bytes = sourceDocumentRepository.readManagedBytes(document)
            if (bytes == null) {
                _uiState.update {
                    it.copy(
                        isExtracting = false,
                        message = "Kaynak okunamadı."
                    )
                }
                return@launch
            }

            val inputType = when (document.mimeType) {
                com.example.core.data.ExamSourceDocumentRepository.WORD_MIME_TYPE -> {
                    try {
                        com.example.core.data.DocxParser.parse(bytes)
                    } catch (e: Exception) {
                        _uiState.update { 
                            it.copy(
                                isExtracting = false,
                                message = "Word belgesi güvenilir biçimde okunamadı."
                            )
                        }
                        return@launch
                    }
                }
                com.example.core.data.ExamSourceDocumentRepository.TEXT_MIME_TYPE -> ExamExtractionInput.Text(String(bytes))
                com.example.core.data.ExamSourceDocumentRepository.ZIP_MIME_TYPE -> {
                    val images = mutableListOf<Pair<String, com.example.core.network.ExamExtractionImage>>()
                    try {
                        var totalBytes = 0L
                        java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { zis ->
                            var entry = zis.nextEntry
                            while (entry != null) {
                                if (entry.isDirectory) throw IllegalArgumentException("ZIP içinde klasör desteklenmiyor")
                                if (images.size >= 100) throw IllegalArgumentException("ZIP en fazla 100 görsel içerebilir")
                                val ext = entry.name.substringAfterLast(".", "").lowercase()
                                val mime = when (ext) {
                                    "png" -> "image/png"
                                    "webp" -> "image/webp"
                                    "jpg", "jpeg" -> "image/jpeg"
                                    else -> throw IllegalArgumentException("ZIP içinde desteklenmeyen dosya türü var")
                                }
                                val out = java.io.ByteArrayOutputStream()
                                val buffer = ByteArray(64 * 1024)
                                var entryBytes = 0L
                                while (true) {
                                    val read = zis.read(buffer)
                                    if (read < 0) break
                                    entryBytes += read
                                    totalBytes += read
                                    if (entryBytes > 20L * 1024L * 1024L || totalBytes > 50L * 1024L * 1024L) {
                                        throw IllegalArgumentException("ZIP açılmış veri boyutu güvenlik sınırını aşıyor")
                                    }
                                    out.write(buffer, 0, read)
                                }
                                if (entryBytes <= 0L) throw IllegalArgumentException("ZIP içinde boş görsel var")
                                images.add(entry.name to com.example.core.network.ExamExtractionImage(out.toByteArray(), mime))
                                zis.closeEntry()
                                entry = zis.nextEntry
                            }
                        }
                        if (images.isEmpty()) throw IllegalArgumentException("ZIP içinde geçerli görsel yok")
                    } catch (e: Exception) {
                        _uiState.update { it.copy(isExtracting = false, message = "Görsel paketi güvenli biçimde okunamadı: ${e.message ?: "Geçersiz ZIP"}") }
                        return@launch
                    }
                    ExamExtractionInput.Images(images.sortedBy { it.first }.map { it.second })
                }
                else -> {
                    if (document.mimeType.startsWith("image/")) {
                        ExamExtractionInput.Images(listOf(com.example.core.network.ExamExtractionImage(bytes, document.mimeType)))
                    } else {
                        ExamExtractionInput.Pdf(bytes)
                    }
                }
            }
            val currentExamType = _uiState.value.draft?.examType ?: ExamType.WRITTEN
            val isHomework = currentExamType == ExamType.HOMEWORK
            val result = coordinator.process(
                examDraftId = draftId,
                sourceFingerprint = document.sha256,
                input = inputType,
                examType = currentExamType
            )

            when (result) {
                is ExamQuestionExtractionCoordinatorResult.Promoted,
                is ExamQuestionExtractionCoordinatorResult.Staged,
                is ExamQuestionExtractionCoordinatorResult.ExistingCanonicalEquivalent -> {
                    _uiState.update { it.copy(isExtracting = false) }
                    onReviewableResult()
                }
                is ExamQuestionExtractionCoordinatorResult.MissingApiKey -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Yapay zekâ bağlantısı için API anahtarı gerekli."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.Unauthorized -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "API anahtarı geçersiz veya yetkisiz."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.NetworkFailure -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Bağlantı kurulamadı. İnternet bağlantısını kontrol edip yeniden deneyin."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.RateLimited -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Yapay zekâ hizmeti şu anda yoğun. Bir süre sonra yeniden deneyin."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.ServiceUnavailable -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Yapay zekâ hizmetine şu anda ulaşılamıyor."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.NoQuestionsFound -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Ödev kaynağında değerlendirilebilir görev/madde bulunamadı. Kaynağı kontrol edip yeniden deneyin." else "Dosya içinde soru bulunamadı. Dosyayı kontrol edip yeniden deneyin."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.MalformedResponse -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Görev/maddeler güvenilir biçimde çıkarılamadı. Yeniden deneyin." else "Sorular güvenilir biçimde çıkarılamadı. Yeniden deneyin."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.LockedCanonical,
                is ExamQuestionExtractionCoordinatorResult.PromotionLocked -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Ödev görev/maddeleri kilitlendiği için değiştirilemez." else "Sınav kilitlendiği için sorular değiştirilemez."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.InvalidArguments -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Geçersiz istek."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.InvalidInput -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Geçersiz dosya."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.PromotionDraftNotFound -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (_uiState.value.draft?.examType == ExamType.HOMEWORK) "Ödev kontrolü taslağı bulunamadı." else "Sınav taslağı bulunamadı."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.PromotionValidationFailed -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Görev/madde puanları doğrulaması başarısız oldu." else "Soru puanları doğrulaması başarısız oldu."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.PromotionRevisionConflict -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Çakışma oluştu. Ödev görev/maddeleri güncellenmiş olabilir." else "Çakışma oluştu. Sınav güncellenmiş olabilir."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.PromotionFailure -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = if (isHomework) "Görev/maddeler kaydedilemedi." else "Sorular kaydedilemedi."
                        )
                    }
                }
                is ExamQuestionExtractionCoordinatorResult.UnexpectedFailure -> {
                    _uiState.update {
                        it.copy(
                            isExtracting = false,
                            message = "Beklenmeyen bir hata oluştu."
                        )
                    }
                }
            }
        }
        questionExtractionJob = job
        job.invokeOnCompletion {
            if (questionExtractionJob === job) questionExtractionJob = null
            _uiState.update { it.copy(isExtracting = false) }
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }

    private fun messageFor(failure: ExamSourceImportFailure): String {
        return when (failure) {
            ExamSourceImportFailure.DRAFT_NOT_FOUND -> "Sınav taslağı bulunamadı."
            ExamSourceImportFailure.UNSUPPORTED_MIME_TYPE -> "Desteklenmeyen dosya türü."
            ExamSourceImportFailure.SOURCE_UNAVAILABLE -> "Seçilen dosya açılamadı."
            ExamSourceImportFailure.EMPTY_FILE -> "Seçilen dosya boş."
            ExamSourceImportFailure.FILE_TOO_LARGE -> "Metin kaynakları en fazla 2 MB, diğer kaynaklar en fazla 50 MB olabilir."
            ExamSourceImportFailure.INVALID_PDF -> "Şifreli, bozuk veya geçersiz dosyalar desteklenmemektedir."
            ExamSourceImportFailure.STORAGE_ERROR -> "Dosya cihazda saklanamadı."
            ExamSourceImportFailure.DATABASE_ERROR -> "Dosya bilgileri kaydedilemedi."
        }
    }

    fun extractScenario(mimeType: String, openInputStream: () -> java.io.InputStream?) {
        if (uiState.value.isExtractingScenario) return
        _uiState.update { it.copy(isExtractingScenario = true, message = "Senaryo inceleniyor...") }
        val job = viewModelScope.launch {
            try {
                val latestDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (latestDraft?.currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE) {
                    _uiState.update { it.copy(message = "Senaryo çıkarma yalnız Kaynak Yükleme aşamasında yapılabilir.") }
                    return@launch
                }
                val bytes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    openInputStream()?.use { com.example.core.security.BoundedInputReader.read(it, com.example.core.security.BoundedInputReader.MAX_DOCUMENT_BYTES, "Senaryo dosyası") }
                }
                if (bytes == null) {
                    _uiState.update { it.copy(isExtractingScenario = false, message = "Senaryo dosyası okunamadı.") }
                    return@launch
                }
                val input = if (mimeType.contains("pdf")) {
                    com.example.core.network.ExamExtractionInput.Pdf(bytes)
                } else if (mimeType.contains("image")) {
                    com.example.core.network.ExamExtractionInput.Images(listOf(com.example.core.network.ExamExtractionImage(bytes, mimeType)))
                } else {
                    com.example.core.network.ExamExtractionInput.Text(String(bytes))
                }
                val currentExamType = _uiState.value.draft?.examType ?: ExamType.WRITTEN
                val result = scenarioExtractor.extract(draftId, input, currentExamType)
                if (result is com.example.core.network.ExamScenarioExtractionResult.Success) {
                    val stageDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    if (stageDraft?.currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE) {
                        return@launch
                    }
                    objectiveRepository.replaceStagingObjectivesForDraft(draftId, result.objectives)
                    val currentDraft = examDraftRepository.getDraftByIdOnce(draftId)
                    if (currentDraft != null) {
                        val meta = result.metadata
                        examDraftRepository.updateDraft(currentDraft.copy(
                            stagingCourseName = meta?.courseName,
                            stagingGradeLevel = meta?.gradeLevel,
                            stagingTerm = meta?.term,
                            stagingExamSequenceNumber = meta?.examSequenceNumber
                        ))
                    }
                    _uiState.update { it.copy(isExtractingScenario = false, message = "Senaryo başarıyla çıkarıldı.") }
                } else {
                    _uiState.update { it.copy(isExtractingScenario = false, message = "Senaryo çıkarılamadı.") }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(isExtractingScenario = false, message = "Hata: ${e.message}") }
            } finally {
                _uiState.update { it.copy(isExtractingScenario = false) }
            }
        }
        scenarioExtractionJob = job
        job.invokeOnCompletion {
            if (scenarioExtractionJob === job) scenarioExtractionJob = null
            _uiState.update { it.copy(isExtractingScenario = false) }
        }
    }
    fun confirmScenario() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val staging = objectiveRepository.getStagingObjectivesByDraftId(draftId)
                if (staging.isEmpty()) {
                    withContext(Dispatchers.Main) { _uiState.update { it.copy(message = "Onaylanacak senaryo bulunamadı.") } }
                    return@launch
                }
                for (obj in staging) {
                    if (obj.objectiveText.isBlank()) {
                        val label = if (_uiState.value.draft?.examType == ExamType.READINESS) "Ön koşul bilgi/beceri hedefi" else "Kazanım"
                        withContext(Dispatchers.Main) { _uiState.update { it.copy(message = "$label metni boş olamaz.") } }
                        return@launch
                    }
                    if (obj.expectedQuestionCount != null && obj.expectedQuestionCount < 0) {
                        withContext(Dispatchers.Main) { _uiState.update { it.copy(message = "Beklenen soru sayısı negatif olamaz.") } }
                        return@launch
                    }
                }
                objectiveRepository.approveStagingObjectivesAndDraft(draftId)
                val currentDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (currentDraft != null) {
                    examDraftRepository.updateDraft(currentDraft.copy(
                        approvedCourseName = currentDraft.stagingCourseName,
                        approvedGradeLevel = currentDraft.stagingGradeLevel,
                        approvedTerm = currentDraft.stagingTerm,
                        approvedExamSequenceNumber = currentDraft.stagingExamSequenceNumber
                    ))
                }
                withContext(Dispatchers.Main) { _uiState.update { it.copy(message = "Senaryo onaylandı.") } }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { _uiState.update { it.copy(message = "Onaylanırken hata oluştu.") } }
            }
        }
    }
    fun clearScenarioPreview() {
        viewModelScope.launch {
            try {
                objectiveRepository.replaceStagingObjectivesForDraft(draftId, emptyList())
                val currentDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (currentDraft != null) {
                    examDraftRepository.updateDraft(currentDraft.copy(
                        stagingCourseName = null,
                        stagingGradeLevel = null,
                        stagingTerm = null,
                        stagingExamSequenceNumber = null
                    ))
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "Senaryo önizlemesi temizlenemedi: ${e.message ?: "Bilinmeyen hata"}") }
            }
        }
    }
    fun removeScenario() {
        viewModelScope.launch {
            try {
                objectiveRepository.replaceObjectivesForDraft(draftId, emptyList())
                objectiveRepository.replaceStagingObjectivesForDraft(draftId, emptyList())
                objectiveRepository.replaceQuestionObjectiveCrossRefsForDraft(draftId, emptyList())
                val currentDraft = examDraftRepository.getDraftByIdOnce(draftId)
                if (currentDraft != null) {
                    examDraftRepository.updateDraft(currentDraft.copy(
                        hasScenario = false, 
                        isScenarioApproved = false,
                        isObjectiveMappingApproved = false,
                        isMismatchAccepted = false,
                        stagingCourseName = null,
                        stagingGradeLevel = null,
                        stagingTerm = null,
                        stagingExamSequenceNumber = null,
                        approvedCourseName = null,
                        approvedGradeLevel = null,
                        approvedTerm = null,
                        approvedExamSequenceNumber = null
                    ))
                }
                _uiState.update { it.copy(message = "Senaryo temizlendi.") }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "Senaryo temizlenemedi: ${e.message ?: "Bilinmeyen hata"}") }
            }
        }
    }

    fun updateStagingObjective(objective: com.example.core.database.ExamObjectiveEntity) {
        viewModelScope.launch {
            try {
                // To update one, we can just replace the whole list? No, we need an update method in DAO or we can just fetch, replace, insert.
                // Wait, objectiveRepository doesn't have updateStagingObjective, but we can just use `insertObjectives` in DAO if we add it to repository.
                // It's easier to just fetch all staging, replace the one, and save again. Or just update it via Dao.
                val currentStaging = objectiveRepository.getStagingObjectivesByDraftId(draftId).toMutableList()
                val index = currentStaging.indexOfFirst { it.id == objective.id }
                if (index != -1) {
                    currentStaging[index] = objective.copy(isStaging = true)
                    objectiveRepository.replaceStagingObjectivesForDraft(draftId, currentStaging)
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "Kazanım güncellenemedi: ${e.message ?: "Bilinmeyen hata"}") }
            }
        }
    }

    fun addStagingObjective(objective: com.example.core.database.ExamObjectiveEntity) {
        viewModelScope.launch {
            try {
                val currentStaging = objectiveRepository.getStagingObjectivesByDraftId(draftId).toMutableList()
                currentStaging.add(objective.copy(id = 0, isStaging = true, examDraftId = draftId))
                objectiveRepository.replaceStagingObjectivesForDraft(draftId, currentStaging)
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "Kazanım eklenemedi: ${e.message ?: "Bilinmeyen hata"}") }
            }
        }
    }

    fun deleteStagingObjective(objectiveId: Long) {
        viewModelScope.launch {
            try {
                val currentStaging = objectiveRepository.getStagingObjectivesByDraftId(draftId).toMutableList()
                currentStaging.removeAll { it.id == objectiveId }
                objectiveRepository.replaceStagingObjectivesForDraft(draftId, currentStaging)
            } catch (e: Exception) {
                _uiState.update { it.copy(message = "Kazanım silinemedi: ${e.message ?: "Bilinmeyen hata"}") }
            }
        }
    }

    class Factory(
        private val examDraftRepository: com.example.core.data.ExamDraftRepository,
        private val sourceDocumentRepository: com.example.core.data.ExamSourceDocumentRepository,
        private val draftId: Long,
        private val coordinator: com.example.core.data.ExamQuestionExtractionCoordinator,
        private val questionRepository: com.example.core.data.ExamQuestionRepository,
        private val objectiveRepository: com.example.core.data.ExamObjectiveRepository,
        private val scenarioExtractor: com.example.core.network.ExamScenarioExtractor
    ) : androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            return UploadSourceViewModel(
                examDraftRepository = examDraftRepository,
                sourceDocumentRepository = sourceDocumentRepository,
                coordinator = coordinator,
                questionRepository = questionRepository,
                objectiveRepository = objectiveRepository,
                scenarioExtractor = scenarioExtractor,
                draftId = draftId
            ) as T
        }
    }
}
