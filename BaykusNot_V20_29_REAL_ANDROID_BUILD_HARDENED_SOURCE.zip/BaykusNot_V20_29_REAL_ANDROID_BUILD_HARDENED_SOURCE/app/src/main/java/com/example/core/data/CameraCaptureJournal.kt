package com.example.core.data

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.util.UUID

/**
 * Process-death-safe journal for the temporary plaintext JPEG created by TakePicture.
 * The marker contains only a generated cache filename, never student identity/content.
 */
object CameraCaptureJournal {
    private const val DIRECTORY = "paper_camera"
    private const val MARKER = ".active_capture"
    private const val STALE_AGE_MS = 2L * 60L * 60L * 1000L

    private fun directory(context: Context): File =
        File(context.cacheDir, DIRECTORY).apply { mkdirs() }

    private fun markerFile(context: Context): File = File(directory(context), MARKER)

    fun currentCapture(context: Context): File? {
        val atomic = AtomicFile(markerFile(context))
        val name = runCatching {
            atomic.openRead().bufferedReader(Charsets.UTF_8).use { it.readLine()?.trim() }
        }.getOrNull().orEmpty()
        if (name.isBlank() || name.contains('/') || name.contains('\\')) {
            clear(context)
            return null
        }
        val dir = directory(context).canonicalFile
        val candidate = File(dir, name).canonicalFile
        if (candidate.parentFile != dir || !candidate.name.startsWith("paper_camera_") || !candidate.name.endsWith(".jpg")) {
            clear(context)
            return null
        }
        if (!candidate.exists()) {
            clear(context)
            return null
        }
        if (System.currentTimeMillis() - candidate.lastModified() >= STALE_AGE_MS) {
            scrubPlaintext(candidate)
            clear(context)
            return null
        }
        return candidate
    }


    /**
     * App-process startup recovery. A TakePicture capture cannot safely continue across process
     * death, therefore every leftover plaintext camera JPEG is scrubbed immediately, regardless of
     * age, and the marker is cleared.
     */
    fun cleanupAfterProcessStart(context: Context): Boolean {
        var complete = true
        directory(context).listFiles()
            ?.filter { it.isFile && it.name.startsWith("paper_camera_") && it.name.endsWith(".jpg") }
            ?.forEach { leftover ->
                if (!scrubPlaintext(leftover)) complete = false
            }
        clear(context)
        cleanupStaleUntracked(context)
        return complete
    }

    fun prepareCapture(context: Context): Result<File> = runCatching {
        currentCapture(context)?.let { previous ->
            check(scrubPlaintext(previous)) {
                "Önceki yarım kamera çekimi güvenli biçimde temizlenemedi."
            }
            clear(context)
        }
        cleanupStaleUntracked(context)
        val file = File(directory(context), "paper_camera_${UUID.randomUUID()}.jpg")
        writeMarker(context, file)
        file
    }

    fun clearIfMatches(context: Context, file: File?) {
        if (file == null) return
        val active = currentCapture(context)
        if (active == null || runCatching { active.canonicalPath == file.canonicalPath }.getOrDefault(false)) {
            clear(context)
        }
    }

    fun clear(context: Context) {
        val atomic = AtomicFile(markerFile(context))
        runCatching { atomic.delete() }
    }

    fun scrubPlaintext(file: File): Boolean {
        if (!file.exists()) return true
        if (file.delete()) return true
        return runCatching {
            file.outputStream().use { it.flush() }
            file.length() == 0L && (file.delete() || file.length() == 0L)
        }.getOrDefault(false)
    }

    fun cleanupStaleUntracked(context: Context, nowMs: Long = System.currentTimeMillis()) {
        val activePath = currentCapture(context)?.let { runCatching { it.canonicalPath }.getOrNull() }
        directory(context).listFiles()
            ?.filter { it.isFile && it.name != MARKER }
            ?.filter { file -> runCatching { file.canonicalPath != activePath }.getOrDefault(true) }
            ?.filter { file -> nowMs - file.lastModified() >= STALE_AGE_MS }
            ?.forEach { stale ->
                // Stale cache data must not remain readable indefinitely. Do not crash app startup;
                // a file that cannot be removed is never accepted as an active capture.
                scrubPlaintext(stale)
            }
    }

    private fun writeMarker(context: Context, file: File) {
        val dir = directory(context).canonicalFile
        val canonical = file.canonicalFile
        require(canonical.parentFile == dir && canonical.name.startsWith("paper_camera_") && canonical.name.endsWith(".jpg")) {
            "Geçersiz kamera geçici dosyası."
        }
        val atomic = AtomicFile(markerFile(context))
        val out = atomic.startWrite()
        try {
            out.write((canonical.name + "\n").toByteArray(Charsets.UTF_8))
            out.fd.sync()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }
}
