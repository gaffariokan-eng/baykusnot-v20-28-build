package com.example.feature.workflow

import com.example.core.model.ExamQuestion
import com.example.core.model.ExamQuestionSetMetadata
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.ExamRubricSetMetadata
import com.example.core.model.ExamRubricValidationResult
import com.example.core.model.ExamRubricValidator

data class RubricFormEvaluation(
    val domainCriteria: List<ExamRubricCriterion>?,
    val inputIssues: List<RubricInputIssue>,
    val saveValidation: ExamRubricValidationResult?,
    val currentValidation: ExamRubricValidationResult?,
    val calculatedPointsByQuestionOrder: Map<Int, Long>,
    val canSave: Boolean,
    val canLock: Boolean
)

object RubricFormEvaluator {

    fun evaluate(
        examDraftId: Long,
        questions: List<ExamQuestion>,
        questionSetMetadata: ExamQuestionSetMetadata?,
        rubricMetadata: ExamRubricSetMetadata?,
        editableCriteria: List<EditableExamRubricCriterion>,
        hasUnsavedChanges: Boolean
    ): RubricFormEvaluation {

        val inputIssues = mutableListOf<RubricInputIssue>()
        val calculatedPointsByQuestionOrder = linkedMapOf<Int, Long>()
        val domainCriteria = mutableListOf<ExamRubricCriterion>()

        for (editable in editableCriteria) {
            when (val parseResult = RubricMaxPointsInputParser.parse(editable.maxPointsText)) {
                is RubricMaxPointsParseResult.Parsed -> {
                    val currentPoints = calculatedPointsByQuestionOrder[editable.questionOrderIndex] ?: 0L
                    calculatedPointsByQuestionOrder[editable.questionOrderIndex] = currentPoints + parseResult.maxPoints

                    domainCriteria.add(
                        ExamRubricCriterion(
                            id = editable.persistedId,
                            examDraftId = examDraftId,
                            questionOrderIndex = editable.questionOrderIndex,
                            questionNumberSnapshot = editable.questionNumberSnapshot,
                            criterionOrderIndex = editable.criterionOrderIndex,
                            title = editable.title,
                            description = editable.description,
                            maxPoints = parseResult.maxPoints,
                            expectedAnswer = editable.expectedAnswer,
                            partialCreditGuidance = editable.partialCreditGuidance,
                            commonMistakes = editable.commonMistakes
                        )
                    )
                }
                is RubricMaxPointsParseResult.Rejected -> {
                    inputIssues.add(
                        RubricInputIssue(
                            localId = editable.localId,
                            code = parseResult.code
                        )
                    )
                }
            }
        }

        if (inputIssues.isNotEmpty()) {
            return RubricFormEvaluation(
                domainCriteria = null,
                inputIssues = inputIssues,
                saveValidation = null,
                currentValidation = null,
                calculatedPointsByQuestionOrder = calculatedPointsByQuestionOrder,
                canSave = false,
                canLock = false
            )
        }

        if (questionSetMetadata == null) {
            return RubricFormEvaluation(
                domainCriteria = domainCriteria,
                inputIssues = inputIssues,
                saveValidation = null,
                currentValidation = null,
                calculatedPointsByQuestionOrder = calculatedPointsByQuestionOrder,
                canSave = false,
                canLock = false
            )
        }

        val candidateMetadata = rubricMetadata?.copy(
            examDraftId = examDraftId,
            questionSetRevision = questionSetMetadata.revision,
            isLocked = false,
            lockedAt = null
        ) ?: ExamRubricSetMetadata(
            examDraftId = examDraftId,
            questionSetRevision = questionSetMetadata.revision,
            isLocked = false,
            lockedAt = null,
            revision = 1,
            createdAt = 0L,
            updatedAt = 0L
        )

        val saveValidation = ExamRubricValidator.validate(
            targetDraftId = examDraftId,
            questions = questions,
            questionSetRevision = questionSetMetadata.revision,
            questionSetLocked = questionSetMetadata.isLocked,
            rubricMetadata = candidateMetadata,
            criteria = domainCriteria
        )

        val currentValidation = if (rubricMetadata != null) {
            ExamRubricValidator.validate(
                targetDraftId = examDraftId,
                questions = questions,
                questionSetRevision = questionSetMetadata.revision,
                questionSetLocked = questionSetMetadata.isLocked,
                rubricMetadata = rubricMetadata,
                criteria = domainCriteria
            )
        } else null

        val canSave = rubricMetadata?.isLocked != true && saveValidation.isValid

        val canLock = rubricMetadata != null &&
                !rubricMetadata.isLocked &&
                !hasUnsavedChanges &&
                currentValidation?.isValid == true

        return RubricFormEvaluation(
            domainCriteria = domainCriteria,
            inputIssues = inputIssues,
            saveValidation = saveValidation,
            currentValidation = currentValidation,
            calculatedPointsByQuestionOrder = saveValidation.calculatedPointsByQuestionOrder,
            canSave = canSave,
            canLock = canLock
        )
    }
}
