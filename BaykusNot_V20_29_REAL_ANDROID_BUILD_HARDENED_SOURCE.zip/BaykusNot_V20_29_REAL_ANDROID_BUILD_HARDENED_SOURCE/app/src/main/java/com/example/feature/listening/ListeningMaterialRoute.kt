package com.example.feature.listening

import android.content.Intent
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ListeningMaterialRoute(
    viewModel: ListeningMaterialViewModel,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val audioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult

        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // The selected file is copied immediately into app-private storage, so a provider
            // that does not support persistable grants can still be used safely.
        }

        var displayName = "Dinleme sesi"
        var declaredSize: Long? = null
        try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                        declaredSize = cursor.getLong(sizeIndex)
                    }
                }
            }
        } catch (_: Exception) {
            // Repository validates the stream and actual byte count independently.
        }

        val mimeType = context.contentResolver.getType(uri).orEmpty()
        viewModel.importAudio(
            originalUri = uri.toString(),
            displayName = displayName,
            mimeType = mimeType,
            declaredSizeBytes = declaredSize,
            openInputStream = { context.contentResolver.openInputStream(uri) }
        )
    }

    val textLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                com.example.core.security.BoundedInputReader.read(input, com.example.core.security.BoundedInputReader.MAX_TEXT_BYTES, "Metin dosyası")
            } ?: return@rememberLauncherForActivityResult
            val text = bytes.toString(Charsets.UTF_8)
            if (text.isNotBlank()) {
                viewModel.updateTranscript(text)
            }
        } catch (e: Exception) {
            viewModel.reportTextFileSelectionError(e.message ?: "Metin dosyası güvenli biçimde okunamadı. Manuel giriş kullanabilirsiniz.")
        }
    }

    ListeningMaterialScreen(
        uiState = uiState,
        onSelectAudio = { audioLauncher.launch(arrayOf("audio/*")) },
        onRemoveAudio = viewModel::removeAudio,
        onTranscriptChange = viewModel::updateTranscript,
        onSelectTextFile = { textLauncher.launch(arrayOf("text/plain")) },
        onPlaybackCountChange = viewModel::updatePlaybackCount,
        onInstructionsChange = viewModel::updateInstructions,
        onSave = { viewModel.save() },
        onContinue = { viewModel.saveAndContinue(onContinue) },
        modifier = modifier
    )
}
