package com.example.core.data

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.core.database.ExamDraftEntity
import com.example.core.database.ExamObjectiveEntity
import com.example.core.database.ExamRubricSetMetadataEntity
import com.example.core.database.QuestionObjectiveCrossRef
import com.example.core.model.EvaluationPreferences
import com.example.core.model.ExamQuestion
import com.example.core.model.ExamRubricCriterion
import com.example.core.model.documentExamName
import com.example.core.model.formatExamSequenceForDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TeacherRubricPdfGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_X = 40f
    private const val MARGIN_Y = 40f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (2 * MARGIN_X)

    private val titlePaint = Paint().apply {
        color = Color.BLACK
        textSize = 12f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    
    private val subTitlePaint = Paint().apply {
        color = Color.parseColor("#475569")
        textSize = 10f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val sectionHeaderPaint = Paint().apply {
        color = Color.parseColor("#1E293B")
        textSize = 11f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private val infoBgPaint = Paint().apply {
        color = Color.parseColor("#F8FAFC")
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    private val infoBorderPaint = Paint().apply {
        color = Color.parseColor("#E2E8F0")
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }

    private val questionHeaderBgPaint = Paint().apply {
        color = Color.parseColor("#F1F5F9") // Light Slate
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val questionHeaderBorderPaint = Paint().apply {
        color = Color.parseColor("#CBD5E1")
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }
    
    private val questionBoxBgPaint = Paint().apply {
        color = Color.parseColor("#F8FAFC") // Very light neutral
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    private val questionBoxBorderPaint = Paint().apply {
        color = Color.parseColor("#E2E8F0")
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }
    
    private val answerBoxBgPaint = Paint().apply {
        color = Color.parseColor("#F0FDF4") // Very light green-ish neutral
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    private val answerBoxBorderPaint = Paint().apply {
        color = Color.parseColor("#BBF7D0")
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }

    private val questionHeaderTitlePaint = Paint().apply {
        color = Color.parseColor("#0F172A") // Slate 900
        textSize = 12f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private val questionHeaderPointsPaint = Paint().apply {
        color = Color.parseColor("#334155") // Slate 700
        textSize = 11f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    private val criterionTitlePaint = Paint().apply {
        color = Color.parseColor("#0F172A") // Slate 900
        textSize = 10f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }
    
    private val criterionPointsPaint = Paint().apply {
        color = Color.parseColor("#475569") // Slate 600
        textSize = 10f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    private val criterionLabelPaint = Paint().apply {
        color = Color.parseColor("#64748B") // Slate 500
        textSize = 8.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }
    
    private val commonMistakesLabelPaint = Paint().apply {
        color = Color.parseColor("#B45309") // Amber 700
        textSize = 8.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private val criterionSeparatorPaint = Paint().apply {
        color = Color.parseColor("#E2E8F0") // Slate 200
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }
    
    private val continuationHeaderPaint = Paint().apply {
        color = Color.parseColor("#64748B") // Slate 500
        textSize = 10f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.parseColor("#1E293B")
        textSize = 9.5f
        isAntiAlias = true
    }

    private val boldTextPaint = Paint().apply {
        color = Color.parseColor("#0F172A")
        textSize = 9.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        isAntiAlias = true
    }

    private val smallTextPaint = Paint().apply {
        color = Color.parseColor("#475569")
        textSize = 8.5f
        isAntiAlias = true
    }
    
    val footerPaint = Paint().apply {
        color = Color.parseColor("#64748B")
        textSize = 8.5f
        isAntiAlias = true
    }

    private class PdfWriter(val document: PdfDocument) {
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var currentY = MARGIN_Y
        var activeQuestionTitle: String? = null
        var hasRenderedOnThisPage: Boolean = false

        fun wrapText(text: String, paint: Paint, width: Float): List<String> {
            val result = mutableListOf<String>()
            val paragraphs = text.split("\n")
            for (p in paragraphs) {
                if (p.isEmpty()) {
                    result.add("")
                    continue
                }
                val words = p.split(" ")
                var line = ""
                for (word in words) {
                    val testLine = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(testLine) > width) {
                        if (line.isNotEmpty()) {
                            result.add(line)
                            line = ""
                        }
                        if (paint.measureText(word) > width) {
                            var remainingWord = word
                            while (remainingWord.isNotEmpty()) {
                                val count = paint.breakText(remainingWord, true, width, null)
                                result.add(remainingWord.substring(0, count))
                                remainingWord = remainingWord.substring(count)
                            }
                        } else {
                            line = word
                        }
                    } else {
                        line = testLine
                    }
                }
                if (line.isNotEmpty()) {
                    result.add(line)
                }
            }
            return result
        }

        fun measureMultilineTextHeight(text: String, paint: Paint, width: Float): Float {
            val lines = wrapText(text, paint, width)
            return lines.size * (paint.textSize * 1.4f)
        }

        fun checkPageBreak(requiredHeight: Float) {
            if (currentY + requiredHeight > PAGE_HEIGHT - MARGIN_Y - 30f) {
                val shouldShowDevam = activeQuestionTitle != null && hasRenderedOnThisPage
                
                // Draw Footer
                footerPaint.textAlign = Paint.Align.CENTER
                canvas.drawText("BaykuşNot • Öğretmen Değerlendirme Rubriği", PAGE_WIDTH / 2f, PAGE_HEIGHT - 20f, footerPaint)
                footerPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("Sayfa $pageNumber", PAGE_WIDTH - MARGIN_X, PAGE_HEIGHT - 20f, footerPaint)
                
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                currentY = MARGIN_Y
                hasRenderedOnThisPage = false

                if (shouldShowDevam) {
                    canvas.drawText("$activeQuestionTitle — Devam", MARGIN_X, currentY, continuationHeaderPaint)
                    currentY += 18f
                    hasRenderedOnThisPage = true
                }
            }
        }

        fun drawMultilineText(text: String, paint: Paint, width: Float = CONTENT_WIDTH, startX: Float = MARGIN_X) {
            val lines = wrapText(text, paint, width)
            for (l in lines) {
                checkPageBreak(paint.textSize * 1.4f)
                canvas.drawText(l, startX, currentY + paint.textSize, paint)
                currentY += paint.textSize * 1.4f
            }
        }

        fun drawCenteredMultilineText(text: String, paint: Paint, width: Float = CONTENT_WIDTH, centerX: Float = PAGE_WIDTH / 2f) {
            val lines = wrapText(text, paint, width)
            for (l in lines) {
                checkPageBreak(paint.textSize * 1.4f)
                canvas.drawText(l, centerX, currentY + paint.textSize, paint)
                currentY += paint.textSize * 1.4f
            }
        }

        fun drawChunkedBox(
            boxTitle: String,
            titlePaint: Paint,
            text: String,
            textPaint: Paint,
            bgPaint: Paint,
            borderPaint: Paint,
            startX: Float = MARGIN_X,
            width: Float = CONTENT_WIDTH,
            padding: Float = 8f
        ) {
            val contentWidth = width - 2 * padding
            val lines = wrapText(text, textPaint, contentWidth)
            val lineHeight = textPaint.textSize * 1.4f
            
            var lineIndex = 0
            var isFirstChunk = true
            
            while (lineIndex < lines.size) {
                val titleText = if (isFirstChunk) boxTitle else "$boxTitle — DEVAM"
                val titleHeight = titlePaint.textSize + 6f
                
                val minRequired = padding * 2 + titleHeight + lineHeight
                if (currentY + minRequired > PAGE_HEIGHT - MARGIN_Y - 30f) {
                    checkPageBreak(minRequired)
                }
                
                val availableHeight = (PAGE_HEIGHT - MARGIN_Y - 30f) - currentY
                val maxLinesForThisPage = ((availableHeight - (padding * 2) - titleHeight) / lineHeight).toInt()
                
                val linesToDraw = if (maxLinesForThisPage >= lines.size - lineIndex) {
                    lines.size - lineIndex
                } else {
                    maxLinesForThisPage
                }
                
                val chunkHeight = (padding * 2) + titleHeight + (linesToDraw * lineHeight)
                
                val rect = android.graphics.RectF(startX, currentY, startX + width, currentY + chunkHeight)
                canvas.drawRoundRect(rect, 4f, 4f, bgPaint)
                canvas.drawRoundRect(rect, 4f, 4f, borderPaint)
                
                currentY += padding
                canvas.drawText(titleText, startX + padding, currentY + titlePaint.textSize, titlePaint)
                currentY += titleHeight
                
                for (i in 0 until linesToDraw) {
                    val lineStr = lines[lineIndex + i]
                    if (lineStr.isNotEmpty()) {
                        canvas.drawText(lineStr, startX + padding, currentY + textPaint.textSize, textPaint)
                    }
                    currentY += lineHeight
                }
                
                currentY += padding
                lineIndex += linesToDraw
                isFirstChunk = false
                
                if (lineIndex < lines.size) {
                    checkPageBreak(PAGE_HEIGHT.toFloat())
                }
            }
            currentY += 6f
        }
    }

    fun buildRubricTitle(draft: ExamDraftEntity?): String {
        if (draft == null) return "DERECELİ PUANLAMA ANAHTARI"
        
        val rawYear = draft.academicYear.trim()
        val yearStr = if (rawYear.contains("EĞİTİM", ignoreCase = true)) {
            rawYear.uppercase()
        } else if (rawYear.isNotEmpty()) {
            "$rawYear EĞİTİM-ÖĞRETİM YILI".uppercase()
        } else {
            "EĞİTİM-ÖĞRETİM YILI"
        }

        val rawInst = draft.institutionName.trim()
        val instStr = if (rawInst.isNotEmpty()) rawInst.uppercase() else "OKUL ADI"

        val rawCourse = draft.courseName.trim()
        val courseStr = if (rawCourse.contains("DERSİ", ignoreCase = true) || rawCourse.contains("DERS", ignoreCase = true)) {
            rawCourse.uppercase()
        } else if (rawCourse.isNotEmpty()) {
            "${rawCourse.uppercase()} DERSİ"
        } else {
            "DERSİ"
        }

        val rawTerm = draft.term.trim()
        val termStr = if (rawTerm.contains("DÖNEM", ignoreCase = true)) {
            rawTerm.uppercase()
        } else if (rawTerm.isNotEmpty()) {
            "$rawTerm. DÖNEM".uppercase()
        } else {
            "1. DÖNEM"
        }

        val seqStr = draft.examType.formatExamSequenceForDocument(draft.examSequenceNumber)

        return "$yearStr $instStr $courseStr $termStr $seqStr — DERECELİ PUANLAMA ANAHTARI".trim()
    }

    fun generateTeacherRubricPdf(
        context: Context,
        draft: ExamDraftEntity?,
        questions: List<ExamQuestion>,
        criteria: List<ExamRubricCriterion>,
        objectives: List<ExamObjectiveEntity>,
        crossRefs: List<QuestionObjectiveCrossRef>,
        preferences: EvaluationPreferences?,
        metadata: ExamRubricSetMetadataEntity? = null
    ): File {
        val pdfDocument = PdfDocument()
        val writer = PdfWriter(pdfDocument)

        val rubricTitle = buildRubricTitle(draft)
        writer.checkPageBreak(40f)
        writer.drawCenteredMultilineText(rubricTitle, titlePaint)
        writer.currentY += 8f
        writer.drawCenteredMultilineText("ÖĞRETMEN DEĞERLENDİRME RUBRİĞİ", subTitlePaint)
        writer.currentY += 16f

        if (draft != null) {
            val dateStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(draft.examDate))
            val teachers = draft.teachers.joinToString(", ")
            
            val colWidth = (CONTENT_WIDTH - 30f) / 2f
            val leftX = MARGIN_X + 10f
            val rightX = PAGE_WIDTH / 2f + 5f
            
            val rows = listOf(
                Pair("Kurum: ${draft.institutionName}", when (draft.examType) {
                    com.example.core.model.ExamType.HOMEWORK -> "Ödev No: ${draft.examSequenceNumber} • ${draft.examType.documentExamName()}"
                    com.example.core.model.ExamType.READINESS -> "Hazırbulunuşluk No: ${draft.examSequenceNumber} • ${draft.examType.documentExamName()}"
                    else -> "Sınav No: ${draft.examSequenceNumber} • ${draft.examType.documentExamName()}"
                }),
                Pair("Ders: ${draft.courseName}", "Tarih: $dateStr"),
                Pair("Sınıf: ${draft.gradeLevel}", "Öğretmen: $teachers"),
                Pair("Eğitim Yılı: ${draft.academicYear} - ${draft.term}. Dönem", "Toplam Puan: ${draft.totalPoints}")
            )
            
            var totalHeight = 16f
            val rowHeights = mutableListOf<Float>()
            val wrappedRows = mutableListOf<Pair<List<String>, List<String>>>()
            
            for (row in rows) {
                val leftLines = writer.wrapText(row.first, textPaint, colWidth)
                val rightLines = writer.wrapText(row.second, textPaint, colWidth)
                wrappedRows.add(Pair(leftLines, rightLines))
                
                val maxLines = maxOf(leftLines.size, rightLines.size)
                val rHeight = maxLines * (textPaint.textSize * 1.4f) + 6f
                rowHeights.add(rHeight)
                totalHeight += rHeight
            }
            
            writer.checkPageBreak(totalHeight + 10f)
            
            val rect = android.graphics.RectF(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY + totalHeight)
            writer.canvas.drawRoundRect(rect, 4f, 4f, infoBgPaint)
            writer.canvas.drawRoundRect(rect, 4f, 4f, infoBorderPaint)
            
            writer.currentY += 10f
            
            for (i in wrappedRows.indices) {
                val (leftLines, rightLines) = wrappedRows[i]
                val startY = writer.currentY
                
                var yL = startY
                for (l in leftLines) {
                    writer.canvas.drawText(l, leftX, yL + textPaint.textSize, textPaint)
                    yL += textPaint.textSize * 1.4f
                }
                
                var yR = startY
                for (l in rightLines) {
                    if (i == 3) {
                        writer.canvas.drawText(l, rightX, yR + boldTextPaint.textSize, boldTextPaint)
                        yR += boldTextPaint.textSize * 1.4f
                    } else {
                        writer.canvas.drawText(l, rightX, yR + textPaint.textSize, textPaint)
                        yR += textPaint.textSize * 1.4f
                    }
                }
                writer.currentY += rowHeights[i]
            }
            writer.currentY += 6f
            
            if (!draft.draftName.isNullOrBlank()) {
                val draftNameLabel = when (draft.examType) {
                    com.example.core.model.ExamType.HOMEWORK -> "Ödev / Taslak Adı"
                    com.example.core.model.ExamType.READINESS -> "Hazırbulunuşluk / Taslak Adı"
                    else -> "Sınav / Taslak Adı"
                }
                val draftNameLines = writer.wrapText("$draftNameLabel: ${draft.draftName}", smallTextPaint, CONTENT_WIDTH - 20f)
                val draftH = draftNameLines.size * (smallTextPaint.textSize * 1.4f) + 16f
                
                writer.checkPageBreak(draftH + 10f)
                val dRect = android.graphics.RectF(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY + draftH)
                writer.canvas.drawRoundRect(dRect, 4f, 4f, infoBgPaint)
                writer.canvas.drawRoundRect(dRect, 4f, 4f, infoBorderPaint)
                
                writer.currentY += 8f
                for (l in draftNameLines) {
                    writer.canvas.drawText(l, leftX, writer.currentY + smallTextPaint.textSize, smallTextPaint)
                    writer.currentY += smallTextPaint.textSize * 1.4f
                }
                writer.currentY += 8f
            }
        }
        
        writer.checkPageBreak(70f)
        var statusStr = "Taslak"
        var revStr = "1"
        var sourceStr = "Belirtilmemiş"
        
        if (metadata != null) {
            statusStr = if (metadata.isLocked) "Öğretmen Onaylı / Kilitli" else "Taslak"
            revStr = metadata.revision.toString()
            
            val typeStr = when (metadata.evaluationSourceType) {
                "AI_GENERATED_RUBRIC" -> "Yapay zekâ ile oluşturulan rubrik"
                "TEACHER_ANSWER_KEY" -> "Öğretmen cevap anahtarı"
                "TEACHER_RUBRIC" -> "Öğretmen rubriği"
                "TEACHER_ANSWER_KEY_AND_RUBRIC" -> "Öğretmen cevap anahtarı + rubrik"
                else -> "Belirtilmemiş"
            }
            val detailStr = if (metadata.isAsIs) "Öğretmen kaynağı aynen kullanıldı" else "Öğretmen kaynağı ayrıntılandırıldı"
            sourceStr = if (metadata.evaluationSourceType.startsWith("TEACHER")) "$typeStr ($detailStr)" else typeStr
        }
        
        val deductWriting = preferences?.writingAndPunctuation?.deductPoints == true
        val writingRuleText = if (deductWriting) "Puan kesilir (ilgili kriterden)" else "Ayrıca puan kesilmez"
        val feedbackRuleText = if (preferences?.writingAndPunctuation?.provideFeedback == true) "Dönüt verilir" else "Dönüt verilmez"
        
        val adherenceLevelStr = when (preferences?.rubricAdherenceLevel?.name) {
            "STRICT" -> "Katı (Yalnızca rubrikte olanı kabul et)"
            "BALANCED" -> "Dengeli"
            "FLEXIBLE" -> "Esnek (Eş anlamlı ve benzer yorumları kabul et)"
            else -> preferences?.rubricAdherenceLevel?.name ?: "Normal"
        }
        
        val diagnosticRule = if (draft?.examType == com.example.core.model.ExamType.READINESS)
            "\nTanılayıcı Amaç: Rubrik, yalnız bu sınavda gözlenen konu/ünite öncesi mevcut ön koşul bilgi ve beceri kanıtını ölçer; ileri kazanım eklenmez."
        else ""
        val rulesText = "Rubrik Durumu: $statusStr (Sürüm $revStr)\n" +
                        "Değerlendirme Kaynağı: $sourceStr\n" +
                        "Yazım/Noktalama: $writingRuleText, $feedbackRuleText\n" +
                        "Rubriğe Bağlılık: $adherenceLevelStr" + diagnosticRule
        
        val ruleLines = writer.wrapText(rulesText, textPaint, CONTENT_WIDTH - 20f)
        val ruleH = ruleLines.size * (textPaint.textSize * 1.4f) + 20f
        
        writer.checkPageBreak(sectionHeaderPaint.textSize + 12f + ruleH)
        writer.canvas.drawText("DEĞERLENDİRME KURALLARI & DURUM", MARGIN_X, writer.currentY + sectionHeaderPaint.textSize, sectionHeaderPaint)
        writer.currentY += sectionHeaderPaint.textSize + 12f
        
        val rulesRect = android.graphics.RectF(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY + ruleH)
        writer.canvas.drawRoundRect(rulesRect, 4f, 4f, infoBgPaint)
        writer.canvas.drawRoundRect(rulesRect, 4f, 4f, infoBorderPaint)
        
        writer.currentY += 10f
        for(l in ruleLines) {
            writer.canvas.drawText(l, MARGIN_X + 10f, writer.currentY + textPaint.textSize, textPaint)
            writer.currentY += textPaint.textSize * 1.4f
        }
        writer.currentY += 10f

        val criteriaByQuestion = criteria.groupBy { it.questionOrderIndex }
        val objectiveMap = objectives.associateBy { it.id }
        val refsByQuestionId = crossRefs.groupBy { it.questionId }
        val sortedQuestions = questions.sortedBy { it.orderIndex }

        for (question in sortedQuestions) {
            writer.checkPageBreak(60f)

            val qCriteria = criteriaByQuestion[question.orderIndex] ?: emptyList()
            val totalCriteriaPoints = qCriteria.sumOf { it.maxPoints }

            val isHomework = draft?.examType == com.example.core.model.ExamType.HOMEWORK
            val qTitleLeft = if (isHomework) "GÖREV/MADDE ${question.questionNumber}" else "SORU ${question.questionNumber}"
            val qTitleRight = "${question.points} PUAN"
            writer.activeQuestionTitle = if (isHomework) "Görev/Madde ${question.questionNumber} — ${question.points} Puan" else "Soru ${question.questionNumber} — ${question.points} Puan"
            writer.hasRenderedOnThisPage = false

            val headerHeight = 24f
            val headerBgRect = android.graphics.RectF(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY + headerHeight)
            writer.canvas.drawRoundRect(headerBgRect, 4f, 4f, questionHeaderBgPaint)
            writer.canvas.drawRoundRect(headerBgRect, 4f, 4f, questionHeaderBorderPaint)
            
            val textY = writer.currentY + 16f
            writer.canvas.drawText(qTitleLeft, MARGIN_X + 8f, textY, questionHeaderTitlePaint)
            writer.canvas.drawText(qTitleRight, PAGE_WIDTH - MARGIN_X - 8f, textY, questionHeaderPointsPaint)
            writer.currentY += headerHeight + 10f
            writer.hasRenderedOnThisPage = true
            
            if (totalCriteriaPoints != question.points && totalCriteriaPoints > 0) {
                writer.canvas.drawText("Kriter Toplamı: $totalCriteriaPoints Puan", MARGIN_X, writer.currentY + 10f, smallTextPaint)
                writer.currentY += 14f
            }

            if (question.questionText.isNotBlank()) {
                writer.drawChunkedBox(
                    boxTitle = "SORU",
                    titlePaint = criterionLabelPaint,
                    text = question.questionText,
                    textPaint = textPaint,
                    bgPaint = questionBoxBgPaint,
                    borderPaint = questionBoxBorderPaint
                )
            }

            val expectedAnswers = qCriteria
                .filter { it.expectedAnswer.isNotBlank() }
                .map { it.expectedAnswer.trim() }
                .distinct()
                
            if (expectedAnswers.isNotEmpty()) {
                val combinedAnswer = if (expectedAnswers.size == 1) {
                    expectedAnswers.first()
                } else {
                    expectedAnswers.mapIndexed { idx, ans -> "${idx + 1}. $ans" }.joinToString("\n\n")
                }
                
                writer.drawChunkedBox(
                    boxTitle = "BEKLENEN CEVAP / CEVAP ANAHTARI",
                    titlePaint = criterionLabelPaint,
                    text = combinedAnswer,
                    textPaint = textPaint,
                    bgPaint = answerBoxBgPaint,
                    borderPaint = answerBoxBorderPaint
                )
            }

            val qRefs = refsByQuestionId[question.id] ?: emptyList()
            val qObjectives = qRefs.mapNotNull { objectiveMap[it.objectiveId] }
            if (qObjectives.isNotEmpty()) {
                writer.checkPageBreak(25f)
                writer.canvas.drawText("KAZANIMLAR", MARGIN_X, writer.currentY + criterionLabelPaint.textSize, criterionLabelPaint)
                writer.currentY += criterionLabelPaint.textSize + 4f
                val objText = qObjectives.joinToString("\n") { "${it.objectiveCode ?: ""} — ${it.objectiveText}" }
                writer.drawMultilineText(objText, smallTextPaint)
                writer.currentY += 8f
            }

            if (qCriteria.isNotEmpty()) {
                writer.checkPageBreak(30f)
                writer.canvas.drawText("PUANLAMA KRİTERLERİ", MARGIN_X, writer.currentY + sectionHeaderPaint.textSize, sectionHeaderPaint)
                writer.currentY += sectionHeaderPaint.textSize + 8f

                for ((index, criterion) in qCriteria.withIndex()) {
                    val titleWidth = (PAGE_WIDTH - 2 * MARGIN_X) - 60f
                    val titleLines = writer.wrapText("${index + 1}. ${criterion.title}", criterionTitlePaint, titleWidth)
                    val titleHeight = titleLines.size * (criterionTitlePaint.textSize * 1.4f)
                    
                    val requiredHeight = (if (index > 0) 8f else 0f) + titleHeight + 14f
                    writer.checkPageBreak(requiredHeight)
                    
                    if (index > 0) {
                        writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, criterionSeparatorPaint)
                        writer.currentY += 8f
                    }
                    
                    writer.canvas.drawText("${criterion.maxPoints} PUAN", PAGE_WIDTH - MARGIN_X, writer.currentY + criterionTitlePaint.textSize, criterionPointsPaint)
                    for (l in titleLines) {
                        writer.canvas.drawText(l, MARGIN_X, writer.currentY + criterionTitlePaint.textSize, criterionTitlePaint)
                        writer.currentY += criterionTitlePaint.textSize * 1.4f
                    }
                    writer.currentY += 6f

                    if (criterion.description.isNotBlank()) {
                        val labelHeight = criterionLabelPaint.textSize
                        val gap = 4f
                        writer.checkPageBreak(labelHeight + gap + (textPaint.textSize * 1.4f))
                        
                        writer.canvas.drawText("AÇIKLAMA", MARGIN_X, writer.currentY + labelHeight, criterionLabelPaint)
                        writer.currentY += labelHeight + gap
                        writer.drawMultilineText(criterion.description, textPaint)
                        writer.currentY += 4f
                    }
                    
                    if (criterion.partialCreditGuidance.isNotBlank()) {
                        val labelHeight = criterionLabelPaint.textSize
                        val gap = 4f
                        writer.checkPageBreak(labelHeight + gap + (textPaint.textSize * 1.4f))

                        writer.canvas.drawText("KISMİ PUAN REHBERİ", MARGIN_X, writer.currentY + labelHeight, criterionLabelPaint)
                        writer.currentY += labelHeight + gap
                        writer.drawMultilineText(criterion.partialCreditGuidance, textPaint)
                        writer.currentY += 4f
                    }
                    
                    if (criterion.commonMistakes.isNotBlank()) {
                        val labelHeight = commonMistakesLabelPaint.textSize
                        val gap = 4f
                        writer.checkPageBreak(labelHeight + gap + (smallTextPaint.textSize * 1.4f))

                        writer.canvas.drawText("YAYGIN HATALAR", MARGIN_X, writer.currentY + labelHeight, commonMistakesLabelPaint)
                        writer.currentY += labelHeight + gap
                        writer.drawMultilineText(criterion.commonMistakes, smallTextPaint)
                        writer.currentY += 4f
                    }
                    writer.currentY += 4f
                }
            }
            writer.currentY += 12f
            writer.activeQuestionTitle = null
            writer.hasRenderedOnThisPage = false
        }
        
        if (metadata != null) {
            val sourceType = metadata.evaluationSourceType
            val isAsIs = metadata.isAsIs

            val answerKeyText = if (isAsIs || metadata.elaboratedAnswerKey.isNullOrBlank()) {
                metadata.originalTeacherAnswerKey
            } else {
                metadata.elaboratedAnswerKey
            }

            val rubricText = if (isAsIs || metadata.elaboratedRubric.isNullOrBlank()) {
                metadata.originalTeacherRubric
            } else {
                metadata.elaboratedRubric
            }

            val showAnswerKey = (sourceType == "TEACHER_ANSWER_KEY" || sourceType == "TEACHER_ANSWER_KEY_AND_RUBRIC") && !answerKeyText.isNullOrBlank()
            val showRubric = (sourceType == "TEACHER_RUBRIC" || sourceType == "TEACHER_ANSWER_KEY_AND_RUBRIC") && !rubricText.isNullOrBlank()

            if (showAnswerKey || showRubric) {
                writer.checkPageBreak(60f)
                writer.currentY += 10f
                writer.canvas.drawLine(MARGIN_X, writer.currentY, PAGE_WIDTH - MARGIN_X, writer.currentY, questionHeaderBorderPaint)
                writer.currentY += 20f
                writer.canvas.drawText("KAYNAK NOTLARI / ÖĞRETMENİN ORİJİNAL KAYNAĞI", MARGIN_X, writer.currentY, sectionHeaderPaint)
                writer.currentY += 16f
                
                if (showAnswerKey) {
                    writer.checkPageBreak(50f)
                    writer.canvas.drawText("Öğretmen Cevap Anahtarı", MARGIN_X, writer.currentY, boldTextPaint)
                    writer.currentY += 14f
                    writer.drawMultilineText(answerKeyText!!, smallTextPaint)
                    writer.currentY += 12f
                }

                if (showRubric) {
                    writer.checkPageBreak(50f)
                    writer.canvas.drawText("Öğretmen Rubrik Kaynağı", MARGIN_X, writer.currentY, boldTextPaint)
                    writer.currentY += 14f
                    writer.drawMultilineText(rubricText!!, smallTextPaint)
                    writer.currentY += 12f
                }
            }
        }

        footerPaint.textAlign = Paint.Align.CENTER
        writer.canvas.drawText("BaykuşNot • Öğretmen Değerlendirme Rubriği", PAGE_WIDTH / 2f, PAGE_HEIGHT - 20f, footerPaint)
        footerPaint.textAlign = Paint.Align.RIGHT
        writer.canvas.drawText("Sayfa ${writer.pageNumber}", PAGE_WIDTH - MARGIN_X, PAGE_HEIGHT - 20f, footerPaint)

        pdfDocument.finishPage(writer.page)

        val fileName = buildSafeFilename(draft)
        val exportDir = File(context.cacheDir, "rubric_exports").apply { mkdirs() }
        val file = File(exportDir, fileName)
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }

    private fun buildSafeFilename(draft: ExamDraftEntity?): String {
        val course = sanitize(draft?.courseName ?: "Ders")
        val term = sanitize(draft?.term ?: "Donem")
        return "BaykusNot_${course}_${term}_Ogretmen_Degerlendirme_Rubrigi.pdf"
    }

    private fun sanitize(input: String): String {
        return input.replace(Regex("[^a-zA-Z0-9_\\-\\.]"), "_")
    }
}
