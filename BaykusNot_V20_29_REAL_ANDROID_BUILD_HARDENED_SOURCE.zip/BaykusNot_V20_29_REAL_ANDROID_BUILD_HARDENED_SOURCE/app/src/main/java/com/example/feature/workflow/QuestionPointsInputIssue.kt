package com.example.feature.workflow

enum class QuestionPointsInputIssueCode {
    BLANK_POINTS,
    INVALID_POINTS_FORMAT,
    POINTS_OUT_OF_RANGE
}

data class QuestionPointsInputIssue(
    val localId: Long,
    val code: QuestionPointsInputIssueCode
)
