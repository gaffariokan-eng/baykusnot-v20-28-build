package com.example.feature.listening

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.ui.BaykusBanner
import com.example.core.ui.BaykusCard
import com.example.core.ui.BaykusPrimaryButton
import com.example.core.ui.BaykusSecondaryButton
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.StatusType
import java.util.Locale

internal object ListeningMaterialTestTags {
    const val SCREEN = "listening_material_screen"
    const val AUDIO_CARD = "listening_audio_card"
    const val SELECT_AUDIO = "listening_select_audio"
    const val TRANSCRIPT = "listening_transcript"
    const val SAVE = "listening_save"
    const val CONTINUE = "listening_continue"
}

@Composable
fun ListeningMaterialScreen(
    uiState: ListeningMaterialUiState,
    onSelectAudio: () -> Unit,
    onRemoveAudio: () -> Unit,
    onTranscriptChange: (String) -> Unit,
    onSelectTextFile: () -> Unit,
    onPlaybackCountChange: (Int) -> Unit,
    onInstructionsChange: (String) -> Unit,
    onSave: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (uiState.isLoading) {
        Column(
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(12.dp))
            Text("Dinleme materyali yükleniyor...")
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .testTag(ListeningMaterialTestTags.SCREEN),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        BaykusCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Dinleme Materyali",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Kaynak olarak ses dosyası veya dinleme metni kullanın. İkisini birlikte vermek zorunda değilsiniz.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    BaykusStatusChip(
                        text = if (uiState.canContinue) "Kaynak Hazır" else "Kaynak Bekleniyor",
                        type = if (uiState.canContinue) StatusType.SUCCESS else StatusType.INFO
                    )
                }
            }
        }

        if (uiState.isQuestionSetLocked) {
            BaykusBanner(
                message = "Soru seti kilitli. Dinleme kaynağının soru, rubrik ve değerlendirme ile tutarlı kalması için bu alanlar salt okunur. Kaynağı değiştirmek gerekiyorsa önce Sorular aşamasında soru kilidini açın.",
                type = StatusType.WARNING,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (uiState.message != null) {
            BaykusBanner(
                message = uiState.message,
                type = if (uiState.isMessageError) StatusType.ERROR else StatusType.SUCCESS,
                modifier = Modifier.fillMaxWidth()
            )
        }

        BaykusCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag(ListeningMaterialTestTags.AUDIO_CARD)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "1. Dinleme Sesi (İsteğe Bağlı)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Ses dosyası kullanacaksanız ekleyin. MP3, WAV, M4A, AAC, OGG ve FLAC desteklenir. Dinleme metni kullanıyorsanız ses yüklemek zorunlu değildir.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))

                if (uiState.hasAudio) {
                    val material = uiState.material
                    BaykusStatusChip(text = "Ses dosyası hazır", type = StatusType.SUCCESS)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = material?.displayName.orEmpty(),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "${formatBytes(material?.sizeBytes ?: 0L)} • ${material?.mimeType.orEmpty()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BaykusSecondaryButton(
                            text = "Değiştir",
                            onClick = onSelectAudio,
                            enabled = uiState.canEditSource,
                            isLoading = uiState.isImporting,
                            icon = Icons.Default.FolderOpen,
                            modifier = Modifier.weight(1f).testTag(ListeningMaterialTestTags.SELECT_AUDIO)
                        )
                        BaykusSecondaryButton(
                            text = "Kaldır",
                            onClick = onRemoveAudio,
                            enabled = uiState.canEditSource,
                            isLoading = uiState.isRemovingAudio,
                            icon = Icons.Default.DeleteOutline,
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    BaykusStatusChip(text = "Ses dosyası eklenmedi", type = StatusType.WARNING)
                    Spacer(modifier = Modifier.height(12.dp))
                    BaykusPrimaryButton(
                        text = "Ses Dosyası Seç",
                        onClick = onSelectAudio,
                        enabled = uiState.canEditSource,
                        isLoading = uiState.isImporting,
                        icon = Icons.Default.FolderOpen,
                        modifier = Modifier.testTag(ListeningMaterialTestTags.SELECT_AUDIO)
                    )
                }
            }
        }

        BaykusCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "2. Dinleme Metni (İsteğe Bağlı)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Ses yerine dinleme metnini kullanabilirsiniz. Metni yazın, yapıştırın veya düz metin (.txt) dosyasından yükleyin. Ses dosyanız varsa bu alan zorunlu değildir.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                BaykusSecondaryButton(
                    text = "Metin Dosyası Seç (.txt)",
                    onClick = onSelectTextFile,
                    enabled = uiState.canEditSource,
                    icon = Icons.Default.FolderOpen,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = uiState.transcript,
                    onValueChange = onTranscriptChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(ListeningMaterialTestTags.TRANSCRIPT),
                    label = { Text("Dinleme metni") },
                    minLines = 8,
                    maxLines = 18,
                    enabled = uiState.canEditSource
                )
            }
        }

        BaykusCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "3. Uygulama Ayarları",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Dinletme sayısı",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..3).forEach { count ->
                        FilterChip(
                            selected = uiState.playbackCount == count,
                            onClick = { onPlaybackCountChange(count) },
                            label = { Text("$count kez") },
                            enabled = uiState.canEditSource
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = uiState.instructions,
                    onValueChange = onInstructionsChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Sınav yönergesi (öğrenciye gösterilir, isteğe bağlı)") },
                    placeholder = { Text("Örn. Metin iki kez dinletilecektir. İlk dinlemede not almayınız.") },
                    minLines = 3,
                    maxLines = 6,
                    enabled = uiState.canEditSource
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BaykusSecondaryButton(
                text = if (!uiState.isDirty && uiState.material != null) "Kaydedildi" else "Kaydet",
                onClick = onSave,
                enabled = uiState.isDirty && uiState.canEditSource,
                isLoading = uiState.isSaving,
                icon = Icons.Default.Save,
                modifier = Modifier.weight(1f).testTag(ListeningMaterialTestTags.SAVE)
            )
            BaykusPrimaryButton(
                text = if (uiState.isQuestionSetLocked) "Sorulara Dön" else "Sorulara Geç",
                onClick = onContinue,
                enabled = uiState.canContinue,
                isLoading = uiState.isSaving,
                modifier = Modifier.weight(1f).testTag(ListeningMaterialTestTags.CONTINUE)
            )
        }

        Text(
            text = "Dinleme kaynağından sonra sorular, rubrik, cevap kâğıdı ve değerlendirme adımları Yazılı Sınav ile aynı çekirdeği kullanır.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(Locale.getDefault(), "%.1f KB", kb)
    val mb = kb / 1024.0
    return String.format(Locale.getDefault(), "%.1f MB", mb)
}
