package com.example.feature.homework

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.core.data.PdfSelectionResolver
import com.example.feature.workflow.UploadSourceCopy
import com.example.feature.workflow.UploadSourceRoute
import com.example.feature.workflow.UploadSourceViewModel

/**
 * Homework reuses the shared source-import and question-extraction pipeline.
 * Teachers may either upload the assignment source (PDF/Word/image) or paste its text.
 * After extraction the workflow continues to the shared question/task review stage.
 */
internal val HomeworkSourceCopy = UploadSourceCopy(
    title = "Ödev Kaynağı",
    description = "Ödev yönergesini, görevleri/soruları ve varsa değerlendirme ölçütlerini yükleyin veya metin olarak yapıştırın. Sistem bunları görev/soru taslağına dönüştürür; sonraki aşamada siz kontrol edersiniz.",
    emptyTitle = "Henüz ödev kaynağı eklenmedi",
    emptyDescription = "PDF, Word, TXT, JPEG, PNG, WebP yükleyebilir veya ödev metnini doğrudan yapıştırabilirsiniz. (Maks. 50 MB)",
    documentTypeLabel = "Ödev Kaynağı",
    readyLabel = "Ödev kaynağı hazır",
    unusableLabel = "Ödev kaynağı kullanılamıyor",
    replaceLabel = "Ödev Kaynağını Değiştir",
    continueLabel = "Görevleri Çıkar ve Kontrol Et"
)
internal val HomeworkSourceMimeTypes = listOf(
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
    "image/jpeg",
    "image/png",
    "image/webp"
)

@Composable
fun HomeworkSourceRoute(
    viewModel: UploadSourceViewModel,
    pdfSelectionResolver: PdfSelectionResolver,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    UploadSourceRoute(
        viewModel = viewModel,
        pdfSelectionResolver = pdfSelectionResolver,
        onContinue = onContinue,
        copy = HomeworkSourceCopy,
        showScenarioSection = false,
        allowedSourceMimeTypes = HomeworkSourceMimeTypes,
        modifier = modifier
    )
}
