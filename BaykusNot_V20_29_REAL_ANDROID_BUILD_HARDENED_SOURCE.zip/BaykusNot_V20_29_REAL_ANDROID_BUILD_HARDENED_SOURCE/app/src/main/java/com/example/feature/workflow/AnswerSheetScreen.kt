package com.example.feature.workflow

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.example.core.ui.BaykusStatusChip
import com.example.core.ui.StatusType
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.core.data.AnswerSheetDensity
import com.example.core.data.AnswerSheetPageLayout
import com.example.core.data.BranchConstants
import com.example.core.data.ExamAnswerSheetLayoutCalculator
import com.example.core.data.ExamAnswerSheetPageRenderer
import com.example.core.data.ListeningAnswerSheetGuidance
import com.example.core.data.QrCodeGenerator
import com.example.core.model.ExamType
import java.io.File

object AnswerSheetTestTags {
    const val SCREEN = "answer_sheet_screen"
    const val STUDENT_COUNT_INPUT = "student_count_input"
    const val GENERATE_PDF_BUTTON = "generate_pdf_button"
    const val SHARE_PDF_BUTTON = "share_pdf_button"
    const val SAVE_PDF_BUTTON = "save_pdf_button"
    const val CONTINUE_BUTTON = "answer_sheet_continue_button"
    const val PREVIEW_CARD = "answer_sheet_preview_card"
    const val PREVIOUS_PAGE_BUTTON = "preview_previous_page_button"
    const val NEXT_PAGE_BUTTON = "preview_next_page_button"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AnswerSheetScreen(
    uiState: AnswerSheetUiState,
    onStudentCountChange: (Int) -> Unit,
    onLayoutDensityChange: (String) -> Unit = {},
    onLineOverrideChange: (Int, Int) -> Unit = { _, _ -> },
    onResetLineOverrides: () -> Unit = {},
    onSelectPreviewPage: (Int) -> Unit,
    onGeneratePdf: (Context) -> Unit,
    onSavePdf: (Context) -> Unit,
    onClearSaveMessage: () -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val isReadiness = uiState.draft?.examType == ExamType.READINESS
    val isMultipleChoice = uiState.draft?.examType == ExamType.MULTIPLE_CHOICE
    var isRowOverridesExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag(AnswerSheetTestTags.SCREEN)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Save Success Banner
        if (uiState.saveSuccessMessage != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = uiState.saveSuccessMessage,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClearSaveMessage) {
                        Icon(
                            Icons.Default.Remove,
                            contentDescription = "Kapat",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Error / Preflight Banner if any
        if (uiState.errorMessage != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = uiState.errorMessage,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return
        }

        if (!uiState.isPreflightValid) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = when {
                            isReadiness -> "Hazırbulunuşluk Cevap Kâğıdı Oluşturulamaz"
                            isMultipleChoice -> "Test Cevap Kâğıdı Oluşturulamaz"
                            else -> "Öğrenci Cevap Kâğıdı Oluşturulamaz"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when {
                            isReadiness -> "Hazırbulunuşluk soru ve puan setinin ve tanılayıcı rubriğin tamamen kilitlenmiş ve onaylanmış olduğundan emin olun."
                            isMultipleChoice -> "Test soru ve puan setinin ve doğru seçenekleri içeren cevap anahtarının tamamen kilitlenmiş ve onaylanmış olduğundan emin olun."
                            else -> "Soru ve puan setinin ile detaylı rubriğin tamamen kilitlenmiş ve onaylanmış olduğundan emin olun."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            return
        }

        // TOP STATUS SUMMARY CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = when {
                        isReadiness -> "Hazırbulunuşluk Cevap Kâğıdı Durum Özeti"
                        isMultipleChoice -> "Test Cevap Kâğıdı Durum Özeti"
                        else -> "Cevap Kâğıdı Durum Özeti"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Lock Status
                    BaykusStatusChip(
                        text = if (uiState.hasUploadedPapers) "Kilitli" else "Düzenlenebilir",
                        type = if (uiState.hasUploadedPapers) StatusType.LOCKED else StatusType.WARNING
                    )
                    // Student Count
                    BaykusStatusChip(
                        text = "${uiState.studentCount} Öğrenci",
                        type = StatusType.INFO
                    )
                    // PDF Status
                    if (uiState.generatedPdfFile != null) {
                        if (uiState.isPdfUpToDate) {
                            BaykusStatusChip(text = "PDF Hazır", type = StatusType.SUCCESS)
                        } else {
                            BaykusStatusChip(text = "PDF Güncellenmeli", type = StatusType.WARNING)
                        }
                    } else {
                        BaykusStatusChip(text = "PDF Yok", type = StatusType.INFO)
                    }
                }
            }
        }

        uiState.listeningGuidance?.let { guidance ->
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "Dinleme Sınavı Öğrenci Yönergesi",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Dinletme sayısı: ${guidance.normalizedPlaybackCount} kez",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    if (guidance.instructions.isNotBlank()) {
                        Text(
                            text = guidance.instructions.trim(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Text(
                        text = "Bu bilgi oluşturulan cevap kâğıdının ilk sayfasına otomatik eklenir.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // SECTION A: Cevap Kâğıdı Ayarları
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isReadiness) "A. Hazırbulunuşluk Cevap Kâğıdı Ayarları" else "A. Cevap Kâğıdı Ayarları",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Smart Layout Summary Banner
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "Akıllı / Adaptif Kâğıt Düzeni",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = uiState.layoutSummaryText.ifEmpty { "Akıllı yerleşim hazır" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }

                // Uploaded Papers Safety Lock Banner
                if (uiState.hasUploadedPapers) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Bu cevap kâğıdı ile öğrenci kâğıdı yüklendiği için yerleşim düzeni kilitlenmiştir.",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }

                // Layout choice. Test sınavında teknik "kompakt/geniş" yerine öğretmenin
                // doğrudan anlayacağı fiziksel çıktı sonucu gösterilir.
                if (isMultipleChoice) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Bir A4'e kaç öğrenci formu sığsın?", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        val choices = listOf("SPACIOUS" to "1", "AUTOMATIC" to "2", "COMPACT" to "4")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            choices.forEach { (code, label) ->
                                FilterChip(
                                    selected = uiState.layoutDensity.equals(code, ignoreCase = true),
                                    onClick = { onLayoutDensityChange(code) },
                                    enabled = !uiState.hasUploadedPapers,
                                    label = { Text("$label öğrenci") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        val formsPerA4 = when (uiState.layoutDensity.uppercase()) { "COMPACT" -> 4; "SPACIOUS" -> 1; else -> 2 }
                        val logicalPages = uiState.pageLayouts.size.coerceAtLeast(1)
                        val totalForms = uiState.studentCount.coerceAtLeast(1) * logicalPages
                        val a4Pages = (totalForms + formsPerA4 - 1) / formsPerA4
                        Text(
                            "Sonuç: ${uiState.questions.size} soru • ${uiState.studentCount} öğrenci • yaklaşık $a4Pages A4 sayfası. Formları kesip öğrencilere dağıtın; okuma için her küçük formu ayrı fotoğraflayın/tarayın.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        val previewLineColor = MaterialTheme.colorScheme.outline
                        val previewFillColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        Canvas(
                            modifier = Modifier
                                .width(116.dp)
                                .aspectRatio(595f / 842f)
                                .border(1.dp, previewLineColor, RoundedCornerShape(3.dp))
                                .align(Alignment.CenterHorizontally)
                        ) {
                            drawRect(previewFillColor)
                            if (formsPerA4 >= 2) {
                                drawLine(previewLineColor, start = androidx.compose.ui.geometry.Offset(0f, size.height / 2f), end = androidx.compose.ui.geometry.Offset(size.width, size.height / 2f), strokeWidth = 2f)
                            }
                            if (formsPerA4 == 4) {
                                drawLine(previewLineColor, start = androidx.compose.ui.geometry.Offset(size.width / 2f, 0f), end = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height), strokeWidth = 2f)
                            }
                        }
                        Text(
                            "Canlı A4 yerleşim önizlemesi • sayfa başına $formsPerA4 öğrenci",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Yerleşim Yoğunluğu", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AnswerSheetDensity.values().forEach { densityOption ->
                                FilterChip(
                                    selected = uiState.layoutDensity.equals(densityOption.code, ignoreCase = true),
                                    onClick = { onLayoutDensityChange(densityOption.code) },
                                    enabled = !uiState.hasUploadedPapers,
                                    label = { Text(densityOption.label, fontSize = 11.sp, maxLines = 1) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // SECTION B: Cevap Alanı / Satır Ayarları
        if (uiState.draft?.examType == ExamType.MULTIPLE_CHOICE) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "B. Test İşaretleme Alanları",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Her soru tek kompakt satırda gösterilir. Seçenek harfleri dairelerin içindedir. Her küçük form kendi QR ve hizalama işaretlerini taşır; kesilip öğrenciye dağıtılabilir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${uiState.questions.size} test sorusu için optik işaretleme alanı hazır.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        } else {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "B. Cevap Alanı / Satır Ayarları",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (uiState.lineOverrides.isNotEmpty()) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${uiState.lineOverrides.size} Değişiklik",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (uiState.lineOverrides.isNotEmpty()) {
                    TextButton(
                        onClick = onResetLineOverrides,
                        enabled = !uiState.hasUploadedPapers,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Varsayılana Sıfırla")
                    }
                }

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    uiState.questions.sortedBy { it.orderIndex }.forEach { question ->
                        val boxSpec = ExamAnswerSheetLayoutCalculator.calculateQuestionBoxSpec(
                            question = question,
                            rubricCriteria = uiState.rubricCriteria,
                            density = AnswerSheetDensity.fromCode(uiState.layoutDensity),
                            lineOverrides = uiState.lineOverrides,
                            examType = uiState.draft?.examType ?: ExamType.WRITTEN
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Soru ${question.questionNumber}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${question.points} Puan",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                IconButton(
                                    onClick = { onLineOverrideChange(question.orderIndex, -1) },
                                    enabled = !uiState.hasUploadedPapers && boxSpec.lineCount > 3,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (!uiState.hasUploadedPapers && boxSpec.lineCount > 3)
                                                MaterialTheme.colorScheme.primaryContainer
                                            else
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            RoundedCornerShape(20.dp)
                                        )
                                ) {
                                    Icon(
                                        Icons.Default.Remove,
                                        contentDescription = "Satır Azalt",
                                        modifier = Modifier.size(18.dp),
                                        tint = if (!uiState.hasUploadedPapers && boxSpec.lineCount > 3)
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        else
                                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                }

                                Text(
                                    text = "${boxSpec.lineCount} satır",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.widthIn(min = 60.dp),
                                    textAlign = TextAlign.Center
                                )

                                IconButton(
                                    onClick = { onLineOverrideChange(question.orderIndex, 1) },
                                    enabled = !uiState.hasUploadedPapers && boxSpec.lineCount < 25,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (!uiState.hasUploadedPapers && boxSpec.lineCount < 25)
                                                MaterialTheme.colorScheme.primaryContainer
                                            else
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            RoundedCornerShape(20.dp)
                                        )
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Satır Artır",
                                        modifier = Modifier.size(18.dp),
                                        tint = if (!uiState.hasUploadedPapers && boxSpec.lineCount < 25)
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        else
                                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        }

        // SECTION C: Öğrenci Sayısı
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "C. Öğrenci Sayısı",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Toplam Öğrenci Sayısı",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Her öğrenciye özel QR kod üretilir.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { onStudentCountChange(uiState.studentCount - 1) },
                            enabled = uiState.studentCount > 1 && !uiState.hasUploadedPapers,
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (uiState.studentCount > 1) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    RoundedCornerShape(20.dp)
                                )
                        ) {
                            Icon(
                                Icons.Default.Remove,
                                contentDescription = "Azalt",
                                tint = if (uiState.studentCount > 1) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }

                        OutlinedTextField(
                            value = if (uiState.studentCount == 0) "" else uiState.studentCount.toString(),
                            onValueChange = { input ->
                                if (input.isEmpty()) {
                                    onStudentCountChange(0)
                                } else {
                                    val count = input.toIntOrNull()
                                    if (count != null) {
                                        onStudentCountChange(count)
                                    }
                                }
                            },
                            modifier = Modifier
                                .width(75.dp)
                                .testTag(AnswerSheetTestTags.STUDENT_COUNT_INPUT),
                            enabled = !uiState.hasUploadedPapers,
                            singleLine = true,
                            textStyle = MaterialTheme.typography.titleMedium.copy(textAlign = TextAlign.Center),
                            shape = RoundedCornerShape(8.dp)
                        )

                        IconButton(
                            onClick = { onStudentCountChange(uiState.studentCount + 1) },
                            enabled = uiState.studentCount < 500 && !uiState.hasUploadedPapers,
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (uiState.studentCount < 500) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    RoundedCornerShape(20.dp)
                                )
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Artır",
                                tint = if (uiState.studentCount < 500) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }

        // SECTION D: PDF Durumu ve İşlemleri
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "D. PDF Durumu ve İşlemleri",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                // PDF Generation Progress Banner
                if (uiState.isGeneratingPdf) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.5.dp
                            )
                            Column {
                                Text(
                                    text = uiState.pdfGenerationProgress ?: "Toplu PDF hazırlanıyor...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Lütfen bekleyin, bu işlem öğrenci sayısına göre biraz zaman alabilir.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                } else {
                    // PDF Status Indicator (Up-to-date vs Stale vs None)
                    if (uiState.generatedPdfFile != null) {
                        if (uiState.isPdfUpToDate) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                                Column {
                                    Text(
                                        text = "PDF Hazır ✓",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                    Text(
                                        text = "${uiState.studentCount} Öğrenci • ${uiState.generatedPdfFile.name} (${uiState.generatedPdfFile.length() / 1024} KB)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            }
                        } else {
                            // PDF is STALE (Amber / Warning indication rather than red error)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(1.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                                Column {
                                    Text(
                                        text = uiState.pdfStaleTitle ?: "Cevap kâğıdı düzeni değiştirildi.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Text(
                                        text = uiState.pdfStaleSubtitle ?: "Yeni yerleşimi kullanmak için PDF'yi yeniden oluşturun.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp)
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "PDF henüz oluşturulmadı. Devam etmek için PDF oluşturun.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (uiState.generatedPdfFile != null && uiState.isPdfUpToDate) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onGeneratePdf(context) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag(AnswerSheetTestTags.GENERATE_PDF_BUTTON),
                            enabled = !uiState.isGeneratingPdf && !uiState.isSavingSettings
                        ) {
                            if (uiState.isGeneratingPdf) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Hazırlanıyor...")
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Yeniden Oluştur", maxLines = 1)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onSavePdf(context) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag(AnswerSheetTestTags.SAVE_PDF_BUTTON)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kaydet")
                            }

                            Button(
                                onClick = {
                                    sharePdfFile(context, uiState.generatedPdfFile)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag(AnswerSheetTestTags.SHARE_PDF_BUTTON)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Paylaş")
                            }
                        }
                    }
                } else {
                    Button(
                        onClick = { onGeneratePdf(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag(AnswerSheetTestTags.GENERATE_PDF_BUTTON),
                        enabled = !uiState.isGeneratingPdf && !uiState.isSavingSettings
                    ) {
                        if (uiState.isGeneratingPdf) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Hazırlanıyor...")
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (uiState.generatedPdfFile != null) "Yeniden Oluştur" else "Toplu PDF Oluştur", maxLines = 1)
                        }
                    }
                }
            }
        }

        // SECTION E: Cevap Kâğıdı Önizlemesi
        val pageLayout = uiState.pageLayouts.find { it.pageIndex == uiState.selectedPreviewPageIndex }
            ?: uiState.pageLayouts.firstOrNull()

        if (pageLayout != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(AnswerSheetTestTags.PREVIEW_CARD),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column {
                        Text(
                            text = if (isMultipleChoice) "E. Test Cevap Kâğıdı Önizlemesi" else "E. Cevap Kâğıdı Önizlemesi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Öğrenci #1 Örnek Yerleşimi",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // A4 Paper Canvas Container with Zoom/Pan & Fullscreen Inspection
                    ZoomableA4PreviewContainer(
                        titleHeader = uiState.titleHeader,
                        pageLayouts = uiState.pageLayouts,
                        selectedPageIndex = uiState.selectedPreviewPageIndex,
                        onSelectPreviewPage = onSelectPreviewPage,
                        teachers = uiState.draft?.teachers ?: emptyList(),
                        totalPoints = uiState.draft?.totalPoints ?: 100,
                        examDraftId = uiState.draft?.id ?: 0L,
                        examDateMillis = uiState.draft?.examDate ?: 0L,
                        examType = uiState.draft?.examType ?: ExamType.WRITTEN,
                        listeningGuidance = uiState.listeningGuidance
                    )
                }
            }
        }

        // SECTION F: Devam Et
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (uiState.isSavingSettings) {
                Text(
                    text = "Cevap kâğıdı ayarları kaydediliyor…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(
                onClick = onContinue,
                enabled = uiState.isPdfUpToDate && !uiState.isSavingSettings,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag(AnswerSheetTestTags.CONTINUE_BUTTON)
            ) {
                Text(
                    text = "Devam Et",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = if (uiState.isPdfUpToDate) {
                    "Güncel cevap kâğıdı oluşturuldu. Bir sonraki aşamaya geçebilirsiniz."
                } else {
                    "Devam etmek için öncelikle güncel bir PDF oluşturmalısınız."
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (uiState.isPdfUpToDate) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
fun ZoomableA4PreviewContainer(
    titleHeader: String,
    pageLayouts: List<AnswerSheetPageLayout>,
    selectedPageIndex: Int,
    onSelectPreviewPage: (Int) -> Unit,
    teachers: List<String>,
    totalPoints: Int,
    examDraftId: Long,
    examDateMillis: Long,
    examType: ExamType = ExamType.WRITTEN,
    listeningGuidance: ListeningAnswerSheetGuidance? = null,
    modifier: Modifier = Modifier
) {
    val pageLayout = pageLayouts.getOrElse(selectedPageIndex - 1) { pageLayouts.firstOrNull() }
        ?: return

    var isFullscreenOpen by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Visible and Prominent Page Navigation Bar for Multi-Page Answer Sheets
        if (pageLayouts.size > 1) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (selectedPageIndex > 1) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPreviewPage(selectedPageIndex - 1)
                            }
                        },
                        enabled = selectedPageIndex > 1,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag(AnswerSheetTestTags.PREVIOUS_PAGE_BUTTON)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Önceki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "Sayfa $selectedPageIndex / ${pageLayouts.size}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedButton(
                        onClick = {
                            if (selectedPageIndex < pageLayouts.size) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPreviewPage(selectedPageIndex + 1)
                            }
                        },
                        enabled = selectedPageIndex < pageLayouts.size,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag(AnswerSheetTestTags.NEXT_PAGE_BUTTON)
                    ) {
                        Text("Sonraki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Quick zoom & inspect toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = scale <= 1.05f,
                    onClick = {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                    },
                    label = { Text("Sayfaya Sığdır", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = scale in 1.8f..2.4f,
                    onClick = {
                        scale = 2.1f
                        offsetX = 0f
                        offsetY = 0f
                    },
                    label = { Text("Genişliğe Sığdır", fontSize = 11.sp) }
                )
            }

            OutlinedButton(
                onClick = { isFullscreenOpen = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tam Ekran İncele", fontSize = 11.sp)
            }
        }

        // Interactive Inline Preview Canvas Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f / 1.414f)
                .clip(RoundedCornerShape(6.dp))
                .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                .background(Color(0xFFE2E8F0))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1.2f) {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            } else {
                                scale = 2.2f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        },
                        onTap = {
                            isFullscreenOpen = true
                        }
                    )
                }
                .pointerInput(selectedPageIndex, pageLayouts.size, scale) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        if (scale <= 1.05f && pageLayouts.size > 1) {
                            if (dragAmount < -50f && selectedPageIndex < pageLayouts.size) {
                                change.consume()
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPreviewPage(selectedPageIndex + 1)
                            } else if (dragAmount > 50f && selectedPageIndex > 1) {
                                change.consume()
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                                onSelectPreviewPage(selectedPageIndex - 1)
                            }
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 4f)
                        scale = newScale
                        if (newScale > 1f) {
                            offsetX += pan.x
                            offsetY += pan.y
                        } else {
                            offsetX = 0f
                            offsetY = 0f
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
            ) {
                A4AnswerSheetPaperPreview(
                    titleHeader = titleHeader,
                    pageLayout = pageLayout,
                    teachers = teachers,
                    totalPoints = totalPoints,
                    examDraftId = examDraftId,
                    examDateMillis = examDateMillis,
                    examType = examType,
                    listeningGuidance = listeningGuidance
                )
            }

            if (scale > 1.05f) {
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "${(scale * 100).toInt()}%",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }

    // Fullscreen Inspect Dialog
    if (isFullscreenOpen) {
        Dialog(
            onDismissRequest = { isFullscreenOpen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            var fsScale by remember { mutableFloatStateOf(1f) }
            var fsOffsetX by remember { mutableFloatStateOf(0f) }
            var fsOffsetY by remember { mutableFloatStateOf(0f) }

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF1E293B)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Dialog Header
                    Surface(
                        color = Color(0xFF0F172A),
                        tonalElevation = 4.dp
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .statusBarsPadding()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(onClick = { isFullscreenOpen = false }) {
                                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                                    }
                                    Text(
                                        text = "Cevap Kâğıdı İnceleme",
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            fsScale = 1f
                                            fsOffsetX = 0f
                                            fsOffsetY = 0f
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, Color.Gray),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("Sığdır", fontSize = 11.sp)
                                    }
                                    IconButton(
                                        onClick = { fsScale = (fsScale + 0.5f).coerceAtMost(4f) }
                                    ) {
                                        Icon(Icons.Default.ZoomIn, contentDescription = "Yakınlaştır", tint = Color.White)
                                    }
                                    IconButton(
                                        onClick = {
                                            fsScale = (fsScale - 0.5f).coerceAtLeast(1f)
                                            if (fsScale == 1f) {
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.ZoomOut, contentDescription = "Uzaklaştır", tint = Color.White)
                                    }
                                }
                            }

                            if (pageLayouts.size > 1) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E293B))
                                        .padding(horizontal = 16.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            if (selectedPageIndex > 1) {
                                                fsScale = 1f
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                                onSelectPreviewPage(selectedPageIndex - 1)
                                            }
                                        },
                                        enabled = selectedPageIndex > 1,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, Color.Gray),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Önceki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Text(
                                        text = "Sayfa $selectedPageIndex / ${pageLayouts.size}",
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )

                                    OutlinedButton(
                                        onClick = {
                                            if (selectedPageIndex < pageLayouts.size) {
                                                fsScale = 1f
                                                fsOffsetX = 0f
                                                fsOffsetY = 0f
                                                onSelectPreviewPage(selectedPageIndex + 1)
                                            }
                                        },
                                        enabled = selectedPageIndex < pageLayouts.size,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                        border = BorderStroke(1.dp, Color.Gray),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("Sonraki", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Dialog Content Container
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        if (fsScale > 1.2f) {
                                            fsScale = 1f
                                            fsOffsetX = 0f
                                            fsOffsetY = 0f
                                        } else {
                                            fsScale = 2.5f
                                            fsOffsetX = 0f
                                            fsOffsetY = 0f
                                        }
                                    }
                                )
                            }
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (fsScale * zoom).coerceIn(1f, 4f)
                                    fsScale = newScale
                                    if (newScale > 1f) {
                                        fsOffsetX += pan.x
                                        fsOffsetY += pan.y
                                    } else {
                                        fsOffsetX = 0f
                                        fsOffsetY = 0f
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .aspectRatio(1f / 1.414f)
                                .graphicsLayer(
                                    scaleX = fsScale,
                                    scaleY = fsScale,
                                    translationX = fsOffsetX,
                                    translationY = fsOffsetY
                                )
                        ) {
                            A4AnswerSheetPaperPreview(
                                titleHeader = titleHeader,
                                pageLayout = pageLayout,
                                teachers = teachers,
                                totalPoints = totalPoints,
                                examDraftId = examDraftId,
                                examDateMillis = examDateMillis,
                                examType = examType,
                                listeningGuidance = listeningGuidance
                            )
                        }

                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Ölçek: ${(fsScale * 100).toInt()}% • Çift dokunarak veya iki parmakla yakınlaştırın",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun A4AnswerSheetPaperPreview(
    titleHeader: String,
    pageLayout: AnswerSheetPageLayout,
    teachers: List<String>,
    totalPoints: Int,
    examDraftId: Long,
    examDateMillis: Long,
    examType: ExamType = ExamType.WRITTEN,
    listeningGuidance: ListeningAnswerSheetGuidance? = null,
    modifier: Modifier = Modifier
) {
    val examDateStr = remember(examDateMillis) {
        ExamAnswerSheetLayoutCalculator.formatExamDate(examDateMillis)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(595f / 842f)
            .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
            .clip(RoundedCornerShape(4.dp)),
        color = Color.White,
        shadowElevation = 4.dp
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val scale = size.width / 595f
            drawIntoCanvas { composeCanvas ->
                val nativeCanvas = composeCanvas.nativeCanvas
                val count = nativeCanvas.save()
                nativeCanvas.scale(scale, scale)

                ExamAnswerSheetPageRenderer.drawPage(
                    canvas = nativeCanvas,
                    pageLayout = pageLayout,
                    titleText = titleHeader,
                    teachers = teachers,
                    totalPoints = totalPoints,
                    examDraftId = examDraftId,
                    formToken = "PREVIEW",
                    studentIdx = 1,
                    examDateStr = examDateStr,
                    listeningGuidance = listeningGuidance,
                    examType = examType
                )

                nativeCanvas.restoreToCount(count)
            }
        }
    }
}

private fun sharePdfFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Cevap Kâğıdı PDF Paylaş"))
    } catch (e: Exception) {
        // Fallback or error logging
    }
}

