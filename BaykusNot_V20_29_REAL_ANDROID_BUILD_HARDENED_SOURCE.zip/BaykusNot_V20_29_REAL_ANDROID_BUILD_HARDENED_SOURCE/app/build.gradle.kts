import java.io.File as JavaFile
import java.net.URI as JavaURI
import java.security.KeyFactory as JavaKeyFactory
import java.security.MessageDigest as JavaMessageDigest
import java.security.Signature as JavaSignature
import java.security.spec.X509EncodedKeySpec as JavaX509EncodedKeySpec
import java.util.Base64 as JavaBase64

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.kotlin.serialization)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
}

fun baykusSourceFingerprint(label: String, sourceRoot: JavaFile, files: List<JavaFile>): String {
  val md = JavaMessageDigest.getInstance("SHA-256")
  md.update(label.toByteArray(Charsets.UTF_8)); md.update(0.toByte())
  files.sortedBy { it.path }.forEach { f ->
    require(f.isFile) { "Benchmark fingerprint kaynağı bulunamadı: ${f.path}" }
    md.update(f.path.substringAfter(sourceRoot.path).replace('\\', '/').toByteArray(Charsets.UTF_8)); md.update(0.toByte())
    md.update(f.readBytes()); md.update(0.toByte())
  }
  return md.digest().joinToString("") { "%02x".format(it) }
}

val evalPromptSha256 = baykusSourceFingerprint("EVALUATION_PROMPT", rootProject.projectDir, listOf(
  rootProject.file("app/src/main/java/com/example/core/network/EvaluationPromptPolicy.kt")
))
val evalSchemaSha256 = baykusSourceFingerprint("EVALUATION_SCHEMA", rootProject.projectDir, listOf(
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiExamEvaluator.kt")
))
val feedbackPromptSha256 = baykusSourceFingerprint("FEEDBACK_PROMPT", rootProject.projectDir, listOf(
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt")
))
val feedbackSchemaSha256 = baykusSourceFingerprint("FEEDBACK_SCHEMA", rootProject.projectDir, listOf(
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt")
))
val authoringSources = listOf(
  rootProject.file("app/src/main/java/com/example/core/network/ExtractionPromptPolicy.kt"),
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiExamQuestionExtractor.kt"),
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt"),
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiExamScenarioExtractor.kt"),
  rootProject.file("app/src/main/java/com/example/core/network/HttpGeminiQuestionObjectiveMatcher.kt")
)
val authoringPromptSha256 = baykusSourceFingerprint("AUTHORING_PROMPT", rootProject.projectDir, authoringSources)
val authoringSchemaSha256 = baykusSourceFingerprint("AUTHORING_SCHEMA", rootProject.projectDir, authoringSources)
val evalEngineRevision = "BN-EVAL-ENGINE-V20.29"
val feedbackEngineRevision = "BN-FEEDBACK-ENGINE-V20.29"
val authoringEngineRevision = "BN-AUTHOR-ENGINE-V20.29"

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.examevaluator.xkxqz"
    minSdk = 26
    targetSdk = 36
    versionCode = 30
    versionName = "1.27-v20.29"

    val gatewayUrl = (System.getenv("BAYKUS_AI_GATEWAY_URL") ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
    buildConfigField("String", "AI_GATEWAY_BASE_URL", "\"$gatewayUrl\"")

    val providerRetentionDays = (System.getenv("BAYKUS_PROVIDER_RETENTION_DAYS") ?: "-1").toIntOrNull() ?: -1
    val providerDatasetSharingDisabled = (System.getenv("BAYKUS_PROVIDER_DATASET_SHARING_DISABLED") ?: "false").equals("true", ignoreCase = true)
    val providerAccessRoles = (System.getenv("BAYKUS_PROVIDER_ACCESS_ROLES") ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
    val providerOperator = (System.getenv("BAYKUS_PROVIDER_OPERATOR") ?: "Google Gemini API via institution gateway").replace("\\", "\\\\").replace("\"", "\\\"")
    buildConfigField("int", "PROVIDER_RETENTION_DAYS", providerRetentionDays.toString())
    buildConfigField("boolean", "PROVIDER_DATASET_SHARING_DISABLED", providerDatasetSharingDisabled.toString())
    buildConfigField("String", "PROVIDER_ACCESS_ROLES", "\"$providerAccessRoles\"")
    buildConfigField("String", "PROVIDER_OPERATOR", "\"$providerOperator\"")

    // Production model approvals are developer-signed. The APK contains only the public key
    // and a base64-encoded signed manifest; the private signing key must never enter source or APK.
    val modelApprovalPublicKeyB64 = (System.getenv("BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64") ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
    val modelApprovalManifestB64 = (System.getenv("BAYKUS_MODEL_APPROVAL_MANIFEST_B64") ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
    buildConfigField("String", "MODEL_APPROVAL_PUBLIC_KEY_B64", "\"$modelApprovalPublicKeyB64\"")
    buildConfigField("String", "MODEL_APPROVAL_MANIFEST_B64", "\"$modelApprovalManifestB64\"")
    buildConfigField("String", "BENCH_EVALUATION_PROMPT_SHA256", "\"$evalPromptSha256\"")
    buildConfigField("String", "BENCH_EVALUATION_SCHEMA_SHA256", "\"$evalSchemaSha256\"")
    buildConfigField("String", "BENCH_EVALUATION_ENGINE_REVISION", "\"$evalEngineRevision\"")
    buildConfigField("String", "BENCH_FEEDBACK_PROMPT_SHA256", "\"$feedbackPromptSha256\"")
    buildConfigField("String", "BENCH_FEEDBACK_SCHEMA_SHA256", "\"$feedbackSchemaSha256\"")
    buildConfigField("String", "BENCH_FEEDBACK_ENGINE_REVISION", "\"$feedbackEngineRevision\"")
    buildConfigField("String", "BENCH_AUTHORING_PROMPT_SHA256", "\"$authoringPromptSha256\"")
    buildConfigField("String", "BENCH_AUTHORING_SCHEMA_SHA256", "\"$authoringSchemaSha256\"")
    buildConfigField("String", "BENCH_AUTHORING_ENGINE_REVISION", "\"$authoringEngineRevision\"")

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      buildConfigField("boolean", "ALLOW_DIRECT_GEMINI", "false")
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Development only. Production builds fail closed unless a secure gateway is configured.
      buildConfigField("boolean", "ALLOW_DIRECT_GEMINI", "true")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions {
    unitTests.isIncludeAndroidResources = true
    unitTests.all {
      it.jvmArgs(
        "--add-opens=java.base/java.lang=ALL-UNNAMED",
        "--add-opens=java.base/java.util=ALL-UNNAMED",
        "--add-opens=java.base/java.io=ALL-UNNAMED",
        "--add-opens=java.base/java.net=ALL-UNNAMED",
        "--add-opens=java.base/java.security=ALL-UNNAMED",
        "--add-opens=java.base/java.text=ALL-UNNAMED",
        "--add-opens=java.base/jdk.internal.access=ALL-UNNAMED",
        "--add-opens=java.desktop/java.awt.font=ALL-UNNAMED",
        "--add-opens=jdk.compiler/com.sun.tools.javac.api=ALL-UNNAMED"
      )
    }
  }
  sourceSets {
    getByName("androidTest") {
      assets.directories.add(
        "$projectDir/schemas"
      )
    }
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
}

ksp {
    arg(
        "room.schemaLocation",
        "$projectDir/schemas"
    )
}

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.kotlinx.serialization.json)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation("net.zetetic:sqlcipher-android:4.17.0@aar")
  implementation("androidx.sqlite:sqlite:2.6.2")
  implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  implementation(libs.zxing.core)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.room.testing)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}

// Release deployment guard lives in Gradle itself, not only in the convenience BAT wrapper.
val verifyReleaseDeploymentConfig = tasks.register("verifyReleaseDeploymentConfig") {
  doLast {
    val gateway = System.getenv("BAYKUS_AI_GATEWAY_URL")?.trim().orEmpty()
    require(gateway.startsWith("https://", ignoreCase = true) && JavaURI(gateway).host?.isNotBlank() == true) {
      "BAYKUS_AI_GATEWAY_URL geçerli bir HTTPS adresi olmalıdır."
    }
    val retention = System.getenv("BAYKUS_PROVIDER_RETENTION_DAYS")?.trim()?.toIntOrNull()
    require(retention in setOf(0, 7, 14, 28, 55)) { "Provider retention profili eksik/geçersiz." }
    require(System.getenv("BAYKUS_PROVIDER_DATASET_SHARING_DISABLED")?.equals("true", ignoreCase = true) == true) {
      "Production provider dataset sharing kapalı olarak doğrulanmalıdır."
    }
    require(System.getenv("BAYKUS_PROVIDER_ACCESS_ROLES")?.trim().orEmpty().isNotBlank()) {
      "Production provider access roles eksik."
    }
    val keystorePath = System.getenv("KEYSTORE_PATH")?.trim().orEmpty()
    require(keystorePath.isNotBlank() && file(keystorePath).isFile) { "KEYSTORE_PATH eksik veya dosya bulunamadı." }
    require(System.getenv("STORE_PASSWORD")?.isNotBlank() == true) { "STORE_PASSWORD eksik." }
    require(System.getenv("KEY_PASSWORD")?.isNotBlank() == true) { "KEY_PASSWORD eksik." }
  }
}

// Release-only cryptographic governance gate. A production APK must contain signed approvals for
// every default AI role; unsigned candidates and stale/tampered manifests cannot reach assembleRelease.
val verifyReleaseModelApprovals = tasks.register("verifyReleaseModelApprovals") {
  doLast {
    val publicKeyB64 = System.getenv("BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64")?.trim().orEmpty()
    val manifestB64 = System.getenv("BAYKUS_MODEL_APPROVAL_MANIFEST_B64")?.trim().orEmpty()
    require(publicKeyB64.isNotBlank()) { "BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64 eksik." }
    require(manifestB64.isNotBlank()) { "BAYKUS_MODEL_APPROVAL_MANIFEST_B64 eksik." }

    val publicKey = JavaKeyFactory.getInstance("EC").generatePublic(
      JavaX509EncodedKeySpec(JavaBase64.getDecoder().decode(publicKeyB64))
    )
    val manifest = String(JavaBase64.getDecoder().decode(manifestB64), Charsets.UTF_8)
    val records = manifest.lineSequence().map(String::trim).filter(String::isNotBlank).toList()
    require(records.isNotEmpty()) { "İmzalı model onay manifesti boş." }
    val approved = mutableMapOf<String, String>()
    val now = System.currentTimeMillis() / 1000L

    records.forEach { record ->
      val parts = record.split('|')
      require(parts.firstOrNull() == "BNBENCH4") { "Yalnız BNBENCH4 imzalı kayıt kabul edilir." }
      val sigPart = parts.lastOrNull().orEmpty()
      require(sigPart.startsWith("sig=")) { "BNBENCH4 imzası eksik." }
      val payload = parts.dropLast(1).joinToString("|")
      val verifier = JavaSignature.getInstance("SHA256withECDSA")
      verifier.initVerify(publicKey)
      verifier.update(payload.toByteArray(Charsets.UTF_8))
      require(verifier.verify(JavaBase64.getDecoder().decode(sigPart.removePrefix("sig=")))) {
        "BNBENCH4 imzası doğrulanamadı."
      }
      val kv = parts.drop(1).dropLast(1).associate { item ->
        val i = item.indexOf('='); require(i > 0) { "Bozuk BNBENCH4 alanı." }
        item.substring(0, i) to item.substring(i + 1)
      }
      require(kv["decision"] == "ADOPT" && kv["dataset"] == "REAL_ANONYMIZED" && kv["coverage"] == "PASS") {
        "Release manifesti yalnız REAL_ANONYMIZED + coverage PASS + ADOPT kayıtları içerebilir."
      }
      require((kv["cases"]?.toIntOrNull() ?: 0) >= 20) { "En az 20 gerçek anonim benchmark vakası gerekir." }
      val role = kv.getValue("role")
      val protocol = kv.getValue("protocol")
      val expectedFingerprint = when (role) {
        "EVALUATION" -> Triple(evalPromptSha256, evalSchemaSha256, evalEngineRevision)
        "FEEDBACK" -> Triple(feedbackPromptSha256, feedbackSchemaSha256, feedbackEngineRevision)
        "AUTHORING" -> Triple(authoringPromptSha256, authoringSchemaSha256, authoringEngineRevision)
        else -> error("Bilinmeyen BNBENCH4 rolü: $role")
      }
      require(kv["promptPolicySha256"] == expectedFingerprint.first &&
          kv["responseSchemaSha256"] == expectedFingerprint.second &&
          kv["evaluationEngineRevision"] == expectedFingerprint.third) {
        "BNBENCH4 prompt/schema/engine fingerprint'i bu kaynak sürümüyle eşleşmiyor."
      }
      fun metric(name: String): Double = kv[name]?.toDoubleOrNull() ?: Double.NaN
      when (role) {
        "EVALUATION" -> {
          require(protocol == "BN-EVAL-B") { "Evaluation benchmark protokolü geçersiz." }
          require(metric("within") >= 0.95 && metric("sim") >= 0.90 && metric("recall") >= 0.95) {
            "Evaluation benchmark kalite eşikleri karşılanmıyor."
          }
          require(kv["highTokens"]?.toIntOrNull() == 1120 && kv["highMedia"] == "1" &&
              kv["batch"] == "1" && kv["cache"] == "1" && kv["thinking"] == "1") {
            "Evaluation capability profili varsayılan release profiliyle eşleşmiyor."
          }
        }
        "FEEDBACK" -> {
          require(protocol == "BN-FEEDBACK-B") { "Feedback benchmark protokolü geçersiz." }
          require(metric("consistency") >= 0.98 && metric("pedagogy") >= 0.90 &&
              metric("turkish") >= 0.90 && metric("safety") >= 0.99 && metric("personalization") >= 0.85) {
            "Feedback benchmark kalite eşikleri karşılanmıyor."
          }
        }
        "AUTHORING" -> {
          require(protocol == "BN-AUTHOR-B") { "Authoring benchmark protokolü geçersiz." }
          require(metric("extraction") >= 0.95 && metric("rubric") >= 0.90 && metric("objective") >= 0.90 &&
              metric("hallucination") <= 0.02 && metric("correction") <= 0.10) {
            "Authoring benchmark kalite eşikleri karşılanmıyor."
          }
        }
        else -> error("Bilinmeyen BNBENCH4 rolü: $role")
      }
      val ts = kv["ts"]?.toLongOrNull() ?: error("BNBENCH4 ts eksik.")
      val expires = kv["expires"]?.toLongOrNull() ?: error("BNBENCH4 expires eksik.")
      require(now in ts..expires && expires - ts <= 366L * 24L * 60L * 60L) { "BNBENCH4 onayı süresi dolmuş/geçersiz." }
      approved[role] = kv.getValue("model")
    }

    val expected = mapOf(
      "EVALUATION" to "gemini-3.6-flash",
      "FEEDBACK" to "gemini-3.1-flash-lite",
      "AUTHORING" to "gemini-3.6-flash"
    )
    expected.forEach { (role, model) ->
      require(approved[role] == model) { "$role için varsayılan model $model imzalı release manifestinde onaylı değil." }
    }
  }
}

tasks.matching { it.name == "preReleaseBuild" }.configureEach {
  dependsOn(verifyReleaseDeploymentConfig)
  dependsOn(verifyReleaseModelApprovals)
}
