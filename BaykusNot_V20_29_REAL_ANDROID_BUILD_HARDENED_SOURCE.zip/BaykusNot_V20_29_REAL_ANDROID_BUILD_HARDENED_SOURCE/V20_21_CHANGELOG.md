# BaykuşNot V20.21 Changelog

## Production model governance
- Unsigned/hash-only BNBENCH3 records no longer grant production approval.
- Added ECDSA P-256 signed BNBENCH4 approval records.
- Added external signing helpers; private key is never stored in source/APK.
- Release build now requires signed approval public key + manifest.
- Build gate validates signature, REAL_ANONYMIZED dataset, coverage, >=20 cases, role protocol/quality thresholds, expiry and default evaluation capability binding.
- Runtime approval snapshots carry expiry timestamps and fail closed after expiry.
- Existing locked exam AI profiles are revalidated against current signed approvals before reuse.
- Production-facing error no longer tells teachers to manually paste benchmark codes; manual signed-record input remains DEBUG-only.

## Teacher Mode canonical migration
- Room schema 29 -> 30.
- Hidden technical settings are normalized to PAPER_BY_PAPER / BALANCED / STANDARD / reports enabled / Batch preference off / prompt caching on.
- Explicit teacher-owned writing, punctuation and feedback-detail choices are preserved.
- Runtime defensive canonicalization remains in place in addition to migration.

## Durable large-exam evaluation
- Added `exam_evaluation_run_state` durable checkpoint table.
- RUNNING evaluations resume after process death; PAUSED/ERROR do not auto-resume.
- 50+ student exams auto-select recoverable Batch when the approved model/backend supports it.
- Completed per-student transactions are reused rather than duplicated after recovery.
- Explicit stop persists PAUSED state.

## QA
- Added `v20_21_governance_scale_audit.py` with real ephemeral P-256 negative tests.
- Active source audit: 191/191 PASS.
- Governance/scale oracle: 24/24 PASS.
- Kotlin PSI: 320/320 PASS.
- Constructor/factory call-shape: 1544/1544 PASS.
- Real Gradle build remains BLOCKED_ENV before Kotlin compile because `services.gradle.org` DNS is unavailable in this environment.
