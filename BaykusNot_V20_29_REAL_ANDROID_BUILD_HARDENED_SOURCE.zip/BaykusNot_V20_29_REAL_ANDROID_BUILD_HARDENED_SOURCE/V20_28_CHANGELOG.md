# BaykuşNot V20.28 — Final Approval / Text Memory / Live Monitor / Import Lifecycle Hardened

V20.27 kaynak ağacının PASS kayıtlarına güvenmeden yapılan bağımsız taramada kalan beş açık ve aynı kökten bir import commit yarışı kapatıldı.

## Kaynak düzeltmeleri

1. **AI Evaluation Room hot-poll kaldırıldı.** `getLockedEvaluationModel()` artık 500 ms döngüsünde koşmuyor; yalnız ilk yüklemede ve evaluation inactive→active geçişinde yenileniyor.
2. **Tüm sonuçları onayla compare-and-commit oldu.** Öğrenci ve soru evaluation snapshot'ları, workflow `TEACHER_REVIEW` aşaması ve açık review request yokluğu aynı Room transaction içinde yeniden doğrulanmadan approval yazılmıyor.
3. **Teacher-review N+1 azaltıldı.** Final validation/report integrity yolları exam-wide question-evaluation snapshot'ını tek sorguyla alıp bellekte gruplayarak kullanıyor.
4. **TXT kaynak sınırı 2 MB olarak gerçek import sınırına bağlandı.** `text/plain` için declared-size, streamed actual-size, stored-file usability ve rubric source read aynı `BoundedInputReader.MAX_TEXT_BYTES` sınırını kullanıyor; `File.readText()` kaldırıldı.
5. **Multi-image ZIP lifecycle cancellation-cooperative oldu.** ZIP hazırlama döngüleri coroutine cancellation kontrol ediyor; cancellation temp ZIP'i siliyor ve sinyali yeniden yayıyor.
6. **Geçici kaynak dosyası sahipliği açık hale getirildi.** `SelectedPdfSource.cleanup` ile temp ZIP import Job'u tamamlandığında/cancel edildiğinde temizleniyor.
7. **Source import Job'u ViewModel lifecycle'a bağlandı.** Upload Source aşamasından çıkış/dispose artık source import işini de cancel ediyor.
8. **Import file/DB commit sınırı sertleştirildi.** Permanent move öncesi cancellation doğrulanıyor; move sonrası kısa DB ownership commit `NonCancellable` tamamlanıyor, böylece orphan file veya DB→missing-file yarışı oluşmuyor.
9. **Çoklu senaryo seçimi fail-closed.** OpenMultipleDocuments üzerinden birden fazla senaryo girdisinin ZIP olup metin gibi yorumlanması engellendi; senaryo için tek PDF/görsel zorunlu.
10. **QA kimliği V20.28'e taşındı.** `ACTIVE_AUDITS.md`, build marker'ları, release/local BAT'leri ve BNBENCH4 governance fingerprint helper aynı V20.28 revision'a bağlandı.

## Sürüm

- `versionCode = 29`
- `versionName = 1.26-v20.28`
- Room schema: **30** (değişmedi; yeni migration gerekmedi)
- Engine revisions: `BN-EVAL-ENGINE-V20.28`, `BN-FEEDBACK-ENGINE-V20.28`, `BN-AUTHOR-ENGINE-V20.28`
