# V20.15 Requirements Matrix

| Gereksinim | V20.15 karşılığı | Durum |
|---|---|---|
| Ana sayfadan gerçek akışa devam | `Screen.Workflow(draftId)` | PASS |
| Geri dönüş DB'de persist edilsin | `WorkflowViewModel.selectStage()` persisted rewind | PASS |
| Rewind sırasında stale AI/Batch sonucu yazılmasın | `stopEvaluationAndAwait` + reset + stage guards | PASS |
| Yerel optik rewind sonrası stale yazmasın | persisted `AI_EVALUATION` yazım guardları | PASS |
| Kaynak değişince eski soru seti kullanılmasın | `invalidateUnlockedQuestionSet` + retry/fail-closed | PASS |
| Yeni extraction staging seti öncelikli olsun | unlocked staging-first review | PASS |
| Mapping onayı cross-ref ile atomik geçersizleşsin | Room transaction | PASS |
| Soru toplamı/rubrik revision yeniden doğrulansın | Workflow contract guards | PASS |
| Eski basılı cevap formu reddedilsin | QR V4 + SHA-256 form token + `STALE_FORM` | PASS |
| Manuel eşleştirme stale formu aşamasın | repository + UI `status != VALID` | PASS |
| QR üretimi hata verirse form üretilmesin | fail-closed `QrCodeGenerator` | PASS |
| Test öğretmen anahtarı yanlış/eski formu reddetsin | versioned teacher-key QR token | PASS |
| Import process-death güvenli olsun | durable import journal + recovery | PASS |
| Import eşzamanlı mutasyonlara kapalı olsun | ViewModel single-operation guards | PASS |
| Çoklu görsel OOM/zip-bomb riski sınırlansın | streaming ZIP + 100 item / 50 MB | PASS |
| Dinleme source değişimi downstream'i invalid etsin | question invalidation | PASS |
| Ödev yarım kilitle ilerlemesin | question+rubric+preferences triple contract | PASS |
| Açık yeniden inceleme varken final onay olmasın | final integrity review-request gate | PASS |
| YAZEK beyan + veri bilgilendirme/onam kapısı | iki ayrı fail-closed doğrulama | PASS_SOURCE |
| Crash-safe tam silme | PREPARED/COMMITTED deletion journal | PASS |
| Statik audit | 150/150 | PASS |
| Semantik audit | 9/9 | PASS |
| Transactional audit | 23/23 | PASS |
| Runtime/lifecycle audit | 21/21 | PASS |
| Process-death audit | 18/18 | PASS |
| Deletion journal audit | 15/15 | PASS |
| YAZEK/onam audit | 16/16 | PASS |
| Compile-risk audit | 14/14 | PASS |
| V20.15 full-flow audit | 78/78 | PASS |
| Kotlin PSI syntax | 311/311 | PASS |
| Constructor/Factory call-shape | 1540/1540 | PASS |
| Android XML parse | 14/14 | PASS |
| Secret/private-key scan | 0 findings | PASS |
| Room migration validator | 21→25 schema + 25→28 SQL | PASS_STATIC |
| Gerçek Gradle/Android compile | `services.gradle.org` DNS çözülemiyor | BLOCKED_ENV |
| Room final schema 28 KSP export | gerçek Android/KSP build gerekli | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | kurum/backend altyapısı gerekli | BLOCKED_EXTERNAL_INFRA |
| TalkBack / %200 font / kamera / picker smoke | gerçek Android cihaz gerekli | DEVICE_TEST_REQUIRED |
| 20+ gerçek anonim öğretmen benchmarkı | gerçek veri ve öğretmen ground-truth gerekli | BLOCKED_REAL_DATA |
