# BaykuşNot V20.29 — Real Android Build Hardened

V20.29 gerçek GitHub Actions Android derlemesinin açığa çıkardığı build sorunlarını kaynağın kendisinde kapatır.

- `app/build.gradle.kts` içindeki `java.*` başvuruları Gradle Kotlin DSL `java` extension çakışmasını önlemek için explicit alias importlara taşındı.
- `net.zetetic:sqlcipher-android` 4.18.0 → 4.17.0 olarak pinlendi; compileSdk 36.1 korunur.
- targetSdk 36 değişmedi.
- versionCode 30 / versionName 1.27-v20.29.
- AI evaluation/feedback/authoring kaynakları değişmedi; engine revision değerleri V20.29 olarak güncellenir; production release için yeni signed benchmark approval gerekir.
