# V20.9 Requirements Matrix

| Gereksinim | V20.9 karşılığı | Durum |
|---|---|---|
| AI sınırı yalnız READY öğrenci kâğıdını kabul etsin | Repository `paper.status == READY` gate | PASS_STATIC / PASS_TRANSACTIONAL |
| Kimlik AI sınırında yeniden doğrulansın | `validateStudentIdentity()` repository re-check | PASS_STATIC / PASS_TRANSACTIONAL |
| YAZEK hedef şube yalnız doğrulanmış kâğıttan oluşsun | `eligiblePapers` fail-closed scope | PASS_TRANSACTIONAL |
| SQLCipher yarım swap sonrası veri kaybetmesin | `.encrypted.tmp` / `.plaintext.backup` startup recovery | PASS_STATIC / DEVICE_TEST_REQUIRED |
| Plaintext DB residue sessizce kalmasın | verified encrypted active + hard-delete residue check | PASS_STATIC / DEVICE_TEST_REQUIRED |
| Uzak Batch silme doğrulansın | cancel + delete, 2xx/404 confirmation | PASS_TRANSACTIONAL / GATEWAY_DEPLOY_REQUIRED |
| Uzak Files input/output silme doğrulansın | `files.delete` confirmation | PASS_TRANSACTIONAL / GATEWAY_DEPLOY_REQUIRED |
| Uzak silme başarısızsa retry bilgisi kaybolmasın | `REMOTE_DELETE_PENDING` + retained resource IDs | PASS_TRANSACTIONAL |
| Cleanup ledger crash-safe olsun | Android `AtomicFile` + read-back verify | PASS_TRANSACTIONAL |
| Sınav silinse de pending remote cleanup korunabilsin | file-based cleanup ledger independent of Room draft | PASS_TRANSACTIONAL |
| Bekleyen cleanup uygulama açılışında yeniden denensin | AppContainer maintenance retry | PASS_TRANSACTIONAL |
| Gateway eşleşince pending cleanup hemen denensin | settings enrollment retry | PASS_TRANSACTIONAL |
| Release gateway gerçek session alsın | enrollment → `/baykusnot/v1/session` → short token | PASS_STATIC / BACKEND_DEPLOY_REQUIRED |
| Token yalnız RAM'de, süreli ve yenilenebilir olsun | `GatewayAuthTokenStore` + expiry refresh | PASS_TRANSACTIONAL |
| 401 sonsuz retry oluşturmasın | exactly-once refresh/retry | PASS_TRANSACTIONAL |
| Hatalı enrollment kalıcı görünmesin | rollback/clear failed enrollment | PASS_TRANSACTIONAL |
| MANUAL moda geçiş local job'u tamamen durdursun | `cancelAndJoin()` | PASS_TRANSACTIONAL |
| MANUAL geçiş remote AI işini temizlesin/işaretlesin | cleanupDraft + pending count | PASS_TRANSACTIONAL |
| Fiziksel görüntü silinmeden DB referansı kaybolmasın | per-file verified deletion | PASS_TRANSACTIONAL |
| Legacy plaintext upgrade başarısızsa kullanılmasın | encryption fail-closed | PASS_TRANSACTIONAL |
| Provider retention/dataset/access policy zorunlu olsun | deployment-bound `ProviderDataProtectionProfile` | PASS_TRANSACTIONAL / DEPLOY_CONFIG_REQUIRED |
| Provider policy YAZEK fingerprint'ini değiştirsin | `providerPolicySignature` | PASS_TRANSACTIONAL |
| Öğrenci/veli harici veri işleme politikasını görebilsin | provider policy notice | PASS_STATIC |
| YAZEK amaç/kazanım scope kilidi | V20.8 learning outcome SHA-256 + fingerprint | PASS_SEMANTIC |
| MANUAL mod AI'ı yeniden başlatmasın | persistent processing mode | PASS_SEMANTIC |
| Rapor AI açıklaması gerçek rolleri göstersin | usage ledger + processing mode | PASS_SEMANTIC |
| Sınav silmede exam-scoped report cache temizlensin | report prefix deletion | PASS_SEMANTIC |
| Statik denetim | 131/131 | PASS |
| Semantik akış denetimi | 9/9 | PASS |
| Transactional/lifecycle denetimi | 23/23 | PASS |
| Kaynak manifest bütünlüğü | 460/460 SHA-256 | PASS |
| Room migration zinciri | 21→25 + 25→26 + 26→27 + 27→28 | PASS_SQL |
| Gerçek Gradle/Kotlin/Compose/KSP build | Gradle distribution dış DNS nedeniyle indirilemedi | BLOCKED_ENV |
| SQLCipher gerçek cihaz migration | fiziksel cihaz kabul testi | DEVICE_TEST_REQUIRED |
| Production authenticated gateway backend | kurum/backend deployment | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim benchmark | gerçek öğretmen adjudication verisi | BLOCKED_REAL_DATA |
| Accessibility gerçek cihaz testi | TalkBack / %200 font / focus | DEVICE_TEST_REQUIRED |
