# V20.10 Requirements Matrix

| Gereksinim | V20.10 karşılığı | Durum |
|---|---|---|
| Batch cancel gerçek terminal duruma ulaşmadan operation silinmesin | cancel → provider re-check → terminal gate → delete | PASS_RUNTIME |
| `batches.delete` iptal yerine kullanılmasın | aktif işte önce `:cancel`, sonra terminal doğrulama | PASS_RUNTIME |
| Batch input/output Files kaynakları operation'dan önce silinsin | confirmed file delete before operation delete | PASS_RUNTIME |
| Güncel Batch file sonucu okunsun | `responsesFile` + JSONL parser | PASS_STATIC / PASS_RUNTIME |
| Güncel inline sonucu okunsun | nested `inlinedResponses.inlinedResponses[]` parser | PASS_STATIC / PASS_RUNTIME |
| Batch remote cleanup başarısızlığı takip kimliğini kaybetmesin | AtomicFile + PENDING ledger | PASS_TRANSACTIONAL |
| Prompt cache başarısız remote delete yeniden denensin | `REMOTE_DELETE_PENDING` + retry | PASS_RUNTIME |
| Prompt cache audit yazılamazsa remote resource orphan olmasın | compensating delete | PASS_RUNTIME |
| Gateway enrollment sonrası tüm pending remote veri denensin | Batch + cache retry | PASS_STATIC / PASS_RUNTIME |
| Öğrenci görüntüsü crash-safe şifrelensin | AES-GCM + `AtomicFile` | PASS_STATIC / PASS_RUNTIME |
| Legacy plaintext upgrade fail-closed olsun | encryption doğrulanmadan görüntü kullanılmaz | PASS_TRANSACTIONAL |
| Kamera geçici plaintext'i DB kaydından önce silinsin | verified delete before page registration | PASS_RUNTIME |
| Kamera iptal/hatasında plaintext kalmasın | scrub/truncate + cleanup | PASS_STATIC / PASS_RUNTIME |
| Şifreli kamera orphan cleanup hatası gizlenmesin | hard failure | PASS_STATIC |
| Tam sınav silmede remote tracking privacy state'ten önce güvenli olsun | remote cleanup/PENDING → durable masks → local files → DB | PASS_RUNTIME |
| Privacy mask silme kalıcı yazılsın | `clearDurably()` + `commit()` | PASS_RUNTIME |
| Production gateway cleartext kullanmasın | HTTPS-only + `usesCleartextTraffic=false` | PASS_RUNTIME |
| Mobil production config Gemini secret istemesin | gateway-only `.env.example` | PASS_RUNTIME |
| Production build script HTTPS/policy fail-closed olsun | V20.10 BAT validation | PASS_STATIC |
| Room 25→28 migration kodu gerçekten ardışık çalıştırılsın | instrumented 25→26→27→28 migration test | PASS_STATIC / DEVICE_TEST_REQUIRED |
| Final Room schema 28 compiler tarafından export edilsin | KSP `room.schemaLocation` yapılandırılmış | BUILD_REQUIRED |
| Boş/ignored acceptance test kalmasın | no `dummyTest()` / no `@Ignore` | PASS_STATIC / PASS_RUNTIME |
| Önceki YAZEK kimlik/READY/scope kontrolleri korunsun | V20.9 transactional gates | PASS_TRANSACTIONAL |
| MANUAL mod AI'ı yeniden başlatmasın | V20.8 persistent processing mode | PASS_SEMANTIC |
| YAZEK eğitsel amaç/kazanım fingerprint'i korunsun | learning outcome signature | PASS_SEMANTIC |
| Statik denetim | `tools/static_audit.py` | 145/145 PASS |
| Semantik akış denetimi | `tools/semantic_flow_audit.py` | 9/9 PASS |
| Transactional denetim | `tools/transactional_flow_audit.py` | 23/23 PASS |
| Runtime/lifecycle denetimi | `tools/runtime_lifecycle_audit.py` | 20/20 PASS |
| Room migration validator | exported 21→25 + SQL 25→28 | PASS |
| Android XML parse | 14 XML | 14/14 PASS |
| Kaynak manifest bütünlüğü | 457 tracked source files | 457/457 PASS |
| Secret/private-key source scan | common secret patterns + sensitive files | PASS |
| Değiştirilen Kotlin dosyalarında parser/syntax riski | isolated `kotlinc` parser scan | NO_SYNTAX_DIAGNOSTIC |
| Gerçek Gradle/Kotlin/Compose/KSP build | Gradle 9.3.1 indirilemiyor (`services.gradle.org` DNS) | BLOCKED_ENV |
| SQLCipher gerçek cihaz migration | fiziksel Android cihaz | DEVICE_TEST_REQUIRED |
| Authenticated production gateway backend | kurum/backend deployment | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim/adjudicated benchmark | gerçek öğretmen verisi | BLOCKED_REAL_DATA |
| TalkBack/%200 font/focus kabul testi | fiziksel cihaz | DEVICE_TEST_REQUIRED |
