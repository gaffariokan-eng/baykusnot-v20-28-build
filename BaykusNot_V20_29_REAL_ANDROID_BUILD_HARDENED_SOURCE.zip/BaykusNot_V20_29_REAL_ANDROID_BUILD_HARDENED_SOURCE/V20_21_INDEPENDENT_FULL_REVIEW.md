# V20.21 Independent Full Review

V20.21 was produced after an independent audit of V20.20 found three production-governance/scale defects: forgeable hash-only benchmark evidence, lack of a production-supplied approval mechanism for clean installs, legacy technical preferences that could contradict the simplified Teacher Mode, and long evaluation work that was not explicitly durable.

## Closed findings

### 1. Benchmark authenticity
BNBENCH3 SHA-256 evidence no longer grants production authorization. BNBENCH4 uses ECDSA P-256 signatures. Runtime and release build both verify signatures; role thresholds and REAL_ANONYMIZED/coverage/case requirements are reapplied after signature verification. A source-package private key is prohibited.

The negative oracle creates an ephemeral P-256 key in memory and proves that a correct signature verifies while a changed payload and a wrong key fail. Result: 24/24 PASS.

### 2. Production clean-install governance
A production release no longer expects a teacher to paste benchmark records. The release process must inject a public key and signed manifest into BuildConfig. `preReleaseBuild` depends on `verifyReleaseModelApprovals`; the APK cannot be produced without valid approvals for the default evaluation, feedback and authoring roles. Manual signed-record entry exists only in DEBUG.

No synthetic/fake signed approval manifest is included in this source package. Actual release approval remains intentionally dependent on real 20+ anonymized teacher benchmark data and an external private signing key.

### 3. Teacher Mode migration
Room schema 30 canonicalizes hidden technical preferences from older installations. PAPER_BY_PAPER/BALANCED/STANDARD/report flags/cache policy are normalized while teacher-owned writing/punctuation and feedback detail choices are left intact. The repository also canonicalizes defensively before evaluation.

### 4. Durable evaluation scale
A durable `exam_evaluation_run_state` records user intent and progress metadata. RUNNING work can resume when the evaluation screen is recreated after process death, while PAUSED and ERROR do not auto-resume. For 50+ papers, approved Batch-capable profiles auto-route to recoverable Batch. Existing per-student transactions and Batch ledgers prevent unnecessary duplicate work.

## Regression state
- Static 191/191 PASS
- Full-flow 98/98 PASS
- Workflow matrix 25/25 PASS
- Governance/scale negative oracle 24/24 PASS
- Scale/retention 16/16 PASS
- Semantic 9/9 PASS
- Transactional 23/23 PASS
- Runtime/lifecycle 21/21 PASS
- Process-death 18/18 PASS
- Deletion journal 15/15 PASS
- YAZEK/onam 16/16 PASS
- YAZEK alignment 47/47 PASS
- Ethics evidence 37/37 PASS_SOURCE
- Compile-risk 14/14 PASS
- Kotlin PSI 320/320 PASS
- Call-shape 1544/1544 PASS
- Android XML 14/14 PASS
- Secret/private-key scan: 0 findings
- Room migration validator through schema 30: PASS_STATIC

## Not claimed
A real Android Gradle/Kotlin/KSP compilation was attempted but Gradle 9.3.1 could not be downloaded because `services.gradle.org` DNS resolution failed before Kotlin compilation. This is BLOCKED_ENV, not PASS.

Physical-device SQLCipher migration/recovery, TalkBack/%200 font/camera/picker and 500-student performance acceptance are still required. Production HTTPS gateway/backend deployment and real role-bound 20+ anonymized teacher benchmark/signing are external release requirements.

## Result
No new source-level P0/P1/P2 defect was found after the V20.21 corrections and final active regression/negative-audit pass. The remaining blockers are build-environment, device acceptance, real benchmark evidence and external production infrastructure.
