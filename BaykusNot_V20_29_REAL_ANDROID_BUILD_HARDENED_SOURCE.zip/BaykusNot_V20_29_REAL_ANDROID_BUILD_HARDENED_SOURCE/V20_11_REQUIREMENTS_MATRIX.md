# V20.11 Requirements Matrix

| Gereksinim | V20.11 karşılığı | Durum |
|---|---|---|
| Kamera açıkken Android process ölürse yeni çekim silinmesin | `CameraCaptureJournal` + active `AtomicFile` marker | PASS_STATIC / PASS_PROCESS_DEATH |
| Compose `remember` state kaybolsa bile kamera sonucu bulunabilsin | callback `tempCameraFile ?: currentCapture()` | PASS_PROCESS_DEATH |
| Yeni kamera çekimi önceki yarım plaintext'i bırakmasın | prepare-before-launch scrub + marker reset | PASS_PROCESS_DEATH |
| Eski aktif kamera plaintext'i süresiz kalmasın | stale active capture scrub/marker clear | PASS_PROCESS_DEATH |
| Kamera decode/context hatası cleanup'ı atlamasın | early `return` kaldırıldı; exception cleanup path | PASS_PROCESS_DEATH |
| Kamera plaintext'i DB registration öncesi silinsin | scrub → marker clear → page registration | PASS_RUNTIME |
| Toplu PDF ortada bozulursa yarım sayfa bırakmasın | per-exam AtomicFile import journal + rollback | PASS_PROCESS_DEATH |
| Çoklu fotoğrafta bozuk dosya sessizce atlanmasın | unreadable item = full batch failure | PASS_PROCESS_DEATH |
| Import sırasında process ölürse sonraki açılış toparlasın | `recoverInterruptedImport()` in upload startup | PASS_PROCESS_DEATH |
| Rollback DB referansını dosyadan önce silmesin | physical delete verified before DAO delete | PASS_PROCESS_DEATH |
| Tümünü Temizle yarım import orphan'larını da silsin | journal discard + upload directory cleanup | PASS_PROCESS_DEATH |
| Tam sınav silme import journalını da silsin | exam deletion managed target | PASS_PROCESS_DEATH |
| Release build JDK gereksinimini açık kontrol etsin | JDK 17+ BAT preflight | PASS_STATIC |
| Release source marker/builder aynı sürümü doğrulasın | V20.11 builder + marker | PASS_STATIC |
| Android sürüm güncellemesi kurulabilir olsun | versionCode 13 / versionName 1.10-v20.11 | PASS_STATIC |
| Önceki Batch/cache/remote cleanup güvenliği korunsun | V20.10 runtime gates | 20/20 PASS |
| Önceki YAZEK/SQLCipher/gateway transactional güvenliği korunsun | V20.9 transactional gates | 23/23 PASS |
| MANUAL/YAZEK purpose/report semantics korunsun | V20.8 semantic gates | 9/9 PASS |
| Kaynak/statik kurallar | `tools/static_audit.py` | 145/145 PASS |
| V20.11 process-death/import kuralları | `tools/v20_12_process_death_audit.py` | 18/18 PASS |
| Room migration validator | exported 21→25 + SQL 25→28 | PASS |
| Android XML parse | 14 XML | 14/14 PASS |
| Değiştirilen Kotlin dosyalarında parser/syntax riski | isolated `kotlinc` parser scan | NO_SYNTAX_DIAGNOSTIC |
| Gemini GenerateContent structured-output contract | current official REST docs rechecked | COMPATIBLE_AS_DOCUMENTED |
| Gerçek Gradle/Kotlin/Compose/KSP build | Gradle 9.3.1 download DNS failure before compiler | BLOCKED_ENV |
| Final Room schema 28 export | successful Room/KSP build required | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | physical Android device | DEVICE_TEST_REQUIRED |
| Authenticated production gateway backend | institution/backend deployment | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim/adjudicated benchmark | real teacher data | BLOCKED_REAL_DATA |
| TalkBack/%200 font/focus acceptance | physical device | DEVICE_TEST_REQUIRED |
