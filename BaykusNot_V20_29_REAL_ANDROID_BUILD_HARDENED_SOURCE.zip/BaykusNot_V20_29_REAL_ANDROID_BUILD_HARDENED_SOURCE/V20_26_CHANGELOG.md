# V20.26 Changelog

## Retry lifecycle
- Direct single-student retry jobs are tracked per draft/paper.
- Stop and workflow rewind cancel-and-join direct retry jobs together with the main evaluation job.
- Direct retry is rejected while a main evaluation is active or a durable pause/remote-cancel boundary is active.
- Direct retry never clears the global pause marker.

## Cancellation propagation
- `CancellationException` is rethrown instead of being persisted as an evaluation ERROR.
- Batch request preparation rethrows cancellation.
- Coroutine-aware OkHttp bridge cancels the underlying `Call` when the coroutine is cancelled.
- Evaluator, Batch, prompt-cache and gateway-session network paths use the cancellable bridge.

## Stage/write boundaries
- Active Batch polling validates AI_EVALUATION inside every polling iteration.
- Stage is checked again after provider status returns and before local result commit.
- Single-student failure path does not write stale ERROR after workflow rewind.

## Version / governance
- versionCode 27 / versionName 1.24-v20.26.
- Room schema remains 30; no DB schema change.
- Evaluation/feedback/authoring engine revisions advanced to V20.26.
