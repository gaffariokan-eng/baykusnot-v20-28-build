# V20.26 Requirements Matrix

| Requirement | Source control | Verification |
|---|---|---|
| Direct retry stops with workflow pause/rewind | retry jobs tracked per draft/paper; stop paths cancelAndJoin | 35/35 V20.26 lifecycle audit |
| Retry cannot clear a fresh Stop | retry path never calls clearPause; pause states reject retry | 35/35 |
| Cancellation is not persisted as ERROR | CancellationException rethrown | 35/35 + PSI |
| Stop cancels active evaluator HTTP | coroutine-aware OkHttp Call.cancel bridge | 35/35 |
| Stop cancels active Batch/cache/session HTTP | cancellable bridge on Batch/cache/gateway session | 35/35 |
| Batch stage guard is per poll iteration | guard physically inside while | 35/35 structural audit |
| Provider return cannot commit after rewind | post-status stage check + pre-commit guard | 35/35 |
| V20.25 uncertain submission/backoff protections retained | durable uncertain state, bounded recovery, exponential polling | 21/21 |
| AI Evaluation bulk live query retained | exam-level question evaluation Flow | 21/21 + 16/16 scale |
| Remote-cancel rewind boundary retained | workflow uses cleanupRemoteBatch=true | 21/21 + 25/25 workflow |
| Privacy/recovery/export controls retained | fail-closed + destructive recovery confirmation | 34/34 + 36/36 |
| YAZEK chain retained | declaration, anonymization, teacher final authority | 47/47 + 37/37 |
| Source syntax/call-shape | Kotlin PSI + constructor/factory call analysis | 323/323 + 1571/1571 |
| Real Android compilation | Gradle wrapper download unavailable in environment | BLOCKED_ENV |
