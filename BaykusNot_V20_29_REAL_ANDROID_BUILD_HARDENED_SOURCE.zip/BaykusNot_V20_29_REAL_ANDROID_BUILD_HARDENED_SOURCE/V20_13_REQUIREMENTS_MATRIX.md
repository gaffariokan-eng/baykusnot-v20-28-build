# V20.13 Requirements Matrix

| Gereksinim | V20.13 karşılığı | Durum |
|---|---|---|
| Resmî YAZEK beyanı uygulanmadan AI başlamasın | Ayrı `officialDeclarationApplied` doğrulaması | PASS_SOURCE |
| Gerekli öğrenci/veli bilgilendirme/onam tamamlanmadan AI başlamasın | Ayrı `noticeAndConsentCompleted` doğrulaması | PASS_SOURCE |
| Eski tek-tık YAZEK onayı yeni sürümde geçerli olmasın | `CURRENT_POLICY_VERSION=4` | PASS_SOURCE |
| UI iki koşul tamamlanmadan ilerlemesin | Confirm button `enabled = A && B` | PASS_SOURCE |
| Per-exam audit doğrulamanın anlamını kaydetsin | `scopeSummary` + `confirmedAt` | PASS_SOURCE |
| V20.12 crash-safe deletion korunmalı | PREPARED/COMMITTED deletion journal | PASS_LIFECYCLE |
| Gerçek Gradle/Android compile | `services.gradle.org` DNS erişimi yok | BLOCKED_ENV |
| Room final schema export | Gerçek KSP/Room build gerekli | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | Fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production gateway | Kurum/backend altyapısı gerekli | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim benchmark | Gerçek öğretmen verisi gerekli | BLOCKED_REAL_DATA |
| TalkBack / %200 font | Fiziksel cihaz/emülatör kabul testi | DEVICE_TEST_REQUIRED |
