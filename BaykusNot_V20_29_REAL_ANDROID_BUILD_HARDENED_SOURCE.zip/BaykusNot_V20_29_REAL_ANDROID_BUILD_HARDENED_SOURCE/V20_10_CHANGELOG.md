# BaykuşNot V20.10 Changelog

## P0 — Gemini Batch güncel API sözleşmesi ve transactional cleanup
- Aktif Batch işleminde `batches.delete` artık iptal yerine kullanılmaz.
- `batches.cancel` sonrası provider durumu tekrar okunur; işlem terminal duruma gelmeden operation kaydı silinmez.
- File-based Batch'te bilinen input/output Files kaynakları doğrulanarak silinmeden Batch operation kaydı kaldırılmaz.
- Başarısız iptal/silme `REMOTE_CANCEL_PENDING` / `REMOTE_DELETE_PENDING` olarak crash-safe ledger'da kalır.
- Güncel Gemini çıktıları desteklenir: `responsesFile` ve nested `inlinedResponses.inlinedResponses[]`; eski varyantlar geriye dönük uyumluluk için korunur.
- Output file resource kimliği indirmeden önce kalıcı ledger'a yazılır.

## P0 — Prompt-cache uzak veri yaşam döngüsü
- Prompt-cache kayıtları `AtomicFile` tabanlı crash-safe ledger'a alındı.
- Başarısız cached-content silmeleri `REMOTE_DELETE_PENDING` olarak korunur ve sonraki güvenli oturumda yeniden denenir.
- Cache provider'da oluşturulup yerel audit kaydı yazılamazsa compensating remote delete yapılır; izlenemeyen remote resource ile devam edilmez.
- Tam sınav silme orkestrasyonu prompt cache'i de kapsar.
- Gateway eşleştirmesi tamamlanınca bekleyen Batch ve prompt-cache cleanup birlikte yeniden denenir.

## P0 — Görüntü ve kamera crash-safety
- Öğrenci görüntüsü AES-GCM yazımı `AtomicFile` ile atomik hale getirildi.
- Legacy plaintext → encrypted yükseltme başarısızsa görüntü kullanılmaz.
- Kamera `TakePicture` geçici plaintext JPEG'i, şifreli kopya DB'ye kaydedilmeden önce silinmek zorundadır.
- Kamera iptali/başlatma hatasında geçici plaintext dosya scrub edilir; önceki oturumdan kalan `paper_camera` artefaktları açılışta temizlenir.
- Kamera işleme hatasında oluşan şifreli yetim dosya silinemiyorsa hata artık gizlenmez.

## P1 — Tam silme semantiği
- Uzak cleanup tamamlanmadan veya retry ledger'a güvenli biçimde alınmadan yerel privacy mask durumu değişmez.
- Privacy mask temizliği tam sınav silmede synchronous/durable `commit()` ile doğrulanır.
- Yerel sınav kök kaydı ancak remote tracking + privacy cleanup + managed file cleanup başarılı olduktan sonra silinir.

## P1 — Production gateway ve deployment hardening
- Release transport yalnız HTTPS gateway kabul eder; `usesCleartextTraffic=false`.
- Enrollment → kısa ömürlü session token → expiry refresh → tek 401 refresh/retry zinciri korunur.
- Başarılı enrollment sonrası hem Batch hem prompt-cache pending cleanup aynı oturumda denenir.
- `.env.example` mobil Gemini secret istemez; yalnız gateway ve provider retention/dataset/access policy alanlarını içerir.
- Release BAT HTTPS gateway ve provider policy değerlerini fail-closed doğrular.

## QA / test altyapısı
- `dummyTest()` testler gerçek sözleşme testleriyle değiştirildi; `@Ignore` acceptance kısayolları kaldırıldı.
- Room 25→26→27→28 ara migration zinciri, son committed exported schema 25 üzerinden instrumented testte gerçekten çalıştırılır.
- Ara schema 26/27 JSON'ları uydurulmaz; final schema 28 gerçek Room/KSP build tarafından export edilmelidir.
- Yeni `tools/runtime_lifecycle_audit.py` çapraz kaynak yaşam döngüsü ve işlem sırası kontrollerini yapar.
- Android `versionCode=12`, `versionName=1.9-v20.10`.
