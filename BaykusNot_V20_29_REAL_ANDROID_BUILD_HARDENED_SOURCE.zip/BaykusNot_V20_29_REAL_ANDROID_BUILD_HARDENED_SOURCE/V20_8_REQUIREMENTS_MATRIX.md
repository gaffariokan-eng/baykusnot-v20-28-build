# V20.8 Requirements Matrix

| Gereksinim | V20.8 karşılığı | Durum |
|---|---|---|
| YAZEK kapsamı gerçek eğitsel amaç/kazanım değişiminde geçersizleşsin | Objective/question content SHA-256 + scope fingerprint | PASS_STATIC |
| Hazırbulunuşluk yanlışlıkla normal yazılı sayılmasın | `ExamType.READINESS` ayrı purpose | PASS_STATIC |
| Manuel B-plan AI'ı kalıcı kapatsın | `exam_processing_mode`: MANUAL/NONE | PASS_STATIC |
| Rapor ekranı AI dönütünü yeniden başlatmasın | `countMissingFinalFeedback()` feedbackSource gate | PASS_SEMANTIC |
| AI yeniden açma açık öğretmen eylemi olsun | `enableAiProcessing()` + ayrı UI butonu | PASS_STATIC |
| Manuel aktif kayıtta eski AI provenance kalmasın | AI score/read/confidence reset; MANUAL source | PASS_SEMANTIC |
| Rapor AI açıklaması gerçek kullanılan rollere göre olsun | Usage ledger + processing mode disclosure | PASS_SEMANTIC |
| Sınav silince geçici rapor cache'i de silinsin | exam-scoped PDF prefix + delete orchestration | PASS_SEMANTIC |
| Öğrenci/veli veri bilgilendirmesi üretilebilsin | `studentParentDataNotice()` + copy UI | PASS_STATIC |
| Gateway kimliksiz relay olmasın | short-lived Bearer token fail-closed | PASS_STATIC / DEPLOY_REQUIRED |
| Room processing mode migration | 27→28 | PASS_SQL |
| Statik denetim | 108/108 | PASS |
| Semantik akış denetimi | 9/9 | PASS |
| Gerçek Gradle build | dış DNS engeli | BLOCKED_ENV |
| SQLCipher gerçek cihaz migrationı | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Gerçek authenticated gateway | kurum/backend deployment gerekli | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim benchmark | gerçek öğretmen verisi gerekli | BLOCKED_REAL_DATA |
