# V20.12 Requirements Matrix

| Gereksinim | V20.12 karşılığı | Durum |
|---|---|---|
| Tam silme yarım kullanılabilir sınav bırakmasın | PREPARED/COMMITTED `ExamDeletionJournal` | PASS_STATIC/SEMANTIC |
| Uzak kaynak takibi kaybolmasın | Remote Batch/cache cleanup/pending ledger journal'dan önce | PASS_TRANSACTIONAL |
| Room silme fiziksel dosya temizliğinden önce logical commit olsun | DB delete + read-back verify → COMMITTED | PASS_LIFECYCLE |
| Process DB silme ile marker arasında ölürse kurtarılsın | Startup `retryPendingLocalDeletion()` | PASS_LIFECYCLE |
| Dosya/mask cleanup yarıda kalırsa tekrar denensin | COMMITTED journal cleanup tamamlanana kadar korunur | PASS_LIFECYCLE |
| Gizlilik maskeleri yalnız commit sonrası kaldırılsın | `cleanupCommittedDeletion()` | PASS_LIFECYCLE |
| Geçici rapor/import journal tam silmeye dahil olsun | exam-scoped targets | PASS |
| Silme journal atomik olsun | Android `AtomicFile` + read-back verification | PASS |
| Journal davranış testi olsun | `ExamDeletionJournalTest` | PASS_SOURCE |
| Statik audit | 145/145 | PASS |
| Semantik audit | 9/9 | PASS |
| Transactional audit | 23/23 | PASS |
| Runtime/lifecycle audit | 21/21 | PASS |
| Process-death/import audit | 18/18 | PASS |
| V20.12 deletion-journal audit | 15/15 | PASS |
| Room migration validator | 21→25 schema + 25→28 SQL | PASS_STATIC |
| Gerçek Gradle/Android compile | `services.gradle.org` DNS erişimi yok | BLOCKED_ENV |
| Room final schema 28 export | gerçek KSP/Room build gerekli | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production gateway deployment | kurum/backend altyapısı gerekli | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim benchmark | gerçek öğretmen verisi gerekli | BLOCKED_REAL_DATA |
