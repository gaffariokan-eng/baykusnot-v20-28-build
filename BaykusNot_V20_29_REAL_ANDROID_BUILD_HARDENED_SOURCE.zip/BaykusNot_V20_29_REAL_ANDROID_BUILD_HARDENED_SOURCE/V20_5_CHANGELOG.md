# BaykuşNot V20.5 Changelog

## V20.4 sonrası kapatılan son denetim maddeleri
1. **Gerçek cache saklama maliyeti:** Cache create yanıtındaki `usageMetadata.totalTokenCount`, `createTime` ve `expireTime` kaydedilir; delete anı da tutulur. Maliyet gerçek token-saat üzerinden hesaplanır.
2. **Gerçek sağlayıcı model audit izi:** GenerateContent yanıtlarındaki `modelVersion`, `responseId`, `modelStatus.modelStage`, `retirementTime` ve mesaj alanları usage kayıtlarında saklanır.
3. **BN-BENCH-2 onay profili:** Eski model-adı-only onay kodu üretim için kullanılmaz. Onay kaydı model/protokol/kalite metrikleri + HIGH görüntü bütçesi + HIGH media/Batch/cache/thinking capability profilini bağlar. Minimum 20 benchmark vakası zorunludur.
4. **Dönüt payload minimizasyonu:** `originalAiScore` ve `teacherModified` dış modele gönderilmez. Öğretmen-AI çelişkisi yerelde sanitize edilir.
5. **Final safety/pedagoji kapısı:** Prompt block, finish reason, provider safety ratings, aşağılayıcı/etiketleyici dil ve tekrar üretilmiş sayısal puan yerelde kontrol edilir. Geçmeyen uzun dönüt kaydedilmez; Reports'ta eksik dönüt olarak yeniden denenebilir.
6. **Room 24→25:** `exam_ai_usage` sağlayıcı model audit alanlarıyla genişletildi.
7. **Rapor maliyet görünürlüğü:** Gerçek çağrı maliyeti ve gerçek cache saklama maliyeti ayrı, toplam sağlayıcı maliyeti birlikte gösterilir; actual model sürümleri ve response audit sayısı görünür.

## Korunan kararlar
- Öğretmenin günlük akışına model/YAZEK teknik ayrıntıları eklenmez.
- Öğretmen nihai not otoritesidir; e-Okul güncel resmi kayıttır.
- İki sayfalık kâğıt tek uzun görsel yapılmaz.
- Uzun kişisel dönüt BaykuşNot'un temel farklılaştırıcı özelliği olarak korunur.
- SQLCipher bu kaynak sürümünde bilinçli olarak zorla etkinleştirilmemiştir; gerçek Android build/device migration testi gerektirir.
