# BaykuşNot V20.19 Changelog

Tarih: 5 Eylül 2026

## Kapatılan bulgular

### P1 — Benchmark üretim kapısı fail-open
- Default model otomatik onayı kaldırıldı.
- EVALUATION / FEEDBACK / AUTHORING için rol-bazlı runtime network gate eklendi.
- Yalnız `BNBENCH3`, `REAL_ANONYMIZED`, minimum 20 vaka, coverage PASS ve rol kalite eşiklerini geçen kayıt üretim onayı verir.
- Profil reseti benchmark audit kanıtını artık silmez.

### P1/P2 — Öğretmen kısa notu eksik
- `exam_student_evaluation.teacherNote` eklendi.
- Room `MIGRATION_28_29` eklendi.
- Öğretmen inceleme UI, repository/DAO ve rapor/PDF zinciri tamamlandı.
- Not AI dönütünden görsel ve veri düzeyinde ayrı tutulur.

### P2 — Büyük raster OOM riski
- `SafeBitmapDecoder` eklendi.
- Dimension-first + sampled decode zorunlu hale getirildi.
- Öğrenci fotoğrafı, kamera dosyası, optik form ve legacy şifreli görüntü yolları bağlandı.

### P2 — DOCX / genel stream bellek güvenliği
- DOCX compressed, entry-count, XML/media-entry ve aggregate-uncompressed sınırları eklendi.
- ZIP traversal ve XML DOCTYPE/ENTITY reddi eklendi.
- `BoundedInputReader` ile belge/metin/şifreli görsel okumaları üst sınırlandı.
- Ana kullanıcı-kontrollü Kotlin kaynaklarında sınırsız `readBytes()` kaldırıldı.
- Kaynak ZIP 100 entry üstünde fail-closed.

### P2 — Batch cache-hit maliyet hatası
- Batch evaluation cache-hit token maliyeti `batchPriceFactor` ile çarpılır.
- Registry Batch pricing aynı davranışı uygular.
- Storage token-hour fiyatı Batch indiriminden bağımsız kalır.

## Test ekleri
- `GeminiModelRegistryHardeningTest`
- `DocxParserSecurityTest`
- `BoundedInputReaderTest`
- Room 28→29 intermediate migration assertion
- Statik hardening kontrolleri genişletildi.
