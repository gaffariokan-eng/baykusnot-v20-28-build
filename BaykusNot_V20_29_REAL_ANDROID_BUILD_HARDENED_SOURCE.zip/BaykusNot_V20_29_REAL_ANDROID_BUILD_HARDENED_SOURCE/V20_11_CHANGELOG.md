# BaykuşNot V20.11 Changelog

## Process-death-safe camera capture
- External `TakePicture` plaintext JPEG is tracked with an `AtomicFile` capture journal.
- Repository startup no longer wipes every `paper_camera` file; the active capture survives Android process recreation.
- Activity-result callback can recover the exact active file even when Compose `remember` state was lost.
- Starting a new capture safely scrubs any previous unfinished capture first.
- Missing/invalid/stale active markers are cleared; stale plaintext capture data is scrubbed instead of being preserved indefinitely.
- Decode/context/DB failures cannot bypass plaintext cleanup.
- Robolectric coverage was added for active capture preservation, replacement cleanup, missing-file recovery and stale-capture cleanup.

## Transactional PDF/photo import recovery
- PDF and multi-photo imports now use an `AtomicFile` per-exam import journal.
- Every newly-created encrypted page path is journaled before it can become an untracked partial import.
- A failed item causes the whole import batch to roll back instead of silently leaving the earlier pages committed.
- An unreadable photo is a hard batch failure; it is no longer silently skipped.
- If Android kills the process during import, reopening the upload workflow retries rollback from the durable journal.
- Rollback deletes physical student content before deleting its Room page row.
- `Tümünü Temizle` removes interrupted-import journal/orphan files; complete exam deletion removes the journal as well.

## Build/install hardening
- `versionCode=13`, `versionName=1.10-v20.11`.
- Release builder renamed to `BAYKUSNOT_BUILD_V20_11_RELEASE_APK.bat`.
- Build source marker is `BAYKUSNOT_SOURCE_V20_11_YAZEK_PROCESS_DEATH_HARDENED.marker`.
- Release builder checks Java first and stops with a clear message when JDK 17+ is unavailable.
- Production HTTPS gateway/provider-policy/signing fail-closed checks remain in place.
- Stale `.bak` test source was removed from the delivery package.

## API compatibility recheck
- Current Gemini GenerateContent documentation was rechecked on 2026-09-03. The legacy GenerateContent request still documents `responseMimeType` / `responseSchema`; therefore those existing calls were not changed blindly.
- Interactions-style calls continue to use their `response_format` contract.

## Acceptance expansion
- New `tools/v20_12_process_death_audit.py` covers camera journal, import rollback/recovery, cleanup integration, version/marker and JDK checks.
- Existing static, semantic, transactional, runtime/lifecycle and Room migration audits are rerun after the V20.11 changes.
