# BaykuşNot V20.15 Changelog

## Full-flow / navigation
- Ana sayfa **Devam Et** rotası gerçek Workflow'a bağlandı.
- Workflow içindeki **Bu Taslağı Sil** boş callback olmaktan çıkarılıp crash-safe tam silmeye bağlandı.
- Workflow rewind DB'de persist edilir; evaluation öncesine dönüşte çalışan AI/Batch/optik işler durdurulur ve türetilmiş sonuçlar geçersizleştirilir.
- İleri geçişler persisted stage'i yeniden okur; stale UI callback'leri yeni aşamaya zorlayamaz.

## Soru / rubrik / kaynak bütünlüğü
- Kaynak gerçekten değiştiğinde unlocked canonical sorular invalid edilir; reset başarısızsa extraction fail-closed durur.
- Kilit açıkken yeni staging soru seti eski canonical setten önce gelir.
- Soru toplam puanı ve rubrik question-set revision'ı ileri geçişlerde yeniden doğrulanır.
- Soru-kazanım cross-ref değişikliği ile `isObjectiveMappingApproved/isMismatchAccepted` sıfırlaması aynı Room transaction'ına alındı.
- Soru kaydetmeden önce mapping approval invalidasyonu başarısızsa kayıt durdurulur.
- Ders/sınıf/dönem/sınav sırası değişirse eski senaryo/kazanım kapsamı geçersizleştirilir.

## Fiziksel formlar
- Cevap kâğıdı layout version `6`, QR version `4` oldu.
- QR; sınav, soru, rubrik, layout ve sınav bilgilerine bağlı SHA-256 tabanlı form token taşır.
- Eski veya uyuşmayan form `STALE_FORM` olur; manuel eşleştirme bunu `VALID` yapamaz.
- QR üretimi başarısızsa PDF üretilmez.
- Öğrenci kâğıdı yüklendikten sonra öğrenci sayısı/layout/satır ayarları repository seviyesinde kilitlenir.
- Test öğretmen cevap anahtarı formu da güncel sınav+soru fingerprint'ine bağlı sürümlü QR taşır.

## Import / process-death / concurrency
- Yarım import recovery başarısızsa yükleme ekranı ilerlemez.
- Aynı anda iki import veya import sırasında sayfa silme/eşleştirme/düzenleme engellenir.
- Import mutasyon hataları kullanıcıya görünür hale getirildi.
- Çoklu kaynak görselleri RAM'de topluca biriktirmek yerine geçici ZIP'e stream edilir; 100 dosya ve 50 MB açılmış toplam boyut sınırı uygulanır.
- Bozuk, boş veya desteklenmeyen ZIP girdileri fail-closed reddedilir.

## Tür-özel akışlar
- Dinleme ses/metin değişikliği eski soru yapısını invalid eder.
- Ödev, soru + rubrik + değerlendirme tercihleri birlikte kilitli ve güncel revision'a bağlı olmadıkça hazır sayılmaz.
- Test/optik yerel sonuç yazımları AI_EVALUATION persisted-stage kontrolüne bağlıdır; rewind sonrası stale sonuç yazılamaz.
- Açık öğrenci/veli yeniden inceleme talebi nihai onay/rapor bütünlüğünü engeller.

## UI / hata yönetimi
- Kayıp taslak ve profil DB hatalarında sonsuz spinner yolları kapatıldı.
- Taslak/profil/final onay/import gibi işlemlerde ViewModel seviyesinde çift işlem korumaları eklendi.
- Kullanıcıya buton gibi görünüp `onClick={}` ile hiçbir şey yapmayan durum chip'leri pasif göstergelere çevrildi.
- Rapor geri-bildirim üretimi ve optik form okuma hata sonrası busy-state'te takılmaz.

## Sürüm
- `versionCode=16`
- `versionName=1.13-v20.15`
- Aktif marker: `BAYKUSNOT_SOURCE_V20_15_FULL_FLOW_HARDENED.marker`
