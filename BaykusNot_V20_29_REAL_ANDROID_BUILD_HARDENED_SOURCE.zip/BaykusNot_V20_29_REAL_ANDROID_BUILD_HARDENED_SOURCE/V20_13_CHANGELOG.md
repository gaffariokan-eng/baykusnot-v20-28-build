# BaykuşNot V20.13 Changelog

## P0 — YAZEK veri bilgilendirme / onam kapısı
- Gerçek öğrenci verisi AI hizmetine gönderilmeden önce iki ayrı fail-closed doğrulama zorunlu hale getirildi: resmî YAZEK Etik Beyan Formunun `Uygula` durumunda olması ve gerekli öğrenci/veli veri bilgilendirme + açık rıza/aydınlatılmış onam sürecinin tamamlanması.
- Tek eski YAZEK acknowledgement kayıtları policy v4 ile otomatik olarak geçersiz sayılır.
- UI onay düğmesi iki koşul da işaretlenmeden etkinleşmez.
- Öğrenci/veli veri bilgilendirme metni fotoğraf/görüntü/ses/video gibi kişisel veri için açık rıza/aydınlatılmış onam gereğini açıkça belirtir.
- Per-exam YAZEK audit snapshot, `confirmedAt` kaydının iki koşulun birlikte doğrulanmasını temsil ettiğini açıklar.

## Build / QA
- `versionCode=15`, `versionName=1.12-v20.13`.
- V20.13 release marker/build betiği oluşturuldu.
- Yeni `tools/v20_13_yazek_consent_audit.py` eklendi.

## Yerel compile/smoke test kolaylığı
- `BAYKUSNOT_BUILD_V20_13_LOCAL_TEST_ONLY.bat` eklendi. Gateway/signing istemeden `assembleDebug` çalıştırır ve yalnız sentetik/demo veriyle telefon açılış testi için APK kopyalar. Gerçek öğrenci verisi için uygun değildir.
