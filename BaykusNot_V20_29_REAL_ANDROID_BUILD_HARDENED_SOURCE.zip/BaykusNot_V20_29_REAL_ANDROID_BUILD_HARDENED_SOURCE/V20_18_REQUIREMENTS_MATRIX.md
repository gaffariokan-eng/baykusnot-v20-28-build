# V20.18 Requirements Matrix

| Gereksinim | V20.18 karşılığı | Durum |
|---|---|---|
| Resmî YAZEK form yardımında uygulama adı | `YazekDeclarationScope.applicationName` | PASS_SOURCE |
| Sınıf / Şube / Ders açık gösterilsin | `humanSummary()` form bloğu | PASS_SOURCE |
| Resmî kapsam kategorisi açık olsun | `Ölçme, Değerlendirme ve Geri Bildirim` | PASS_SOURCE |
| Kısa özet 10–500 karakter olsun | scope validation | PASS_SOURCE |
| Gerçek YZ aracı adı gösterilsin | `Google Gemini` | PASS_SOURCE |
| Çok şube tek belirsiz forma sıkıştırılmasın | şube başına ayrı `FORM n/N` bloğu | PASS_SOURCE |
| Resmî YAZEK doğrudan açılabilsin | `https://yazek.meb.gov.tr/` URI action | PASS_SOURCE |
| 8 etik ilke otomatik onaylanmasın | öğretmen manuel değerlendirme uyarısı | PASS_SOURCE |
| Halüsinasyon riski öğretmene gösterilsin | AI değerlendirme gate | PASS_SOURCE |
| Halüsinasyon riski öğrenci/veli bilgilendirmesinde olsun | `studentParentDataNotice()` | PASS_SOURCE |
| AI raporunda öğretmen nihai otoritesi + risk açıklansın | `ReportsViewModel` AI disclosure | PASS_SOURCE |
| Resmî beyan ve veri onamı ayrı doğrulansın | dual fail-closed confirmation | PASS_SOURCE |
| Resmî form yerel kayıtla ikame edilmesin | UI + store disclaimer | PASS_SOURCE |
| 3 günlük düzeltme penceresi açıklansın | teacher gate help text | PASS_SOURCE |
| Scope/purpose/tool/target değişimi eski beyanı geçersiz kılsın | fingerprint + policy v5 | PASS_SOURCE |
| Ayarlar teknik notu resmî YAZEK özeti gibi görünmesin | `AI Dağıtım / Şeffaflık Notu` | PASS_SOURCE |
| Öğretmen nihai karar verici olsun | score correction + final approval gates | PASS_SOURCE |
| Öğrenci/veli yeniden inceleme yolu olsun | `exam_review_request` | PASS_SOURCE |
| AI olmadan manuel B-plan olsun | `prepareManualTeacherReview` | PASS_SOURCE |
| Protected-attribute ayrımcılığı engellensin | `YazekContentPolicy` + local feedback validator | PASS_SOURCE |
| Millî/manevi/kültürel değer policy'si olsun | `YazekContentPolicy.promptRules` | PASS_SOURCE |
| Öğrenci görüntüsü at-rest şifreli | AES-256-GCM / Android Keystore | PASS_SOURCE |
| DB plaintext→SQLCipher geçişi fail-closed | `sqlcipher_export` + recovery | PASS_SOURCE |
| Provider retention/dataset/access profili eksikse AI bloklansın | `ProviderDataProtectionProfile.requireReady()` | PASS_SOURCE |
| Production release telefonda kalıcı Gemini secret istemesin | authenticated HTTPS gateway policy | PASS_SOURCE |
| V20.17 paper-mutation kapıları korunuyor | import/mutation busy gates | PASS |
| Static audit | 150/150 | PASS |
| Semantic audit | 9/9 | PASS |
| Transactional audit | 23/23 | PASS |
| Runtime/lifecycle audit | 21/21 | PASS |
| Process-death audit | 18/18 | PASS |
| Deletion journal audit | 15/15 | PASS |
| YAZEK/onam audit | 16/16 | PASS |
| YAZEK form-alignment audit | 47/47 | PASS |
| YAZEK 8-ethics source evidence | 37/37 | PASS_SOURCE |
| Compile-risk audit | 14/14 | PASS |
| Full-flow audit | 97/97 | PASS |
| 5 aktif sınav türü rota matrisi | 25/25 | PASS |
| Kotlin PSI syntax | 312/312 | PASS |
| Constructor/factory call-shape | 1542/1542 | PASS |
| Android XML parse | 14/14 | PASS |
| Secret/private-key scan | 0 finding | PASS |
| Room migration validator | exported 21→25 + 25→28 SQL | PASS_STATIC |
| Gerçek Gradle/Android compile | Gradle 9.3.1 download DNS engeli | BLOCKED_ENV |
| Room final schema 28 KSP export | gerçek Android/KSP build gerekli | BUILD_REQUIRED |
| SQLCipher gerçek cihaz migration | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| TalkBack / %200 font / kamera / picker | gerçek cihaz kabulü | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | kurum/backend altyapısı | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim/adjudicated benchmark | gerçek veri + teacher ground-truth | BLOCKED_REAL_DATA |
