# BaykuşNot V20.9 Changelog

## P0 — Repository-level öğrenci kâğıdı kimlik/READY kapısı
- `ExamEvaluationRepository.validatePaperIntegrity()` artık `paper.status == READY` ister.
- AI sınırında sınıf/şube/okul numarası tekrar `validateStudentIdentity()` ile doğrulanır.
- YAZEK `targetBranches` yalnız doğrulanmış READY kâğıtlardan üretilir; tek uyumsuz kâğıt tüm AI değerlendirmesini fail-closed durdurur.

## P0 — SQLCipher crash-safe geçiş ve plaintext residue kontrolü
- Açılışta eksik active DB + `.encrypted.tmp` veya `.plaintext.backup` durumları kurtarılır.
- Aktif şifreli DB yeniden doğrulanmadan Room açılmaz.
- Plaintext backup/WAL/SHM/journal kalıntıları silinemezse uygulama sessizce devam etmez.
- Instrumented test kaynağına interrupted-swap recovery senaryoları eklendi.

## P0 — Transactional remote Batch/Files cleanup
- `batches.cancel`, `batches.delete` ve `files.delete` sonuçları 2xx/404 ile doğrulanır.
- Uzak silme başarısızsa resource ID'ler `REMOTE_DELETE_PENDING` olarak korunur.
- Batch output Files resource adı indirme öncesi persist edilir; crash sonrası orphan resource izlenebilir kalır.
- Yerel sınav silme, uzak cleanup ledger'ını silmez.
- Bekleyen cleanup uygulama açılışında ve başarılı gateway eşleştirmesinden hemen sonra yeniden denenir.
- Ledger Android `AtomicFile` ile crash-safe yazılır ve read-back doğrulanır.

## P0 — Production gateway session zinciri
- Keystore-encrypted, kurum tarafından iptal edilebilir enrollment credential eklendi.
- `/baykusnot/v1/session` üzerinden kısa ömürlü token acquisition eklendi.
- Access token yalnız RAM'de tutulur ve expiry-aware yenilenir.
- Gateway 401 durumunda token bir kez yenilenip request yalnız bir kez retry edilir.
- Başarısız enrollment önceki credential'a rollback eder veya yeni credential'ı temizler.
- Ayarlar ekranına kurumsal gateway eşleştirme/çıkarma ve bağlantı testi eklendi.

## P1 — MANUAL geçiş ve aktif AI cancellation
- MANUAL geçiş local evaluation job'unu `cancelAndJoin()` ile tamamen bitirmeden manuel kayıt yazmaz.
- Uzak Batch/Files cleanup aynı geçişte başlatılır; doğrulanamayan silme retry ledger'da kalır.

## P1 — Yerel dosya silme doğruluğu
- `deletePage`, `deleteStudentPaper`, `clearAllPapers` ve arşiv-sonrası görüntü cleanup fiziksel dosya silinmesini doğrular.
- Silinemeyen dosyanın DB referansı korunur; kısmi başarısızlık kullanıcıya raporlanır ve tekrar denenebilir.

## P1 — Legacy plaintext fail-closed
- Eski plaintext öğrenci görüntüsü şifrelemeye yükseltilemezse bitmap kullanılmaz; işlem güvenli hata ile durur.

## P1 — Provider veri koruma profili
- Retention, dataset-sharing-disabled, operator ve access-role deployment alanları eklendi.
- Profil eksik/geçersizse production öğrenci AI gate fail-closed durur.
- Provider policy signature YAZEK scope fingerprint'ine eklenir; politika değişirse eski yerel uygunluk teyidi yeniden kullanılamaz.
- Öğrenci/veli veri bilgilendirmesi harici işleyen, saklama ve erişim rollerini gösterir.

## QA / paket
- `tools/static_audit.py`: 131/131 PASS.
- `tools/semantic_flow_audit.py`: 9/9 PASS.
- `tools/transactional_flow_audit.py`: 23/23 PASS.
- Room migration validation: PASS through target schema 28.
- Android XML: 14/14 PASS.
- `GatewayAuthTokenStore.kt` standalone Kotlin compile: PASS.
- Gradle build compiler öncesi dış DNS engelinde durdu: BLOCKED_ENV.
