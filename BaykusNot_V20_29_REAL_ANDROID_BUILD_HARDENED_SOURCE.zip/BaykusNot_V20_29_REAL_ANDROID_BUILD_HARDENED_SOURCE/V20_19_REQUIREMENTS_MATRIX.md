# BaykuşNot V20.19 Requirements Matrix

| Gereksinim | Kaynak kanıtı | Durum |
|---|---|---|
| Default AI modeli benchmark olmadan üretimde çalışmasın | role-specific approval sets + network `require*ModelApproved` gates | PASS_SOURCE |
| Benchmark gerçek anonim ve rol bazlı olsun | BNBENCH3 + REAL_ANONYMIZED + >=20 + coverage/thresholds | PASS_SOURCE |
| Profil reseti onay auditini silmesin | `PROFILE_SETTING_KEYS` selective reset | PASS_SOURCE |
| Öğretmen öğrenciye kendi kısa notunu yazabilsin | teacherNote entity/DAO/repository/UI | PASS_SOURCE |
| Öğretmen notu rapora/PDF'ye ayrı taşınsın | ReportsViewModel/Screen/PdfGenerator | PASS_SOURCE |
| DB eski kurulumdan teacherNote'a güvenli geçsin | Room 28→29 migration | PASS_STATIC |
| Büyük telefon fotoğrafı tam çözünürlükte kör açılmasın | SafeBitmapDecoder bounds/sample policy | PASS_SOURCE |
| Fotoğraf batch sayısı sınırlı olsun | repository max 100 | PASS_SOURCE |
| DOCX ZIP-bomb/traversal/XXE-benzeri belge reddedilsin | bounded entry/aggregate + path + DTD/entity gates | PASS_SOURCE |
| Kullanıcı kontrollü stream sınırsız heap okumaya dönüşmesin | BoundedInputReader; main source no `readBytes()` | PASS_SOURCE |
| Görsel kaynak ZIP >100 entry reddedilsin | repository ZIP count gate | PASS_SOURCE |
| Batch cache-hit fiyatı güncel Batch oranıyla hesaplansın | repository + registry batch factor | PASS_SOURCE |
| 5 aktif sınav türü uçtan uca route | workflow matrix | 25/25 PASS |
| Tam uygulama akış zinciri | full-flow audit | 98/98 PASS |
| YAZEK/onam | dual fail-closed consent audit | 16/16 PASS |
| YAZEK resmi form hizalaması | form alignment audit | 47/47 PASS |
| 8 etik ilke için kaynak kanıtı | ethics evidence audit | 37/37 PASS_SOURCE |
| Transactional bütünlük | transactional audit | 23/23 PASS |
| Runtime/lifecycle | lifecycle audit | 21/21 PASS |
| Process-death | process-death audit | 18/18 PASS |
| Crash-safe tam silme | deletion journal audit | 15/15 PASS |
| Statik denetim | static audit | 173/173 PASS |
| Kotlin sözdizimi | compiler PSI parser | 317/317 PASS |
| Constructor/factory call-shape | PSI call-shape | 1542/1542 PASS |
| Android XML | parser | 14/14 PASS |
| Secret/private key | source scan | 0 finding |
| Room 20→29 migration logic | exported 20→25 + intermediate 25→29 SQL | PASS_STATIC |
| Gerçek Gradle/KSP/Room derleme | Gradle distribution DNS erişimi yok | BLOCKED_ENV |
| Gerçek cihaz SQLCipher migration | fiziksel cihaz | DEVICE_TEST_REQUIRED |
| TalkBack/%200 font/kamera/picker | fiziksel cihaz | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | kurum/backend | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim öğretmen benchmarkı | gerçek veri + ground truth | BLOCKED_REAL_DATA |
