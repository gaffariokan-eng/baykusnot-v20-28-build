# V20.3 Validation Status

## Kaynak seviyesinde doğrulananlar
- Tam Android kaynak ağacı mevcut; `versionCode=5`, `versionName=1.3-v20.3`, Room schema 23.
- `tools/static_audit.py` V20.3 davranış kontrollerini kaynak karşılıklarıyla doğrular; son koşu **47/47 PASS**.
- Room `20→21`, `21→22`, `22→23` migration zinciri `tools/validate_room_schema_migrations.py` ile exported schema kolonlarına karşı doğrulanır.
- V20.3'te değişen Kotlin dosyaları bağımlılıksız `kotlinc` parser geçişine sokulmuştur; `expecting`, `unexpected tokens`, fazla/eksik named argument gibi doğrudan parser/call-shape tanısı görülmemiştir. Android/Compose/Room/coroutines classpath bulunmadığı için unresolved-reference çıktıları bu testin kapsamı dışındadır.
- Yeni form privacy davranışı: V3/unknown sayfada fiducial rectification başarısızsa AI hazırlığı `PrivacyAlignmentException` ile fail-closed olur.
- Teacher Review ve AI Review, soru crop'unda aynı rectified geometry yardımcılarını kullanır.
- Main evaluator'da öğrenci-facing soru prose'u ve yazım/noktalama prose schema'sı yoktur; yapılandırılmış teşhis vardır.
- Final prose writer raw answer/question/rubric/image tiplerini alamayan kompakt DTO kullanır; öğretmen nihai puanı eski AI score'undan üstün tutulur.
- Toplu PDF aggregate yolu `PdfRenderer`/bitmap rasterizasyonu kullanmaz.
- EXIF normalize, 2000px PRINT render ve kalite-94 şifreli kalıcı image yolu kaynakta bağlıdır.
- Runtime model profilinde standard input/output, cached input, cache storage, feedback input/output ve Batch katsayısı vardır.
- Üretim kodunda `*-latest` Gemini alias'ı yoktur.
- Benchmark `--dry-run` PASS; örnek scorer koşusu thinking tokenlarını billed output içine dahil ederek PASS.
- Benchmark runner dry-run PASS; örnek score koşusunda thinking tokenları billed output toplamına dahil edilerek maliyet hesabı doğrulanmıştır.

## Bu ortamda tamamlanamayan kabul testi
Gerçek `assembleDebug` / `compileDebugKotlin`: Gradle Wrapper 9.3.1 dağıtımı bu çalışma ortamında cache'li değildir ve dış indirme kanalları başarısız olmuştur. Bu nedenle AGP/KSP/Compose/Room resource linking ile APK üretimi ve fiziksel cihaz testi henüz PASS sayılamaz.

## İlk Windows/telefon kabul testleri
1. `BAYKUSNOT_BUILD_V20_3_APK.bat` ile `assembleDebug` PASS olmalı.
2. V20.2 üzerine V20.3 güncellemesi DB `22→23` migration ile veri kaybetmeden kurulmalı.
3. Yeni iki sayfalık cevap kâğıdında QR `V:3` ve dört fiducial yazıcıdan tam çıkmalı.
4. Bir fiducial kapatıldığında/kağıt aşırı yamuk çekildiğinde V3 sayfa AI'a gönderilmemeli ve yeniden çekim mesajı görünmeli.
5. Düz + hafif perspektifli fotoğraflarda kimlik başlığı AI payload'ında bulunmamalı.
6. 90°/180°/270° EXIF orientation örneklerinde upload preview ve AI hizalaması doğru yönde olmalı.
7. İki sayfa aynı öğrenci isteğinde iki ayrı HIGH image part olarak görünmeli.
8. Şüpheli soruda ikinci istek yalnız doğru cevap kutusunu taşımalı.
9. Teacher Review crop'u AI crop'uyla aynı cevabı göstermeli.
10. Öğretmen AI puanını belirgin artırıp/azalttığında final prose eski AI teşhisiyle çelişmemeli.
11. Yazım/noktalama prose yalnız onay sonrası ekonomik dönüt çağrısında oluşmalı.
12. Dönüt servisi kontrollü hata verdiğinde eksik dönüt görünür olmalı; yalnız dönüt retry notlamayı tekrarlamamalı.
13. `Tüm Öğrenci Dönütlerini Tek PDF` metinleri baskıda keskin kalmalı; bitmap/raster artefaktı olmamalı.
14. Model profilinde cached-input/storage fiyatı değiştirildiğinde maliyet tahmini yeniden hesaplanmalı.
15. Yeni öğrenci görüntüsü dosya baytları JPEG header'ı olmamalı; uygulama içi preview/decrypt çalışmalı.
16. Rapor sonrası cevap görüntüsü temizleme, puan/dönüt/onay kayıtlarını silmemeli.

## Bilinçli ertelenen sertleştirme
Room veritabanı ayrıca SQLCipher ile şifrelenmemiştir. SQLCipher yeni dış bağımlılık ve Room entegrasyonu gerektirdiğinden, gerçek Android derlemesi çalıştırılamayan bu ortamda zorla eklenmesi regresyon riskini artırır. Hassas öğrenci görüntüleri ayrı AES-GCM katmanında korunur; DB için SQLCipher gerçek build/device doğrulaması yapılabilen sonraki güvenlik sertleştirmesinde değerlendirilebilir.
