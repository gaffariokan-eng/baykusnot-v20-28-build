# V20.2 Validation Status

## Tamamlanan kaynak/doğrulama kontrolleri
- V20.2 tam kaynak ağacı V20.1 tabanından üretildi; 190+ Kotlin kaynak dosyası mevcut.
- Davranış odaklı `tools/static_audit.py` tüm V20.2 kabul kontrollerini çalıştırır.
- Room export schema 21/22 migration uyumu `tools/validate_room_schema_migrations.py` ile PASS. V20.2 DB şemasını değiştirmediği için DB sürümü 22 korunur.
- Değiştirilen Kotlin dosyalarında bağımlılıksız `kotlinc` parser geçişinde `expecting`, `unexpected tokens`, yinelenen named argument, eksik/çok argüman gibi parse/çağrı-sözdizimi tanısı görülmedi. Android/Compose/Room/coroutines classpath'i bulunmadığı için normal unresolved-reference tanıları bu kontrolün kapsamı dışındadır.
- Benchmark runner `--dry-run` ile sabit model kimliği + vaka manifesti doğrulanır; gerçek model çağrısı için `GEMINI_API_KEY` gerekir.
- Üretim kodunda `*-latest` Gemini alias'ı yoktur.
- Main evaluator görüntüleri `ExamImagePrivacyProcessor` üzerinden alır ve HIGH medya çözünürlüğü kullanır.
- Kamera ham görüntüsü yalnız cache'te geçici tutulur; kalıcı kayıt şifreli öğrenci görüntü deposuna terfi ettirilir.
- V20.1 belgeleri `docs/history/` altına taşınmıştır; V20.2 kök belgeleri güncel sürümü temsil eder.

## Bu ortamda tamamlanamayan kontrol
Gerçek `assembleDebug`/`compileDebugKotlin`: proje Gradle Wrapper 9.3.1 ister. Bu çalışma ortamında dağıtım önceden cache'lenmiş değildir ve `services.gradle.org` üzerinden indirme başarısız olmuştur. Bu nedenle Android SDK/AGP/KSP/Compose/Room ile gerçek derleme ve fiziksel cihaz testi henüz PASS sayılamaz.

## İlk Windows/telefon kabul testleri
1. `BAYKUSNOT_BUILD_V20_2_APK.bat` ile `assembleDebug` PASS olmalı.
2. V20.1 üzerine V20.2 güncellemesi veri kaybetmeden kurulmalı.
3. Yeni iki sayfalık cevap kâğıdı yazdırılıp dört fiducial'ın yazıcıdan kesilmeden çıktığı görülmeli.
4. Düz + hafif yamuk + perspektifli fotoğraflarda kimlik başlığının AI payload'ına girmediği log/test proxy ile doğrulanmalı.
5. İki sayfa aynı öğrenci isteğinde iki ayrı HIGH image part olarak görülmeli.
6. Şüpheli soruda ikinci istek yalnız doğru cevap kutusunu taşımalı.
7. Öğretmen AI puanını değiştirdikten sonra onaylanan final puanla ayrıntılı dönüt çelişmemeli.
8. Onay düğmesi ağ dönütünü beklemeden tamamlanmalı; Raporlar sayfasında dönüt ilerlemesi görünmeli.
9. Dönüt servisi kontrollü hata verdiğinde PDF engellenmeli; `Yalnız Dönütleri Yeniden Dene` notlamayı çalıştırmadan eksikleri tamamlamalı.
10. `Tüm Öğrenci Dönütlerini Tek PDF` bütün onaylı öğrencileri doğru sırayla içermeli; 2 kopya baskıda cevap görüntüsü tekrar basılmamalı.
11. Yeni yüklenen/kamera ile çekilen öğrenci görüntülerinin dosya baytları normal JPEG header'ı olmamalı; uygulama içi önizleme yine çalışmalı.
12. Ödev modunda AI başlamadan önce batch düzeyi gizlilik kapısı görünmeli; standart yazılı sınavda görünmemeli.
13. YAZEK v2 yıllık doğrulaması bir kez tamamlandıktan sonra aynı öğretim yılında tekrar çıkmamalı; V20.1 eski onayı bir kez yeniden doğrulama istemeli.
14. Gelişmiş model profilinde explicit model ID değişikliği sonraki çağrıda etkili olmalı; `*-latest` reddedilmeli.
15. Batch açıldığında gerçek değerlendirme Batch yoluna girmeli; kapalıyken Standard yol kullanılmalı.
16. Rapor sonrası cevap görüntüleri silindiğinde puan, dönüt ve öğretmen onayı verileri kalmalı.

## Bilinen, engelleyici olmayan güvenlik sertleştirmesi
Room veritabanı Android uygulama özel alanındadır ve Android yedekleme kapalıdır; ancak SQLCipher/alan-bazlı uygulama şifrelemesi eklenmemiştir. V20.2'nin hassas öğrenci **görüntü dosyaları** için ayrıca Keystore AES-256-GCM koruması vardır. SQLCipher eklemek, bağımlılık/Room entegrasyonu gerçek derleme yapılmadan güvenle doğrulanamayacağı için bu sürüme zorla eklenmemiştir.
