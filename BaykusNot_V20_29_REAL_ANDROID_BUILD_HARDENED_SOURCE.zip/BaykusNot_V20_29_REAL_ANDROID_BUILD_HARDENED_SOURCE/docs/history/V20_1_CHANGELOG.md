# BaykuşNot V20.1 Changelog

## Kritik düzeltmeler
1. **Perspektif/hizalama güvenliği:** Dört fiducial işareti + cihaz içi `Matrix.setPolyToPoly` A4 rektifikasyonu eklendi. Hiza başarısızsa hedef soru koordinat kırpması yapılmaz.
2. **Dönüt sırası:** Uzun öğrenci dönütü ana AI değerlendirmesinden çıkarıldı; öğretmen `Sonuçları Onayla` işleminden sonra final puanlardan üretilir.
3. **Pedagojik teşhis:** Doğru yapılanlar, eksikler, kavram yanılgıları ve sonraki adımlar yapılandırılmış alanlara ayrıldı ve DB'de saklandı.
4. **Genel öğrenci değerlendirmesi:** Soru bazlı yorumların yanında bütün sınav örüntüsünü özetleyen final genel dönüt eklendi.
5. **Batch orphan-file koruması:** Uzak input file resource adı batch oluşturma çağrısından önce yerel metadata'ya kaydedilir; hata/terminal akışlarda best-effort silme uygulanır.
6. **Ödev gizliliği:** Harici ödevlerde dosya adı/metadata gönderilmez ve üst kimlik bölgesi cihaz üzerinde konservatif olarak çıkarılır. Serbest biçimli ödev gövdesine yazılmış kişisel bilgi otomatik olarak kesin tespit edilemez; bu mod için ayrıca dikkat gerekir.

## Maliyet ve model yönetimi
- Ana değerlendirme modeli, ekonomik dönüt modeli ve soru/rubrik modeli çalışma anında yerel profilden okunur.
- Model kimlikleri ve milyon-token fiyatları uygulama içinden güncellenebilir; APK yeniden derleme zorunluluğu kaldırıldı.
- `*-latest` kullanımına izin verilmez.
- Tam doğru/boş basit cevaplarda yerel sıfır-token dönüt kullanılır.
- Sağlayıcı Batch, ana toplu puanlama için korunmuştur. Final öğrenci dönütü varsayılan olarak düşük maliyetli modelde standart çağrı ile **hemen** üretilir; sağlayıcı Batch'in belirsiz tamamlanma süresi öğretmenin onay→çıktı akışını geciktirmesin diye final prose aşamasına zorunlu edilmemiştir.
- Model karşılaştırması için `tools/model_benchmark` eklendi.

## YAZEK ve arşiv
- **YAZEK yıllık kapısı:** Ayarlardaki doğrulama artık yalnız bilgilendirme değildir; o eğitim öğretim yılında ilk gerçek AI değerlendirmesi başlatılırken henüz doğrulanmamışsa tek seferlik kapı açılır. Sınav başına tekrar sorulmaz.
- Öğretim yılı başına tek seferlik kurum bilgilendirme/onam süreci doğrulaması.
- Kopyalanabilir YAZEK beyan özeti.
- Bireysel PDF'den taranmış cevap görüntüleri kaldırıldı.
- Fiziksel arşiv sonrası yalnız cevap görüntülerini cihazdan silme seçeneği eklendi.
- Rapor şeffaflık notu öğretmenin/e-Okul'un güncel kaydını nihai kayıt olarak belirtir.

## Veri/DB
- **Room schema varlıkları:** Eksik `21.json` ve `22.json` şema varlıkları eklendi; 20→21 ve 21→22 migration kolon uyumu ayrı SQLite doğrulama aracıyla kontrol edilir. 21→22 instrumentation migration testi de eklendi.
- DB sürümü 22.
- `exam_question_evaluation`: `interpretedMeaning`, `gradingEvidence`, `strengths`, `missingElements`, `misconceptions`, `nextSteps`.
- `exam_student_evaluation`: `overallFeedback`, `feedbackGeneratedAt`.
- `MIGRATION_21_22` eklendi.

## Arayüz doğruluğu
- AI değerlendirme ekranındaki eski sabit “Gemini 3.6 Flash / tek geçişli” etiketi kaldırıldı. Aktif model kimliği merkezi registry’den okunur ve hedefli ikinci kontrol zinciri doğru biçimde belirtilir.

## Sürüm
- `versionCode=3`
- `versionName=1.1-v20.1`
