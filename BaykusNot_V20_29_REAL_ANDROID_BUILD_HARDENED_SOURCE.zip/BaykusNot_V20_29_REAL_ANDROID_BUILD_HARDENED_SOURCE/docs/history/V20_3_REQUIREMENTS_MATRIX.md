# V20.3 — Konuşulan Kararlar / Kaynak Karşılıkları

| Karar | Durum | Kaynak karşılığı |
|---|---|---|
| Öğretmen günlük akışı değişmesin | PASS | AI → öğretmen kontrolü → onay → rapor aşamaları korunur; teknik model/Batch ayarı gelişmiş ayarlardadır. |
| 2 sayfa tek uzun görsel olmasın | PASS | `ExamImagePrivacyProcessor` sayfa başına ayrı `PreparedImage`; `HttpGeminiExamEvaluator` aynı istekte ayrı inline image partları. |
| El yazısında HIGH medya çözünürlüğü | PASS | `HttpGeminiExamEvaluator` `MEDIA_RESOLUTION_HIGH`. |
| Kaynak görüntü küçük/sıkıştırılmış kalmasın | PASS | `ExamPaperUploadRepository`: PDF render width 2000, PRINT render, JPEG 94. |
| EXIF yönü hesaba katılsın | PASS | `decodeUriRespectingExif`, `decodeFileRespectingExif`, `applyExifOrientation`. |
| Kimlik başlığı AI'a gitmesin | PASS | Perspektif düzeltme + privacy crop; yeni/unknown form hizalanamazsa fail-closed. |
| Yeni form hizalanamazsa AI'a gönderme | PASS | `requiresStrictAlignment` + `PrivacyAlignmentException`; QR `AIEKSAM|V:3|...`. |
| Yamuk telefon fotoğrafı düzelsin | PASS | Dört fiducial + `setPolyToPoly` canonical A4 rectification. |
| Öğretmen de AI ile aynı geometriyi görsün | PASS | `prepareQuestionPreview`, `prepareFullPagePreview` hem Teacher Review hem AI Review'da. |
| Şüpheli soru yalnız kendi alanıyla yeniden okunsun | PASS | target question bounds + güvenli fiducial rectification. |
| Ana pahalı model öğrenci-facing prose yazmasın | PASS | Soru `feedback` schema yok; yazım prose schema yok. |
| Ana model pedagojik teşhis üretsin | PASS | `strengths`, `missingElements`, `misconceptions`, `nextSteps`. |
| Ana model yazım/anlatımı da yapılandırılmış teşhis etsin | PASS | `writingStrengths`, `writingIssues`, `writingNextSteps`; DB23'te saklanır. |
| Uzun dönüt öğretmen onayından sonra | PASS | `validateAndConfirmAllResults` prose ağı çağırmaz; Reports katmanı sonradan hazırlar. |
| Ucuz model ham cevap/rubrik/görüntü görmesin | PASS | `ApprovedFeedbackRequest` yalnız öğretmen puanı + kompakt teşhis + yapılandırılmış writing diagnosis. |
| Öğretmen puanı AI teşhisinden üstün olsun | PASS | `originalAiScore` + `sanitizedEvidence`; maddi score delta'da çelişkili eski teşhis bastırılır. |
| Tam doğru/boş cevapta gereksiz token harcanmasın | PASS | `deterministicFeedback`. |
| Her öğrencide genel öğretmen değerlendirmesi | PASS | `overallFeedback`; detail seviyesine göre kontrollü uzunluk. |
| Yazım/noktalama öğrenci prose'u ucuz katmanda | PASS | `writingFeedback` yalnız `HttpGeminiStudentFeedbackWriter` içinde. |
| Dönüt maliyeti kontrolsüz büyümesin | PASS | Final prose katmanında detail seviyesi + AI gereken soru sayısına göre dinamik `maxOutputTokens` tavanı vardır. |
| Dönüt hatası gizlenmesin | PASS | Eksik/boş final prose hata verir; `feedbackGeneratedAt` tamamlanmaz. |
| Yalnız dönüt yeniden denensin | PASS | `retryMissingFeedback` / `generateMissingFinalFeedback`; notlama yeniden çağrılmaz. |
| Öğretmen puan değiştirirse eski final dönüt geçersiz olsun | PASS | final feedback invalidation DAO/repository zinciri. |
| Tek tek 30 PDF ile uğraşılmasın | PASS | `generateAllIndividualReportsPdf`. |
| Toplu PDF baskı kalitesi düşmesin | PASS | Aynı `drawIndividualReportContent` doğrudan tek PDF document üzerine çizilir; `PdfRenderer`/bitmap birleştirme yok. |
| İki basılı nüsha yöntemi | PASS | Toplu PDF tek dosya; cevap kâğıdı görüntüsü dönüt raporuna yeniden basılmaz. |
| İtiraz sonrası uygulamaya dönmek zorunlu olmasın | PASS | Basılı rapor + fiziksel cevap kâğıdı + e-Okul nihai kayıt yaklaşımı korunur. |
| Rapor sonrası görüntüler silinebilsin | PASS | yalnız cevap görüntülerini temizleyen arşiv sonrası akış. |
| YAZEK kapısı yılda bir kez | PASS | akademik yıl + policy version acknowledgement. |
| Kurum bilgilendirme/onam + uygun provider koşulları | PASS | yıllık iki ayrı doğrulama flag'i. |
| Ödev gövdesinde PII garanti edilemezse sessiz gönderilmesin | PASS | Homework Privacy Gate. |
| Model kolay değişsin | PASS | `GeminiModelProfileStore`; sabit model IDs + fiyatlar runtime. |
| `*-latest` kullanılmasın | PASS | registry doğrulaması + static audit. |
| Cache fiyatları da runtime değişsin | PASS | cached input ve storage $/1M token-hour profil alanları + ayar UI. |
| Ekonomik Batch kullanılabilsin ama öğretmene dayatılmasın | PASS | Standard varsayılan; `preferBatchEvaluation` gelişmiş profil üzerinden effective batch'e katılır. |
| Yeni modeller kalite+maliyette ölçülsün | PASS | `run_candidate.py` HIGH image + structured output kullanır; `score_results.py` candidate output + thinking tokenlarını gerçek output maliyetine dahil eder. |
| Öğrenci görüntüleri cihazda şifreli saklansın | PASS | `StudentImageCrypto` AES-256-GCM/AndroidKeyStore; upload yolları secure write/read. |
| Kamera geçici açık JPEG bırakmasın | PASS | kamera ham dosyası `cacheDir`, kalıcı copy şifreli ve temp silinir. |
| Uzak Batch dosyaları temizlensin | PASS | resource name erken persist + terminal cleanup. |
| Fiziksel arşiv ana yöntem olsun; flash/bulut zorunlu olmasın | PASS | yeni zorunlu uzun dönem dijital yedek eklenmez. |

## Bilinçli sınırlar
- Açıkça eski BaykuşNot formu olduğu doğrulanan legacy sayfalarda geriye dönük yüzdelik privacy crop yolu korunur. Yeni V3 veya kimliği belirsiz formda bu fallback kullanılmaz.
- Serbest biçimli ödev sayfasının gövdesindeki her kişisel veriyi yerel OCR olmadan otomatik bulma garantisi yoktur; bu nedenle ödev gizlilik kapısı vardır.
- Room DB Android uygulama özel alanındadır, Android backup kapalıdır; ayrıca SQLCipher ile şifrelenmemiştir. Cevap/ödev **görüntü dosyaları** uygulama seviyesinde AES-GCM şifrelidir.
- Gerçek Android/Compose/KSP derleme ve fiziksel cihaz testi Gradle 9.3.1 bu ortamda bulunmadığı için henüz PASS değildir.
