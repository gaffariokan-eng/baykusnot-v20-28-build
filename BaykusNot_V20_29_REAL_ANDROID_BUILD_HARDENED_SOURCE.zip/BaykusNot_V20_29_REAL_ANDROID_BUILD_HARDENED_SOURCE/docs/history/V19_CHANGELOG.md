# BaykuşNot v19 — Öğretmen Modu

Tarih: 2026-08-18

## Bu sürümün amacı
BaykuşNot'un basit sınav okuma akışını korurken el yazısı okuma, rubrik oluşturma ve puanlama çekirdeğini öğretmen davranışına yaklaştırmak.

## Ana değişiklikler
- Öğrencinin yazdığı cevap **birebir transkripsiyon** olarak korunur; yazım hataları otomatik düzeltilmez.
- Öğrencinin olası anlamı birebir transkripsiyondan ayrı değerlendirilir.
- Puanlama yalnız OCR metnine değil; gerçek cevap görüntüsü, kilitli soru/kaynak bağlamı ve öğretmenin kilitlediği rubriğe dayanır.
- Belirsiz, düşük güvenli, normal ama 0 puanlanan veya çok düşük puanlı cevaplar bağımsız ikinci kontrolden geçirilir.
- İkinci kontrolde ciddi puan farkı kalırsa öğrenci aleyhine otomatik karar verilmez; öğretmen kontrolü istenir.
- El yazısı görüntüleri Gemini'ye yüksek medya ayrıntısıyla gönderilir.
- Normal değerlendirmede Gemini 3.6 Flash orta düşünme; şüpheli cevap ikinci kontrolünde yüksek düşünme kullanılır.
- AI tarafından oluşturulan rubrik Gemini 3.6 Flash yüksek düşünme ile hazırlanır ve bağımsız ikinci rubrik denetiminden geçirilir.
- Rubrik, anlamca eşdeğer cevapları ve somut kısmi puanı kapsayacak şekilde oluşturulur; açık uçlu sorular tek örnek cevaba daraltılmaz.
- Yazım/noktalama yalnız ölçülen beceri veya kilitli rubrik bunu gerektiriyorsa puana etki eder; aynı hata iki kez cezalandırılmaz.
- Aynı sınavda aynı normalize edilmiş cevabın belirgin biçimde farklı puanlanması sınıf içi tutarlılık kontrolünde öğretmen incelemesine işaretlenir.
- Dönüt ayrıntısı dört seviyedir: **Yok / Kısa / Standart / Ayrıntılı**. Dönüt seviyesi puanı değiştirmez.
- Değerlendirme ekranı sadeleştirildi: normal öğretmen yalnız dönüt ayrıntısını seçer. Teknik model, batch, cache, rubrik katılığı ve yazım kesintisi tercihleri görünür akıştan çıkarıldı.
- API ayarlarında teknik model seçimi yerine **Akıllı Değerlendirme** açıklaması gösterilir.
- Test Sınavı AI yolundan ayrı kalır ve yalnız yerel optik okuma kullanır.
- Soru çıkarma, ortak metin/paragraf/şiir/tablo/görsel bağlamını ilgili sorularla birlikte koruyan mevcut v16 kuralını sürdürür.

## Derleme notu
Bu paket gerçek Android APK derlemesini kullanıcının Windows bilgisayarındaki kurulu Android SDK 36.1 + JDK 17 ile yapar. `BAYKUSNOT_BUILD_V19_APK.bat` tek pencerede çalışır ve başarıda/hatada kapanmaz.
