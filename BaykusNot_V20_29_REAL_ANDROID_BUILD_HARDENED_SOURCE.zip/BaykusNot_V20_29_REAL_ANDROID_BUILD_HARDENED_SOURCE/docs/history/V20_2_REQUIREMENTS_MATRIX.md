# V20.2 — Konuşulan Kararlar / Kaynak Karşılıkları

| Karar | Durum | Kaynak karşılığı |
|---|---|---|
| Öğretmen günlük akışı değişmesin | PASS | AI/teacher/reports aşamaları korunur; teknik model/Batch ayarı gelişmiş ayarlardadır. |
| 2 sayfa tek uzun görsel olmasın | PASS | `ExamImagePrivacyProcessor` her sayfayı ayrı `PreparedImage` üretir; `HttpGeminiExamEvaluator` aynı istekte ayrı inlineData partları kullanır. |
| El yazısında HIGH medya çözünürlüğü | PASS | `HttpGeminiExamEvaluator.kt` `MEDIA_RESOLUTION_HIGH`. |
| Kimlik başlığı AI'a gitmesin | PASS | `ExamImagePrivacyProcessor.kt`; fiducial rectification sonrası yalnız soru/cevap alanı. |
| Yamuk telefon fotoğrafı düzelsin | PASS | `ExamAnswerSheetPdfGenerator` dört fiducial basar; `ExamImagePrivacyProcessor` `setPolyToPoly` ile canonical A4'e rectification yapar. |
| Şüpheli soru yalnız kendi alanıyla yeniden okunsun | PASS | `targetQuestionOrderIndex` + `getQuestionCropBounds`; hizalama başarısızsa targeted crop kullanılmaz. |
| Ana model uzun dönüt yazmasın | PASS | Main response şemasında öğrenci-facing `feedback` yok; structured diagnostics var. |
| Ana model pedagojik teşhis üretsin | PASS | `strengths`, `missingElements`, `misconceptions`, `nextSteps`. |
| Uzun dönüt öğretmen onayından sonra | PASS | `validateAndConfirmAllResults` prose çağırmaz; `ReportsViewModel` eksik feedback'i onaylı sonuçlardan sonra hazırlar. |
| Ucuz model ham cevap/rubrik görmesin | PASS | `ApprovedFeedbackRequest` yalnız final puan + kompakt teşhis taşır. |
| Tam doğru/boş cevapta gereksiz token harcanmasın | PASS | `deterministicFeedback`. |
| Her öğrencide genel öğretmen değerlendirmesi | PASS | `overallFeedback`, DETAILED'da 2–3 doğal paragraf talebi. |
| Dönüt hatası gizlenmesin | PASS | Hata throw edilir; `feedbackGeneratedAt` eksik kalır; Raporlar pending/failure gösterir. |
| Yalnız dönüt yeniden denensin | PASS | `retryMissingFeedback`; notlama tekrar çağrılmaz. |
| Öğretmen puan değiştirirse eski dönüt geçersiz olsun | PASS | `invalidateApprovalAndFinalFeedback`. |
| Tek tek 30 PDF ile uğraşılmasın | PASS | `generateAllIndividualReportsPdf`; bütün öğrenciler tek PDF. |
| İki basılı nüsha yöntemi | PASS | Toplu PDF UI açıklaması 2 kopya baskıyı yönlendirir; cevap kâğıdı görüntüsü tekrar basılmaz. |
| İtiraz sonrası uygulamaya dönmek zorunlu olmasın | PASS | Rapor şeffaflık metni öğretmen/e-Okul güncel kaydını esas alır; dijital itiraz zorunluluğu yok. |
| Rapor sonrası görüntüler silinebilsin | PASS | `deleteAnswerImagesAfterArchive`. |
| YAZEK kapısı yılda bir kez | PASS | `YazekComplianceStore.currentAcademicYear` + policy v2. |
| Kurum bilgilendirme/onam + uygun provider koşulları birlikte doğrulansın | PASS | iki ayrı policy flag yıllık acknowledgement içinde zorunlu. |
| Ödev gövdesinde PII garanti edilemezse sessiz gönderilmesin | PASS | `showHomeworkPrivacyGate`; batch başına öğretmen gizlilik kontrolü. |
| Model kolay değişsin | PASS | `GeminiModelProfileStore`; sabit model/fiyat profili runtime. |
| `*-latest` kullanılmasın | PASS | Registry doğrulaması ve static audit. |
| Ekonomik Batch kullanılabilsin ama öğretmene dayatılmasın | PASS | `preferBatchEvaluation`; Standard varsayılan, gelişmiş ayar. |
| Yeni modeller kalite+maliyette ölçülsün | PASS | `tools/model_benchmark/run_candidate.py` + `score_results.py`. |
| Öğrenci görüntüleri cihazda şifreli saklansın | PASS | `StudentImageCrypto` AES-256-GCM/AndroidKeyStore; yükleme yolları secure write/read. |
| Kamera geçici açık JPEG bırakmasın | PASS | Capture `cacheDir`; repository encrypted persistent copy oluşturur ve temp dosyayı siler. |
| Uzak Batch öğrenci dosyaları temizlensin | PASS | `GeminiBatchJobManager`: resource name anında metadata'ya yazılır, terminal durumlarda delete. |
| Dijital uzun dönem yedek öğretmene zorunlu olmasın | PASS | V20.2 yeni flash/bulut yedek zorunluluğu eklemez; fiziksel arşiv + isteğe bağlı görüntü silme yaklaşımı korunur. |

## Bilinçli sınırlar
- Serbest biçimli ödev sayfasının gövdesindeki her kişisel veriyi yerel OCR olmadan otomatik bulma garantisi yoktur; bu nedenle gizlilik kapısı vardır.
- Room veritabanı Android uygulama özel alanında tutulur fakat ayrıca SQLCipher ile şifrelenmemiştir. Cevap/ödev **görüntü dosyaları** uygulama seviyesinde ayrıca AES-GCM şifrelidir.
- Gerçek Android/Compose/KSP derlemesi bu çalışma ortamında Gradle 9.3.1 bulunmadığı için henüz doğrulanamamıştır.
