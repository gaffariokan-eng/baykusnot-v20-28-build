# BaykuşNot V20 değişiklik özeti

## 1. YAZEK odaklı veri minimizasyonu
- `ExamImagePrivacyProcessor` eklendi.
- BaykuşNot tarafından üretilmiş Yazılı/Dinleme/Hazırbulunuşluk cevap kâğıtlarında kimlik başlığı AI'a gönderilmeden önce görüntüden çıkarılır.
- İlk geçişte aynı öğrencinin cevap kutuları sayfa bağlamıyla korunur.
- Eski/yerleşimi çözülemeyen kontrollü kâğıtlarda privacy-first güvenli üst alan kırpması kullanılır.
- Ödev, serbest biçimli harici belge olabildiği için bu sürümde otomatik kimlik koordinatı varsayımı yapılmaz; ödev akışı ayrıca test/iyileştirme gerektirir.

## 2. Daha doğru ikinci okuma
- Düşük güven, olağandışı düşük puan veya mevcut ikinci-kontrol tetikleyicilerinde bütün kâğıt yeniden gönderilmez.
- `ExamAnswerSheetLayoutCalculator` tarafından bilinen gerçek soru kutusu koordinatları kullanılarak yalnız şüpheli cevap alanı HIGH çözünürlükte ikinci kez okunur.
- İki okuma uyuşmazsa mevcut öğretmen inceleme davranışı korunur.

## 3. İki aşamalı AI mimarisi
- Ana model: el yazısı okuma + rubrik puanlama + kısa pedagojik teşhis.
- Dönüt modeli: yalnız yapılandırılmış kanıtları doğal ve ayrıntılı öğrenci dönütüne çevirir; görüntü almaz ve puanı değiştiremez.
- Dönüt servisi başarısız olursa puanlama kaybolmaz; ana modelin kısa teşhisi yedek olarak kalır.
- Yeni sınav varsayılanı `DETAILED` dönüttür.

## 4. Model değiştirme ve maliyet
- Tüm Gemini model ID'leri `GeminiModelRegistry.kt` içine taşındı.
- Üretimde `*-latest` alias kullanılmaz.
- V20 puanlama modelini sessizce değiştirmedi: ana model başlangıçta `gemini-3.6-flash`, ekonomik dönüt modeli `gemini-3.1-flash-lite` olarak ayarlı.
- Yeni model ancak BaykuşNot el yazısı/rubrik benchmark'ından geçtikten sonra registry'de değiştirilmelidir.
- Maliyet tahmini artık ana okuma ve ekonomik dönüt maliyetini ayrı hesaplar; fiyat sabitleri de registry'de merkezidir.

## 5. Batch ve geçici uzak dosyalar
- Batch Files API giriş kaynağı metadata'da izlenir.
- Başarılı sonuç indirildiğinde giriş ve sonuç dosyaları best-effort DELETE ile temizlenir.
- Terminal hata/iptal/süre aşımında giriş dosyası temizlenmeye çalışılır.

## 6. Öğretmen alışkanlığı ve basılı kayıt
- Öğretmen onayı mevcut akışta kalır.
- Bireysel rapora AI destekli hazırlanma ve nihai akademik kararın öğretmende olduğu notu eklendi.
- Rapor, sonradan yeniden incelemede öğretmenin/e-Okul'un güncel kaydının esas olduğunu belirtir.
- Öğretmen itiraz sonrası BaykuşNot'a dönmek zorunda değildir; fiziksel rapora manuel not düşebilir.

## Bilerek bu sürüme eklenmeyenler
- Öğrenci/veli portalı veya dijital itiraz modülü.
- Zorunlu bulut arşiv/yedek sistemi.
- Öğretmene her sınavda yeni onam ekranları.
- AI'nın resmi/e-Okul not kaydı olması.
- Ücretsiz/ücretli Gemini hesabını teknik olarak otomatik ayırt edip engelleme (API anahtarından güvenilir şekilde belirlenemediği için yalnız açık uyarı verilir).
