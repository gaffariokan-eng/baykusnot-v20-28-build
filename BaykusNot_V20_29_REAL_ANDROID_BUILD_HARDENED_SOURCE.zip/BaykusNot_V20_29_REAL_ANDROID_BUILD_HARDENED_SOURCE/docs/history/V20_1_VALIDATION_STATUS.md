# V20.1 Validation Status

## Başarılı kontroller
- Room schema 21/22 migration assets eklendi; `tools/validate_room_schema_migrations.py` ile 20→21 ve 21→22 kolon uyumu SQLite üzerinde PASS.
- `RoomSchemaAssetInstrumentedTest` içine 21→22 migration testi eklendi. Gerçek Android instrumentation çalıştırması yerel SDK/Gradle ortamında yapılmalıdır.
- YAZEK gate wiring: AI değerlendirmesi yıllık doğrulama yoksa başlamadan önce tek seferlik doğrulama kapısına yönlenir.
- AI motor etiketi sabit model adına bağlı değildir; aktif registry modelini gösterir ve ikinci kontrol mimarisini doğru tanımlar.
- `tools/static_audit.py`: 25/25 PASS.
- 194 Kotlin kaynak dosyasında yorum/string dışı `()[]{}` yapısal denge: PASS.
- Değiştirilen Kotlin dosyalarında `kotlinc` parser çalıştırıldı; Android/Compose sınıfları classpath'te olmadığı için unresolved-reference tanıları oluştu, ancak `expecting`/syntax tanısı çıkmadı.
- AndroidManifest XML parse: PASS.
- `android:allowBackup=false`: PASS.
- `MIGRATION_21_22` ALTER SQL'leri in-memory SQLite üzerinde: PASS.
- Model benchmark örnek koşusu: PASS.
- Üretim Kotlin kaynaklarında Gemini model ID'leri yalnız `GeminiModelRegistry.kt` varsayılan profilinde bulunuyor; `*-latest` varsayılanı yok.
- Main evaluator görüntüyü doğrudan dosyadan API'ye taşımıyor; `ExamImagePrivacyProcessor` üzerinden geçiriyor.
- Final prose yazarı main evaluator içinde çağrılmıyor; teacher-confirm sonrasında repository katmanından çağrılıyor.
- Bireysel PDF taranmış cevap görüntülerini tekrar üretmiyor.

## Bu ortamda yapılamayan kontrol
`./gradlew :app:compileDebugKotlin --offline` denendi. Wrapper yerelde Gradle 9.3.1 bulamadığı için `https://services.gradle.org/distributions/gradle-9.3.1-bin.zip` indirmeye çalıştı ve ortam DNS/ağ erişimi nedeniyle `UnknownHostException` ile durdu. Dolayısıyla gerçek Android/Room/KSP/Compose derlemesi ve cihaz testi henüz yapılmış sayılmaz.

## İlk gerçek cihaz kabul testleri
1. Yeni V20.1 iki sayfalık cevap kâğıdını yazdır; dört fiducial'ın yazıcıda görünür kaldığını doğrula.
2. Düz, hafif yamuk ve perspektifli üç fotoğrafla aynı cevap kâğıdını okut; kimlik başlığının AI payload'ına girmediğini doğrula.
3. Bir şüpheli soruda ikinci isteğin yalnız ilgili cevap alanını içerdiğini doğrula.
4. AI puanını öğretmen değiştirip onaylasın; final soru dönütü ve genel değerlendirme öğretmenin son puanıyla çelişmesin.
5. Tam doğru ve boş soruda ekonomik model çağrısı gerekmeyen yerel dönüt yolunu doğrula.
6. İki nüsha bireysel raporu kontrol et; cevap görüntüsü PDF'ye eklenmemeli.
7. Rapor sonrası `Cihazdaki Cevap Görüntülerini Sil` çalıştır; rapor/puan/onay kayıtları kalmalı.
8. Batch upload sırasında kontrollü ağ kesintisi yap; uzak input resource kimliğinin yerel metadata'da korunduğunu doğrula.
9. Gelişmiş model profilini değiştirip yeni çağrıların yeni sabit model ID'sini kullandığını doğrula.
10. YAZEK yıllık doğrulaması bir kez yapıldığında aynı öğretim yılında tekrar zorunlu ekran oluşmadığını doğrula.

## Bilinen sınır
Serbest biçimli harici ödevlerde BaykuşNot üst kimlik/header bölgesini otomatik çıkarır; öğrencinin sayfanın gövdesine yazdığı her tür kişisel bilgiyi yerel OCR olmadan kesin olarak bulma garantisi yoktur. BaykuşNot'un kendi standart cevap kâğıtlarında ise koordinat tabanlı kimlik çıkarımı vardır.
