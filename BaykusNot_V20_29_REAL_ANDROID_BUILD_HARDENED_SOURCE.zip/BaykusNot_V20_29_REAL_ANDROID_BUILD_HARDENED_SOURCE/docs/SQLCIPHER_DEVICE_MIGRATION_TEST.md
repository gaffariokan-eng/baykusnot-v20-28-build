# BaykuşNot V20.8 — SQLCipher Gerçek Cihaz Migration Kabulü

V20.6 veya önceki gerçek verili bir cihaz kopyasında:

1. Güncelleme öncesi DB/yönetilen dosyaların yedeğini alın.
2. V20.8'i üzerine kurun; ilk açılış plaintext Room DB'yi SQLCipher'a dönüştürmelidir.
3. Öğretmen profili, sınavlar, sorular, rubrikler, öğrenciler, puanlar ve rapor sonuçlarını örneklemle karşılaştırın.
4. `PRAGMA user_version` 28 olmalı; Room 26→27 ve 27→28 migrationları uygulanmalı.
5. DB dosyasının ilk 16 baytı `SQLite format 3\0` olmamalı; doğru SQLCipher passphrase olmadan standart SQLite ile açılamamalıdır.
6. Uygulamayı kapat/aç, cihazı yeniden başlat ve tekrar doğrula.
7. Bir sınavı silip özel dosyaları ve ilişkili DB satırlarını kontrol edin.
8. Migration ortasında zorla kapatma senaryosunda orijinal DB'nin kaybolmadığını doğrulayın.

Android instrumented `DatabaseEncryptionManagerTest` de plaintext → encrypted veri ve `user_version` korunmasını doğrular. Fiziksel cihaz testi tamamlanmadan SQLCipher statüsü `DEVICE_TEST_REQUIRED` kalır.
