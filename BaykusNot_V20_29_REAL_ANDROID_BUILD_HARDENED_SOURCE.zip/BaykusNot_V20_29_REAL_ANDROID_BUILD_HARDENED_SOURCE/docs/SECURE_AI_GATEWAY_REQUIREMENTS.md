# BaykuşNot V20.9 — Production AI Gateway + Data Protection Contract

BaykuşNot production/release APK'sı Gemini kimlik bilgisini mobil cihazda saklamaz. Release çağrıları yalnız kurumsal gateway üzerinden ve kısa ömürlü oturumla çalışır.

## Zorunlu deployment alanları

- `BAYKUS_AI_GATEWAY_URL`
- `BAYKUS_PROVIDER_RETENTION_DAYS` = `0`, `7`, `14`, `28` veya `55`
- `BAYKUS_PROVIDER_DATASET_SHARING_DISABLED=true`
- `BAYKUS_PROVIDER_ACCESS_ROLES` = öğrenci verisine erişebilecek kurum/gateway rollerinin açık tanımı
- `BAYKUS_PROVIDER_OPERATOR` = opsiyonel; varsayılan `Google Gemini API via institution gateway`

Bu veri koruma profili YAZEK kapsam fingerprint'ine bağlanır. Retention/dataset/access politikası değişirse eski yerel YAZEK doğrulaması yeniden kullanılmaz.

## Kurumsal gateway oturum sözleşmesi

Cihazda Gemini secret bulunmaz. Kurum, öğretmen/cihaz için revocable bir **gateway enrollment credential** üretir. Öğretmen bu kodu BaykuşNot Ayarlar ekranında bir kez girer. Kod Android Keystore ile şifrelenir.

BaykuşNot oturum alırken:

`POST <AI_GATEWAY_BASE_URL>/baykusnot/v1/session`

Header:

`Authorization: Enrollment <institution-issued-revocable-token>`

Body:

`{"client":"BaykusNot","platform":"android"}`

Beklenen yanıt:

`{"accessToken":"<short-lived-token>","expiresInSeconds":300}`

- `expiresInSeconds` 60–3600 saniye aralığında olmalıdır.
- Access token yalnız RAM'de tutulur.
- Süre dolmadan önce otomatik yenilenir.
- Gateway 401 döndürürse token temizlenir, bir kez refresh edilir ve istek yalnız bir kez tekrar edilir.
- Enrollment credential Gemini'ye gönderilmez; yalnız kurum gateway session endpoint'ine gönderilir.
- Enrollment credential kurum tarafından iptal edilebilir ve cihazdan kaldırılabilir.
- Başarısız eşleştirme denemesi kalıcı durum bırakmaz; önceki geçerli credential varsa geri yüklenir, yoksa yeni credential silinir.
- Eşleştirme başarıyla tamamlandığında bekleyen `REMOTE_DELETE_PENDING` kayıtları aynı doğrulanmış oturumla hemen yeniden denenir.

## Gateway upstream kuralları

1. Gemini Auth key/service-account-bound upstream kimliği yalnız server-side secret store'da tutulmalıdır.
2. Gateway açık/kimliksiz proxy olmamalıdır.
3. İstemciden gelen `key`, `x-goog-api-key` ve upstream `Authorization` güvenilmemeli; BaykuşNot gateway bearer oturumu ayrı doğrulanmalıdır.
4. Yalnız gerekli Gemini `v1beta`, Files, Batch, Cache/upload/download yollarına izin verilmelidir.
5. Öğrenci payload'ı gateway/APM/error-log body capture'a yazılmamalıdır.
6. Dataset/model geliştirme paylaşımı kapalı olmalıdır.
7. Retention ve erişim rolleri deployment profile ile birebir eşleşmelidir.
8. Gateway yoksa BaykuşNot MANUAL öğretmen değerlendirme B-planına geçer; cihaz anahtarına sessiz fallback yapılmaz.

## Batch / Files silme sözleşmesi

- BaykuşNot `batches.cancel` sonrası `batches.delete` ve `files.delete` işlemlerini HTTP 2xx/404 ile doğrular.
- Uzak silme doğrulanamazsa resource adı `REMOTE_DELETE_PENDING` olarak yerelde korunur.
- Uygulama açılışında veya yeni geçerli gateway oturumu alındığında bekleyen silmeler tekrar denenir.
- Yerel sınav silinse bile bekleyen uzak cleanup ledger kaydı, uzak silme doğrulanıncaya kadar silinmez.
