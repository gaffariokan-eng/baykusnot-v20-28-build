# V20.7 Validation Status

## Kaynak/statik doğrulamalar
- `tools/static_audit.py`: **92/92 PASS** (final paketleme öncesi; son kaynak denetiminde yeniden çalıştırılacaktır).
- Room exported schema 21→25 önceki migration zinciri: PASS.
- 25→26 migration SQL: PASS.
- 26→27 migration SQL: PASS.
- Python benchmark/audit araçları `py_compile`: PASS.
- Android manifest/resource XML parse: PASS.
- Evaluation/Feedback/Authoring bundled synthetic safety smoke test: her üçünde de production adoption engellendi (`KEEP_BASELINE`, coverage FAIL).
- Gemini source URLs: `?key=` / `&key=` kullanımı kaldırıldı.

## BLOCKED_ENV — Gradle derleme
`./gradlew :app:compileDebugKotlin --stacktrace` derleyici başlamadan Gradle wrapper dağıtımını indirmeye çalışırken durdu:

`java.net.UnknownHostException: services.gradle.org`

Bu nedenle aşağıdakiler henüz PASS değildir:
- gerçek Kotlin/Compose compile,
- Room/KSP schema 26/27 export,
- unit test çalıştırması,
- Android instrumented tests,
- APK assemble/install.

## DEVICE_TEST_REQUIRED
- Mevcut V20.6 plaintext Room DB → V20.7 SQLCipher gerçek veri migrationı.
- Crash/rollback/power-loss senaryosu.
- Android 12+ backup/device-transfer davranışı.
- TalkBack, 200% font scale, focus/semantics.
- `FLAG_SECURE` ekran yakalama davranışı.
- YAZEK scope değişikliği ile AI gate'in gerçekten bloke olması.
- Sınav complete-delete sonrasında app-private veri artığı kalmaması.

## BLOCKED_EXTERNAL_INFRA
V20.7 release client artık Gemini secret'ı telefonda kullanmaz ve güvenli gateway olmadan fail-closed kalır. Production AI için ayrıca HTTPS, kimlik doğrulamalı, yetkilendirmeli, rate-limited, log-redaction uygulanmış bir gateway kurulup `BAYKUS_AI_GATEWAY_URL` ile release build'e bağlanmalıdır. Android kaynak paketine kimliksiz/açık proxy eklenmemiştir; böyle bir proxy güvenlik açığı olurdu.

## BLOCKED_REAL_DATA
Production model onayı için gerçek öğrenci kimliğinden arındırılmış ve öğretmen/adjudicator tarafından doğrulanmış en az 20 benzersiz vaka gerekir. Paket sentetik gerçek-veri taklidi üretmez.

## YAZEK sınırı
Uygulamadaki scope/audit kaydı resmî MEB YAZEK Etik Beyan Formu değildir ve onu otomatik göndermez. Kurum/öğretmen ilgili kapsam için resmî YAZEK sürecini tamamlamalıdır; BaykuşNot yalnız kapsamın uygulama içinde yeniden kullanılmasını fail-closed denetler.
