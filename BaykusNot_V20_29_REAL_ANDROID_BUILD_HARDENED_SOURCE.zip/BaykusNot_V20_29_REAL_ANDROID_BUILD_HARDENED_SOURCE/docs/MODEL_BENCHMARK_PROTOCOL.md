# Model Kabul Protokolü

BaykuşNot'un model seçimi “en yeni model” değil, **kalite eşiğini geçen en ekonomik sabit model** ilkesine dayanır. `*-latest` alias'ları kullanılmaz.

## Test seti
Anonim vaka setinde en az: temiz/zor/küçük el yazısı, silinti/üstü çizili metin, uzun açık uçlu cevap, kısmi doğru, yanlış, boş, düşük okunabilirlik ve gerektiğinde matematik/sembol örnekleri bulunmalıdır.

## Çalıştırma
1. `tools/model_benchmark/benchmark_manifest.csv` öğretmen doğrularını içerir. Gerçek çağrı için vakaya `image_path` ve/veya `prompt_path` eklenir.
2. `GEMINI_API_KEY` ortam değişkeni ayarlanır.
3. Aday: `python tools/model_benchmark/run_candidate.py tools/model_benchmark/benchmark_manifest.csv candidate.jsonl --model gemini-X-flash`
4. Ağ çağrısı yapmadan kurulum kontrolü: aynı komuta `--dry-run` eklenir.
5. Sonuç: `python tools/model_benchmark/score_results.py tools/model_benchmark/benchmark_manifest.csv candidate.jsonl --baseline baseline.jsonl ...fiyat parametreleri...`

## Temel metrikler
- transkripsiyon benzerliği
- öğretmen puanına mutlak hata ve ±0,5 puan uyumu
- düşük-güven/öğretmen kontrolü recall
- yapılandırılmış yanıt başarısı
- gerçek usageMetadata giriş + candidate output + thinking tokenı (thinking output maliyetine dahildir)
- öğrenci başına toplam maliyet

Aday üretime otomatik geçmez. Araç `ADOPT/KEEP_BASELINE` önerisi üretir; onaylanan sabit model ID'si ve fiyat profili Ayarlar > Gelişmiş model yönetiminden kaydedilir.
