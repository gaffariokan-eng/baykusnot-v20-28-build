# V20.6 Validation Status

## PASS — kaynak seviyesinde
- `tools/static_audit.py`: **58/58 PASS**.
- Android backup/device-transfer ve FileProvider XML'leri parse edilebilir ve daraltılmış kuralları içerir.
- Room exported schema zinciri 21→25 önceki migration kaynaklarıyla uyumlu doğrulandı.
- 25→26 migration SQL authoring pricing snapshot kolonlarını ekliyor.
- `tools/model_benchmark/*.py` Python compile PASS.
- BNBENCH3 non-default production approval role-bound'dur ve minimum 20 `REAL_ANONYMIZED` vaka ister.
- Bundled benchmark örneği sentetiktir; gerçek üretim onayı üretemez.

## BLOCKED_ENV — bu ortamda doğrulanamayanlar
`./gradlew testDebugUnitTest --stacktrace` Gradle wrapper dağıtımını indirmeden önce durmuştur:

`java.net.UnknownHostException: services.gradle.org`

Bunun sonucu olarak aşağıdakiler PASS sayılamaz:
- Kotlin/Compose/AGP/KSP gerçek compile,
- Room-generated `app/schemas/.../26.json`,
- unit testler,
- instrumented Room migration testleri,
- assembleDebug/APK,
- fiziksel cihaz V20.5→V20.6 upgrade/smoke testi.

## BLOCKED_REAL_DATA
Paket gerçek öğrenci verisi üretmez veya uydurmaz. Yeni production model adayının rol bazında onaylanması için en az 20 anonimleştirilmiş/adjudicated gerçek vaka gerekir.

## DEFERRED — SQLCipher
Room DB hâlâ düz SQLite'tır. Öğrenci cevap görüntüleri ayrı Android Keystore AES-256-GCM katmanında korunur ve backup/device-transfer dışlama kuralları sertleştirilmiştir. Mevcut kullanıcı DB'sinin SQLCipher'a veri kaybetmeden dönüşümü gerçek Android cihaz migration testi yapılmadan etkinleştirilmemiştir.

## İlk gerçek Windows/telefon kabul sırası
1. `BAYKUSNOT_BUILD_V20_6_APK.bat` ile compile/assembleDebug.
2. Room schema 26 export edildiğini ve 25→26 migration instrumented testini doğrula.
3. Mevcut V20.5 verisiyle uygulamayı V20.6'ya yükselt; sınav/rubrik/sonuç kayıtlarının kaybolmadığını doğrula.
4. Legacy sınav ve çok sayfalı ödev privacy gate'lerinde render edilemeyen veya görülmeyen tek sayfanın bile onayı bloke ettiğini smoke-test et.
5. Android 12+ cihazda backup/device-transfer davranışını kontrol et.
6. Batch+cache gerçek usageMetadata örneğinde gösterilen maliyetin provider fiyatıyla eşleştiğini kontrol et.
7. Manuel puan değişiminde approval/final feedback'in aynı anda invalid olduğunu doğrula; büyük değişimde eski diagnosis alanlarının temizlendiğini doğrula.
8. Authoring/evaluation/feedback usage kayıtlarında requested model, actual provider model, response ID/status ve token/maliyet alanlarını kontrol et.
9. Yerel optik çoktan seçmeli raporda AI kullanılmadıysa local disclosure çıktığını doğrula.
10. Gerçek 20+ anonim benchmark setiyle her rolün scorer'ını ayrı çalıştır; bir rolün approval kaydının diğer role geçmediğini doğrula.
11. Bu testlerden sonra SQLCipher migration için ayrı cihaz migration çalışması yap.
