# V20.5 Requirements Matrix

| Konuşulan karar / gereksinim | V20.5 karşılığı | Durum |
|---|---|---|
| Öğretmen akışını bozma | Günlük sınav akışı aynı; teknik ayarlar gelişmiş bölümde | PASS |
| Kimlik AI'a gitmesin | V3 fiducial fail-closed + privacy crop | PASS |
| İki sayfa birlikte ama ayrı görüntü | Aynı request içinde ayrı HIGH image part | PASS |
| Şüpheli soruyu hedefli tekrar oku | Yalnız soru cevap alanı | PASS |
| Öğretmen nihai otorite | Approval + manuel puan değişikliği; e-Okul nihai kayıt | PASS |
| Uzun kişisel dönüt | Onay sonrası ekonomik model | PASS |
| Pahalı model prose yazmasın | Yapılandırılmış strengths/missing/misconceptions/nextSteps | PASS |
| Ucuz model yeniden notlamasın | Ham cevap/soru/rubrik/görüntü yok | PASS |
| Ucuz model öğretmen-AI çatışmasını görmesin | originalAiScore/teacherModified yalnız yerel sanitizasyonda | PASS |
| Dönüt güvenli olsun | Provider safety + yerel pedagojik filtre | PASS |
| Model kolay değişsin | Runtime model/fiyat/capability profile | PASS |
| Sınav yarıda model değiştirmesin | ExamAiRunProfile snapshot | PASS |
| Yeni model test edilmeden üretime girmesin | BN-BENCH-2 approval record | PASS |
| Benchmark capability profilini de bağlasın | HIGH token + high media/batch/cache/thinking | PASS |
| Gerçek maliyeti ölç | usageMetadata + thinking + cached tokens | PASS |
| Cache saklama maliyetini gerçek süreyle ekle | provider cached token count × create→delete/expire hours | PASS |
| Hangi model gerçekten cevap verdi bilinsin | modelVersion/responseId/modelStatus DB audit | PASS |
| Tüm raporlar tek PDF / iki nüsha | Vektör/metin aggregate PDF | PASS |
| Dijital görüntüleri sonradan temizle | Cevap görüntüsü cleanup, sonuç kayıtları kalır | PASS |
| Ödevde PII maskeleme | Yerel mask + repository privacy gate | PASS |
| Eski form kör gönderilmesin | Legacy privacy preview approval | PASS |
| Görüntüler at-rest şifreli | Keystore AES-256-GCM | PASS |
| Room DB uygulama seviyesinde şifreli | SQLCipher ertelendi; gerçek build/device migration gerekli | DEFERRED |
| Gerçek APK derlemesi | Gradle 9.3.1 bu ortamda indirilemedi | BLOCKED_ENV |
