# BaykuşNot V20.18 — YAZEK 8 Etik İlke Kaynak/Evidence Matrisi

**Denetim tarihi:** 2026-09-05  
**Kaynak tabanı:** erişilebilen güncel YAZEK SSS, YAZEK Kullanım Rehberi ve MEB Eğitimde Yapay Zekâ Uygulamaları Etik Kılavuzu.

Bu tablo **kaynak seviyesi kanıt** ile **gerçek deployment/cihaz kabulü**nü ayrı tutar. `PASS_SOURCE`, uygulama kaynaklarında gerekli mekanizmanın bulunduğunu; dış testlerin tamamlandığını göstermez.

| Etik ilke | BaykuşNot kaynak kanıtı | Kaynak durumu | Dış/release kapısı |
|---|---|---|---|
| 1. İnsan merkezlilik / haklar | AI önerisi nihai karar değil; öğretmen puanı atomik değiştirebilir; değişiklik eski AI teşhis/dönütünü invalid eder | PASS_SOURCE | Gerçek öğretmen kullanım kabulü |
| 2. Eşitlik ve kapsayıcılık | Korunan özellik çıkarımı/ayrımcılık yasak; rubrik dışı demografik puan ölçütü yok; erişilebilirlik kabul protokolü mevcut | PASS_SOURCE | **DEVICE_TEST_REQUIRED:** TalkBack, %200 font, focus/zoom |
| 3. Şeffaflık / açıklanabilirlik | AI kullanımı, manuel/yerel ayrımı, halüsinasyon riski, öğretmen nihai otoritesi ve veri amacı görünür | PASS_SOURCE | Kurumun öğrenci/veli bilgilendirme uygulaması |
| 4. Mahremiyet / veri yönetişimi | Scope-aware YAZEK gate; provider retention/dataset/access fail-closed; AES-GCM öğrenci görüntüsü; SQLCipher migration; gateway no-payload-log kuralı | PASS_SOURCE | **DEVICE_TEST_REQUIRED** SQLCipher migration + **BLOCKED_EXTERNAL_INFRA** gateway |
| 5. Güvenilirlik / güvenlik | Düşük güven → öğretmen inceleme; provider safety; manuel B-plan; kısa ömürlü gateway oturumu; gerçek benchmark politikası | PASS_SOURCE | **BLOCKED_REAL_DATA** 20+ gerçek anonim/adjudicated benchmark + gerçek build |
| 6. Hesap verebilirlik / insan denetimi | Öğretmen düzeltmesi, final onay, öğrenci/veli yeniden inceleme talebi ve resolution kaydı | PASS_SOURCE | Kurumun itiraz/yeniden inceleme işletimi |
| 7. Eğitsel değer / amaçla sınırlılık | YAZEK scope onaylı kazanım/öğrenme çıktısı veya kilitli soru kapsamına bağlı; kilitli rubrik; feedback modeli puanı değiştiremez | PASS_SOURCE | Gerçek pedagojik benchmark ve öğretmen kabulü |
| 8. Millî/manevi/kültürel değerlere uyum | Türk Millî Eğitiminin amaç/ilkeleri prompt policy'ye bağlı; nefret/şiddet/ideolojik yönlendirme ve küçümseyici içerik yasak; local feedback validator | PASS_SOURCE | Gerçek içerik örnekleriyle kurum QA'sı |

## Otomatik kaynak denetimi

`python tools/v20_18_yazek_ethics_evidence_audit.py`

Beklenen sonuç: **37/37 PASS**.

## Önemli sınır

Uygulama resmî YAZEK formundaki 8 etik ilkeyi öğretmen adına otomatik işaretlemez. BaykuşNot yalnız kanıt ve yardımcı metin sağlar; resmî beyan ve kurum süreçleri kullanıcı/kurum sorumluluğundadır.
