# V20.5 Validation Status

## Kaynak seviyesinde PASS
- V20.5 davranış audit: `tools/static_audit.py`.
- Room migration zinciri: `20→21→22→23→24→25` exported schema kolonlarına karşı doğrulandı.
- `app/schemas/.../25.json` sağlayıcı model audit alanlarını içerir.
- BN-BENCH-2 scorer minimum 20 vaka olmadan ADOPT üretmez; başarılı kayıtta kalite metrikleri ve capability profili digest'e bağlıdır.
- Final feedback external payload'ında raw cevap/soru/rubrik/görüntü, `originalAiScore` ve `teacherModified` yoktur.
- Final prose provider `promptFeedback`, candidate `finishReason`, `safetyRatings` ve yerel pedagojik filtrelerden geçer.
- GenerateContent responses actual `modelVersion`, `responseId` ve `modelStatus` alanlarını usage audit'e taşır.
- CachedContent `usageMetadata.totalTokenCount`, create/expire/delete yaşam döngüsüyle storage token-hour maliyeti hesaplanır.

## Bu ortamda tamamlanamayan kabul testi
- Gradle Wrapper 9.3.1 dağıtımı yerel cache'te yok ve dış indirme bu çalışma ortamında başarısız oluyor.
- Bu nedenle AGP/KSP/Compose/Room gerçek `assembleDebug` ve fiziksel telefon testi henüz PASS değildir.

## İlk Windows/telefon kabul testleri
1. `BAYKUSNOT_BUILD_V20_5_APK.bat` ile assembleDebug PASS.
2. V20.4→V20.5 güncellemesinde Room 24→25 migration veri kaybetmeden tamamlanmalı.
3. Bir gerçek sınavda Reports ekranında input/cache/output/thinking tokenları ile çağrı/cache/total maliyet görünmeli.
4. Provider yanıtında actual modelVersion kayıt edilmeli; response ID sayısı audit olarak görünmeli.
5. Prompt cache oluşturulup birkaç dakika sonra silindiğinde cache storage cost sıfırdan büyük ve gerçek süreyle orantılı olmalı.
6. 19-vakalık benchmark ADOPT üretmemeli; 20+ ve kalite eşiklerini geçen test tam BN-BENCH-2 record üretmeli.
7. Benchmark record capability profili değiştirildiğinde uygulama model profilini onaylamamalı.
8. Dönüt modeline giden JSON'da originalAiScore/teacherModified bulunmamalı.
9. Kontrollü uygunsuz/blocked veya sayısal puan içeren final prose kaydedilmemeli ve 'eksik dönüt' retry akışına düşmeli.
10. V3 privacy fail-closed, legacy preview, homework mask ve Batch retry senaryoları yeniden smoke-test edilmeli.

## Bilinçli ertelenen sertleştirme
Room DB henüz SQLCipher ile ayrıca şifreli değildir. Mevcut kullanıcıların düz SQLite DB'sini şifreli formata veri kaybetmeden taşımak için gerçek Android build/device migration testi gerektirir. Öğrenci cevap görüntüleri ayrı Keystore AES-GCM katmanında korunur ve Android backup kapalıdır.
