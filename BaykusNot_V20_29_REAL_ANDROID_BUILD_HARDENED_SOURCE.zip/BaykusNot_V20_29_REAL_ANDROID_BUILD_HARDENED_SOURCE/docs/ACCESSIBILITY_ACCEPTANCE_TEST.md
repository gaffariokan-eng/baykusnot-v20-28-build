# BaykuşNot V20.8 — Erişilebilirlik Kabul Kapısı

YAZEK'in eşitlik/kapsayıcılık ilkesi için release kabulünde fiziksel cihaz veya emulator üzerinde aşağıdaki testler yapılmalıdır:

- TalkBack ile ana ekran → yeni sınav → kâğıt yükleme → AI/YAZEK kapısı → öğretmen inceleme → rapor akışı eksiksiz gezilebiliyor.
- Tüm işlevsel ikonların erişilebilir adı var; dekoratif görseller odak sırasını kirletmiyor.
- Sistem yazı boyutu %200 olduğunda kritik metin, puan alanı ve onay butonları kesilmiyor/ulaşılamaz hale gelmiyor.
- Ekran zoom/büyük görüntü ayarında yatay taşma kritik eylemleri gizlemiyor.
- Klavye/harici erişim ile odak sırası mantıklı.
- Hata, güven ve review durumları yalnız renkle anlatılmıyor; metinsel durum etiketi de var.
- “AI olmadan manuel değerlendirme” yolu erişilebilir biçimde kullanılabiliyor.

Bu kontrol source-level `contentDescription`/metin etiketlerinin varlığından ayrı bir gerçek cihaz kabul testidir. Test sonucu `PASS` olmadan erişilebilirlik üretim doğrulaması tamamlanmış sayılmaz.
