# V20.6 Requirements Matrix

| Karar / gereksinim | V20.6 karşılığı | Durum |
|---|---|---|
| Öğretmen günlük akışı bozulmasın | Temel sınav→okuma→kontrol→onay→dönüt→rapor akışı korunuyor | PASS_STATIC |
| Kimlik AI'a gitmesin | V3 fiducial fail-closed + yerel privacy crop | PASS_STATIC |
| İki sayfa birlikte ama ayrı görüntü | Aynı request içinde ayrı HIGH image part | PASS_STATIC |
| Şüpheli soruyu hedefli tekrar oku | Yalnız ilgili cevap alanı | PASS_STATIC |
| Öğretmen nihai otorite | Approval + manuel score transaction + e-Okul nihai kayıt | PASS_STATIC |
| Uzun kişisel dönüt onaydan sonra | Ekonomik feedback modeli yalnız öğretmen onayı sonrası | PASS_STATIC |
| Feedback modeli yeniden notlamasın | Ham cevap/soru/rubrik/görüntü ve puan-çatışma alanları dış payload'a girmez | PASS_STATIC |
| Dönüt güvenliği | Provider safety + yerel pedagojik filtre | PASS_STATIC |
| Legacy privacy kör gönderim olmasın | Tüm sayfalar render + viewed; UI ve repository fail-closed | PASS_STATIC |
| Ödev privacy kör gönderim olmasın | Tüm sayfalar decode + viewed; repository fail-closed | PASS_STATIC |
| Android cihazdan-cihaza öğrenci verisi taşınmasın | Android 12+ device-transfer root/file/database/sharedpref/external exclude | PASS_STATIC |
| FileProvider gereksiz kök paylaşmasın | Yalnız kullanılan kamera/rapor/çıktı alt dizinleri | PASS_STATIC |
| Batch + cache maliyeti doğru olsun | Cached input Batch factor almaz; uncached/output Batch factor alır | PASS_STATIC |
| Cache storage gerçek süreyle hesaplansın | Provider cached token count × create→delete/expire token-hour | PASS_STATIC |
| Bütün AI aşamaları maliyet/audit'e girsin | Evaluation/feedback + authoring question/scenario/objective/rubric ledger | PASS_STATIC |
| Authoring gerçek geçmiş modelini kanıtlasın | Call-time requested model + provider actual model/response/status usage kaydı | PASS_STATIC |
| Sınav run fiyat/model profili snapshot olsun | ExamAiRunProfile + authoring fiyat alanları | PASS_STATIC |
| Öğretmen puan değişikliği atomik olsun | Score/total/approval/final feedback tek Room transaction | PASS_STATIC |
| Büyük manuel değişiklik eski AI teşhisini geçersiz kılsın | >= max(1 puan, %20 maxScore) diagnosis clear | PASS_STATIC |
| Yeni model rolüne göre test edilmeden üretime girmesin | BNBENCH3 role-bound EVALUATION/FEEDBACK/AUTHORING approval | PASS_STATIC |
| Evaluation benchmark capability profilini bağlasın | HIGH image token + high media/batch/cache/thinking binding | PASS_STATIC |
| Feedback benchmark pedagojik kaliteyi ölçsün | Consistency/pedagogy/Turkish/safety/personalization + token/cost | PASS_STATIC |
| Authoring benchmark hazırlık kalitesini ölçsün | Extraction/rubric/objective/hallucination/correction + token/cost | PASS_STATIC |
| Gerçek benchmark seti en az 20 vaka olsun | Kod production approval için 20 REAL_ANONYMIZED şart koşuyor; gerçek set pakette yok | BLOCKED_REAL_DATA |
| Sentetik örnek production approval vermesin | Bundled manifest `SYNTHETIC_EXAMPLE`; scorer ADOPT üretemez | PASS_STATIC |
| Yerel optik rapor yanlış AI beyanı vermesin | AI yoksa local-optical disclosure; authoring-only kullanım ayrıştırılır | PASS_STATIC |
| YAZEK beyanı tüm AI rollerini göstersin | Authoring/evaluation/feedback rol özeti | PASS_STATIC |
| Model retirement kullanıcıya uyarı versin | Provider retirement/status summary Reports UI'da görünür | PASS_STATIC |
| Görüntüler at-rest şifreli | Android Keystore AES-256-GCM mevcut davranış korunuyor | PASS_STATIC |
| Room 25→26 migration | Authoring pricing snapshot kolonları migration SQL ile ekleniyor | PASS_SOURCE_MIGRATION |
| Room schema 26 exported JSON | Room/KSP başarılı build gerekiyor | BLOCKED_ENV |
| Room DB uygulama seviyesinde SQLCipher | Gerçek cihaz migration testi öncesi bilinçli ertelendi | DEFERRED |
| Gerçek Gradle unit/instrumented build | Gradle 9.3.1 distribution DNS/erişim engeli | BLOCKED_ENV |
| Gerçek APK + fiziksel telefon upgrade/smoke testi | Bu ortamda APK üretilemedi | BLOCKED_ENV |
