# V20.7 Requirements Matrix

Durum anahtarı: `PASS_STATIC` = kaynak/statik denetimle doğrulandı; `PASS_SOURCE_MIGRATION` = migration SQL kaynak testi geçti; `DEVICE_TEST_REQUIRED` = gerçek Android cihaz testi zorunlu; `BLOCKED_REAL_DATA` = gerçek anonim veri gerekli; `BLOCKED_EXTERNAL_INFRA` = harici authenticated gateway kurulumu gerekli; `BLOCKED_ENV` = mevcut çalışma ortamı derlemeyi başlatamadı.

| Gereksinim | V20.7 karşılığı | Durum |
|---|---|---|
| Öğretmen nihai karar verici olsun | AI önerisi + Teacher Review + atomik manuel puan/approval invalidation | PASS_STATIC |
| Öğrenci kimliği AI'a gitmesin | V3 privacy crop/fiducial fail-closed; legacy/homework all-pages preview gate | PASS_STATIC |
| YAZEK beyanı tek yıllık checkbox olmasın | Scope fingerprint: kurum/ders/sınıf/şube/kapsam/amaç/AI aracı | PASS_STATIC |
| Kapsam değişirse eski beyan kullanılmasın | Fingerprint değişir; StudentAiComplianceGate fail-closed | PASS_STATIC |
| Eksik YAZEK hedef kapsamıyla AI'a gidilmesin | Kurum/ders/sınıf/hedef şube/kapsam/amaç/AI aracı completeness gate | PASS_STATIC |
| Resmî YAZEK beyanının yerine yerel checkbox geçmesin | UI açıkça resmî `Uygula` işlemini ister; yerel kayıt yalnız safety/audit | PASS_STATIC |
| Gerçek AI kullanımına beyan izi bağlansın | `exam_yazek_declaration` scope fingerprint/time/reference audit | PASS_STATIC |
| Sınav silinince yönetilen öğrenci verileri de silinsin | `ExamDeletionRepository.deleteExamCompletely()` | PASS_STATIC |
| Uzak Batch kalıntıları temizlenmeye çalışılsın | credential varsa cancel/file cleanup best-effort; local record her durumda purge | PASS_STATIC |
| Öğrenci/veli yeniden inceleme kaydı olsun | `exam_review_request` + Teacher Review UI + before/after score audit | PASS_STATIC |
| AI puan kararının dayanağı öğretmene gösterilsin | `interpretedMeaning` + `gradingEvidence` Teacher Review UI | PASS_STATIC |
| AI servisi yoksa öğretmen mağdur olmasın | Written/listening/homework manuel değerlendirme B-planı | PASS_STATIC |
| Test sınavı AI'a bağlı olmasın | Yerel optik/deterministik değerlendirme yolu korunuyor | PASS_STATIC |
| Production Gemini secret telefonda tutulmasın | release direct Gemini kapalı; gateway-managed store | PASS_STATIC |
| API key URL/query loglarına düşmesin | tüm Gemini çağrıları key query'den temizlendi; debug header auth | PASS_STATIC |
| Production gateway yoksa fail-closed | release interceptor güvenli gateway olmadan isteği reddeder | PASS_STATIC |
| Authenticated production gateway gerçekten çalışsın | Android client contract hazır; kurum/servis gateway deploy+auth haricî | BLOCKED_EXTERNAL_INFRA |
| Görüntüler at-rest şifreli | Android Keystore AES-256-GCM | PASS_STATIC |
| Room akademik verileri uygulama seviyesinde şifreli | SQLCipher factory + Keystore passphrase + plaintext export migration | PASS_STATIC |
| Mevcut plaintext DB veri kaybetmeden şifrelensin | `sqlcipher_export()` + encrypted copy verify + fail-closed swap | PASS_SOURCE_MIGRATION |
| SQLCipher gerçek cihaz migrationı doğrulansın | instrumented test kaynağı var; fiziksel V20.6 verisiyle çalıştırılmalı | DEVICE_TEST_REQUIRED |
| Android backup/device-transfer öğrenci verisi taşınmasın | cloud/device-transfer exclusions | PASS_STATIC |
| FileProvider gereksiz kök paylaşmasın | daraltılmış özel dizinler | PASS_STATIC |
| Hassas ekran capture edilemesin | `FLAG_SECURE` | PASS_STATIC |
| Batch akademik içerik plaintext temp JSONL olmasın | streaming `RequestBody`; disk JSONL yaratılmıyor | PASS_STATIC |
| Evaluation benchmark gerçek/çeşitli vaka istesin | >=20 unique REAL_ANONYMIZED + handwriting/image/correction/Turkish/grade coverage | PASS_STATIC |
| Feedback benchmark pedagojik/fairness kapsamı istesin | kategori + grade-band + misconception + teacher-modified coverage | PASS_STATIC |
| Authoring benchmark görev kapsamı istesin | extraction + rubric + objective + >=2 grade band | PASS_STATIC |
| Sentetik örnek production model onaylamasın | scorer sonucu `KEEP_BASELINE`; `coverage=FAIL` | PASS_STATIC |
| Gerçek production benchmark seti mevcut olsun | kullanıcı/kurumdan anonim, adjudicated gerçek set gerekli; paket üretmiyor | BLOCKED_REAL_DATA |
| AI çıktısı etiketleyici/ayrımcı olmasın | YAZEK prompt policy + local content validator | PASS_STATIC |
| Millî/manevi/kültürel değerlere uyum politikası olsun | `YazekContentPolicy` evaluation+feedback zincirine bağlı | PASS_STATIC |
| Erişilebilirlik kabul protokolü olsun | TalkBack/200% font/focus/semantics test planı | PASS_STATIC |
| Erişilebilirlik gerçek cihazda doğrulansın | test protokolü mevcut; cihaz testi yapılmadı | DEVICE_TEST_REQUIRED |
| Gerçek Gradle/Kotlin/Compose/KSP compile | Gradle 9.3.1 download `UnknownHostException` | BLOCKED_ENV |
| Room schema 26/27 export + gerçek migration tests | başarılı KSP/Room build gerekir | BLOCKED_ENV |
| APK + fiziksel telefon smoke/upgrade testi | bu ortamda APK üretilemedi | BLOCKED_ENV |
