# BaykuşNot V20.8 Changelog

## P0 — YAZEK gerçek eğitsel amaç/kapsam kilidi
- `ExamEvaluationRepository.buildYazekDeclarationScope()` onaylı `ExamObjectiveEntity` kayıtlarını kullanır.
- Objective yoksa kilitli soru seti güvenli fallback kapsamıdır.
- `READINESS` ayrı eğitsel amaç olarak ele alınır.
- Tam içerik SHA-256 `learningOutcomeSignature` üretir ve YAZEK fingerprint'ine katılır.

## P0 — Kalıcı MANUAL fail-closed modu
- Yeni `exam_processing_mode` tablosu.
- Manuel B-planı `evaluationSource=MANUAL`, `feedbackSource=NONE` yazar.
- AI evaluation restart ve final feedback manual modda engellenir.
- AI yeniden açma yalnız ayrı, açık öğretmen işlemiyle mümkündür.

## P1 — Manuel provenance temizliği
- Eski AI `readAnswerText`, score, confidence, answer type ve originalScore aktif manuel kayıttan kaldırılır/resetlenir.
- Manuel puanlama 0'dan başlar; AI usage/audit geçmişi korunur.

## P1 — Doğru rapor AI açıklaması
- Authoring/evaluation/feedback usage ledger + persistent processing mode birlikte değerlendirilir.
- Tamamen manuel, yalnız authoring-AI, yerel optik ve AI-destekli yollar farklı açıklama üretir.

## P1 — Tam cache silme
- Rapor cache dosyaları `BaykusNot_Exam_<id>_...pdf` biçimindedir.
- `deleteExamCompletely()` ilgili sınavın geçici PDF'lerini anında siler.

## P1 — Öğrenci/veli veri bilgilendirme
- YAZEK kapsamından veri türü, amaç, AI rolü, saklama ve erişim/düzeltme/yeniden inceleme/silme haklarını açıklayan metin üretilir.
- YAZEK kapısında tek dokunuşla kopyalanabilir.

## Production gateway auth hardening
- `GatewayAuthTokenStore` eklendi.
- Release gateway isteği kısa ömürlü Bearer token olmadan fail-closed durur.
- Token yalnız RAM'de tutulur; uzun ömürlü secret cihazda tutulmaz.

## DB / QA
- Room 27→28 migration: `exam_processing_mode`.
- `tools/static_audit.py`: 108/108 PASS.
- `tools/semantic_flow_audit.py`: 9/9 PASS.
- `tools/validate_room_schema_migrations.py`: 27→28 dahil PASS.
- Gradle build bu ortamda dış DNS engeli nedeniyle compiler aşamasına ulaşamadı; BLOCKED_ENV olarak bırakıldı.
