# V20.27 Requirements Matrix

| Gereksinim | Kaynak kanıtı | Sonuç |
|---|---|---|
| Implicit-Unit compile bug kaldırılmış olmalı | `RubricViewModel.processUploadedDocument()` | PASS |
| App main kaynaklarında senkron OkHttp `.execute()` kalmamalı | network scan + V20.27 audit | PASS |
| AI/Batch cancellation gerçek HTTP call'a ulaşmalı ve yutulmamalı | `OkHttpCoroutine.kt`, Batch remote helpers | PASS |
| Authoring AI işleri workflow stage + screen lifecycle ile sınırlı olmalı | UploadSource / QuestionPoints / Rubric VM + routes + coordinators | PASS |
| Final feedback stale teacher/workflow snapshot üstüne yazmamalı | `saveFinalFeedbackIfSnapshotMatches()` Room transaction | PASS |
| Reports feedback işi stage/dispose ile iptal edilmeli | `ReportsViewModel`, `ReportsScreen` | PASS |
| Text answer-key import bounded olmalı | `TestAnswerKeyScreen` + `BoundedInputReader` | PASS |
| Teacher answer-key PDF tüm bitmapleri RAM'de tutmamalı | `TestOpticalFormReader.readTeacherAnswerKey()` | PASS |
| Batch/cache dahili audit ledger dosyaları bounded okunup yazılmalı | `GeminiBatchJobManager`, `GeminiCacheManager` | PASS |
| Eski V20.26 Batch/recovery/privacy/YAZEK akışları bozulmamalı | V20.27 regression logs | PASS |
| Kotlin PSI parse temiz olmalı | 324/324 | PASS |
| Constructor/factory call-shape temiz olmalı | 1581/1581 | PASS |
| Gerçek Android Gradle/KSP build tamamlanmalı | `V20_27_GRADLE_BUILD_ATTEMPT.log` | BLOCKED_ENV |
| Fiziksel cihaz/SQLCipher/SAF/camera/accessibility release testleri | Harici cihaz gerekir | DEVICE_TEST_REQUIRED |
| Production gateway + V20.27 source-bound signed BNBENCH approvals | Harici altyapı/gerçek benchmark/signing gerekir | EXTERNAL_GATE_REQUIRED |
