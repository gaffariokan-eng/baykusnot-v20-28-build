# V20.25 Changelog

- Belirsiz Batch submission artık `SUBMISSION_UNCERTAIN` durable durumuna geçiyor; aynı ERROR tekrar yazılmıyor.
- Batch polling 15s→30s→60s→120s exponential backoff kullanıyor; 10 dakika içinde doğrulanamayan belirsiz submission fail-closed ERROR durumuna geçiyor ve otomatik yeniden gönderilmiyor.
- AI Evaluation canlı ekranındaki per-student N+1 Room sorguları kaldırıldı; sınav düzeyinde bulk Flow kullanılıyor.
- Workflow rewind, normal Durdur ile aynı remote Batch cancel/terminal cleanup sınırını kullanıyor.
- Batch polling her turda workflow stage'i yeniden doğruluyor; stale remote sonuç yazımı engelleniyor.
- Tek öğrenci değerlendirme/retry yolu AI öncesi ve commit öncesi stage guard kullanıyor.
- Startup privacy blocker durumunda da iki aşamalı kontrollü yerel sıfırlama yolu erişilebilir.
- versionCode 26 / versionName 1.23-v20.25. Room schema 30.
