# V20.29 Real Build Findings

- GitHub build #1/#2: Gradle Kotlin DSL içindeki `java.*` namespace çakışması görüldü.
- Sonraki cloud build: script aşaması geçildi; `sqlcipher-android:4.18.0` compileSdk 37 gereksinimi AAR metadata kontrolünde yakalandı.
- Android SDK manager `platforms;android-37` paketini bulamadığı için compileSdk 37'ye zorlamak reddedildi.
- Kalıcı çözüm: compileSdk 36.1 + targetSdk 36 korunarak SQLCipher 4.17.0 / AndroidX SQLite 2.6.2'ye pin ve Gradle alias importları.
- V20.29 cloud workflow kaynakta geçici patch uygulamaz.
