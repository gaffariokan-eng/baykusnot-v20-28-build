# V20.29 Real Build Findings

- GitHub build #1/#2: Gradle Kotlin DSL içindeki `java.*` namespace çakışması görüldü.
- Sonraki cloud build: script aşaması geçildi; `sqlcipher-android:4.18.0` compileSdk 37 gereksinimi AAR metadata kontrolünde yakalandı.
- Android SDK manager `platforms;android-37` paketini bulamadığı için compileSdk 37'ye zorlamak reddedildi.
- Kalıcı çözüm: compileSdk 36.1 + targetSdk 36 korunarak SQLCipher 4.17.0 / AndroidX SQLite 2.6.2'ye pin ve Gradle alias importları.
- V20.29 cloud workflow kaynakta geçici patch uygulamaz.

## GitHub Actions build #7 — Kotlin compiler pass

Cloud build reached `:app:compileDebugKotlin` successfully after SDK, AAR metadata, KSP, resource, manifest, dex/native and debug-signing preparation stages. The compiler then exposed the remaining source-level errors that static audits could not prove.

Fixed in the source package:
- `ExamEvaluationRepository`: out-of-scope `httpEvaluator` reference replaced with a safe evaluator cast/cache-manager lookup.
- `GeminiBatchJobManager` / `GeminiCacheManager`: bounded-reader limits changed from `Long` constants to required `Int` limits.
- `GeminiProductionSecurityInterceptor`: nullable `GatewaySessionManager` stabilized in a local non-null reference before retry.
- `HttpGeminiExamRubricGenerator`: `withContext` early return labelled correctly.
- `TestAnswerKeyScreen`: bounded-reader size argument aligned to `Int`.
- `AiEvaluationScreen`: missing Material3 `OutlinedTextField` import restored.
- `AnswerSheetScreen`: preview renderer now provides an explicit non-authoritative `PREVIEW` form token.
- `NewDraftScreen`: delegated `loadError` state copied to a local value before null-check/smart-cast use.
- `UploadSourceRoute`: missing `ByteArrayInputStream` import restored.

Post-fix static regression status: all active V20.29 audit suites pass, including 216/216 static and 98/98 full-flow checks. A new cloud build is still required before declaring APK build PASS.
