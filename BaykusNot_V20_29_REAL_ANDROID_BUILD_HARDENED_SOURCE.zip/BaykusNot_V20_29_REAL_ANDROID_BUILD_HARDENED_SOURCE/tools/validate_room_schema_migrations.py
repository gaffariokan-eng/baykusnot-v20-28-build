#!/usr/bin/env python3
from pathlib import Path
import json, sqlite3, sys
ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app/schemas/com.example.core.database.AppDatabase'
M20_21 = ['''CREATE TABLE IF NOT EXISTS `exam_listening_material` (
        `examDraftId` INTEGER NOT NULL, `localRelativePath` TEXT, `originalUri` TEXT,
        `displayName` TEXT, `mimeType` TEXT, `sizeBytes` INTEGER, `sha256` TEXT,
        `transcript` TEXT NOT NULL DEFAULT '', `playbackCount` INTEGER NOT NULL DEFAULT 2,
        `instructions` TEXT NOT NULL DEFAULT '', `isTranscriptApproved` INTEGER NOT NULL DEFAULT 0,
        `importedAt` INTEGER, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`examDraftId`),
        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )''']
M21_22 = [
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `interpretedMeaning` TEXT",
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `gradingEvidence` TEXT",
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `strengths` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `missingElements` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `misconceptions` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_question_evaluation` ADD COLUMN `nextSteps` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `overallFeedback` TEXT",
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `feedbackGeneratedAt` INTEGER",
]
M22_23 = [
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingStrengths` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingIssues` TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `writingNextSteps` TEXT NOT NULL DEFAULT '[]'",
]

M23_24 = [
    """CREATE TABLE IF NOT EXISTS `exam_ai_run_profile` (
        `examDraftId` INTEGER NOT NULL, `evaluationModel` TEXT NOT NULL,
        `feedbackModel` TEXT NOT NULL, `authoringModel` TEXT NOT NULL,
        `evaluationInputPerMillionUsd` REAL NOT NULL, `evaluationOutputPerMillionUsd` REAL NOT NULL,
        `evaluationCachedInputPerMillionUsd` REAL NOT NULL, `cacheStoragePerMillionTokenHourUsd` REAL NOT NULL,
        `feedbackInputPerMillionUsd` REAL NOT NULL, `feedbackOutputPerMillionUsd` REAL NOT NULL,
        `batchPriceFactor` REAL NOT NULL, `highImageTokens` INTEGER NOT NULL,
        `supportsHighMediaResolution` INTEGER NOT NULL, `supportsBatch` INTEGER NOT NULL,
        `supportsPromptCaching` INTEGER NOT NULL, `supportsThinkingLevel` INTEGER NOT NULL,
        `preferBatchEvaluation` INTEGER NOT NULL, `promptPolicyVersion` TEXT NOT NULL,
        `legacyPrivacyApprovedAt` INTEGER, `homeworkPrivacyApprovedAt` INTEGER, `profileUpdatedAt` INTEGER NOT NULL, `lockedAt` INTEGER NOT NULL,
        PRIMARY KEY(`examDraftId`), FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )""",
    """CREATE TABLE IF NOT EXISTS `exam_ai_usage` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `examDraftId` INTEGER NOT NULL,
        `studentPaperId` INTEGER, `stage` TEXT NOT NULL, `modelId` TEXT NOT NULL,
        `useBatchPricing` INTEGER NOT NULL, `inputTokens` INTEGER NOT NULL,
        `cachedInputTokens` INTEGER NOT NULL, `outputTokens` INTEGER NOT NULL,
        `thinkingTokens` INTEGER NOT NULL, `estimatedCostUsd` REAL NOT NULL,
        `recordedAt` INTEGER NOT NULL,
        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )""",
    "CREATE INDEX IF NOT EXISTS `index_exam_ai_usage_examDraftId` ON `exam_ai_usage` (`examDraftId`)",
    "CREATE INDEX IF NOT EXISTS `index_exam_ai_usage_studentPaperId` ON `exam_ai_usage` (`studentPaperId`)",
]

M24_25 = [
    "ALTER TABLE `exam_ai_usage` ADD COLUMN `actualModelVersion` TEXT",
    "ALTER TABLE `exam_ai_usage` ADD COLUMN `responseId` TEXT",
    "ALTER TABLE `exam_ai_usage` ADD COLUMN `modelStatusStage` TEXT",
    "ALTER TABLE `exam_ai_usage` ADD COLUMN `modelRetirementTime` TEXT",
    "ALTER TABLE `exam_ai_usage` ADD COLUMN `modelStatusMessage` TEXT",
]

M25_26 = [
    "ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringInputPerMillionUsd` REAL NOT NULL DEFAULT 0.75",
    "ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringOutputPerMillionUsd` REAL NOT NULL DEFAULT 3.75",
    "ALTER TABLE `exam_ai_run_profile` ADD COLUMN `authoringCachedInputPerMillionUsd` REAL NOT NULL DEFAULT 0.075",
]


M26_27 = [
    """CREATE TABLE IF NOT EXISTS `exam_review_request` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `examDraftId` INTEGER NOT NULL,
        `studentPaperId` INTEGER NOT NULL, `requestedBy` TEXT NOT NULL, `reason` TEXT NOT NULL,
        `status` TEXT NOT NULL, `scoreBefore` REAL, `scoreAfter` REAL, `requestedAt` INTEGER NOT NULL,
        `resolvedAt` INTEGER, `resolutionNote` TEXT,
        FOREIGN KEY(`studentPaperId`) REFERENCES `exam_student_paper`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )""",
    "CREATE INDEX IF NOT EXISTS `index_exam_review_request_examDraftId` ON `exam_review_request` (`examDraftId`)",
    "CREATE INDEX IF NOT EXISTS `index_exam_review_request_studentPaperId` ON `exam_review_request` (`studentPaperId`)",
    """CREATE TABLE IF NOT EXISTS `exam_yazek_declaration` (
        `examDraftId` INTEGER NOT NULL, `scopeFingerprint` TEXT NOT NULL, `scopeSummary` TEXT NOT NULL,
        `academicYear` TEXT NOT NULL, `confirmedAt` INTEGER NOT NULL, `referenceNote` TEXT,
        PRIMARY KEY(`examDraftId`),
        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )""",
]
M27_28 = [
    """CREATE TABLE IF NOT EXISTS `exam_processing_mode` (
        `examDraftId` INTEGER NOT NULL, `evaluationSource` TEXT NOT NULL, `feedbackSource` TEXT NOT NULL,
        `changedAt` INTEGER NOT NULL, `reason` TEXT,
        PRIMARY KEY(`examDraftId`),
        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )"""
]
M28_29 = [
    "ALTER TABLE `exam_student_evaluation` ADD COLUMN `teacherNote` TEXT",
]

M29_30 = [
    """UPDATE `exam_evaluation_preferences`
        SET `evaluationMode` = 'PAPER_BY_PAPER', `rubricAdherenceLevel` = 'BALANCED',
            `modelQualityTier` = 'STANDARD', `reportClass` = 1, `reportIndividual` = 1,
            `reportQuestion` = 1, `useBatchApi` = 0, `usePromptCaching` = 1,
            `revision` = `revision` + 1, `updatedAt` = CAST(strftime('%s','now') AS INTEGER) * 1000
        WHERE `evaluationMode` != 'PAPER_BY_PAPER' OR `rubricAdherenceLevel` != 'BALANCED'
           OR `modelQualityTier` != 'STANDARD' OR `reportClass` != 1 OR `reportIndividual` != 1
           OR `reportQuestion` != 1 OR `useBatchApi` != 0 OR `usePromptCaching` != 1""",
    """CREATE TABLE IF NOT EXISTS `exam_evaluation_run_state` (
        `examDraftId` INTEGER NOT NULL, `requestedMode` TEXT NOT NULL, `status` TEXT NOT NULL,
        `completedCount` INTEGER NOT NULL, `totalCount` INTEGER NOT NULL, `lastError` TEXT,
        `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`examDraftId`),
        FOREIGN KEY(`examDraftId`) REFERENCES `exam_draft`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
    )"""
]

def load(v): return json.loads((SCHEMA/f'{v}.json').read_text())['database']
def create_from_schema(conn,db):
    for e in db['entities']:
        conn.execute(e['createSql'].replace('${TABLE_NAME}',e['tableName']))
        for idx in e.get('indices',[]): conn.execute(idx['createSql'].replace('${TABLE_NAME}',e['tableName']))
    conn.commit()
def actual_columns(conn,table): return {row[1]:(row[2].upper(),bool(row[3]),bool(row[5])) for row in conn.execute(f'PRAGMA table_info(`{table}`)')}
def expected_columns(entity):
    pk=set(entity.get('primaryKey',{}).get('columnNames',[]))
    return {f['columnName']:(f['affinity'].upper(),bool(f.get('notNull',False)),f['columnName'] in pk) for f in entity['fields']}
def validate(conn,db):
    errors=[]
    for e in db['entities']:
        t=e['tableName']; a=actual_columns(conn,t); x=expected_columns(e)
        if set(a)!=set(x): errors.append(f'{t}: columns actual={sorted(a)} expected={sorted(x)}'); continue
        for c in x:
            aa=a[c]; xx=x[c]
            if aa[0]!=xx[0] or aa[2]!=xx[2] or (not xx[2] and aa[1]!=xx[1]): errors.append(f'{t}.{c}: actual={aa} expected={xx}')
    return errors
def main():
    db20,db21,db22,db23,db24,db25=map(load,[20,21,22,23,24,25])
    conn=sqlite3.connect(':memory:'); conn.execute('PRAGMA foreign_keys=ON'); create_from_schema(conn,db20)
    all_errors=[]
    for label,sqls,target in [('20->21',M20_21,db21),('21->22',M21_22,db22),('22->23',M22_23,db23),('23->24',M23_24,db24),('24->25',M24_25,db25)]:
        for sql in sqls: conn.execute(sql)
        conn.commit(); errs=validate(conn,target)
        if errs: all_errors.extend((label,e) for e in errs)
        else: print(f'PASS | exported Room schema {target["version"]} matches {label} migration columns')
    for sql in M25_26: conn.execute(sql)
    conn.commit()
    cols=actual_columns(conn,'exam_ai_run_profile')
    expected_new={'authoringInputPerMillionUsd','authoringOutputPerMillionUsd','authoringCachedInputPerMillionUsd'}
    if not expected_new.issubset(cols): all_errors.append(('25->26',f'missing authoring pricing columns: {sorted(expected_new-set(cols))}'))
    else: print('PASS | 25->26 migration SQL adds authoring pricing snapshot columns (exported schema 26 pending successful Room/KSP build)')
    for sql in M26_27: conn.execute(sql)
    conn.commit()
    if set(actual_columns(conn,'exam_review_request')) != {'id','examDraftId','studentPaperId','requestedBy','reason','status','scoreBefore','scoreAfter','requestedAt','resolvedAt','resolutionNote'}:
        all_errors.append(('26->27','review table columns mismatch'))
    elif set(actual_columns(conn,'exam_yazek_declaration')) != {'examDraftId','scopeFingerprint','scopeSummary','academicYear','confirmedAt','referenceNote'}:
        all_errors.append(('26->27','YAZEK audit table columns mismatch'))
    else: print('PASS | 26->27 migration SQL adds review requests + per-exam YAZEK audit')
    for sql in M27_28: conn.execute(sql)
    conn.commit()
    expected_mode={'examDraftId','evaluationSource','feedbackSource','changedAt','reason'}
    if set(actual_columns(conn,'exam_processing_mode')) != expected_mode:
        all_errors.append(('27->28','processing mode table columns mismatch'))
    else: print('PASS | 27->28 migration SQL adds persistent AI/MANUAL processing provenance')
    for sql in M28_29: conn.execute(sql)
    conn.commit()
    eval_cols=actual_columns(conn,'exam_student_evaluation')
    if 'teacherNote' not in eval_cols or eval_cols['teacherNote'][0] != 'TEXT':
        all_errors.append(('28->29','teacherNote column missing or wrong type'))
    else: print('PASS | 28->29 migration SQL adds persistent teacher note')
    for sql in M29_30: conn.execute(sql)
    conn.commit()
    expected_run={'examDraftId','requestedMode','status','completedCount','totalCount','lastError','updatedAt'}
    if set(actual_columns(conn,'exam_evaluation_run_state')) != expected_run:
        all_errors.append(('29->30','durable evaluation run-state table columns mismatch'))
    else: print('PASS | 29->30 migration SQL adds durable evaluation run-state table')

    # Semantic canonicalization oracle: explicit teacher writing/feedback choices survive while
    # hidden technical Teacher Mode fields normalize.
    mini=sqlite3.connect(':memory:')
    mini.execute("""CREATE TABLE exam_evaluation_preferences (
        examDraftId INTEGER PRIMARY KEY, evaluationMode TEXT NOT NULL, rubricAdherenceLevel TEXT NOT NULL,
        feedbackDetailLevel TEXT NOT NULL, deductWritingAndPunctuationPoints INTEGER NOT NULL,
        hasExplicitWritingPunctuationPreference INTEGER NOT NULL, provideWritingAndPunctuationFeedback INTEGER NOT NULL,
        modelQualityTier TEXT NOT NULL, reportClass INTEGER NOT NULL, reportIndividual INTEGER NOT NULL,
        reportQuestion INTEGER NOT NULL, useBatchApi INTEGER NOT NULL, usePromptCaching INTEGER NOT NULL,
        revision INTEGER NOT NULL, updatedAt INTEGER NOT NULL)""")
    mini.execute("INSERT INTO exam_evaluation_preferences VALUES (1,'QUESTION_BY_QUESTION','STRICT','BRIEF',1,1,0,'QUALITY',0,0,0,1,0,7,123)")
    mini.execute(M29_30[0])
    row=mini.execute('SELECT * FROM exam_evaluation_preferences').fetchone()
    cols=[x[1] for x in mini.execute('PRAGMA table_info(exam_evaluation_preferences)')]
    d=dict(zip(cols,row))
    if not (d['evaluationMode']=='PAPER_BY_PAPER' and d['rubricAdherenceLevel']=='BALANCED' and d['modelQualityTier']=='STANDARD' and d['reportClass']==1 and d['reportIndividual']==1 and d['reportQuestion']==1 and d['useBatchApi']==0 and d['usePromptCaching']==1 and d['deductWritingAndPunctuationPoints']==1 and d['provideWritingAndPunctuationFeedback']==0):
        all_errors.append(('29->30','Teacher Mode canonicalization changed teacher-owned fields or left hidden technical values stale'))
    else: print('PASS | 29->30 Teacher Mode canonicalization preserves teacher-owned writing/feedback choices')
    if all_errors:
        for label,e in all_errors: print('FAIL',label,'|',e)
        return 1
    return 0
if __name__=='__main__': sys.exit(main())
