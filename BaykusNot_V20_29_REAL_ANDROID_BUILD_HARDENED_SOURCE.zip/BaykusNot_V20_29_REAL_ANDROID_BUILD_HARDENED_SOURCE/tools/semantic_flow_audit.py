#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8',errors='ignore')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
reports=t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
pdf=t('app/src/main/java/com/example/feature/workflow/ReportsPdfGenerator.kt')
delete=t('app/src/main/java/com/example/core/data/ExamDeletionRepository.kt')
yazek=t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
checks={
 'manual_mode_is_persistent': 'ExamProcessingModeEntity' in repo and '"MANUAL", "NONE"' in repo,
 'manual_mode_blocks_ai_evaluation': 'requireAiEvaluationEnabled(examDraftId)' in repo,
 'manual_mode_blocks_auto_feedback': 'if (mode.feedbackSource != "AI")' in repo,
 'reports_do_not_rearm_feedback_in_manual': 'countMissingFinalFeedback(draftId)' in reports,
 'manual_active_provenance_is_reset': all(x in repo for x in ['readAnswerText = ""','readingConfidence = 0.0','evaluationConfidence = 0.0','answerType = "MANUAL"','originalScore = 0.0']),
 'yazek_scope_changes_with_learning_outcomes': 'learningOutcomeSignature = outcomeSignature' in repo and 'learningOutcomeSignature.trim()' in yazek,
 'readiness_has_distinct_purpose': 'ExamType.READINESS -> "Hazırbulunuşluk' in repo,
 'report_cache_is_exam_scoped': 'BaykusNot_Exam_${examDraftId}_' in pdf,
 'exam_delete_removes_report_cache': 'BaykusNot_Exam_${examId}_' in delete,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
failed=[k for k,v in checks.items() if not v]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
