#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
checks=[]

def t(rel):
    return (ROOT/rel).read_text(encoding='utf-8', errors='ignore')

def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+' | '+name)

repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
pause=t('app/src/main/java/com/example/core/data/EvaluationPauseGuard.kt')
passphrase=t('app/src/main/java/com/example/core/security/DatabasePassphraseStore.kt')
camera=t('app/src/main/java/com/example/core/data/CameraCaptureJournal.kt')
application=t('app/src/main/java/com/example/EvaluatorApplication.kt')
main_activity=t('app/src/main/java/com/example/MainActivity.kt')
reports=t('app/src/main/java/com/example/feature/workflow/ReportsPdfGenerator.kt')
camera_test=t('app/src/test/java/com/example/core/data/CameraCaptureJournalTest.kt')
pdf=t('app/src/main/java/com/example/core/data/PdfSafWriter.kt')
answer_vm=t('app/src/main/java/com/example/feature/workflow/AnswerSheetViewModel.kt')
rubric_vm=t('app/src/main/java/com/example/feature/workflow/RubricViewModel.kt')
answer_route=t('app/src/main/java/com/example/feature/workflow/AnswerSheetRoute.kt')
rubric_route=t('app/src/main/java/com/example/feature/workflow/RubricRoute.kt')
delete=t('app/src/main/java/com/example/core/data/ExamDeletionRepository.kt')
new_vm=t('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt')
new_screen=t('app/src/main/java/com/example/feature/workflow/NewDraftScreen.kt')
workflow=t('app/src/main/java/com/example/feature/workflow/WorkflowScreen.kt')
rubric_gen=t('app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt')
upload=t('app/src/main/java/com/example/feature/workflow/UploadPapersScreen.kt')
build=t('app/build.gradle.kts')

# Run-state truth table. Only RUNNING is eligible for automatic resume.
def should_auto_resume(status, pause_guard):
    return status == 'RUNNING' and not pause_guard

check('Truth table RUNNING resumes', should_auto_resume('RUNNING', False))
check('Truth table PAUSED never resumes', not should_auto_resume('PAUSED', False))
check('Truth table ERROR never resumes', not should_auto_resume('ERROR', False))
check('Crash-window pause guard blocks RUNNING', not should_auto_resume('RUNNING', True))
check('Repository requires RUNNING before remote Batch recovery', 'if (state?.status != "RUNNING") return false' in repo)
check('Repository consults synchronous pause guard', 'evaluationPauseGuard?.isPaused(examDraftId) == true' in repo)
check('Pause guard uses commit, not apply', '.commit()' in pause and '.apply()' not in pause)
check('Pause DB state is written before job cancellation',
      'persistEvaluationRunState(examDraftId, requestedMode, "PAUSE_REQUESTED")' in repo and
      repo.index('persistEvaluationRunState(examDraftId, requestedMode, "PAUSE_REQUESTED")')
      < repo.index('job?.cancelAndJoin()'))

check('Existing wrapped DB material is detected before creation', 'if (hasIv || hasValue)' in passphrase)
check('Partial wrapped DB material fails closed', 'if (!hasIv || !hasValue)' in passphrase and 'DatabasePassphraseRecoveryRequiredException' in passphrase)
check('Existing Keystore alias missing fails closed', 'if (!keyStore.containsAlias(KEY_ALIAS))' in passphrase and 'Mevcut şifreli veriler korunuyor' in passphrase)
check('Existing DB recovery path cannot overwrite wrapped record', 'Mevcut veritabanı anahtar kaydının üzerine yazılamaz' in passphrase)
check('First-install key creation is separated', 'createKeyForFirstInstall' in passphrase and 'existingKeyOrThrow' in passphrase)

check('Camera process-start cleanup scrubs all leftover JPEGs', 'cleanupAfterProcessStart' in camera and 'paper_camera_' in camera and 'scrubPlaintext(leftover)' in camera)
check('Application startup invokes camera recovery', 'CameraCaptureJournal.cleanupAfterProcessStart(this)' in application)
check('Camera process-start scrub has Robolectric coverage', 'processStartupScrubsInterruptedPlaintextCaptureImmediately' in camera_test)
check('Startup fails closed if camera/report privacy cleanup fails', 'startupSafetyMessage' in application and '!reportsClean || !cameraClean' in application and 'StartupSafetyRequiredScreen' in main_activity)
check('Expired report cleanup reports deletion failure', 'fun cleanupTemporaryReports' in reports and ': Boolean' in reports and 'if (!deleted) complete = false' in reports)

check('Answer-sheet export uses SAF CreateDocument', 'CreateDocument("application/pdf")' in answer_route)
check('Rubric export uses SAF CreateDocument', 'CreateDocument("application/pdf")' in rubric_route)
check('SAF writer requires actual descriptor', 'openFileDescriptor(destination, "w")' in pdf and '?: error(' in pdf)
check('SAF writer fsyncs output', 'output.fd.sync()' in pdf)
check('SAF writer verifies copied bytes', 'copied == expected' in pdf)
check('SAF writer read-back verifies bytes', 'openInputStream(destination)' in pdf and 'verified == expected' in pdf)
check('Old raw public Downloads writes are gone', all(x not in answer_vm+rubric_vm for x in ['getExternalStoragePublicDirectory','MediaStore.Downloads','savedSuccessfully = true']))

check('Deletion summary exposes full-clean state', 'isFullyCleaned' in delete)
check('Deletion summary exposes pending notice', 'userNoticeOrNull' in delete and 'pendingRemoteBatchRecords' in delete and 'pendingRemoteCacheRecords' in delete and 'pendingLocalCleanup' in delete)
check('Delete view-model passes pending notice to UI', 'onDeleted(summary.userNoticeOrNull())' in new_vm)
check('Both delete surfaces show pending-cleanup dialog', 'Silme işlemi izleniyor' in new_screen and 'Silme işlemi izleniyor' in workflow)
check('Both delete confirmations disclose exported PDFs', 'PDF kopyaları otomatik silinmez' in new_screen and 'PDF kopyaları otomatik silinmez' in workflow)

check('Legacy .doc is rejected instead of parsed as DOCX', 'Eski .doc biçimi desteklenmiyor' in rubric_gen and 'application/msword' in rubric_gen)
check('Upload close affordance has TalkBack label', 'contentDescription = "Kapat"' in upload)
check('V20.29 version is active', 'versionCode = 30' in build and 'versionName = "1.27-v20.29"' in build)
check('V20.29 marker exists', (ROOT/'BAYKUSNOT_SOURCE_V20_29_REAL_ANDROID_BUILD_HARDENED.marker').exists())

failed=[name for name,ok in checks if not ok]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED: '+', '.join(failed))
sys.exit(1 if failed else 0)
