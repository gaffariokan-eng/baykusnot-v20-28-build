#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def t(rel): return (ROOT/rel).read_text(encoding='utf-8',errors='ignore')
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
crypto=t('app/src/main/java/com/example/core/security/StudentImageCrypto.kt')
privacy=t('app/src/main/java/com/example/core/network/ExamImagePrivacyProcessor.kt')
evalr=t('app/src/main/java/com/example/core/network/HttpGeminiExamEvaluator.kt')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
reports=t('app/src/main/java/com/example/feature/workflow/ReportsScreen.kt')
pdf=t('app/src/main/java/com/example/core/data/PdfSafWriter.kt')
app=t('app/src/main/java/com/example/EvaluatorApplication.kt')
main=t('app/src/main/java/com/example/MainActivity.kt')
build=t('app/build.gradle.kts')

# Policy oracle: full page coverage must be exact for whole-paper evaluation.
def full_coverage(expected, actual):
    return len(actual)==len(expected) and sorted(actual)==sorted(expected)
check('Oracle exact pages accepted', full_coverage([1,2,3],[1,2,3]))
check('Oracle missing middle page rejected', not full_coverage([1,2,3],[1,3]))
check('Oracle empty prepared pages rejected', not full_coverage([1],[]))
check('Oracle duplicate page cannot mask missing page', not full_coverage([1,2],[1,1]))

check('Strict image decode API exists', 'fun decodeBitmapStrict(path: String): Bitmap' in crypto)
check('Strict decode missing file is explicit integrity error', 'StudentImageIntegrityException("Öğrenci görüntü dosyası bulunamadı.' in crypto)
check('Encrypted decrypt requires existing key', 'private fun existingKeyOrThrow()' in crypto and 'cipher.init(Cipher.DECRYPT_MODE, existingKeyOrThrow()' in crypto)
check('Decrypt path never calls key creation', 'getOrCreateKeyForEncrypt' in crypto and 'DECRYPT_MODE, getOrCreate' not in crypto)
check('Encrypted corpus startup health gate exists', 'fun verifyExistingCorpusKey(context: Context)' in crypto and 'paper_uploads' in crypto)
check('Encrypted corpus blocks replacement key', 'hasExistingEncrypted' in crypto and 'new key' not in crypto.lower() or 'yeni anahtar üretilmedi' in crypto)
check('Legacy encryption reports unreadable encrypted files as failure', 'val plain = decrypt(raw)' in crypto and 'encryptExistingPlainFileInPlace' in crypto)

check('Evaluation privacy uses strict decoder', 'decodePortraitStrict' in privacy and 'StudentImageCrypto.decodeBitmapStrict' in privacy)
check('Homework requires every page', 'verifyFullPageCoverage(sortedPages.map { it.pageIndex }, prepared)' in privacy)
check('Whole-paper layout path requires every page', privacy.count('verifyFullPageCoverage(sortedPages.map { it.pageIndex }, prepared)') >= 3)
check('Declared pages are not silently mapNotNull-dropped', 'sortedPages.mapNotNull' not in privacy)
check('Missing targeted segment page fails closed', 'Hedef sorunun ${segment.pageIndex}. sayfası bulunamadı' in privacy)
check('Image prep errors share fail-closed base type', 'open class ImagePreparationException' in privacy and 'class PrivacyAlignmentException' in privacy)
check('Synchronous evaluator catches image preparation failure', 'catch (e: ImagePreparationException)' in evalr)
check('Batch builder rejects empty images', 'require(imageParts.isNotEmpty())' in evalr and 'Batch isteği oluşturulmadı' in evalr)
check('Batch repository isolates preparation failure to ERROR paper', 'Öğrenci kâğıdı güvenli Batch isteğine hazırlanamadı' in repo and 'status = "ERROR"' in repo)

check('Reports export uses shared verified SAF writer', 'PdfSafWriter.writeVerified(context, source, uri).getOrThrow()' in reports)
check('Reports export old raw stream path removed', 'openOutputStream(uri)' not in reports and 'FileInputStream(source)' not in reports)
check('Verified writer fsyncs', 'output.fd.sync()' in pdf)
check('Verified writer checks copy count', 'copied == expected' in pdf)
check('Verified writer read-back checks destination', 'openInputStream(destination)' in pdf and 'verified == expected' in pdf)

check('Startup validates student image key', 'StudentImageCrypto.verifyExistingCorpusKey(this)' in app)
check('Startup aggregates image recovery state', 'studentImageRecoveryMessage' in app and 'currentStartupBlockingMessage' in app)
check('Recovery retry is non-destructive', 'fun retryStartupChecks()' in app and 'Never deletes or re-keys user data' in app)
check('Recovery UI offers retry', 'Tekrar dene' in main and 'onRetry' in main)
check('Recovery UI offers safe diagnostic copy', 'Güvenli tanı bilgisini kopyala' in main and 'safeStartupDiagnostic' in app)
check('Diagnostic excludes secrets by contract', 'No key material, student data, paths or API secrets are included.' in app)
check('Controlled reset offered for any unrecoverable startup blocker', 'canResetLocalData = evaluatorApplication.destructiveLocalResetAllowed()' in main)
check('Reset uses Android full app-data wipe', 'clearApplicationUserData()' in main)
check('Reset has explicit irreversible warning', 'geri döndürülemez biçimde siler' in main and 'Tüm yerel verileri kalıcı olarak sil' in main)
check('V20.26 version active', 'versionCode = 27' in build and 'versionName = "1.24-v20.26"' in build)
check('V20.26 marker exists', (ROOT/'BAYKUSNOT_SOURCE_V20_26_RETRY_CANCELLATION_STAGE_LIVE_MONITOR_HARDENED.marker').exists())

failed=[n for n,o in checks if not o]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: print('FAILED: '+', '.join(failed))
sys.exit(1 if failed else 0)
