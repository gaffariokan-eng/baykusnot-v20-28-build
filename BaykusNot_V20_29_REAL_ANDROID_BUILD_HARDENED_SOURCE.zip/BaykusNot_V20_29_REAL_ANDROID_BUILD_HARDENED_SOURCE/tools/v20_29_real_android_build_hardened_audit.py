from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
build = (ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

check('Java File alias import', 'import java.io.File as JavaFile' in build)
check('Java URI alias import', 'import java.net.URI as JavaURI' in build)
check('Java KeyFactory alias import', 'import java.security.KeyFactory as JavaKeyFactory' in build)
check('Java MessageDigest alias import', 'import java.security.MessageDigest as JavaMessageDigest' in build)
check('Java Signature alias import', 'import java.security.Signature as JavaSignature' in build)
check('Java X509 alias import', 'import java.security.spec.X509EncodedKeySpec as JavaX509EncodedKeySpec' in build)
check('Java Base64 alias import', 'import java.util.Base64 as JavaBase64' in build)
check('Fingerprint uses alias File', 'sourceRoot: JavaFile, files: List<JavaFile>' in build)
check('Fingerprint uses alias digest', 'JavaMessageDigest.getInstance("SHA-256")' in build)
check('Gateway URI uses alias', 'JavaURI(gateway)' in build)
check('Approval key factory uses alias', 'JavaKeyFactory.getInstance("EC")' in build)
check('Approval X509 uses alias', 'JavaX509EncodedKeySpec(' in build)
check('Approval Base64 uses alias', 'JavaBase64.getDecoder()' in build)
check('Approval Signature uses alias', 'JavaSignature.getInstance("SHA256withECDSA")' in build)
# Qualified java references must not remain in executable Kotlin DSL code. JVM arg strings are allowed.
lines = [ln for ln in build.splitlines() if '"--add-opens=java.' not in ln and not ln.startswith('import java.')]
check('No executable qualified java.* refs remain', not any('java.io.' in ln or 'java.net.' in ln or 'java.security.' in ln or 'java.util.Base64' in ln for ln in lines))
check('compileSdk 36.1 preserved', 'compileSdk { version = release(36) { minorApiLevel = 1 } }' in build)
check('targetSdk 36 preserved', 'targetSdk = 36' in build)
check('No compileSdk 37 override', 'compileSdk = 37' not in build and 'android-37' not in build)
check('SQLCipher 4.17.0 pinned', 'net.zetetic:sqlcipher-android:4.17.0@aar' in build)
check('SQLCipher 4.18.0 removed', 'sqlcipher-android:4.18.0' not in build)
check('AndroidX SQLite aligned 2.6.2', 'androidx.sqlite:sqlite:2.6.2' in build)
check('V20.29 versionCode', 'versionCode = 30' in build)
check('V20.29 versionName', 'versionName = "1.27-v20.29"' in build)


workflow = (ROOT/'.github/workflows/build-phone-apk.yml').read_text(encoding='utf-8')
check('Cloud workflow installs only Android 36.1', 'platforms;android-36.1' in workflow and 'android-37' not in workflow)
check('Cloud workflow builds unpatched source', './gradlew --no-daemon --stacktrace clean :app:assembleDebug' in workflow and 'Patch Gradle' not in workflow)
check('Cloud workflow publishes V20.29 APK', 'BaykusNot-V20.29-TELEFONA-KUR.apk' in workflow)

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + n)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    sys.exit(1)
