import com.intellij.openapi.util.Disposer
import com.intellij.psi.util.PsiTreeUtil
import org.jetbrains.kotlin.cli.common.CLIConfigurationKeys
import org.jetbrains.kotlin.cli.common.messages.MessageCollector
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment
import org.jetbrains.kotlin.config.CompilerConfiguration
import org.jetbrains.kotlin.psi.*
import java.io.File

fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "root required" }
    val root = File(args[0])
    val files = root.walkTopDown().filter { it.isFile && it.extension == "kt" }.toList().sortedBy { it.path }
    val disposable = Disposer.newDisposable()
    try {
        val config = CompilerConfiguration()
        config.put(CLIConfigurationKeys.MESSAGE_COLLECTOR_KEY, MessageCollector.NONE)
        val env = KotlinCoreEnvironment.createForProduction(disposable, config, EnvironmentConfigFiles.JVM_CONFIG_FILES)
        val factory = KtPsiFactory(env.project, false)
        var explicitUnitFunctions = 0
        var checkedReturns = 0
        var failed = 0
        for (f in files) {
            val psi = factory.createFile(f.name, f.readText())
            val doc = psi.viewProvider.document
            for (fn in PsiTreeUtil.collectElementsOfType(psi, KtNamedFunction::class.java)) {
                val explicitUnit = fn.typeReference?.text?.trim() == "Unit"
                val implicitBlockUnit = fn.typeReference == null && fn.hasBlockBody()
                if (!explicitUnit && !implicitBlockUnit) continue
                explicitUnitFunctions++
                for (ret in PsiTreeUtil.collectElementsOfType(fn, KtReturnExpression::class.java)) {
                    // Only returns whose nearest enclosing named function is this function.
                    val nearest = generateSequence(ret.parent) { it.parent }.filterIsInstance<KtNamedFunction>().firstOrNull()
                    if (nearest !== fn) continue
                    val expr = ret.returnedExpression ?: continue
                    // Labeled local/lambda returns are not returns from this Unit function.
                    if (ret.getLabelName() != null) continue
                    checkedReturns++
                    val rel = f.relativeTo(root).path
                    val knownUnitDelegation = rel.endsWith("HomeworkPrivacyMaskStore.kt") &&
                        fn.name == "save" && expr.text == "clear(pageId)" &&
                        f.readText().contains("fun clear(pageId: Long) = prefs.edit().remove(key(pageId)).apply()")
                    val off = ret.textRange.startOffset
                    val line = doc?.getLineNumber(off)?.plus(1) ?: -1
                    if (knownUnitDelegation) {
                        println("PASS | $rel:$line | Unit-return delegation resolves to SharedPreferences.Editor.apply(): Unit")
                    } else {
                        failed++
                        println("FAIL | $rel:$line | Unit/block-body function ${fn.name} returns expression with unverified Unit type: ${expr.text.take(120)}")
                    }
                }
            }
        }
        println("SUMMARY: explicitUnitFunctions=$explicitUnitFunctions expressionReturnsChecked=$checkedReturns failures=$failed")
        if (failed > 0) kotlin.system.exitProcess(1)
    } finally {
        Disposer.dispose(disposable)
    }
}
