#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def t(rel): return (ROOT/rel).read_text(encoding='utf-8', errors='ignore')
def exists(rel): return (ROOT/rel).exists()
checks=[]
def ck(name, ok):
    ok=bool(ok); checks.append((name,ok)); print(('PASS' if ok else 'FAIL')+' | '+name)

build=t('app/build.gradle.kts')
rubric_vm=t('app/src/main/java/com/example/feature/workflow/RubricViewModel.kt')
upload_vm=t('app/src/main/java/com/example/feature/workflow/UploadSourceViewModel.kt')
qp_vm=t('app/src/main/java/com/example/feature/workflow/QuestionPointsViewModel.kt')
reports_vm=t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
dao=t('app/src/main/java/com/example/core/database/ExamEvaluationDao.kt')
optical=t('app/src/main/java/com/example/core/data/TestOpticalFormReader.kt')
answer=t('app/src/main/java/com/example/feature/testexam/TestAnswerKeyScreen.kt')
qcoord=t('app/src/main/java/com/example/core/data/ExamQuestionExtractionCoordinator.kt')
rcoord=t('app/src/main/java/com/example/core/data/ExamRubricGenerationCoordinator.kt')
container=t('app/src/main/java/com/example/core/data/AppContainer.kt')
upload_route=t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt')
qp_route=t('app/src/main/java/com/example/feature/workflow/QuestionPointsRoute.kt')
rubric_route=t('app/src/main/java/com/example/feature/workflow/RubricRoute.kt')
reports_screen=t('app/src/main/java/com/example/feature/workflow/ReportsScreen.kt')
helper=t('app/src/main/java/com/example/core/network/OkHttpCoroutine.kt')
network_files=list((ROOT/'app/src/main/java/com/example/core/network').glob('*.kt'))
network='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in network_files)

# Compile/type-risk fix
proc=rubric_vm[rubric_vm.find('fun processUploadedDocument'):rubric_vm.find('fun removeUploadedDocument') if 'fun removeUploadedDocument' in rubric_vm else rubric_vm.find('fun matchWithQuestions')]
ck('Legacy .doc branch returns Unit only', 'if (isLegacyDoc)' in proc and 'return Result.failure' not in proc and 'publishState()\n            return' in proc)
ck('No direct OkHttp execute remains in app main', not any('.execute()' in p.read_text(encoding='utf-8', errors='ignore') for p in (ROOT/'app/src/main/java').rglob('*.kt')))
ck('Coroutine OkHttp helper cancels underlying call', 'suspendCancellableCoroutine' in helper and 'invokeOnCancellation { call.cancel() }' in helper)
ck('Coroutine OkHttp helper closes late response', 'response.close()' in helper)

for rel,label in [
 ('app/src/main/java/com/example/core/network/HttpGeminiQuestionObjectiveMatcher.kt','Objective matcher'),
 ('app/src/main/java/com/example/core/network/HttpGeminiExamScenarioExtractor.kt','Scenario extractor'),
 ('app/src/main/java/com/example/core/network/HttpGeminiExamQuestionExtractor.kt','Question extractor'),
 ('app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt','Feedback writer'),
 ('app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt','Rubric generator'),
 ('app/src/main/java/com/example/core/network/HttpGeminiConnectionTester.kt','Connection tester')]:
    s=t(rel)
    ck(f'{label} uses cancellable HTTP', 'executeCancellable(' in s and '.execute()' not in s)

conn=t('app/src/main/java/com/example/core/network/HttpGeminiConnectionTester.kt')
ck('Connection tester propagates cancellation', 'CancellationException' in conn and re.search(r'catch\s*\([^)]*CancellationException[^)]*\)\s*\{\s*throw', conn, re.S))
rubnet=t('app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt')
ck('Rubric generator propagates cancellation across nested calls', rubnet.count('CancellationException') >= 5 and rubnet.count('executeCancellable(') >= 3)
batch_manager=t('app/src/main/java/com/example/core/network/GeminiBatchJobManager.kt')
for fn in ('remoteCancel','remoteGetBatchSnapshot','remoteDeleteBatch','remoteDeleteFileConfirmed'):
    start=batch_manager.find(f'private suspend fun {fn}')
    end=batch_manager.find('private ', start+20)
    if end < 0: end=len(batch_manager)
    bseg=batch_manager[start:end]
    ck(f'Batch {fn} propagates cancellation', start >= 0 and 'catch (e: CancellationException)' in bseg and 'throw e' in bseg and 'runCatching {' not in bseg)
list_start=batch_manager.find('suspend fun listRemoteOperations')
list_end=batch_manager.find('suspend fun submitBatchJob', list_start)
list_seg=batch_manager[list_start:list_end]
ck('Batch remote operation listing propagates cancellation', 'catch (e: CancellationException)' in list_seg and 'throw e' in list_seg)
cache_manager=t('app/src/main/java/com/example/core/network/GeminiCacheManager.kt')
ck('Batch audit ledger uses bounded reads', 'BoundedInputReader.read(input, maxLedgerBytes, "Batch gizlilik/audit kaydı")' in batch_manager and 'maxLedgerBytes = 16L * 1024L * 1024L' in batch_manager)
ck('Batch audit ledger bounds serialized writes', 'encoded.toByteArray(Charsets.UTF_8).size.toLong() <= maxLedgerBytes' in batch_manager)
ck('Prompt-cache ledger uses bounded reads', 'BoundedInputReader.read(input, maxLedgerBytes, "Prompt-cache audit kaydı")' in cache_manager and 'maxLedgerBytes = 8L * 1024L * 1024L' in cache_manager)
ck('Prompt-cache ledger bounds serialized writes', 'encoded.toByteArray(Charsets.UTF_8).size.toLong() <= maxLedgerBytes' in cache_manager)

# Final feedback stale-write and lifecycle
ck('Final feedback stage query exists', 'getWorkflowStageForFinalFeedback' in dao and 'currentWorkflowStage' in dao)
seg=dao[dao.find('suspend fun saveFinalFeedbackIfSnapshotMatches'):dao.find('suspend fun saveFinalFeedbackTransaction')]
ck('Final feedback guarded by Room transaction', '@androidx.room.Transaction' in dao[max(0,dao.find('suspend fun saveFinalFeedbackIfSnapshotMatches')-80):dao.find('suspend fun saveFinalFeedbackIfSnapshotMatches')])
ck('Final feedback requires REPORTS stage', '!= "REPORTS"' in seg)
ck('Final feedback requires current teacher approval', 'currentStudent.isTeacherApproved' in seg)
ck('Final feedback rejects already-generated row', 'feedbackGeneratedAt != null' in seg)
ck('Final feedback compares complete student snapshot', 'currentStudent != expectedStudent' in seg)
ck('Final feedback compares complete question snapshot', 'currentQuestions != expectedQuestions' in seg)
ck('Final feedback keyset must match all questions', 'questionFeedback.keys != expectedQuestions.map { it.id }.toSet()' in seg)
ck('Repository uses guarded feedback commit', 'saveFinalFeedbackIfSnapshotMatches(' in repo and 'if (!committed)' in repo)
feedback_seg=repo[repo.find('suspend fun generateMissingFinalFeedback'):repo.find('suspend fun validateAndConfirmAllResults')]
ck('Feedback rejects non-REPORTS before provider work', 'feedbackDraft?.currentWorkflowStage != WorkflowStage.REPORTS' in feedback_seg)
ck('Feedback rechecks REPORTS for each student', 'draftDao.getDraftByIdOnce(examDraftId)?.currentWorkflowStage != WorkflowStage.REPORTS' in feedback_seg)
ck('Feedback checks coroutine cancellation per student', 'currentCoroutineContext().ensureActive()' in feedback_seg)
ck('Feedback cancellation is not counted as ordinary failure', 'catch (cancellation: CancellationException)' in feedback_seg and 'throw cancellation' in feedback_seg)
ck('Reports tracks feedback generation Job', 'private var feedbackGenerationJob: Job?' in reports_vm)
ck('Reports stage observer cancels feedback Job', 'currentWorkflowStage != com.example.core.model.WorkflowStage.REPORTS' in reports_vm and 'cancelActiveFeedbackGeneration()' in reports_vm)
ck('Reports retry de-duplicates active Job', 'feedbackGenerationJob?.isActive == true' in reports_vm)
ck('Reports screen cancels feedback on dispose', 'DisposableEffect(viewModel)' in reports_screen and 'cancelActiveFeedbackGeneration()' in reports_screen)

# Bounded import / bitmap streaming
ck('Answer-key text import uses bounded reader', 'BoundedInputReader.read(' in answer and '1_000_000L' in answer)
ck('Answer-key text import no readText take pattern', 'readText().take' not in answer and '.readText()' not in answer)
teacher_seg=optical[optical.find('fun readTeacherAnswerKey'):optical.find('private fun readBitmapPage')]
ck('Teacher PDF first pass validates page count only', 'First validate only page counts' in teacher_seg and 'totalPages' in teacher_seg)
ck('Teacher PDF requires exact expected page count', 'totalPages != layouts.size' in teacher_seg)
ck('Teacher PDF has no retained bitmap list', 'mutableListOf<Bitmap>' not in teacher_seg and 'bitmaps' not in teacher_seg)
ck('Teacher PDF renders pages one at a time', 'for (pageIndex in 0 until renderer.pageCount)' in teacher_seg and 'Bitmap.createBitmap' in teacher_seg)
ck('Teacher PDF recycles each rendered bitmap', 'if (!bitmap.isRecycled) bitmap.recycle()' in teacher_seg)
ck('Teacher image input recycles decoded bitmap', teacher_seg.count('if (!bitmap.isRecycled) bitmap.recycle()') >= 2)
ck('Teacher PDF validates page dimensions', 'page.width <= 0 || page.height <= 0' in teacher_seg)
ck('Teacher PDF bounds aspect ratio', 'aspect !in 0.5..2.0' in teacher_seg)
ck('Teacher PDF bounds render height', 'coerceIn(CANONICAL_HEIGHT / 2, CANONICAL_HEIGHT * 2)' in teacher_seg)

# Authoring stage boundaries and active cancellation
ck('Question extraction coordinator has stage validator', 'stageValidator: suspend (Long) -> Boolean' in qcoord)
ck('Question extraction checks stage before and after AI', qcoord.count('stageValidator(examDraftId)') >= 4)
ck('Rubric coordinator has stage validator', 'stageValidator: suspend (Long) -> Boolean' in rcoord)
ck('Rubric coordinator checks stage before/after generation and persistence', rcoord.count('stageValidator(examDraftId)') >= 3)
ck('AppContainer wires UPLOAD_SOURCE stage validator', 'WorkflowStage.UPLOAD_SOURCE' in container and 'stageValidator = { id ->' in container)
ck('AppContainer wires RUBRIC stage validator', 'WorkflowStage.RUBRIC' in container and container.count('stageValidator = { id ->') >= 2)

ck('UploadSource tracks question/scenario Jobs', 'questionExtractionJob: Job?' in upload_vm and 'scenarioExtractionJob: Job?' in upload_vm)
ck('UploadSource cancels authoring on stage exit', 'currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE' in upload_vm and 'cancelActiveAuthoringWork()' in upload_vm)
ck('UploadSource scenario rechecks stage after provider', upload_vm.count('currentWorkflowStage != WorkflowStage.UPLOAD_SOURCE') >= 2)
ck('UploadSource route cancels jobs on dispose', 'DisposableEffect(viewModel)' in upload_route and 'cancelActiveAuthoringWork()' in upload_route)

ck('QuestionPoints tracks objective suggestion Job', 'objectiveSuggestionJob: Job?' in qp_vm)
ck('QuestionPoints cancels suggestion on stage exit', 'currentWorkflowStage != WorkflowStage.QUESTION_POINTS' in qp_vm and 'cancelActiveAuthoringWork()' in qp_vm)
ck('QuestionPoints rechecks stage after provider', qp_vm.count('currentWorkflowStage != WorkflowStage.QUESTION_POINTS') >= 2)
ck('QuestionPoints guards draft mutation at write point', 'draft?.currentWorkflowStage == WorkflowStage.QUESTION_POINTS' in qp_vm)
ck('QuestionPoints route cancels job on dispose', 'DisposableEffect(viewModel)' in qp_route and 'cancelActiveAuthoringWork()' in qp_route)

ck('Rubric tracks generation/document/matching Jobs', all(x in rubric_vm for x in ('rubricGenerationJob: Job?','documentProcessingJob: Job?','matchingJob: Job?')))
ck('Rubric cancels authoring on stage exit', 'currentWorkflowStage != WorkflowStage.RUBRIC' in rubric_vm and 'cancelActiveAuthoringWork()' in rubric_vm)
ck('Rubric provider paths recheck stage', rubric_vm.count('currentWorkflowStage != WorkflowStage.RUBRIC') >= 3)
ck('Rubric route cancels jobs on dispose', 'DisposableEffect(viewModel)' in rubric_route and 'cancelActiveAuthoringWork()' in rubric_route)

# Version/governance identity
ck('V20.29 app version active', 'versionCode = 30' in build and 'versionName = "1.27-v20.29"' in build)
ck('V20.29 engine fingerprints active', all(x in build for x in ('BN-EVAL-ENGINE-V20.29','BN-FEEDBACK-ENGINE-V20.29','BN-AUTHOR-ENGINE-V20.29')))
ck('V20.29 marker exists', exists('BAYKUSNOT_SOURCE_V20_29_REAL_ANDROID_BUILD_HARDENED.marker'))
ck('V20.29 local build script exists', exists('BAYKUSNOT_BUILD_V20_29_LOCAL_TEST_ONLY.bat'))
ck('V20.29 release build script exists', exists('BAYKUSNOT_BUILD_V20_29_RELEASE_APK.bat'))

print(f'\nSUMMARY: {sum(ok for _,ok in checks)}/{len(checks)} PASS')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
