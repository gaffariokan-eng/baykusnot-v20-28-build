#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8', errors='ignore')
store=t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
gate=t('app/src/main/java/com/example/core/security/StudentAiComplianceGate.kt')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
vm=t('app/src/main/java/com/example/feature/workflow/AiEvaluationViewModel.kt')
screen=t('app/src/main/java/com/example/feature/workflow/AiEvaluationScreen.kt')
tests=t('app/src/test/java/com/example/core/security/YazekComplianceStoreTest.kt')
checks={
 'policy_v5_invalidates_older_ack':'CURRENT_POLICY_VERSION = 5' in store,
 'store_requires_official_yazek_applied':'officialDeclarationApplied' in store and 'decl_${fingerprint}_official_applied' in store,
 'store_requires_notice_and_consent':'noticeAndConsentCompleted' in store and 'decl_${fingerprint}_notice_consent' in store,
 'is_acknowledged_requires_both':'.getBoolean("decl_${fingerprint}_official_applied", false)' in store and '.getBoolean("decl_${fingerprint}_notice_consent", false)' in store,
 'clear_removes_confirmation_evidence':'decl_${fingerprint}_notice_consent_at' in store and '.remove("decl_${fingerprint}_official_applied")' in store,
 'student_parent_notice_mentions_required_consent':'açık rıza/aydınlatılmış onam' in store,
 'central_gate_propagates_both':'officialDeclarationApplied = officialDeclarationApplied' in gate and 'noticeAndConsentCompleted = noticeAndConsentCompleted' in gate,
 'repository_propagates_both':'officialDeclarationApplied: Boolean' in repo and 'noticeAndConsentCompleted: Boolean' in repo,
 'per_exam_audit_records_combined_confirmation':'Resmî YAZEK beyanının uygulamaya alındığı' in repo and 'açık rıza-aydınlatılmış onam' in repo,
 'viewmodel_propagates_both':'officialDeclarationApplied = officialDeclarationApplied' in vm and 'noticeAndConsentCompleted = noticeAndConsentCompleted' in vm,
 'ui_has_two_separate_confirmations':'officialYazekApplied' in screen and 'noticeAndConsentCompleted' in screen,
 'ui_cannot_confirm_until_both':'enabled = officialYazekApplied && noticeAndConsentCompleted' in screen,
 'ui_names_official_applied_state':'gereken tüm resmî YAZEK Etik Beyan Formlarını tamamladım' in screen and 'Uygulamaya Al/Uygula adımı tamamlandı' in screen,
 'ui_names_data_notice_consent':'gerekli açık rıza/aydınlatılmış onam sürecini tamamladım' in screen,
 'official_record_not_replaced':'Bu kayıt resmî YAZEK beyanının yerine geçmez' in screen,
 'robolectric_dual_confirmation_tests_exist':'acknowledgementRejectsMissingOfficialYazekApplyConfirmation' in tests and 'acknowledgementRejectsMissingNoticeConsentConfirmation' in tests,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} | {k}")
print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed: raise SystemExit(1)
