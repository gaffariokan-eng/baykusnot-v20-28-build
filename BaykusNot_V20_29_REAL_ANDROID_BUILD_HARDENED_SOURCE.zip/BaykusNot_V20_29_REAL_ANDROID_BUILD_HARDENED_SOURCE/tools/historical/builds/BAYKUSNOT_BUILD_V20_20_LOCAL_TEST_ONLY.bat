@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title BaykusNot V20.20 LOCAL TEST ONLY Build

echo ============================================================
echo   BAYKUSNOT V20.20 - LOCAL TEST ONLY / DEBUG APK
echo ============================================================
echo UYARI: Bu paket SADECE derleme, acilis ve sentetik/demo veri testi icindir.
echo GERCEK OGRENCI VERISI ILE KULLANMAYIN.
echo Production/YAZEK kullanimi icin RELEASE + kurumsal HTTPS gateway gerekir.
echo ============================================================
if not exist "BAYKUSNOT_SOURCE_V20_20_HARDENED.marker" goto :badsource
where java >nul 2>nul || goto :nojava
set "JAVA_VERSION="
for /f "tokens=3" %%v in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /C:"java.version ="') do if not defined JAVA_VERSION set "JAVA_VERSION=%%v"
if not defined JAVA_VERSION goto :nojava
for /f "tokens=1 delims=." %%m in ("%JAVA_VERSION%") do set "JAVA_MAJOR=%%m"
set /a JAVA_MAJOR_NUM=%JAVA_MAJOR% >nul 2>nul
if %JAVA_MAJOR_NUM% LSS 17 goto :oldjava

set "SRC=%CD%"
set "SAFE=%LOCALAPPDATA%\BaykusNotBuildV20_20_LOCAL_TEST\BaykusNot"
set "OUTAPK=%SRC%\BaykusNot-V20_20-LOCAL-TEST-ONLY.apk"
set "SDK=%LOCALAPPDATA%\Android\Sdk"
if defined ANDROID_SDK_ROOT set "SDK=%ANDROID_SDK_ROOT%"
if defined ANDROID_HOME set "SDK=%ANDROID_HOME%"
set "ANDROID_SDK_ROOT=%SDK%"
set "ANDROID_HOME=%SDK%"

if not exist "%SAFE%" mkdir "%SAFE%" >nul 2>nul
robocopy "%SRC%" "%SAFE%" /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XD ".gradle" "build" "app\build" /XF "local.properties" "BaykusNot-*.apk" "BaykusNot-*.sha256.txt" >nul
if !ERRORLEVEL! GTR 7 goto :copyfail
cd /d "%SAFE%"
set "SDKFWD=%SDK:\=/%"
>local.properties echo sdk.dir=%SDKFWD%

call gradlew.bat --no-daemon --no-configuration-cache --console=plain --stacktrace :app:assembleDebug
if errorlevel 1 goto :buildfail
if not exist "app\build\outputs\apk\debug\app-debug.apk" goto :buildfail
copy /y "app\build\outputs\apk\debug\app-debug.apk" "%OUTAPK%" >nul
certutil -hashfile "%OUTAPK%" SHA256 > "%OUTAPK%.sha256.txt" 2>nul
echo.
echo SUCCESS: %OUTAPK%
echo UYARI: GERCEK OGRENCI VERISI KULLANMAYIN. BU DEBUG TEST APK'SIDIR.
goto :finish

:badsource
echo HATA: V20.20 kaynak marker bulunamadi.
goto :failed
:nojava
echo HATA: Java bulunamadi. JDK 17 veya daha yeni surum kurulu olmali.
goto :failed
:oldjava
echo HATA: Java %JAVA_VERSION% bulundu. JDK 17 veya daha yeni surum gerekir.
goto :failed
:copyfail
echo HATA: Kaynak guvenli build klasorune kopyalanamadi.
goto :failed
:buildfail
echo HATA: assembleDebug basarisiz. Ekrandaki Gradle hata metnini ChatGPT'ye gonderin.
goto :failed
:failed
echo DERLEME TAMAMLANAMADI.
:finish
pause
endlocal
