#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
def text(p): return (ROOT/p).read_text(encoding='utf-8',errors='ignore')
def ordered(s,*parts):
    pos=-1
    for part in parts:
        pos=s.find(part,pos+1)
        if pos<0: return False
    return True
repo=text('app/src/main/java/com/example/core/data/ExamDeletionRepository.kt')
journal=text('app/src/main/java/com/example/core/data/ExamDeletionJournal.kt')
container=text('app/src/main/java/com/example/core/data/AppContainer.kt')
test=text('app/src/test/java/com/example/core/data/ExamDeletionJournalTest.kt')
checks={
 'journal_uses_atomic_file': all(x in journal for x in ['AtomicFile','startWrite()','finishWrite','failWrite']),
 'journal_has_prepared_and_committed_stages': 'PREPARED' in journal and 'COMMITTED' in journal,
 'remote_tracking_precedes_delete_intent': ordered(repo,'credentialCleanup','deletionJournal.prepare(examDraftId, pageIds)'),
 'intent_precedes_room_root_delete': ordered(repo,'deletionJournal.prepare(examDraftId, pageIds)','draftRepository.deleteDraftById(examDraftId)'),
 'room_delete_is_verified': 'DB_DELETE_NOT_COMMITTED' in repo and 'getDraftByIdOnce(examDraftId) == null' in repo,
 'room_commit_precedes_local_cleanup': ordered(repo,'deletionJournal.markCommitted(examDraftId)','cleanupCommittedDeletion(examDraftId, pageIds)'),
 'privacy_masks_only_removed_post_commit': 'clearDurably(pageId)' in repo and repo.find('clearDurably(pageId)') > repo.find('private fun cleanupCommittedDeletion'),
 'report_cache_only_removed_post_commit': 'BaykusNot_Exam_${examId}_' in repo and repo.find('BaykusNot_Exam_${examId}_') > repo.find('private fun cleanupCommittedDeletion'),
 'local_failure_keeps_journal': 'pendingLocalCleanup = !local.complete' in repo and 'if (complete && !deletionJournal.clear(examId))' in repo,
 'startup_retries_prepared_intent': 'retryPendingLocalDeletion' in repo and 'intent.stage == ExamDeletionStage.PREPARED' in repo,
 'startup_recovers_missing_db_commit_marker': 'getDraftByIdOnce(intent.examId) != null' in repo and 'deletionJournal.markCommitted(intent.examId)' in repo,
 'app_startup_invokes_local_recovery': 'examDeletionRepository.retryPendingLocalDeletion()' in container,
 'journal_captures_page_ids_before_cascade': 'paperUploadDao.getPagesForExamOnce(examDraftId).map { it.id }' in repo and 'deletionJournal.prepare(examDraftId, pageIds)' in repo,
 'journal_has_robolectric_coverage': 'preparedIntentSurvivesReadAndCanCommit' in test,
 'v20_22_version': 'versionCode = 23' in text('app/build.gradle.kts') and '1.20-v20.22' in text('app/build.gradle.kts'),
}
failed=[]
for name,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' | '+name)
    if not ok: failed.append(name)
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
