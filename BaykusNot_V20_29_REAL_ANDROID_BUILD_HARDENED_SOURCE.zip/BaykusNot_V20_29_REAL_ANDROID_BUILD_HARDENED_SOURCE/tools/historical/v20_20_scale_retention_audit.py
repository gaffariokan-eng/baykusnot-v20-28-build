from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8')
def ck(name, ok):
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
    return bool(ok)
checks=[]
crypto=t('app/src/main/java/com/example/core/security/StudentImageCrypto.kt')
safe=t('app/src/main/java/com/example/core/security/SafeBitmapDecoder.kt')
upload_ui=t('app/src/main/java/com/example/feature/workflow/UploadPapersScreen.kt')
report_vm=t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
report_ui=t('app/src/main/java/com/example/feature/workflow/ReportsScreen.kt')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
papers=t('app/src/main/java/com/example/core/data/ExamPaperUploadRepository.kt')
app=t('app/src/main/java/com/example/EvaluatorApplication.kt')
yazek=t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
review=t('app/src/main/java/com/example/feature/workflow/TeacherReviewViewModel.kt')
draft=t('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt')
prefs=t('app/src/main/java/com/example/core/model/EvaluationPreferences.kt')
checks += [
 ck('thumbnail decoder <=400k pixels', 'maxDecodePixels = 400_000L' in crypto and 'maxDecodePixels' in safe),
 ck('thumbnail UI uses small decoder', 'StudentImageCrypto.decodeThumbnail' in upload_ui),
 ck('unmatched page thumbnails lazy', 'LazyRow' in upload_ui and 'unmatchedPages.forEach' not in upload_ui),
 ck('no report-entry auto feedback', 'autoPrepareFeedback' not in report_vm),
 ck('feedback default BRIEF', 'FeedbackDetailLevel.BRIEF' in prefs),
 ck('feedback worker max 25', 'require(maxItems in 1..25)' in repo and '.take(maxItems)' in repo),
 ck('feedback UI explicit chunk action', 'Sonraki Dönüt Grubunu Hazırla (en fazla 25)' in report_ui),
 ck('PDF compressed byte cap', '200L * 1024L * 1024L' in papers),
 ck('PDF dynamic page cap', 'expectedTotalPages * 2' in papers and 'coerceAtMost(2000)' in papers),
 ck('startup report retention cleanup', 'ReportsPdfGenerator.cleanupTemporaryReports(this)' in app),
 ck('retention disclosure truthful', 'uygulama açılışında ve rapor işlemlerinde 24 saati aşan' in yazek),
 ck('review loads qevals in bulk', 'getQuestionEvaluationsForExamOnce(examDraftId)' in review),
 ck('review loads pages in bulk', 'getPagesForExamOnce(examDraftId)' in review),
 ck('review loads appeals in bulk', 'getReviewRequestsForExam(examDraftId)' in review),
 ck('per-student N+1 calls removed', 'getQuestionEvaluationsForPaperOnce(paper.id)' not in review and 'getPagesForPaperOnce(paper.id)' not in review and 'getReviewRequestsForPaper(paper.id)' not in review),
 ck('draft requires teacher', 'if (teachers.isEmpty())' in draft and 'En az bir öğretmen seçin' in draft),
]
passed=sum(checks)
print(f"SUMMARY: {passed}/{len(checks)} PASS")
sys.exit(0 if passed==len(checks) else 1)
