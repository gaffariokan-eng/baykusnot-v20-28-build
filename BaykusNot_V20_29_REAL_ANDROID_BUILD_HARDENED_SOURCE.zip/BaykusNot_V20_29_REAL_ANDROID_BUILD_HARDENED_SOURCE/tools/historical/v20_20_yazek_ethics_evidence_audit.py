#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]

def t(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8', errors='ignore')

content = t('app/src/main/java/com/example/core/network/YazekContentPolicy.kt')
repo = t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
review_vm = t('app/src/main/java/com/example/feature/workflow/TeacherReviewViewModel.kt')
reports = t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
dao = t('app/src/main/java/com/example/core/database/ExamEvaluationDao.kt')
review_entity = t('app/src/main/java/com/example/core/database/ExamReviewRequestEntity.kt')
feedback = t('app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt')
evaluator = t('app/src/main/java/com/example/core/network/HttpGeminiExamEvaluator.kt')
provider = t('app/src/main/java/com/example/core/security/ProviderDataProtectionProfile.kt')
gate = t('app/src/main/java/com/example/core/security/StudentAiComplianceGate.kt')
yazek = t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
crypto = t('app/src/main/java/com/example/core/security/StudentImageCrypto.kt')
dbcrypto = t('app/src/main/java/com/example/core/database/DatabaseEncryptionManager.kt')
gateway = t('docs/SECURE_AI_GATEWAY_REQUIREMENTS.md')
access = t('docs/ACCESSIBILITY_ACCEPTANCE_TEST.md')
benchmark = t('tools/model_benchmark/README.md')
screen = t('app/src/main/java/com/example/feature/workflow/AiEvaluationScreen.kt')

checks = {
    # 1 — Human-centred / rights
    'human-centred: AI score is not final authority': 'nihai akademik karar' in reports and 'öğretmene aittir' in reports,
    'human-centred: teacher can materially change scores atomically': 'applyTeacherScoreChangeTransaction' in dao and 'isTeacherModified = true' in dao,
    'human-centred: changed teacher score invalidates old AI diagnosis': 'clearAiDiagnosticsForQuestion' in dao,
    'human-centred: final feedback only follows teacher approval': 'Generated only after final teacher approval' in t('app/src/main/java/com/example/core/database/ExamStudentEvaluationEntity.kt') and 'isTeacherApproved' in repo,

    # 2 — Equality / inclusivity
    'equality: protected-attribute inference forbidden': all(x in content for x in ['kimlik, cinsiyet, inanç', 'etnik/kültürel köken', 'engellilik', 'sosyoekonomik durum hakkında çıkarım yapma']),
    'equality: identity-based discriminatory feedback locally rejected': 'identityBasedAttacks' in content and 'kimlik-temelli ayrımcılık kontrolünden geçmedi' in content,
    'equality: grade is used for language calibration not new scoring criteria': 'kilitli rubrik dışında yeni puan koşulu ekleme' in evaluator,
    'equality: real-device accessibility gate is explicitly required': 'TalkBack' in access and '%200' in access and 'PASS` olmadan erişilebilirlik üretim doğrulaması tamamlanmış sayılmaz' in access,

    # 3 — Transparency / explainability
    'transparency: teacher sees AI hallucination warning': 'hata/halüsinasyon' in screen,
    'transparency: report distinguishes AI-supported and local/manual scoring': 'yerel optik okuması' in reports and 'aktif değerlendirme modu MANUEL' in reports and 'yapay zekâ destekli değerlendirme akışı' in reports,
    'transparency: student-parent notice includes purpose/provider/retention/access': all(x in yazek for x in ['Amaç:', 'providerPolicySummary', 'Saklama:', 'Haklar: erişim']),
    'transparency: report identifies teacher as final academic authority': 'nihai akademik karar ve e-Okul kaydı öğretmene aittir' in reports,

    # 4 — Privacy / data governance
    'privacy: central AI gate fails closed on provider policy and YAZEK scope': 'ProviderDataProtectionProfile.current().requireReady()' in gate and 'check(store.isAcknowledged(scope))' in gate,
    'privacy: provider retention is constrained': 'ALLOWED_RETENTION_DAYS = setOf(0, 7, 14, 28, 55)' in provider,
    'privacy: provider dataset/model sharing must be disabled': 'if (!datasetSharingDisabled)' in provider,
    'privacy: provider access roles must be declared': 'if (accessRoles.isBlank())' in provider,
    'privacy: student images use authenticated encryption': 'AES/GCM/NoPadding' in crypto and 'AndroidKeyStore' in crypto,
    'privacy: Room plaintext-to-SQLCipher migration uses sqlcipher_export': "sqlcipher_export('encrypted')" in dbcrypto,
    'privacy: production gateway forbids student payload logging': 'Öğrenci payload\'ı gateway/APM/error-log body capture\'a yazılmamalıdır' in gateway,
    'privacy: production client does not silently fall back to embedded Gemini secret': 'cihaz anahtarına sessiz fallback yapılmaz' in gateway,

    # 5 — Reliability / security
    'reliability: low confidence produces teacher review instead of silent acceptance': 'needsReview = true' in evaluator and 'öğretmen kontrolü gerekiyor' in evaluator,
    'reliability: provider safety response is checked for feedback': 'validateProviderSafety' in feedback and 'safetyRatings' in feedback,
    'reliability: manual no-AI B-plan exists': 'prepareManualTeacherReview' in repo and 'MANUAL' in repo,
    'reliability: gateway contract requires revocable short-lived session': 'revocable' in gateway and 'expiresInSeconds' in gateway and 'Access token yalnız RAM\'de tutulur' in gateway,
    'reliability: production model benchmark requires real anonymized evidence': 'REAL_ANONYMIZED' in benchmark and '20' in benchmark,

    # 6 — Accountability / human oversight / appeal
    'accountability: student-parent re-review request is persisted': 'exam_review_request' in review_entity and 'status: String = "OPEN"' in review_entity,
    'accountability: teacher can record and resolve re-review requests': 'recordStudentParentReviewRequest' in review_vm and 'resolveStudentParentReviewRequest' in review_vm,
    'accountability: open review status participates in final integrity path': 'getReviewRequestsForExam(examDraftId)' in review_vm and 'getReviewRequestsForExam' in dao,
    'accountability: final score corrections invalidate approval and generated feedback': 'invalidateStudentApprovalAndFeedback' in dao and 'clearQuestionFeedbackForStudent' in dao,

    # 7 — Educational value / purpose limitation
    'educational value: YAZEK scope binds approved objectives or locked question scope': 'approvedObjectives' in repo and 'learningOutcomeSignature' in repo and 'kilitli soru kapsamı bulunamadı' in repo,
    'educational value: app declares measurement/evaluation/feedback scope': 'Ölçme, Değerlendirme ve Geri Bildirim' in repo,
    'educational value: rubric is locked before AI scoring': 'Rubrik seti kilitli değil' in repo and 'Kilitli rubrik kriterleri bulunamadı' in repo,
    'educational value: feedback writer cannot regenerate final teacher score': 'finalTeacherScore öğretmenin onayladığı tartışılmaz nihai puandır' in feedback and 'ASLA değiştirme veya yeni puan önerme' in feedback,

    # 8 — National / moral / cultural alignment
    'values: prompt binds Turkish national education principles': 'Türk Millî Eğitiminin genel amaçları ve temel ilkeleriyle' in content,
    'values: prompt forbids degrading national/moral/cultural values': 'millî/manevi/kültürel değerlere karşı küçümseyici' in content,
    'values: hateful/violent/ideological steering is forbidden': 'nefret/şiddet teşvik eden' in content and 'ideolojik/siyasi bir görüşe' in content,
    'values: student-facing feedback runs local YAZEK validation': 'YazekContentPolicy.validateStudentFacingFeedback' in feedback,
}

failed = []
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
    if not ok:
        failed.append(name)

print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print('FAILED: ' + ', '.join(failed))
sys.exit(1 if failed else 0)
