#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
def t(p):
    return (ROOT / p).read_text(encoding='utf-8', errors='ignore')

store = t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
gate = t('app/src/main/java/com/example/core/security/StudentAiComplianceGate.kt')
repo = t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
vm = t('app/src/main/java/com/example/feature/workflow/AiEvaluationViewModel.kt')
screen = t('app/src/main/java/com/example/feature/workflow/AiEvaluationScreen.kt')
reports = t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
settings_vm = t('app/src/main/java/com/example/feature/settings/ApiKeySettingsViewModel.kt')
settings_screen = t('app/src/main/java/com/example/feature/settings/ApiKeySettingsScreen.kt')
scope_test = t('app/src/test/java/com/example/core/security/YazekDeclarationScopeTest.kt')
store_test = t('app/src/test/java/com/example/core/security/YazekComplianceStoreTest.kt')
build = t('app/build.gradle.kts')
release_bat = t('BAYKUSNOT_BUILD_V20_18_RELEASE_APK.bat')

checks = {
    'V20.18 app version': 'versionCode = 19' in build and '1.16-v20.18' in build,
    'V20.18 source marker': (ROOT / 'BAYKUSNOT_SOURCE_V20_18_YAZEK_FORM_ALIGNED.marker').exists(),
    'policy v5 invalidates prior local acknowledgements': 'CURRENT_POLICY_VERSION = 5' in store and 'decl_${fingerprint}_policy' in store,
    'official application name modeled': 'val applicationName: String' in store and 'applicationName = applicationName' in repo,
    'official application scope modeled': 'val applicationScopeLabels: Set<String>' in store and 'applicationScopeLabels = setOf("Ölçme, Değerlendirme ve Geri Bildirim")' in repo,
    'official short summary modeled': 'val applicationSummary: String' in store and 'applicationSummary = applicationSummary' in repo,
    'official summary length constrained 10-500': 'applicationSummary.length !in 10..500' in store and 'YAZEK kısa özet (10-500 karakter)' in store,
    'actual YAZEK AI tool is Google Gemini': 'val aiTool: String = "Google Gemini"' in store and 'BaykuşNot / Google Gemini API' not in repo,
    'form aid includes application name': 'Uygulama adı:' in store,
    'form aid includes class branch course': 'Sınıf / Şube / Ders:' in store,
    'form aid includes official scope': 'Uygulamanın kapsamı:' in store,
    'form aid includes short summary': 'Kısa özet:' in store,
    'form aid includes actual AI tool': 'Kullanılacak YZ aracı:' in store,
    'technical scope hash hidden from form aid': 'Öğrenme çıktısı/kapsam imzası:' not in store and 'officialFormAidDoesNotExposeTechnicalScopeHash' in scope_test,
    'provider signature hidden from teacher form aid': 'test-provider-policy' not in store and 'assertFalse(text.contains("test-provider-policy"))' in scope_test,
    'official form aid can be copied': 'YAZEK Beyan Bilgilerini Kopyala' in screen and 'state.yazekScopeSummary' in screen,
    'settings technical note is not mislabeled as YAZEK declaration summary': 'YAZEK Beyan Özetini Kopyala' not in settings_screen and 'AI Dağıtım / Şeffaflık Notunu Kopyala' in settings_screen,
    'settings technical note explicitly disclaims official form replacement': 'TEKNİK AI DAĞITIM / ŞEFFAFLIK NOTU' in settings_vm and 'Bu metin resmî YAZEK Etik Beyan Formu değildir' in settings_vm and 'buildAiDeploymentTransparencyNote' in settings_screen,
    'official YAZEK can be opened directly': 'https://yazek.meb.gov.tr/' in screen and "Resmî YAZEK'i Aç" in screen,
    'app does not auto-approve eight ethics declarations': '8 etik ilkeyi ayrıca değerlendirin' in screen and 'otomatik olarak onaylamaz' in screen,
    'hallucination risk is disclosed to teacher and student-parent notice': 'hata/halüsinasyon' in screen and 'halüsinasyon riski' in store,
    'AI-assisted report discloses hallucination risk and teacher final authority': 'hata/halüsinasyon' in reports and 'nihai akademik karar' in reports,
    'official applied state wording tolerates guide and FAQ labels': 'Uygulamaya Al/Uygula adımı tamamlandı' in screen and 'gereken tüm resmî YAZEK Etik Beyan Formlarını' in screen,
    'three-day correction window explained': 'ilk 3 gün düzenlenebilir' in screen,
    'scope change tells teacher to create new declaration': 'hedef kitle değiştiyse yeni beyan oluşturun' in screen,
    'app record explicitly not official YAZEK form': 'Bu kayıt resmî YAZEK beyanının yerine geçmez' in screen,
    'official YAZEK confirmation is separate': 'officialYazekApplied' in screen and 'officialDeclarationApplied' in store,
    'data notice consent confirmation is separate': 'noticeAndConsentCompleted' in screen and 'noticeAndConsentCompleted' in store,
    'confirmation button fails closed until both': 'enabled = officialYazekApplied && noticeAndConsentCompleted' in screen,
    'store acknowledgement requires both': 'require(officialDeclarationApplied)' in store and 'require(noticeAndConsentCompleted)' in store,
    'isAcknowledged requires both persisted proofs': '.getBoolean("decl_${fingerprint}_official_applied", false)' in store and '.getBoolean("decl_${fingerprint}_notice_consent", false)' in store,
    'central student AI gate is fail closed': 'scope.requireComplete()' in gate and 'ProviderDataProtectionProfile.current().requireReady()' in gate and 'check(store.isAcknowledged(scope))' in gate,
    'repository binds per-exam YAZEK audit': 'upsertYazekDeclarationAudit' in repo and 'scopeFingerprint = scope.fingerprint()' in repo,
    'repository audit avoids brittle Uygula-only wording': 'Resmî YAZEK beyanının uygulamaya alındığı' in repo and "YAZEK beyanı 'Uygula'" not in repo,
    'scope fingerprint binds official application name': 'applicationName.trim(),' in store and 'changedApplicationNameChangesFingerprint' in scope_test,
    'scope fingerprint binds official summary': 'applicationSummary.trim(),' in store and 'changedApplicationSummaryChangesFingerprint' in scope_test,
    'scope fingerprint still binds purpose outcome tool provider': all(x in store for x in ['educationalPurpose.trim()', 'learningOutcomeSignature.trim()', 'aiTool.trim()', 'providerPolicySignature.trim()']),
    'scope order does not destabilize branch fingerprint': 'branchOrderDoesNotChangeFingerprint' in scope_test,
    'multi-branch scope produces one official form block per branch': 'Gerekli form sayısı:' in store and '--- FORM ' in store and 'multiBranchFormAidProducesOneSeparateBlockPerBranch' in scope_test,
    'multi-branch reference note accepts multiple form numbers': 'birden fazla şube/form varsa numaraları virgülle ayırabilirsiniz' in screen,
    'missing official application scope fails completeness': 'missingOfficialApplicationScopeFailsCompleteness' in scope_test,
    'short official summary fails completeness': 'tooShortOfficialSummaryFailsCompleteness' in scope_test,
    'legacy policy record denied': '.putInt("decl_${fingerprint}_policy", 4)' in store_test and 'assertFalse(store.isAcknowledged(scope))' in store_test,
    'store has Robolectric dual-confirmation tests': 'acknowledgementRejectsMissingOfficialYazekApplyConfirmation' in store_test and 'acknowledgementRejectsMissingNoticeConsentConfirmation' in store_test,
    'viewmodel propagates both confirmations': 'officialDeclarationApplied = officialDeclarationApplied' in vm and 'noticeAndConsentCompleted = noticeAndConsentCompleted' in vm,
    'repository propagates both confirmations': 'officialDeclarationApplied: Boolean' in repo and 'noticeAndConsentCompleted: Boolean' in repo,
    'release build uses V20.18 marker': 'BAYKUSNOT_SOURCE_V20_18_YAZEK_FORM_ALIGNED.marker' in release_bat,
}

failed=[]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
    if not ok: failed.append(name)
print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print('FAILED: ' + ', '.join(failed))
sys.exit(1 if failed else 0)
