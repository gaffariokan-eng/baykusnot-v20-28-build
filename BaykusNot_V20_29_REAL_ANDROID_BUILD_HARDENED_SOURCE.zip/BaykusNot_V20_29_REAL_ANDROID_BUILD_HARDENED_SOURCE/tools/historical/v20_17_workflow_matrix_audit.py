#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8',errors='ignore')
def has(p,*xs):
    s=t(p); return all(x in s for x in xs)
def rx(p,pat): return re.search(pat,t(p),re.S|re.M) is not None
policy='app/src/main/java/com/example/core/model/WorkflowPolicy.kt'
screen='app/src/main/java/com/example/feature/workflow/WorkflowScreen.kt'
vm='app/src/main/java/com/example/feature/workflow/WorkflowViewModel.kt'
checks={
'written_source_route': has(screen,'ExamType.WRITTEN','UploadSourceViewModel.Factory'),
'listening_material_route': has(screen,'ExamType.LISTENING','ListeningMaterialViewModel.Factory','ListeningMaterialRoute'),
'readiness_source_route': has(screen,'ExamType.READINESS','ReadinessSourceRoute'),
'homework_assignment_route': has(screen,'ExamType.HOMEWORK','HomeworkAssignmentScreen'),
'multiple_choice_answer_key_route': has(screen,'ExamType.MULTIPLE_CHOICE','TestAnswerKeyViewModel.Factory','TestAnswerKeyScreen'),
'multiple_choice_optical_route': has(screen,'TestOpticalReadingViewModel.Factory','TestOpticalReadingScreen'),
'non_test_ai_route': has(screen,'AiEvaluationViewModel.Factory','AiEvaluationScreen'),
'all_types_upload_papers_route': has(screen,'UploadPapersRoute','examType = uiState.draft?.examType ?: ExamType.WRITTEN'),
'all_types_teacher_review_route': has(screen,'TeacherReviewRoute','examType = uiState.draft?.examType ?: ExamType.WRITTEN'),
'all_types_reports_route': has(screen,'ReportsViewModel.Factory','ReportsScreen'),
'stepper_uses_type_specific_stages': has(screen,'.workflowStages()'),
'homework_policy_skips_question_rubric_answer_prefs': has(policy,'ExamType.HOMEWORK','WorkflowStage.QUESTION_POINTS','WorkflowStage.RUBRIC','WorkflowStage.ANSWER_SHEET','WorkflowStage.READING_PREFS'),
'mc_policy_skips_source_question_prefs': has(policy,'ExamType.MULTIPLE_CHOICE','WorkflowStage.UPLOAD_SOURCE','WorkflowStage.QUESTION_POINTS','WorkflowStage.READING_PREFS'),
'exam_info_mc_goes_rubric': rx(vm,r'latestDraft\.examType\s*==\s*ExamType\.MULTIPLE_CHOICE.*?WorkflowStage\.RUBRIC.*?WorkflowStage\.UPLOAD_SOURCE'),
'upload_source_homework_goes_upload_papers': has(vm,'val nextStage = if (latestDraft.examType == ExamType.HOMEWORK) WorkflowStage.UPLOAD_PAPERS else WorkflowStage.QUESTION_POINTS'),
'rubric_uses_type_policy': has(vm,'stageAfterRubric()'),
'answer_sheet_goes_upload_papers': rx(vm,r'fun\s+advanceFromAnswerSheet\(\).*?currentWorkflowStage\s*=\s*WorkflowStage\.UPLOAD_PAPERS'),
'upload_papers_test_and_homework_go_evaluation': has(vm,'latestDraft.examType == ExamType.MULTIPLE_CHOICE || latestDraft.examType == ExamType.HOMEWORK','WorkflowStage.AI_EVALUATION','WorkflowStage.READING_PREFS'),
'reading_prefs_goes_ai_evaluation': rx(vm,r'fun\s+advanceFromReadingPreferences\(\).*?currentWorkflowStage\s*=\s*WorkflowStage\.AI_EVALUATION'),
'ai_evaluation_goes_teacher_review': rx(vm,r'fun\s+advanceFromAiEvaluation\(\).*?currentWorkflowStage\s*=\s*WorkflowStage\.TEACHER_REVIEW'),
'teacher_review_goes_reports': rx(vm,r'fun\s+advanceFromTeacherReview\(\).*?currentWorkflowStage\s*=\s*WorkflowStage\.REPORTS'),
'homework_policy_test_exists': (ROOT/'app/src/test/java/com/example/core/model/HomeworkWorkflowPolicyTest.kt').exists(),
'mc_policy_test_exists': (ROOT/'app/src/test/java/com/example/core/model/MultipleChoiceWorkflowPolicyTest.kt').exists(),
'listening_policy_test_exists': (ROOT/'app/src/test/java/com/example/core/model/ListeningSourcePolicyTest.kt').exists(),
'readiness_policy_test_exists': (ROOT/'app/src/test/java/com/example/core/model/ReadinessSupportPriorityPolicyTest.kt').exists(),
}
failed=[]
for n,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' | '+n)
    if not ok: failed.append(n)
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: print('FAILED: '+', '.join(failed))
sys.exit(1 if failed else 0)
