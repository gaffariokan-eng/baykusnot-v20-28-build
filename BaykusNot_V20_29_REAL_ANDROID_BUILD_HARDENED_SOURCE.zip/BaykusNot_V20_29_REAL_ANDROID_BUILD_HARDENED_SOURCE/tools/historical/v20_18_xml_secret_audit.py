#!/usr/bin/env python3
from pathlib import Path
import py_compile, re, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]

py_files=sorted((ROOT/'tools').rglob('*.py'))
py_fail=[]
for p in py_files:
    try: py_compile.compile(str(p), doraise=True)
    except Exception as e: py_fail.append((p,e))
print(f"{'PASS' if not py_fail else 'FAIL'} | Python tools compile | {len(py_files)-len(py_fail)}/{len(py_files)}")
for p,e in py_fail: print(f"  {p.relative_to(ROOT)}: {e}")

xml_files=sorted(list((ROOT/'app/src/main/res').rglob('*.xml')) + list((ROOT/'app/src/main').glob('AndroidManifest.xml')))
xml_fail=[]
for p in xml_files:
    try: ET.parse(p)
    except Exception as e: xml_fail.append((p,e))
print(f"{'PASS' if not xml_fail else 'FAIL'} | Android XML parse | {len(xml_files)-len(xml_fail)}/{len(xml_files)}")
for p,e in xml_fail: print(f"  {p.relative_to(ROOT)}: {e}")

# High-signal secret scan only: real Google API key shape and private-key blocks.
scan_roots=[ROOT/'app/src/main', ROOT/'app/build.gradle.kts', ROOT/'gradle.properties']
findings=[]
patterns=[
    ('google_api_key', re.compile(r'AIza[0-9A-Za-z_-]{30,}')),
    ('private_key', re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
]
files=[]
for r in scan_roots:
    if r.is_file(): files.append(r)
    elif r.exists(): files.extend(p for p in r.rglob('*') if p.is_file() and p.suffix.lower() in {'.kt','.kts','.xml','.properties','.json','.txt','.md'})
for p in files:
    text=p.read_text(encoding='utf-8',errors='ignore')
    for name,rx in patterns:
        if rx.search(text): findings.append((name,p.relative_to(ROOT)))
print(f"{'PASS' if not findings else 'FAIL'} | Secret/private-key scan | {len(findings)} findings")
for name,p in findings: print(f"  {name}: {p}")

sys.exit(1 if py_fail or xml_fail or findings else 0)
