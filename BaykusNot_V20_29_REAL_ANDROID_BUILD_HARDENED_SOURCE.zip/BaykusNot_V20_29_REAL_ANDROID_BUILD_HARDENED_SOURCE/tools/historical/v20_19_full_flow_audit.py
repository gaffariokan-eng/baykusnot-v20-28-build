#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/com/example'

def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def contains(rel, *needles):
    t=read(rel)
    return all(n in t for n in needles)

def regex(rel, pattern):
    return re.search(pattern, read(rel), re.S|re.M) is not None

checks=[]
def ck(name, ok): checks.append((name, bool(ok)))

# Navigation / draft lifecycle
ck('HOME_CONTINUE_OPENS_WORKFLOW', contains('app/src/main/java/com/example/MainActivity.kt', 'Screen.Workflow(draftId)'))
ck('WORKFLOW_EXAM_INFO_FACTORY_HAS_DELETION_REPO', contains('app/src/main/java/com/example/feature/workflow/WorkflowScreen.kt','deletionRepository = appContainer.examDeletionRepository'))
ck('WORKFLOW_DELETE_CALLBACK_NOT_EMPTY', contains('app/src/main/java/com/example/feature/workflow/WorkflowScreen.kt','onDeleteRequest = { showExamInfoDeleteConfirm = true }'))
ck('DRAFT_SAVE_DOUBLE_ACTION_GUARD', regex('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt', r'if\s*\(state\.isSaving\s*\|\|\s*state\.isDeleting\)\s*return'))
ck('DRAFT_DELETE_DOUBLE_ACTION_GUARD', contains('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt','if (state.isSaving || state.isDeleting) return'))
ck('DRAFT_MISSING_LOAD_ERROR', contains('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt','loadError'))
ck('DRAFT_REQUIRES_INSTITUTION_YEAR', contains('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt','academicYear','institution'))
ck('DRAFT_SCOPE_CHANGE_CLEARS_MAPPING', contains('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt','scopeChanged','isObjectiveMappingApproved = if (scopeChanged) false'))
ck('DRAFT_DELETE_CRASH_SAFE_REPOSITORY', contains('app/src/main/java/com/example/feature/workflow/NewDraftViewModel.kt','deletionRepository.deleteExamCompletely'))

# Persisted rewind / stale work
wv='app/src/main/java/com/example/feature/workflow/WorkflowViewModel.kt'
ck('REWIND_PERSISTS_STAGE', regex(wv, r'fun\s+selectStage\(stage: WorkflowStage\).*?currentWorkflowStage\s*=\s*stage'))
ck('REWIND_STOPS_ACTIVE_EVALUATION', contains(wv,'stopEvaluationAndAwait(draftId, cleanupRemoteBatch = true)'))
ck('REWIND_RESETS_OLD_EVALUATIONS', contains(wv,'resetEvaluationsForExam(draftId)'))
ck('REWIND_UNLOCKS_QUESTION_SET', contains(wv,'ensureQuestionSetUnlocked'))
ck('REWIND_UNLOCKS_RUBRIC', contains(wv,'ensureRubricUnlocked'))
ck('REWIND_UNLOCKS_PREFS', contains(wv,'ensurePreferencesUnlocked'))
for fn,stage in [
 ('advanceFromExamInfo','EXAM_INFO'),('advanceFromUploadSource','UPLOAD_SOURCE'),
 ('advanceFromQuestionPoints','QUESTION_POINTS'),('advanceFromRubric','RUBRIC'),
 ('advanceFromAnswerSheet','ANSWER_SHEET'),('advanceFromUploadPapers','UPLOAD_PAPERS'),
 ('advanceFromReadingPreferences','READING_PREFS'),('advanceFromAiEvaluation','AI_EVALUATION'),
 ('advanceFromTeacherReview','TEACHER_REVIEW')]:
    ck('PERSISTED_STAGE_GUARD_'+stage, regex(wv, rf'fun\s+{fn}\(.*?\w+Draft\.currentWorkflowStage\s*!=\s*WorkflowStage\.{stage}'))

# Source and extracted question validity
usv='app/src/main/java/com/example/feature/workflow/UploadSourceViewModel.kt'
ck('SOURCE_FACTORY_HAS_QUESTION_REPO', contains(usv,'private val questionRepository: com.example.core.data.ExamQuestionRepository'))
ck('SOURCE_CHANGE_INVALIDATES_QUESTIONS', contains(usv,'sourceChanged','questionRepository.invalidateUnlockedQuestionSet(draftId)'))
ck('SOURCE_RESET_FAILURE_BLOCKS_EXTRACTION', contains(usv,'requiresQuestionReset','Sorular çıkarılmadı'))
ck('SOURCE_REMOVE_INVALIDATES_BEFORE_DELETE', regex(usv, r'fun\s+removeSource\(\).*?invalidateUnlockedQuestionSet\(draftId\).*?removeByExamDraftId'))
ck('ZIP_MAX_100', contains(usv,'images.size >= 100'))
ck('ZIP_UNCOMPRESSED_MAX_50MB', contains(usv,'totalBytes > 50L * 1024L * 1024L'))
ck('ZIP_ALLOWED_IMAGE_TYPES_ONLY', contains(usv,'"png" -> "image/png"','"webp" -> "image/webp"','"jpg", "jpeg" -> "image/jpeg"'))
ck('MULTI_IMAGE_STREAMING_TEMP_ZIP', contains('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt','ZipOutputStream','createTempFile'))
ck('MULTI_IMAGE_LIMIT_100', contains('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt','uris.size > 100'))

# Question/rubric integrity
qp='app/src/main/java/com/example/feature/workflow/QuestionPointsViewModel.kt'
ck('STAGING_PREFERRED_WHEN_UNLOCKED', contains(qp,'staging','canonical'))
ck('QUESTION_SAVE_INVALIDATES_MAPPING_FIRST', contains(qp,'invalidateQuestionObjectiveMappingApproval(draftId)'))
ck('MAPPING_REFS_ATOMIC_INVALIDATION', contains('app/src/main/java/com/example/core/database/ExamObjectiveDao.kt','invalidateQuestionObjectiveMappingApproval','@Transaction','replaceQuestionObjectiveCrossRefsForDraft'))
ck('QUESTION_LOCK_REQUIRES_DB_MAPPING_APPROVAL', contains(qp,'if (!draft.isObjectiveMappingApproved)'))
ck('QUESTION_TOTAL_VALIDATED_BEFORE_ADVANCE', contains(wv,'QuestionPointsValidator'))
ck('RUBRIC_CONTRACT_REVALIDATED', contains(wv,'lockedRubricContractError'))
ck('RUBRIC_REVISION_BOUND_TO_QUESTIONS', contains(wv,'questionSetRevision'))
ck('MULTIPLE_CHOICE_KEY_POLICY_REVALIDATED', contains(wv,'MultipleChoice'))

# Listening and homework
ck('LISTENING_CHANGE_INVALIDATES_QUESTIONS', contains('app/src/main/java/com/example/feature/listening/ListeningMaterialViewModel.kt','invalidateUnlockedQuestionSet'))
ck('HOMEWORK_TRIPLE_LOCK_CONTRACT', contains('app/src/main/java/com/example/feature/homework/HomeworkAssignmentScreen.kt','qMeta?.isLocked','rMeta?.isLocked','prefs?.isLocked'))
ck('HOMEWORK_RUBRIC_REVISION_BOUND', contains('app/src/main/java/com/example/feature/homework/HomeworkAssignmentScreen.kt','questionSetRevision'))
ck('HOMEWORK_SKIPS_ANSWER_SHEET', contains('app/src/main/java/com/example/core/model/WorkflowPolicy.kt','ExamType.HOMEWORK','WorkflowStage.ANSWER_SHEET'))
ck('MULTIPLE_CHOICE_SKIPS_SOURCE_AND_PREFS', contains('app/src/main/java/com/example/core/model/WorkflowPolicy.kt','ExamType.MULTIPLE_CHOICE','WorkflowStage.UPLOAD_SOURCE','WorkflowStage.READING_PREFS'))

# Physical answer forms / QR
ansrepo='app/src/main/java/com/example/core/data/ExamAnswerSheetRepository.kt'
pdf='app/src/main/java/com/example/core/data/ExamAnswerSheetPdfGenerator.kt'
paper='app/src/main/java/com/example/core/data/ExamPaperUploadRepository.kt'
ck('ANSWER_LAYOUT_VERSION_6', contains(ansrepo,'CURRENT_LAYOUT_VERSION = 6'))
ck('ANSWER_FORM_SHA256_FINGERPRINT', contains(ansrepo,'SHA-256','fingerprintToken'))
ck('ANSWER_QR_V4_HAS_FORM_TOKEN', contains(pdf,'AIEKSAM|V:4','F:$formToken'))
ck('QR_GENERATION_FAIL_CLOSED', contains('app/src/main/java/com/example/core/data/QrCodeGenerator.kt','throw IllegalStateException'))
ck('UPLOAD_PARSES_FORM_TOKEN', contains(paper,'formToken','version'))
ck('OLD_OR_MISMATCHED_FORM_STALE', contains(paper,'STALE_FORM','currentFormToken'))
ck('MANUAL_REASSIGN_PRESERVES_STALE', regex(paper, r'reassignPage.*?STALE_FORM'))
ck('UI_MANUAL_STALE_BLOCKED', regex('app/src/main/java/com/example/feature/workflow/UploadPapersUiState.kt',r'page\.isManuallyAssigned\).*?page\.status\s*!=\s*"VALID"'))
ck('UPLOADED_PAPER_CHECK_FAIL_CLOSED', contains(ansrepo,'PAPER_UPLOAD_DAO_REQUIRED'))
ck('ANSWER_CONFIG_LOCKS_AFTER_UPLOAD', contains('app/src/main/java/com/example/feature/workflow/AnswerSheetViewModel.kt','hasUploadedPapers'))

# Upload transaction / import concurrency
upv='app/src/main/java/com/example/feature/workflow/UploadPapersViewModel.kt'
ck('IMPORT_RECOVERY_FAIL_CLOSED', contains(upv,'recoverInterruptedImport'))
ck('IMPORT_DOUBLE_START_GUARD', contains(upv,'if (_uiState.value.isProcessing) return'))
ck('IMPORT_MUTATIONS_BLOCK_WHILE_PROCESSING', read(upv).count('if (_uiState.value.isProcessing) return') >= 5)
ck('IMPORT_ERRORS_VISIBLE', contains(upv,'errorMessage ='))
# V20.19 paper mutation/continue race hardening
upui='app/src/main/java/com/example/feature/workflow/UploadPapersUiState.kt'
upscreen='app/src/main/java/com/example/feature/workflow/UploadPapersScreen.kt'
ck('UPLOAD_PROCEED_BLOCKS_LOADING_OR_PROCESSING', regex(upui,r'return\s+!isLoading\s*&&\s*!isProcessing'))
ck('UPLOAD_PROCEED_REASON_BLOCKS_PROCESSING', contains(upui,'isLoading ->','isProcessing ->'))
ck('UPLOAD_SCREEN_CONTINUE_EXPLICITLY_BLOCKS_PROCESSING', contains(upscreen,'uiState.canProceed && !uiState.isProcessing'))
ck('UPLOAD_IMPORT_ALWAYS_CLEARS_BUSY_STATE', read(upv).count('finally {') >= 8 and read(upv).count('isProcessing = false') >= 8)
ck('UPLOAD_MUTATIONS_SERIALIZED', read(upv).count('if (_uiState.value.isProcessing) return') >= 8)
ck('UPLOAD_MUTATION_GATE_TEST_EXISTS', (ROOT/'app/src/test/java/com/example/feature/workflow/UploadPapersUiStateMutationGateTest.kt').exists())
ck('UPLOAD_HOMEWORK_NEXT_STEP_LABEL', contains(upscreen,'uiState.isHomework -> "Sonraki adım: Değerlendirme"'))
ck('UPLOAD_TEST_NEXT_STEP_LABEL', contains(upscreen,'contains("Test", ignoreCase = true)','"Sonraki adım: Yerel Optik Okuma"'))

# Test/optical identity and stale writes
keygen='app/src/main/java/com/example/core/data/TestTeacherAnswerKeyFormGenerator.kt'
reader='app/src/main/java/com/example/core/data/TestOpticalFormReader.kt'
ev='app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt'
ck('TEACHER_KEY_FORM_VERSIONED', contains(keygen,'FORM_VERSION = 2'))
ck('TEACHER_KEY_QR_BINDS_DRAFT_AND_TOKEN', contains(keygen,'AIEKSAM-TEACHER','F:$formToken'))
ck('TEACHER_KEY_READER_VALIDATES_TOKEN', contains(reader,'formToken'))
ck('OPTICAL_WRITE_STAGE_GUARD', read(ev).count('WorkflowStage.AI_EVALUATION') >= 3)
ck('AI_ENTRY_STAGE_GUARD', contains(ev,'requireAiEvaluationWorkflowStage'))
ck('REWIND_AWAITABLE_STOP', contains(ev,'stopEvaluationAndAwait'))
ck('BATCH_UNCERTAIN_RECOVERY_PRESENT', contains(ev,'recoverUncertainJobs'))

# Teacher review / reports / YAZEK
ck('OPEN_REVIEW_BLOCKS_FINAL_CONFIRM', contains(ev,'OPEN') and contains(ev,'review'))
ck('FINAL_CONFIRM_INTEGRITY_CHECK', contains(ev,'validateAndConfirmAllResults','checkFinalResultsIntegrity'))
ck('TEACHER_CONFIRM_DOUBLE_ACTION_GUARD', contains('app/src/main/java/com/example/feature/workflow/TeacherReviewViewModel.kt','isConfirming'))
# V20.19 teacher-review mutation/confirm race hardening
trvm='app/src/main/java/com/example/feature/workflow/TeacherReviewViewModel.kt'
trscreen='app/src/main/java/com/example/feature/workflow/TeacherReviewScreen.kt'
ck('TEACHER_REVIEW_MUTATION_PENDING_STATE', contains(trvm,'isSavingChanges'))
ck('TEACHER_REVIEW_MUTATIONS_TRACKED', read(trvm).count('launchTrackedMutation {') >= 5)
ck('TEACHER_NOTE_MUTATION_TRACKED', contains(trvm,'fun updateTeacherNote') and 'launchTrackedMutation {' in read(trvm)[read(trvm).find('fun updateTeacherNote'):read(trvm).find('fun confirmAllResults')])
ck('TEACHER_FINAL_CONFIRM_BLOCKS_PENDING_MUTATION', contains(trvm,'if (_uiState.value.isConfirming || _uiState.value.isSavingChanges) return'))
ck('TEACHER_CONFIRM_UI_BLOCKS_PENDING_MUTATION', contains(trscreen,'!uiState.isConfirming && !uiState.isSavingChanges'))
ck('REPORTS_RECHECK_FINAL_INTEGRITY', contains('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt','checkFinalResultsIntegrity'))
ck('YAZEK_CONSENT_GATE_PRESENT', contains('app/src/main/java/com/example/core/security/YazekComplianceStore.kt','Yazek'))
ck('STUDENT_AI_COMPLIANCE_GATE_PRESENT', contains('app/src/main/java/com/example/core/security/StudentAiComplianceGate.kt','class StudentAiComplianceGate'))

# UX/state safety
ck('PROFILE_LOAD_ERROR_RECOVERABLE', contains('app/src/main/java/com/example/feature/profile/ProfileViewModel.kt','isLoaded = true','errorMessage'))
ck('PROFILE_SAVE_DOUBLE_ACTION_GUARD', contains('app/src/main/java/com/example/feature/profile/ProfileViewModel.kt','isSaving'))
ck('REPORT_FEEDBACK_STATE_RESETS', contains('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt','isGeneratingFeedback'))
ck('NO_TODO_OR_NOT_IMPLEMENTED', not any(('TODO(' in p.read_text(errors='ignore') or 'NotImplementedError' in p.read_text(errors='ignore')) for p in (ROOT/'app/src').rglob('*.kt')))
main_text='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'app/src/main').rglob('*.kt'))
ck('NO_EMPTY_ASSIST_CHIP_CLICK', not re.search(r'AssistChip\s*\([^)]*onClick\s*=\s*\{\s*\}', main_text, re.S))

# V20.19 answer-sheet async setting race hardening
answer_vm='app/src/main/java/com/example/feature/workflow/AnswerSheetViewModel.kt'
answer_ui='app/src/main/java/com/example/feature/workflow/AnswerSheetUiState.kt'
answer_screen='app/src/main/java/com/example/feature/workflow/AnswerSheetScreen.kt'
answer_route='app/src/main/java/com/example/feature/workflow/AnswerSheetRoute.kt'
ck('ANSWER_SETTINGS_HAVE_PENDING_STATE', contains(answer_ui,'isSavingSettings'))
ck('ANSWER_CONFIG_WRITES_LATEST_WINS', contains(answer_vm,'configSaveRevision','previousJob?.cancelAndJoin()','scheduleConfigSave'))
ck('ANSWER_LINE_WRITES_LATEST_WINS', contains(answer_vm,'lineOverrideSaveRevision','scheduleLineOverrideSave'))
ck('ANSWER_SETTING_CHANGE_INVALIDATES_PDF_SYNC', read(answer_vm).count('isPdfUpToDate = false') >= 4)
ck('ANSWER_PDF_GENERATION_BLOCKED_DURING_SETTING_SAVE', contains(answer_vm,'currentState.isSavingSettings') and contains(answer_screen,'!uiState.isSavingSettings'))
ck('ANSWER_CONTINUE_BLOCKED_DURING_SETTING_SAVE', contains(answer_screen,'uiState.isPdfUpToDate && !uiState.isSavingSettings') and contains(answer_route,'!uiState.isSavingSettings && uiState.isPdfUpToDate'))
ck('ANSWER_LINE_OVERRIDES_ATOMICFILE', contains('app/src/main/java/com/example/core/data/ExamAnswerSheetRepository.kt','AtomicFile(file)','startWrite()','finishWrite','failWrite'))

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL')+' | '+n)
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED: '+', '.join(failed))
    sys.exit(1)
