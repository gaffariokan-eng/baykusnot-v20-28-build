#!/usr/bin/env python3
# Compatibility launcher for the current V20.13 process-death audit.
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name("v20_13_process_death_audit.py")), run_name="__main__")
