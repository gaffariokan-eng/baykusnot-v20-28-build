# V20.22 Gereksinim Matrisi

| Gereksinim | Uygulama | Durum |
|---|---|---|
| PAUSED/ERROR iş otomatik başlamasın | RUNNING-only resume + synchronous pause guard | PASS_SOURCE |
| Durdur crash penceresi kapansın | SharedPreferences commit + Room PAUSED before cancel | PASS_SOURCE |
| Keystore bozulması mevcut DB anahtarını ezmesin | recovery-required fail-closed path | PASS_SOURCE |
| Recovery kullanıcıya anlaşılır gösterilsin | startup safety/recovery blocking screen | PASS_SOURCE |
| Kamera plaintext process-death sonrası kalmasın | application-start immediate scrub | PASS_SOURCE |
| Kamera scrub başarısızlığı sessiz geçmesin | startup fail-closed | PASS_SOURCE |
| 24 saat rapor retention gerçek silmeye bağlı olsun | cleanup returns success/failure + startup fail-closed | PASS_SOURCE |
| PDF export API 26–36 güvenli olsun | SAF CreateDocument | PASS_SOURCE |
| PDF yazılmadan başarı gösterilmesin | descriptor + fsync + copy/read-back length verify | PASS_SOURCE |
| Tam silme pending cleanup'ı gizlemesin | deletion summary + blocking notice | PASS_SOURCE |
| Dış export silme kapsamı açık olsun | delete confirmation disclosure | PASS_SOURCE |
| `.doc` yanlış DOCX parse edilmesin | explicit legacy DOC reject | PASS_SOURCE |
| Kapatma kontrolü TalkBack uyumlu olsun | contentDescription=Kapat | PASS_SOURCE |
| Static audit | 205/205 | PASS |
| Recovery/privacy/export negative audit | 34/34 | PASS |
| Governance/scale negative audit | 25/25 | PASS |
| Full flow | 98/98 | PASS |
| 5 active exam routes | 25/25 | PASS |
| Semantic | 9/9 | PASS |
| Transactional | 23/23 | PASS |
| Runtime/lifecycle | 21/21 | PASS |
| Process-death | 18/18 | PASS |
| Deletion journal | 15/15 | PASS |
| Scale/retention | 16/16 | PASS |
| YAZEK/onam | 16/16 | PASS |
| YAZEK form alignment | 47/47 | PASS |
| YAZEK ethics source evidence | 37/37 | PASS_SOURCE |
| Compile-risk | 14/14 | PASS |
| Kotlin PSI | 322/322 | PASS |
| Constructor/factory call-shape | 1552/1552 | PASS |
| Android XML | 14/14 | PASS |
| Secret/private-key scan | 0 findings | PASS |
| Room migration 21→30 | static SQL/export validation | PASS_STATIC |
| Gerçek Gradle/Kotlin/KSP build | services.gradle.org DNS çözülmedi | BLOCKED_ENV |
| SQLCipher/Keystore recovery gerçek cihaz | fiziksel Android gerekli | DEVICE_TEST_REQUIRED |
| API 26–36 SAF export gerçek cihaz | fiziksel/emülatör matrisi gerekli | DEVICE_TEST_REQUIRED |
| 500 öğrenci performans/OOM | fiziksel cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | dış backend/deployment gerekli | BLOCKED_EXTERNAL_INFRA |
| 20+ gerçek anonim benchmark + private-key signing | gerçek veri/haricî signing gerekli | BLOCKED_REAL_DATA |
