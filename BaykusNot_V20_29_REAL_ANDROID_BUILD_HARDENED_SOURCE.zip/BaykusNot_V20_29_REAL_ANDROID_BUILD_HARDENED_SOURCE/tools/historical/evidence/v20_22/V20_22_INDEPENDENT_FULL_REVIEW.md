# V20.22 Bağımsız Tam İnceleme

V20.21 üzerinde yapılan bağımsız kırılma avında bulunan recovery/privacy/export açıkları kaynak seviyesinde kapatıldı ve V20.22 olarak yeniden denetlendi.

## Kapanan gerçek açıklar
- PAUSED/ERROR + remote Batch otomatik resume mantık hatası.
- Kullanıcı pause komutu ile process-death arasındaki kalıcılık yarışı.
- SQLCipher wrapped-passphrase decrypt/Keystore failure durumunda yeni anahtar üretip kaydı ezme riski.
- Recovery-required durumda ilk DB erişiminin anlaşılmaz crash ile sonuçlanması.
- Crash sonrası kamera plaintext JPEG temizliğinin lazy repository'ye bağlı olması.
- Kamera/expired-report startup temizliğinin başarısızlığının sessizce yutulması.
- PDF dışa aktarmada null/yarım yazım sonrası yanlış “başarılı” bildirimi ve API 26–28 raw Downloads yolu.
- Tam silmede bekleyen yerel/uzak cleanup'ın UI'da görünmemesi.
- Legacy `.doc` formatının DOCX gibi denenmesi.
- Upload kapatma kontrolündeki TalkBack etiketi eksikliği.

## Son kaynak sonucu
Aktif kaynak taramasında yeni P0/P1/P2 akış açığı bulunmadı. Bu ifade yalnız source/static/PSI/contract denetimi içindir; gerçek cihaz ve gerçek production altyapısı kabulü yerine geçmez.

## Açık release kapıları
1. Gerçek `clean testDebugUnitTest assembleDebug`: Gradle 9.3.1 indirmesi `services.gradle.org` DNS nedeniyle başlamadı (`BLOCKED_ENV`).
2. Final Room schema 30 KSP export'u gerçek Android build ile alınmalı.
3. SQLCipher/Android Keystore invalidation ve recovery fiziksel cihazda test edilmeli.
4. Kamera process-kill cleanup ve SAF PDF kaydetme API 26–36 cihaz/emülatör matrisinde test edilmeli.
5. TalkBack, %200 font, picker/kamera, 500 öğrenci performans/OOM kabulü gerçek cihazda yapılmalı.
6. Production authenticated HTTPS gateway/backend deploy edilmeli.
7. Her AI rolü için 20+ REAL_ANONYMIZED öğretmen benchmarkı çalıştırılıp private key ile BNBENCH4 imzalanmalı.
