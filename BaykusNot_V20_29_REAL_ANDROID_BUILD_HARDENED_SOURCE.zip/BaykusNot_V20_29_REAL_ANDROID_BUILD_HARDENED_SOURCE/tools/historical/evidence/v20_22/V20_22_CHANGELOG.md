# BaykuşNot V20.22 — Recovery / Privacy / Export Hardened

## Aktif sürüm
- versionCode: 23
- versionName: 1.20-v20.22
- Room schema: 30 (şema değişikliği yok)

## Düzeltmeler
1. `PAUSED` ve `ERROR` değerlendirme işleri uzak Batch kaydı bulunsa bile otomatik devam etmez.
2. Öğretmen `Durdur` dediğinde synchronous pause guard ve Room `PAUSED` kaydı coroutine iptalinden önce kalıcılaştırılır.
3. Var olan SQLCipher wrapped-passphrase çözülemezse ilk kurulum kabul edilmez; yeni Keystore/passphrase üretilip mevcut kayıt ezilmez.
4. Keystore/passphrase recovery gerektiren durumda kullanıcıya bloklayıcı güvenli-başlatma ekranı gösterilir; veri otomatik sıfırlanmaz.
5. Process başlangıcında kalan tüm `paper_camera_*.jpg` plaintext dosyaları yaş beklenmeden scrub edilir. Temizlik başarısızsa uygulama normal akışa geçmez.
6. 24 saatten eski geçici raporların startup temizliği gerçek silme sonucunu doğrular; silme tamamlanamazsa gizlilik için fail-closed güvenli-başlatma ekranı gösterilir.
7. Cevap kâğıdı ve rubrik PDF dışa aktarımı API 26–36 için Storage Access Framework `CreateDocument` yoluna taşındı. Descriptor, fsync, byte-count ve read-back doğrulaması olmadan başarı gösterilmez.
8. Tam silme sonucu yerel veya uzak cleanup bekliyorsa UI bunu açıkça gösterir; “tamamlandı” gibi davranmaz. Dışa aktarılan PDF kopyalarının kullanıcı tarafından yönetildiği açıklanır.
9. Eski binary `.doc` DOCX gibi işlenmez; PDF veya `.docx` dönüşümü istenir.
10. Kâğıt yükleme kapatma kontrolüne TalkBack `contentDescription` eklendi.
11. Camera process-start scrub için Robolectric regresyon testi eklendi.

## Korunan kilitler
V20.21 BNBENCH4 ECDSA production-governance, Teacher Mode 29→30 canonical migration, durable evaluation run-state, 50+ auto-Batch, YAZEK/onam, SQLCipher/AES-Keystore, 500 öğrenci ölçek korumaları ve teacher-final-authority mimarisi korunmuştur.
