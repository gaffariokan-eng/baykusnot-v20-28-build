# V20.23 Requirements Matrix

| Gereksinim | Uygulama | Durum |
|---|---|---|
| Eksik/decrypt edilemeyen öğrenci sayfasıyla AI değerlendirme yapılmasın | strict decode + exact page coverage | PASS_SOURCE |
| Şifreli corpus varken kayıp image key sessiz yenilenmesin | existing-key recovery gate + startup corpus check | PASS_SOURCE |
| Batch görselsiz/eksik kâğıt göndermesin | request require + per-paper ERROR isolation | PASS_SOURCE |
| Nihai rapor PDF yazımı doğrulansın | PdfSafWriter writeVerified | PASS_SOURCE |
| Recovery non-destructive retry sunsun | startup retry checks | PASS_SOURCE |
| Tanı bilgisi sır/veri içermesin | safeStartupDiagnostic | PASS_SOURCE |
| Kalıcı key kaybında kullanıcı kontrollü temiz kurulum mümkün olsun | clearApplicationUserData + destructive confirmation | PASS_SOURCE |
| YAZEK/onam ve öğretmen nihai otoritesi korunsun | mevcut fail-closed gates | PASS |
| Room migration zinciri | 21→30 | PASS_STATIC |
| Gerçek Android/KSP build | Gradle DNS engeli | BLOCKED_ENV |
| Fiziksel cihaz key recovery/SAF/500 öğrenci | cihaz gerekli | DEVICE_TEST_REQUIRED |
| Production gateway | dış backend gerekli | BLOCKED_EXTERNAL_INFRA |
| Gerçek signed benchmark | gerçek anonim veri + haricî private key | BLOCKED_REAL_DATA |
