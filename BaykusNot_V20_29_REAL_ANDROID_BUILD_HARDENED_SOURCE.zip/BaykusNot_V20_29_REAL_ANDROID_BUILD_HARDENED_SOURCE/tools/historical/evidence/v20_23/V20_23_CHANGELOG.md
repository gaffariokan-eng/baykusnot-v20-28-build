# BaykuşNot V20.23 Changelog

- Student image decrypt/decode evaluation path fail-closed yapıldı.
- Exact whole-paper page coverage zorunlu; sessiz page drop kaldırıldı.
- Batch image payload empty/incomplete request engellendi.
- Existing encrypted image corpus + missing Keystore key => recovery-required; silent re-key engellendi.
- Final ReportsScreen PDF export ortak verified SAF writer'a geçirildi.
- Startup recovery UI: retry, secretsiz diagnostic, explicit irreversible full local reset.
- versionCode 24 / versionName 1.21-v20.23 / Room 30.
