# BaykuşNot V20.20 — Independent Full Review

Tarih: 5 Eylül 2026

## Kapsam
V20.19 sonrası bağımsız kırılma avında bulunan thumbnail/OOM, 500 öğrenci dönüt ölçeği, geçici rapor retention, PDF kaynak sınırı, Teacher Review N+1 sorguları, öğretmen kimliği ve gateway-first UI sorunları kaynak seviyesinde yeniden incelendi ve V20.20'de hedefli olarak kapatıldı.

## Sonuç
Aktif kaynak ve audit setinde yeni bir P0/P1/P2 işlevsel kopukluk bulunmadı. Beş aktif sınav türü (Yazılı, Dinleme, Test, Ödev, Hazırbulunuşluk) ana route zincirleri bağlı kaldı. Öğretmen nihai karar, puan düzeltmesinde eski AI/dönüt invalidation, öğrenci/veli review request, manuel AI kesinti B-planı, YAZEK/onam, tam silme journalı, şifreli öğrenci görseli/DB ve release gateway politikası korunuyor.

## V20.20 özel ölçek sonucu
- Thumbnail listeleri artık tam inceleme bitmaplerini topluca yüklemiyor.
- Rapor açılışı AI dönüt üretimi başlatmıyor.
- Öğretmen dönüt üretimini açıkça başlatıyor; bir tur en fazla 25 öğrenci.
- PDF importu dosya/sayfa sınırını rasterdan önce doğruluyor.
- Teacher Review sınav çapında bulk sorgular kullanıyor.

## Kanıt sınırı
Bu inceleme kaynak/statik/PSI seviyesinde güçlü kanıt sağlar; gerçek Android/KSP derlemesi değildir. Gradle 9.3.1 wrapper dağıtımı `services.gradle.org` DNS çözümlenemediği için gerçek build kod aşamasına ulaşmadı. Fiziksel cihazdaki 500 öğrenci yük testi, SQLCipher migration, TalkBack/%200 font, kamera/picker; production gateway ve gerçek öğretmen benchmarkı ayrı release kapılarıdır.
