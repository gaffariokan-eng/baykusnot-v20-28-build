# BaykuşNot V20.20 Changelog

Tarih: 5 Eylül 2026

## Kapatılan bağımsız denetim bulguları

### P1 — Thumbnail / bitmap bellek baskısı
- Liste/kart önizlemeleri için ayrı `decodeThumbnail()` yolu eklendi.
- Thumbnail decode limiti tam inceleme bitmapinden ayrıldı ve ~400K piksel sınıfına indirildi.
- Eşleşmemiş/sorunlu sayfalar `FlowRow` yerine `LazyRow` ile yalnız görünür öğeleri compose eder.
- Thumbnail bitmapleri composable ömrü sonunda recycle edilir.

### P1 — 500 öğrencide otomatik ayrıntılı dönüt zinciri
- Yeni değerlendirme tercihinin varsayılanı `BRIEF` yapıldı; `DETAILED` seçeneği kaldırılmadı.
- Rapor ekranı açılışında eksik AI dönütü artık otomatik üretilmez.
- Dönüt üretimi yalnız öğretmenin açık eylemiyle başlar ve tur başına en fazla 25 öğrenci işler.
- Her öğrenci tamamlandıkça DB'ye yazıldığı için sonraki tur yalnız eksik kalanlardan devam eder.

### P1 — Geçici rapor saklama davranışı / bilgilendirme uyumu
- 24 saati aşan geçici rapor temizliği uygulama açılışına da bağlandı.
- Rapor üretim/rapor ekranı temizliği korunur.
- Öğrenci/veli bilgilendirme metni gerçek teknik davranışla birebir hale getirildi; Android cache'in daha erken silebileceği de belirtilir.

### P1/P2 — PDF cevap kâğıdı kaynak sınırı
- PDF dosya boyutu için 200 MB üst sınır eklendi.
- Sıfır sayfalı PDF reddedilir.
- Sayfa sayısı, beklenen öğrenci × beklenen sayfa hacmine göre dinamik `2x` toleransla ve mutlak 2000 sayfa tavanıyla fail-closed doğrulanır.
- Limit aşılırsa raster üretimi başlamadan kullanıcı dosyayı bölmeye/ayarları kontrol etmeye yönlendirilir.

### P2 — Öğretmen incelemesinde N+1 Room sorguları
- Sınava ait question evaluations, pages ve review requests üç toplu sorguyla alınır.
- Veriler bellekte `studentPaperId` ile gruplanır; öğrenci başına üç DAO çağrısı kaldırıldı.

### P3 — Öğretmen kimliği ve ayar adı
- Yeni sınav kaydı için en az bir öğretmen seçimi zorunlu hale getirildi.
- Release mimarisiyle uyumsuz/yanıltıcı `API Anahtarı Ayarları` başlığı `AI Bağlantısı / Geliştirici Ayarları` olarak değiştirildi.

### QA paket temizliği
- V20.12–V20.19 sürüme özel audit scriptleri `tools/historical/` altına taşındı.
- Aktif V20.20 denetim listesi `tools/ACTIVE_AUDITS.md` ile ayrıldı.

## Korunan V20.19 güvenlik kararları
- Rol-bazlı gerçek-anonim benchmark üretim kapıları.
- Öğretmen kısa notu ve Room schema 29.
- Bounded image/document decode.
- DOCX ZIP-bomb/traversal/DTD-ENTITY kontrolleri.
- Batch cache-hit fiyat düzeltmesi.
- YAZEK/onam, öğretmen nihai karar, itiraz, crash-safe silme, SQLCipher/AES-Keystore, backup engeli.
