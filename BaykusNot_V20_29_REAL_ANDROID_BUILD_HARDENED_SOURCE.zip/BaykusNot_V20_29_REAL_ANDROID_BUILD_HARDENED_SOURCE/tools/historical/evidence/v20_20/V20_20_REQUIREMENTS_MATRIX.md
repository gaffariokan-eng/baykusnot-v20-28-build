# BaykuşNot V20.20 Requirements Matrix

| Gereksinim | Kaynak/denetim kanıtı | Durum |
|---|---|---|
| Thumbnail tam inceleme bitmapini kullanmasın | `StudentImageCrypto.decodeThumbnail` + sampled decoder | PASS_SOURCE |
| Sorunlu sayfa listesi bütün bitmapleri aynı anda yüklemesin | `LazyRow` + keyed lazy items | PASS_SOURCE |
| Rapor ekranı kendiliğinden AI dönütü üretmesin | `ReportsViewModel.init -> loadReports()` only | PASS_SOURCE |
| Yeni sınavda varsayılan dönüt ekonomik/kısa olsun | `FeedbackDetailLevel.BRIEF` defaults | PASS_SOURCE |
| 500 öğrenci tek AI turuna dönüşmesin | explicit teacher action + `maxItems in 1..25` | PASS_SOURCE |
| Dönüt üretimi kaldığı yerden devam edebilsin | per-student DB commit + pending query | PASS_SOURCE |
| Geçici rapor temizliği yalnız yeni PDF üretimine bağlı olmasın | Application startup + report operations | PASS_SOURCE |
| Saklama bilgilendirmesi gerçek teknik davranışla eşleşsin | revised YAZEK data notice | PASS_SOURCE |
| Dev/bozuk PDF raster başlamadan reddedilsin | 200 MB + dynamic page cap + absolute 2000 page cap | PASS_SOURCE |
| Teacher Review 500 öğrencide N+1 sorgu yapmasın | 3 exam-level bulk queries + groupBy | PASS_SOURCE |
| Yeni sınav öğretmensiz kaydedilmesin | `NewDraftViewModel` teacher gate | PASS_SOURCE |
| Gateway-first release UI kullanıcıyı kalıcı keye yönlendirmesin | renamed settings entry | PASS_SOURCE |
| Aktif audit seti tarihsel scriptlerden ayrı olsun | `tools/ACTIVE_AUDITS.md` + `tools/historical/` | PASS_SOURCE |
| 5 aktif sınav türü | workflow matrix | 25/25 PASS |
| Tam akış | full-flow audit | 98/98 PASS |
| Scale/retention sertleştirme | dedicated audit | 16/16 PASS |
| Statik kaynak | static audit | 184/184 PASS |
| Semantik akış | semantic audit | 9/9 PASS |
| Transaction bütünlüğü | transactional audit | 23/23 PASS |
| Runtime/lifecycle | lifecycle audit | 21/21 PASS |
| Process-death | process-death audit | 18/18 PASS |
| Crash-safe deletion | deletion journal audit | 15/15 PASS |
| YAZEK/onam | consent audit | 16/16 PASS |
| YAZEK form hizalama | alignment audit | 47/47 PASS |
| 8 etik ilke kaynak kanıtı | ethics evidence audit | 37/37 PASS_SOURCE |
| Compile-risk | compile-risk audit | 14/14 PASS |
| Kotlin PSI syntax | compiler PSI parser | 317/317 PASS |
| Constructor/factory call-shape | PSI call-shape | 1541/1541 PASS |
| Android XML | parser | 14/14 PASS |
| Secret/private key | source scan | 0 finding |
| Room 21→25 exported + 25→29 SQL zinciri | migration validator | PASS_STATIC |
| Gerçek Gradle/KSP/Room build | Gradle wrapper DNS erişimi yok | BLOCKED_ENV |
| Gerçek cihaz 500 öğrenci/OOM/TalkBack/%200 font/kamera/picker | fiziksel cihaz | DEVICE_TEST_REQUIRED |
| Gerçek cihaz SQLCipher migration | fiziksel cihaz | DEVICE_TEST_REQUIRED |
| Production HTTPS gateway | kurum/backend | BLOCKED_EXTERNAL_INFRA |
| Rol başına 20+ gerçek anonim öğretmen benchmarkı | gerçek veri + ground truth | BLOCKED_REAL_DATA |
