#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8', errors='ignore')
checks={
 'RubricGenerationSourceContext declared':'sealed interface RubricGenerationSourceContext' in t('app/src/main/java/com/example/core/network/ExamRubricGenerator.kt'),
 'UploadSourceCopy declared':'data class UploadSourceCopy' in t('app/src/main/java/com/example/feature/workflow/UploadSourceScreen.kt'),
 'DEFAULT_SOURCE_MIME_TYPES declared':'internal val DEFAULT_SOURCE_MIME_TYPES' in t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt'),
 'saveLocalMultipleChoiceEvaluation declared':'suspend fun saveLocalMultipleChoiceEvaluation' in t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt'),
 'reloadQuestionSources declared':'fun reloadQuestionSources()' in t('app/src/main/java/com/example/feature/workflow/QuestionPointsViewModel.kt'),
 'MC criterion mismatch enum declared':'MULTIPLE_CHOICE_CRITERION_COUNT_MISMATCH' in t('app/src/main/java/com/example/core/model/ExamRubricValidation.kt'),
 'MC invalid answer enum declared':'INVALID_MULTIPLE_CHOICE_EXPECTED_ANSWER' in t('app/src/main/java/com/example/core/model/ExamRubricValidation.kt'),
 'sourceStageLabel extension declared':'fun ExamType.sourceStageLabel()' in t('app/src/main/java/com/example/core/model/ExamType.kt'),
 'Listening screen avoids obsolete explicit weight import':'import androidx.compose.foundation.layout.weight' not in t('app/src/main/java/com/example/feature/listening/ListeningMaterialScreen.kt'),
 'Listening setup avoids obsolete explicit weight import':'import androidx.compose.foundation.layout.weight' not in t('app/src/main/java/com/example/feature/workflow/ListeningQuestionSetupRoute.kt'),
 'Answer sheet layout accepts examType':'examType: ExamType' in t('app/src/main/java/com/example/core/data/ExamAnswerSheetLayout.kt'),
 'Upload route accepts copy and scenario flags':'copy: UploadSourceCopy' in t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt') and 'showScenarioSection: Boolean' in t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt'),
 'Upload route accepts MIME override':'allowedSourceMimeTypes: List<String>' in t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt'),
 'QuestionPoints factory accepts listening repository':'private val examListeningMaterialRepository: ExamListeningMaterialRepository? = null' in t('app/src/main/java/com/example/feature/workflow/QuestionPointsViewModel.kt'),
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} | {k}")
print(f"SUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
raise SystemExit(1 if failed else 0)
