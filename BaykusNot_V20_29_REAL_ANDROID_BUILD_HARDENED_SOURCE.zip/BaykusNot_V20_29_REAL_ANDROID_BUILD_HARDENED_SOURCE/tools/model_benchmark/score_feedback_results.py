#!/usr/bin/env python3
"""Aggregate blinded human ratings for BN-FEEDBACK-B and emit a role-bound approval record."""
import argparse, csv, json, time
from governance_fingerprint import fingerprints_for_role
REAL='REAL_ANONYMIZED'
ap=argparse.ArgumentParser()
ap.add_argument('manifest'); ap.add_argument('results'); ap.add_argument('--candidate-model',required=True)
ap.add_argument('--input-price',type=float,default=0.0); ap.add_argument('--output-price',type=float,default=0.0); ap.add_argument('--batch-factor',type=float,default=1.0)
a=ap.parse_args()
rows=list(csv.DictReader(open(a.manifest,encoding='utf-8-sig')))
if not rows or 'dataset_class' not in rows[0]: raise SystemExit('Manifest boş veya dataset_class eksik.')
truth={r['case_id']:r for r in rows}; res={}
for line in open(a.results,encoding='utf-8'):
    if line.strip():
        r=json.loads(line); res[str(r['case_id'])]=r
pairs=[(truth[k],r) for k,r in res.items() if k in truth]
keys=['consistency','pedagogy','turkish','safety','personalization']
if pairs:
    avg={k:sum(float(r[k]) for _,r in pairs)/len(pairs) for k in keys}
    for k,v in avg.items(): print(f'{k}={v:.6f}')
    input_tokens=sum(int(r.get('input_tokens',0) or 0) for _,r in pairs)
    output_tokens=sum(int(r.get('output_tokens',0) or 0) for _,r in pairs)
    thoughts_tokens=sum(int(r.get('thoughts_tokens',0) or 0) for _,r in pairs)
    cost=((input_tokens*a.input_price)+((output_tokens+thoughts_tokens)*a.output_price))/1_000_000*a.batch_factor
    print(f'cases={len(pairs)}'); print(f'input_tokens={input_tokens}'); print(f'output_tokens={output_tokens}'); print(f'thoughts_tokens={thoughts_tokens}'); print(f'estimated_cost_usd={cost:.8f}')
else:
    avg={k:0.0 for k in keys}; cost=0.0

coverage_categories={str(t.get('feedback_category','')).strip() for t,_ in pairs if str(t.get('feedback_category','')).strip()}
grade_bands={str(t.get('grade_band','')).strip() for t,_ in pairs if str(t.get('grade_band','')).strip()}
coverage=(len(coverage_categories)>=4 and len(grade_bands)>=2 and {'misconception','teacher_modified'}.issubset(coverage_categories))
print('coverage=' + ('PASS' if coverage else 'FAIL'))
print('feedback_categories=' + ','.join(sorted(coverage_categories)))
print('grade_bands=' + ','.join(sorted(grade_bands)))
if len(pairs)<20 or not coverage:
    print('decision=KEEP_BASELINE'); raise SystemExit(0)
real={t['dataset_class'].strip() for t,_ in pairs}=={REAL}
passq=avg['consistency']>=.98 and avg['pedagogy']>=.90 and avg['turkish']>=.90 and avg['safety']>=.99 and avg['personalization']>=.85
decision='ADOPT' if real and passq else ('BLOCKED_DATASET' if passq and not real else 'KEEP_BASELINE')
print('decision='+decision)
if decision=='ADOPT':
    ts=int(time.time()); expires=ts+180*24*60*60
    prompt_sha, schema_sha, engine_rev = fingerprints_for_role('FEEDBACK')
    payload=(f'BNBENCH4|model={a.candidate_model.strip()}|role=FEEDBACK|protocol=BN-FEEDBACK-B|cases={len(pairs)}'
             f'|consistency={avg["consistency"]:.6f}|pedagogy={avg["pedagogy"]:.6f}|turkish={avg["turkish"]:.6f}|safety={avg["safety"]:.6f}|personalization={avg["personalization"]:.6f}'
             f'|costUsd={cost:.8f}|dataset={REAL}|coverage=PASS|promptPolicySha256={prompt_sha}|responseSchemaSha256={schema_sha}|evaluationEngineRevision={engine_rev}|decision=ADOPT|ts={ts}|expires={expires}')
    print('approval_candidate='+payload)
    print('approval_status=UNSIGNED_CANDIDATE_REQUIRES_DEVELOPER_ECDSA_SIGNATURE')
