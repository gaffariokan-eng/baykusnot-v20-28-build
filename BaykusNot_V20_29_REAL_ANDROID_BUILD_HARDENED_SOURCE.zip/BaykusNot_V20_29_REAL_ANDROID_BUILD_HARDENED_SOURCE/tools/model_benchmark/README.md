# BaykuşNot Rol-Bazlı Model Benchmark Sistemi

Üretim model onayı **role bağlıdır**. Bir modelin bir rolde onaylanması diğer role geçmez.

- `BN-EVAL-B`: el yazısı/transkripsiyon, öğretmen puanına yakınlık, NEEDS_REVIEW recall ve maliyet.
- `BN-FEEDBACK-B`: öğretmen nihai puanıyla tutarlılık, pedagojik kalite, doğal Türkçe, safety, kişiselleştirme ve maliyet.
- `BN-AUTHOR-B`: soru çıkarma, rubrik, kazanım eşleme, halüsinasyon ve öğretmen düzeltme oranı.

## Gerçek veri şartı

`approval_record` yalnız `dataset_class=REAL_ANONYMIZED` olan, en az 20 eşleşen gerçekçi/anonimleştirilmiş doğrulama vakasıyla üretilebilir. Paket içindeki `sample_001` yalnız araç zincirini denemek içindir ve **üretim model onayı veremez**. Gerçek öğrenci kimliği benchmark dosyalarına konulmamalıdır.

Evaluation çalıştırma:

`python run_candidate.py benchmark_manifest.csv candidate_results.jsonl --model SABIT_MODEL_ID`

Scoring:

`python score_results.py benchmark_manifest.csv candidate_results.jsonl --candidate-model SABIT_MODEL_ID ...`

Sentetik örnek kalite eşiğini geçse bile scorer `BLOCKED_DATASET` döndürür. `*-latest` model adları yasaktır.

Feedback ve authoring için veri şeması/eşikler `FEEDBACK_BENCHMARK_PROTOCOL.md` ve `AUTHORING_BENCHMARK_PROTOCOL.md` dosyalarındadır. Skorlayıcılar `BNBENCH4` unsigned candidate üretir. Candidate, kaynak dışında tutulan ECDSA P-256 private key ile `sign_release_approvals.py` üzerinden imzalanır; Android yalnız public key ile imzayı, rolü, protokolü, gerçek-anonim dataset sınıfını ve süreyi doğrular. Private key asla kaynak/APK içine konmaz.


## Eşitlik / temsil kapsam kapısı (V20.8)

Üretim onayı yalnız ortalama kalite eşiğine bakmaz. `coverage=PASS` zorunludur. Evaluation setinde en az 20 **benzersiz vaka**, en az iki sınıf bandı ve en az beş yazı/görüntü koşulu bulunmalıdır; zor el yazısı/düşük görüntü kalitesi, silinti-düzeltme ve Türkçe karakter örnekleri özellikle temsil edilmelidir. Feedback setinde en az iki sınıf bandı ile misconception ve teacher_modified dahil en az dört dönüt durumu; authoring setinde extraction/rubric/objective alt görevlerinin tamamı ve en az iki sınıf bandı bulunmalıdır.

BaykuşNot gereksiz hassas öğrenci niteliği toplamaz; eşitlik testi öğrenci kimliği yerine görev, sınıf bandı, yazı ve görüntü koşullarındaki performans ayrışmasını izler. Kurumun hukuken uygun ve anonimleştirilmiş ek adalet analizi varsa ayrıca raporlanabilir.


## V20.26 governance fingerprint
BNBENCH4 candidate kayıtları artık imzadan önce güncel kaynak ağacına bağlanır. Her rol için `promptPolicySha256`, `responseSchemaSha256` ve `evaluationEngineRevision` alanları zorunludur. `governance_fingerprint.py` bu değerleri aynı kaynak dosyalarından üretir; `sign_release_approvals.py` stale candidate'ı imzalamayı reddeder. Prompt/schema/engine davranışı değiştiğinde gerçek benchmark yeniden çalıştırılmalı ve yeni candidate haricî ECDSA private key ile yeniden imzalanmalıdır.
