#!/usr/bin/env python3
"""Run an anonymized BaykuşNot handwriting benchmark against one explicit Gemini model.

Real runs require one anonymized image and one case-specific prompt (question + locked rubric)
per manifest row. The request mirrors BaykuşNot's important media behavior: separate JPEG input,
HIGH media resolution and structured JSON output. Never include student identity data.
"""
import argparse, base64, csv, json, os, pathlib, urllib.request

ap = argparse.ArgumentParser()
ap.add_argument('manifest')
ap.add_argument('output')
ap.add_argument('--model', required=True)
ap.add_argument('--dry-run', action='store_true')
a = ap.parse_args()
if 'latest' in a.model.lower():
    raise SystemExit('Sabit model ID kullanın; *-latest yasaktır.')

manifest_path = pathlib.Path(a.manifest)
rows = list(csv.DictReader(manifest_path.open(encoding='utf-8-sig')))
required_columns = {'case_id', 'question_order', 'teacher_score', 'max_score', 'teacher_read_text', 'should_need_review', 'category'}
missing_columns = required_columns - set(rows[0].keys() if rows else [])
if missing_columns:
    raise SystemExit('Manifest kolonları eksik: ' + ', '.join(sorted(missing_columns)))

# Dry-run validates IDs and any paths that have actually been supplied, without network/API cost.
for r in rows:
    for key in ('image_path', 'prompt_path'):
        raw = (r.get(key) or '').strip()
        if raw and not pathlib.Path(raw).exists():
            raise SystemExit(f"{r.get('case_id')}: {key} bulunamadı: {raw}")
if a.dry_run:
    print(f'cases={len(rows)} model={a.model} dry_run=ok')
    raise SystemExit(0)

key = os.environ.get('GEMINI_API_KEY', '').strip()
if not key:
    raise SystemExit('GEMINI_API_KEY gerekli.')
url = f'https://generativelanguage.googleapis.com/v1beta/models/{a.model}:generateContent?key={key}'

response_schema = {
    'type': 'OBJECT',
    'properties': {
        'readAnswerText': {'type': 'STRING'},
        'score': {'type': 'NUMBER'},
        'needsReview': {'type': 'BOOLEAN'},
    },
    'required': ['readAnswerText', 'score', 'needsReview'],
}

with open(a.output, 'w', encoding='utf-8') as out:
    for r in rows:
        case_id = r['case_id']
        image_path = (r.get('image_path') or '').strip()
        prompt_path = (r.get('prompt_path') or '').strip()
        if not image_path or not prompt_path:
            raise SystemExit(f'{case_id}: gerçek benchmark için image_path ve prompt_path zorunludur.')
        image_file = pathlib.Path(image_path)
        prompt_file = pathlib.Path(prompt_path)
        if not image_file.exists() or not prompt_file.exists():
            raise SystemExit(f'{case_id}: image/prompt dosyası bulunamadı.')

        prompt = prompt_file.read_text(encoding='utf-8')
        data = base64.b64encode(image_file.read_bytes()).decode()
        parts = [
            {'text': prompt},
            {
                'inlineData': {'mimeType': 'image/jpeg', 'data': data},
                'mediaResolution': {'level': 'MEDIA_RESOLUTION_HIGH'},
            },
        ]
        body = {
            'contents': [{'role': 'user', 'parts': parts}],
            'generationConfig': {
                'responseMimeType': 'application/json',
                'responseSchema': response_schema,
            },
            'store': False,
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode(),
            headers={'Content-Type': 'application/json'},
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            obj = json.load(resp)
        text = obj['candidates'][0]['content']['parts'][0]['text']
        result = json.loads(text)
        usage = obj.get('usageMetadata', {})
        candidate_tokens = int(usage.get('candidatesTokenCount', 0) or 0)
        thoughts_tokens = int(usage.get('thoughtsTokenCount', 0) or 0)
        result.update({
            'case_id': case_id,
            'question_order': int(r['question_order']),
            'input_tokens': int(usage.get('promptTokenCount', 0) or 0),
            'candidate_output_tokens': candidate_tokens,
            'thoughts_tokens': thoughts_tokens,
            # Gemini output pricing includes thinking tokens.
            'output_tokens': candidate_tokens + thoughts_tokens,
            'total_tokens': int(usage.get('totalTokenCount', 0) or 0),
        })
        out.write(json.dumps(result, ensure_ascii=False) + '\n')
        out.flush()
