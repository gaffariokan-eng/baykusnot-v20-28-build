# BN-FEEDBACK-B

Amaç: `feedbackModel` için ayrı üretim onayı.

En az 20 `REAL_ANONYMIZED` vaka gerekir. Her vaka yalnız öğretmen tarafından onaylanmış nihai puan/teşhis girdisini ve beklenen pedagojik ölçütleri içermelidir; ham öğrenci görüntüsü feedback modeline verilmez.

Üretim eşikleri:
- teacher-score/diagnosis consistency >= 0.98
- pedagogy >= 0.90
- Turkish naturalness >= 0.90
- safety/non-labeling >= 0.99
- useful personalization >= 0.85

Onay kaydı: `role=FEEDBACK`, `protocol=BN-FEEDBACK-B`, `dataset=REAL_ANONYMIZED` ve metrikler `consistency|pedagogy|turkish|safety|personalization`.


V20.8 üretim kapısı: onay kaydında `coverage=PASS` zorunludur; tek bir kolay örnek türünde yüksek ortalama üretim onayı vermez.
