# BN-AUTHOR-B

Amaç: `authoringModel` için ayrı üretim onayı.

En az 20 `REAL_ANONYMIZED` vaka gerekir. Soru çıkarma, rubrik üretimi/denetimi ve kazanım eşleme alt görevleri temsil edilmelidir.

Üretim eşikleri:
- question extraction accuracy >= 0.95
- rubric quality >= 0.90
- objective mapping accuracy >= 0.90
- hallucination rate <= 0.02
- teacher correction rate <= 0.10

Onay kaydı: `role=AUTHORING`, `protocol=BN-AUTHOR-B`, `dataset=REAL_ANONYMIZED` ve metrikler `extraction|rubric|objective|hallucination|correction`.


V20.8 üretim kapısı: onay kaydında `coverage=PASS` zorunludur; tek bir kolay örnek türünde yüksek ortalama üretim onayı vermez.
