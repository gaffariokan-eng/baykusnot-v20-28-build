#!/usr/bin/env python3
"""BNBENCH4 ECDSA P-256 signing helpers. Private keys are external release secrets."""
from pathlib import Path
import base64


def _load_crypto():
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        return hashes, serialization, ec
    except ImportError as exc:
        raise SystemExit("cryptography paketi gerekli: python -m pip install cryptography") from exc


def sign_payload(payload: str, private_key_path: str) -> str:
    hashes, serialization, ec = _load_crypto()
    key = serialization.load_pem_private_key(Path(private_key_path).read_bytes(), password=None)
    if not isinstance(key, ec.EllipticCurvePrivateKey) or key.curve.name != "secp256r1":
        raise SystemExit("BNBENCH4 için ECDSA P-256 (secp256r1) private key gerekir.")
    signature = key.sign(payload.encode("utf-8"), ec.ECDSA(hashes.SHA256()))
    return payload + "|sig=" + base64.b64encode(signature).decode("ascii")


def public_key_b64(private_key_path: str) -> str:
    _, serialization, ec = _load_crypto()
    key = serialization.load_pem_private_key(Path(private_key_path).read_bytes(), password=None)
    if not isinstance(key, ec.EllipticCurvePrivateKey) or key.curve.name != "secp256r1":
        raise SystemExit("BNBENCH4 için ECDSA P-256 private key gerekir.")
    der = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return base64.b64encode(der).decode("ascii")
