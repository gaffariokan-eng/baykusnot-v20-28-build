#!/usr/bin/env python3
import argparse, csv, json, re, time
from difflib import SequenceMatcher
from governance_fingerprint import fingerprints_for_role

REAL_DATASET = 'REAL_ANONYMIZED'

def norm(s): return re.sub(r"\s+", " ", (s or '').strip().casefold())
def b(v): return str(v).strip().lower() in {'1','true','yes','evet'}
def load_truth(path):
    d={}
    with open(path,encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if not rows: raise SystemExit('Manifest boş.')
    if 'dataset_class' not in rows[0]: raise SystemExit('Manifestte dataset_class kolonu zorunludur.')
    for r in rows: d[(r['case_id'],int(r['question_order']))]=r
    return d

def load_results(path):
    d={}
    with open(path,encoding='utf-8') as f:
        for line in f:
            if line.strip():
                r=json.loads(line); d[(r['case_id'],int(r['question_order']))]=r
    return d

def metrics(truth,res,ip,op,batch):
    pairs=[(t,res[k]) for k,t in truth.items() if k in res]
    if not pairs: raise SystemExit('Eşleşen sonuç yok.')
    mae=sum(abs(float(r.get('score',0))-float(t['teacher_score'])) for t,r in pairs)/len(pairs)
    within=sum(abs(float(r.get('score',0))-float(t['teacher_score']))<=.5 for t,r in pairs)/len(pairs)
    sim=sum(SequenceMatcher(None,norm(t.get('teacher_read_text')),norm(r.get('readAnswerText'))).ratio() for t,r in pairs)/len(pairs)
    rt=[(b(t.get('should_need_review')),bool(r.get('needsReview',False))) for t,r in pairs]
    tp=sum(a and p for a,p in rt); fn=sum(a and not p for a,p in rt); recall=tp/(tp+fn) if tp+fn else 1.0
    inp=sum(int(r.get('input_tokens',0) or 0) for _,r in pairs)
    candidate_out=sum(int(r.get('candidate_output_tokens', r.get('output_tokens',0)) or 0) for _,r in pairs)
    thoughts=sum(int(r.get('thoughts_tokens',0) or 0) for _,r in pairs)
    billed_out=sum(int(r.get('output_tokens',0) or 0) for _,r in pairs)
    cost=(inp*ip+billed_out*op)/1_000_000*batch
    dataset_classes={str(t.get('dataset_class','')).strip() for t,_ in pairs}
    categories={str(t.get('category','')).strip() for t,_ in pairs if str(t.get('category','')).strip()}
    grade_bands={str(t.get('grade_band','')).strip() for t,_ in pairs if str(t.get('grade_band','')).strip()}
    unique_cases={str(t.get('case_id','')).strip() for t,_ in pairs if str(t.get('case_id','')).strip()}
    coverage=(len(categories)>=5 and len(grade_bands)>=2 and bool(categories & {'difficult_handwriting','low_image_quality'}) and 'correction_erasures' in categories and 'turkish_diacritics' in categories)
    return {'cases':len(unique_cases),'items':len(pairs),'mae':mae,'within':within,'sim':sim,'recall':recall,'input_tokens':inp,'candidate_output_tokens':candidate_out,'thoughts_tokens':thoughts,'billed_output_tokens':billed_out,'cost':cost,'dataset_classes':dataset_classes,'coverage':coverage,'categories':categories,'grade_bands':grade_bands}

ap=argparse.ArgumentParser()
ap.add_argument('manifest'); ap.add_argument('candidate'); ap.add_argument('--baseline')
ap.add_argument('--candidate-input-price',type=float,default=0); ap.add_argument('--candidate-output-price',type=float,default=0); ap.add_argument('--candidate-batch-factor',type=float,default=1)
ap.add_argument('--baseline-input-price',type=float,default=0); ap.add_argument('--baseline-output-price',type=float,default=0); ap.add_argument('--baseline-batch-factor',type=float,default=1)
ap.add_argument('--candidate-model'); ap.add_argument('--high-image-tokens',type=int,default=1120)
ap.add_argument('--supports-high-media',type=int,choices=[0,1],default=1); ap.add_argument('--supports-batch',type=int,choices=[0,1],default=1); ap.add_argument('--supports-cache',type=int,choices=[0,1],default=1); ap.add_argument('--supports-thinking',type=int,choices=[0,1],default=1)
a=ap.parse_args()
t=load_truth(a.manifest); c=metrics(t,load_results(a.candidate),a.candidate_input_price,a.candidate_output_price,a.candidate_batch_factor)
for k,v in c.items():
    if k=='dataset_classes': print('candidate_dataset_classes='+','.join(sorted(v)))
    elif k in {'categories','grade_bands'}: print('candidate_'+k+'='+','.join(sorted(v)))
    elif k=='coverage': print('candidate_coverage=' + ('PASS' if v else 'FAIL'))
    else: print(f'candidate_{k}={v:.4f}' if isinstance(v,float) else f'candidate_{k}={v}')
quality=c['cases']>=20 and c['coverage'] and c['within']>=.95 and c['sim']>=.90 and c['recall']>=.95
real_only=c['dataset_classes']=={REAL_DATASET}
if a.baseline:
    bline=metrics(t,load_results(a.baseline),a.baseline_input_price,a.baseline_output_price,a.baseline_batch_factor)
    for k,v in bline.items():
        if k!='dataset_classes': print(f'baseline_{k}={v:.4f}' if isinstance(v,float) else f'baseline_{k}={v}')
    adopt=quality and real_only and c['mae']<=bline['mae']+.10 and c['cost']<=bline['cost']
else: adopt=quality and real_only
decision='ADOPT' if adopt else ('BLOCKED_DATASET' if quality and not real_only else 'KEEP_BASELINE')
print('decision=' + decision)
if adopt and a.candidate_model:
    ts=int(time.time()); expires=ts+180*24*60*60
    prompt_sha, schema_sha, engine_rev = fingerprints_for_role('EVALUATION')
    payload=(f'BNBENCH4|model={a.candidate_model.strip()}|role=EVALUATION|protocol=BN-EVAL-B|cases={c["cases"]}'
             f'|within={c["within"]:.6f}|sim={c["sim"]:.6f}|recall={c["recall"]:.6f}|mae={c["mae"]:.6f}'
             f'|dataset={REAL_DATASET}|coverage=PASS|highTokens={a.high_image_tokens}|highMedia={a.supports_high_media}|batch={a.supports_batch}|cache={a.supports_cache}|thinking={a.supports_thinking}'
             f'|promptPolicySha256={prompt_sha}|responseSchemaSha256={schema_sha}|evaluationEngineRevision={engine_rev}'
             f'|decision=ADOPT|ts={ts}|expires={expires}')
    print('approval_candidate=' + payload)
    print('approval_status=UNSIGNED_CANDIDATE_REQUIRES_DEVELOPER_ECDSA_SIGNATURE')
