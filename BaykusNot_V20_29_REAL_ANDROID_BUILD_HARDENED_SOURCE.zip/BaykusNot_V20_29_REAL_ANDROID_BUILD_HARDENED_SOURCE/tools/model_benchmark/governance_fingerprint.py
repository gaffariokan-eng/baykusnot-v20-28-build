#!/usr/bin/env python3
"""Source-bound BNBENCH4 governance fingerprints shared by benchmark scorers/signing QA."""
from __future__ import annotations
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

ROLE_FILES = {
    "EVALUATION": {
        "prompt": ["app/src/main/java/com/example/core/network/EvaluationPromptPolicy.kt"],
        "schema": ["app/src/main/java/com/example/core/network/HttpGeminiExamEvaluator.kt"],
        "revision": "BN-EVAL-ENGINE-V20.29",
    },
    "FEEDBACK": {
        "prompt": ["app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt"],
        "schema": ["app/src/main/java/com/example/core/network/HttpGeminiStudentFeedbackWriter.kt"],
        "revision": "BN-FEEDBACK-ENGINE-V20.29",
    },
    "AUTHORING": {
        "prompt": [
            "app/src/main/java/com/example/core/network/ExtractionPromptPolicy.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamQuestionExtractor.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamScenarioExtractor.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiQuestionObjectiveMatcher.kt",
        ],
        "schema": [
            "app/src/main/java/com/example/core/network/ExtractionPromptPolicy.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamQuestionExtractor.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamRubricGenerator.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiExamScenarioExtractor.kt",
            "app/src/main/java/com/example/core/network/HttpGeminiQuestionObjectiveMatcher.kt",
        ],
        "revision": "BN-AUTHOR-ENGINE-V20.29",
    },
}

def _fingerprint(label: str, relative_paths: list[str]) -> str:
    h = hashlib.sha256()
    h.update(label.encode("utf-8")); h.update(b"\0")
    for rel in sorted(relative_paths):
        p = ROOT / rel
        if not p.is_file():
            raise FileNotFoundError(f"Benchmark fingerprint source missing: {p}")
        # Match Gradle's substringAfter(rootProject.projectDir.path): leading slash retained.
        normalized = "/" + rel.replace("\\", "/").lstrip("/")
        h.update(normalized.encode("utf-8")); h.update(b"\0")
        h.update(p.read_bytes()); h.update(b"\0")
    return h.hexdigest()

def fingerprints_for_role(role: str) -> tuple[str, str, str]:
    role = role.strip().upper()
    cfg = ROLE_FILES[role]
    return (
        _fingerprint(f"{role}_PROMPT", cfg["prompt"]),
        _fingerprint(f"{role}_SCHEMA", cfg["schema"]),
        cfg["revision"],
    )

if __name__ == "__main__":
    for role in ("EVALUATION", "FEEDBACK", "AUTHORING"):
        prompt, schema, rev = fingerprints_for_role(role)
        print(f"{role}.promptPolicySha256={prompt}")
        print(f"{role}.responseSchemaSha256={schema}")
        print(f"{role}.evaluationEngineRevision={rev}")
