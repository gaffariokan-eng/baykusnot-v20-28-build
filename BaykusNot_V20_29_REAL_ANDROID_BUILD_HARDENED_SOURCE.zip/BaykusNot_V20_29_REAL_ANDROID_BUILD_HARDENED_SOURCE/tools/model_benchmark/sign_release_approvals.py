#!/usr/bin/env python3
"""Sign one-or-more BNBENCH4 candidate payloads and emit build-time release variables."""
import argparse, base64
from pathlib import Path
from approval_signing import sign_payload, public_key_b64
from governance_fingerprint import fingerprints_for_role

ap=argparse.ArgumentParser()
ap.add_argument('--private-key', required=True, help='External PEM ECDSA P-256 private key; NEVER commit it.')
ap.add_argument('candidate_files', nargs='+', help='Text files containing approval_candidate=BNBENCH4|... lines')
ap.add_argument('--out-manifest', required=True)
a=ap.parse_args()
records=[]
for f in a.candidate_files:
    for line in Path(f).read_text(encoding='utf-8').splitlines():
        if line.startswith('approval_candidate='):
            payload=line.split('=',1)[1].strip()
            if not payload.startswith('BNBENCH4|'):
                raise SystemExit(f'{f}: BNBENCH4 candidate bulunamadı')
            kv={}
            for item in payload.split('|')[1:]:
                if '=' in item:
                    k,v=item.split('=',1); kv[k]=v
            role=kv.get('role','').upper()
            try:
                prompt_sha, schema_sha, engine_rev = fingerprints_for_role(role)
            except Exception as exc:
                raise SystemExit(f'{f}: bilinmeyen/bozuk rol: {role}: {exc}')
            if (kv.get('promptPolicySha256') != prompt_sha or
                kv.get('responseSchemaSha256') != schema_sha or
                kv.get('evaluationEngineRevision') != engine_rev):
                raise SystemExit(f'{f}: candidate bu kaynak ağacının prompt/schema/engine fingerprintiyle eşleşmiyor; benchmark yeniden çalıştırılmalı.')
            records.append(sign_payload(payload,a.private_key))
if not records:
    raise SystemExit('İmzalanacak approval_candidate bulunamadı.')
manifest='\n'.join(records)+'\n'
Path(a.out_manifest).write_text(manifest,encoding='utf-8')
print('BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64='+public_key_b64(a.private_key))
print('BAYKUS_MODEL_APPROVAL_MANIFEST_B64='+base64.b64encode(manifest.encode()).decode())
