#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8',errors='ignore')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
paper=t('app/src/main/java/com/example/core/data/ExamPaperUploadRepository.kt')
batch=t('app/src/main/java/com/example/core/network/GeminiBatchJobManager.kt')
delete=t('app/src/main/java/com/example/core/data/ExamDeletionRepository.kt')
dbcrypto=t('app/src/main/java/com/example/core/database/DatabaseEncryptionManager.kt')
img=t('app/src/main/java/com/example/core/security/StudentImageCrypto.kt')
gateway=t('app/src/main/java/com/example/core/network/GeminiProductionSecurityInterceptor.kt')
session=t('app/src/main/java/com/example/core/network/GatewaySessionManager.kt')
enroll=t('app/src/main/java/com/example/core/security/GatewayEnrollmentStore.kt')
yazek=t('app/src/main/java/com/example/core/security/YazekComplianceStore.kt')
provider=t('app/src/main/java/com/example/core/security/ProviderDataProtectionProfile.kt')
app=t('app/src/main/java/com/example/core/data/AppContainer.kt')
reports=t('app/src/main/java/com/example/feature/workflow/ReportsViewModel.kt')
settings=t('app/src/main/java/com/example/feature/settings/ApiKeySettingsViewModel.kt')
checks={
 'repo_rejects_non_ready_papers': 'paper.status != "READY"' in repo,
 'repo_revalidates_identity_at_ai_boundary': 'validateStudentIdentity(paper.classLevel, paper.branch, paper.schoolNumber)' in repo,
 'yazek_branches_only_from_verified_ready_papers': 'eligiblePapers.size == allPapers.size' in repo and 'val branches = eligiblePapers' in repo,
 'sqlcipher_recovers_missing_active_from_backup_or_temp': 'recoverInterruptedMigration' in dbcrypto and '!databaseFile.exists() && encryptedTemp.exists()' in dbcrypto and '!databaseFile.exists() && plaintextBackup.exists()' in dbcrypto,
 'sqlcipher_fails_closed_on_plaintext_residue': 'requirePlaintextArtifactsRemoved' in dbcrypto and 'deleteIfPresentOrFail(plaintextBackup' in dbcrypto,
 'remote_batch_delete_is_confirmed': 'remoteDeleteBatch' in batch and 'it.isSuccessful || it.code == 404' in batch,
 'remote_file_delete_is_confirmed': 'remoteDeleteFileConfirmed' in batch and 'it.isSuccessful || it.code == 404' in batch,
 'remote_cleanup_failure_keeps_retryable_resource_ids': 'REMOTE_DELETE_PENDING' in batch and 'outputFileResourceName' in batch and 'cleanupLastError' in batch,
 'batch_cleanup_ledger_is_atomic_crash_safe': 'AtomicFile(file)' in batch and 'startWrite()' in batch and 'finishWrite' in batch and 'failWrite' in batch,
 'deleted_exam_can_leave_only_remote_cleanup_ledger': 'pendingRemoteBatchRecords' in delete and 'cleanupDraft(examDraftId, null)' in delete,
 'pending_remote_cleanup_retried_on_startup': 'retryPendingRemoteCleanup' in app,
 'pending_remote_cleanup_retried_after_gateway_enrollment': 'retryPendingRemoteCleanup' in settings and 'geminiBatchJobManager' in settings,
 'gateway_has_real_enrollment_to_short_session_path': '/baykusnot/v1/session' in session and 'Enrollment $enrollment' in session,
 'gateway_failed_enrollment_is_rolled_back': 'previousEnrollment' in session and 'enrollmentStore.clear()' in session and 'enrollmentStore.save(previousEnrollment)' in session,
 'gateway_access_token_is_ram_only_and_expiring': 'expiresAtEpochMs' in t('app/src/main/java/com/example/core/security/GatewayAuthTokenStore.kt') and 'SharedPreferences' not in t('app/src/main/java/com/example/core/security/GatewayAuthTokenStore.kt'),
 'gateway_refreshes_before_request_and_on_401': 'validTokenOrRefresh' in gateway and 'first.code != 401' in gateway and 'ensureValidSession' in gateway,
 'gateway_enrollment_is_keystore_encrypted': 'AndroidKeyStore' in enroll and 'AES/GCM/NoPadding' in enroll,
 'manual_transition_awaits_cancel_before_rewrite': 'stopEvaluationAndAwait(examDraftId, cleanupRemoteBatch = true)' in repo and 'cancelAndJoin' in repo,
 'manual_transition_cleans_remote_batch_or_marks_pending': 'remoteCleanupPendingCounts' in repo and 'cleanupDraft(examDraftId, key)' in repo,
 'partial_local_image_delete_is_reported_not_hidden': 'AnswerImageCleanupResult' in paper and 'cleanup.failed' in reports and 'answerImagesPresent = !fullyDeleted' in reports,
 'legacy_plaintext_image_cannot_be_used_if_upgrade_fails': 'Legacy plaintext öğrenci görüntüsü güvenli biçimde şifrelenemedi' in img and 'bitmap.recycle()' in img,
 'provider_retention_dataset_access_policy_is_fail_closed': 'validationProblems' in provider and 'datasetSharingDisabled' in provider and 'accessRoles' in provider,
 'provider_policy_change_invalidates_yazek_fingerprint': 'providerPolicySignature.trim()' in yazek and 'providerProfile.signature()' in repo,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
failed=[k for k,v in checks.items() if not v]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
