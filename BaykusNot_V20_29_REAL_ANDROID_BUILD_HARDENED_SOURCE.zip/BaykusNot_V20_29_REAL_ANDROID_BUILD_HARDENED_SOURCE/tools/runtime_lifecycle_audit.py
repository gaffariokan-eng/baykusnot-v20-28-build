#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
def t(path):
    return (ROOT / path).read_text(encoding='utf-8', errors='ignore')
def pos(text, needle):
    return text.find(needle)
def ordered(text, *needles):
    ps=[pos(text,n) for n in needles]
    return all(p >= 0 for p in ps) and ps == sorted(ps)

batch=t('app/src/main/java/com/example/core/network/GeminiBatchJobManager.kt')
cache=t('app/src/main/java/com/example/core/network/GeminiCacheManager.kt')
delete=t('app/src/main/java/com/example/core/data/ExamDeletionRepository.kt')
mask=t('app/src/main/java/com/example/core/security/HomeworkPrivacyMaskStore.kt')
crypto=t('app/src/main/java/com/example/core/security/StudentImageCrypto.kt')
upload_repo=t('app/src/main/java/com/example/core/data/ExamPaperUploadRepository.kt')
upload_ui=t('app/src/main/java/com/example/feature/workflow/UploadPapersScreen.kt')
settings=t('app/src/main/java/com/example/feature/settings/ApiKeySettingsViewModel.kt')
session=t('app/src/main/java/com/example/core/network/GatewaySessionManager.kt')
interceptor=t('app/src/main/java/com/example/core/network/GeminiProductionSecurityInterceptor.kt')
manifest=t('app/src/main/AndroidManifest.xml')
roomtest=t('app/src/androidTest/java/com/example/core/database/RoomSchemaAssetInstrumentedTest.kt')
build=t('app/build.gradle.kts')
bat=t('BAYKUSNOT_BUILD_V20_29_RELEASE_APK.bat')
env=t('.env.example')
all_tests='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (ROOT/'app/src').rglob('*.kt'))

checks={
 'batch_cancel_precedes_terminal_recheck_and_operation_delete': (lambda seg: ordered(seg, 'remoteCancel(meta.jobId, apiKey)', 'snapshot = remoteGetBatchSnapshot(meta.jobId, apiKey)', 'val operationDeleted ='))(batch[batch.find('if (snapshot.exists && !snapshot.terminal)'):batch.find('suspend fun retryPendingRemoteCleanup')]),
 'batch_files_deleted_before_operation_record': ordered(batch,
     'val inputDeleted =', 'val outputDeleted =', 'val operationDeleted ='),
 'batch_operation_not_deleted_while_nonterminal': 'if (!batchTerminal)' in batch and 'continue' in batch[batch.find('if (!batchTerminal)'):batch.find('if (!batchTerminal)')+300],
 'batch_output_id_persisted_before_download': ordered(batch,
     'Persist output resource before download', ':download?alt=media'),
 'batch_current_file_and_inline_outputs_supported': 'responsesFile' in batch and 'findInlineResponses' in batch and 'direct["inlinedResponses"]' in batch,
 'batch_remote_failure_retains_resource_identity': 'REMOTE_DELETE_PENDING' in batch and 'retained += meta.pendingCleanup' in batch,
 'prompt_cache_creation_has_compensating_delete_on_ledger_failure': ordered(cache,
     'saveRecords(updatedRecords)', 'remoteDeleteCacheResource(resourceName, apiKey)'),
 'prompt_cache_failed_delete_stays_pending': 'cleanupStatus = "REMOTE_DELETE_PENDING"' in cache and 'retryPendingRemoteCleanup' in cache,
 'gateway_enrollment_retries_batch_and_prompt_cache': 'geminiBatchJobManager?.retryPendingRemoteCleanup' in settings and 'geminiCacheManager?.retryPendingRemoteCleanup' in settings,
 'exam_delete_remote_tracking_precedes_durable_delete_intent': ordered(delete,
     'credentialCleanup', 'deletionJournal.prepare(examDraftId, pageIds)', 'draftRepository.deleteDraftById(examDraftId)'),
 'exam_delete_db_commit_precedes_destructive_local_cleanup': ordered(delete,
     'draftRepository.deleteDraftById(examDraftId)', 'deletionJournal.markCommitted(examDraftId)', 'cleanupCommittedDeletion(examDraftId, pageIds)'),
 'exam_delete_uses_durable_mask_removal': 'fun clearDurably' in mask and '.commit()' in mask,
 'student_image_ciphertext_commit_is_atomic': 'AtomicFile(file)' in crypto and 'startWrite()' in crypto and 'finishWrite' in crypto and 'failWrite' in crypto,
 'camera_temp_plaintext_process_death_safe_and_scrubbed': 'CameraCaptureJournal.currentCapture(context)' in upload_ui and 'CameraCaptureJournal.scrubPlaintext(file)' in upload_ui and 'CameraCaptureJournal.prepareCapture(context)' in upload_ui,
 'camera_plaintext_removed_before_db_registration': (lambda seg: ordered(seg, 'CameraCaptureJournal.scrubPlaintext(imageFile)', 'saveAndRegisterPage('))(upload_repo[upload_repo.find('suspend fun processCameraImageFile'):upload_repo.find('private fun decodeUriRespectingExif')]),
 'release_gateway_transport_is_https_only': 'android:usesCleartextTraffic="false"' in manifest and 'scheme != "https"' in session and 'scheme != "https"' in interceptor and 'BAYKUS_AI_GATEWAY_URL:~0,8' in bat,
 'gateway_session_has_expiring_token_and_401_refresh': 'expiresInSeconds' in session and 'ensureValidSession' in interceptor and 'first.code != 401' in interceptor,
 'production_env_does_not_request_mobile_gemini_secret': 'GEMINI_API_KEY=' not in env and 'BAYKUS_AI_GATEWAY_URL=https://' in env,
 'room_25_to_30_chain_is_executed_in_instrumented_test': all(x in roomtest for x in ['MIGRATION_25_26.migrate(db)','MIGRATION_26_27.migrate(db)','MIGRATION_27_28.migrate(db)','MIGRATION_28_29.migrate(db)','MIGRATION_29_30.migrate(db)']),
 'acceptance_tests_have_no_dummy_or_ignore_shortcuts': 'dummyTest' not in all_tests and '@Ignore' not in all_tests,
 'v20_29_installable_version_and_marker': 'versionCode = 30' in build and 'versionName = "1.27-v20.29"' in build and (ROOT/'BAYKUSNOT_SOURCE_V20_29_REAL_ANDROID_BUILD_HARDENED.marker').exists(),
}

failed=[]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
    if not ok: failed.append(name)
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
