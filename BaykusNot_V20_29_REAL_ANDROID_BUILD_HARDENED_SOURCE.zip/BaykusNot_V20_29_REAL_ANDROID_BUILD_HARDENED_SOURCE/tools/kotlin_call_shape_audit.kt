import com.intellij.openapi.util.Disposer
import com.intellij.psi.util.PsiTreeUtil
import org.jetbrains.kotlin.cli.common.CLIConfigurationKeys
import org.jetbrains.kotlin.cli.common.messages.MessageCollector
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment
import org.jetbrains.kotlin.config.CompilerConfiguration
import org.jetbrains.kotlin.psi.*
import java.io.File

data class Param(val name:String, val hasDefault:Boolean, val isVararg:Boolean)
data class Klass(val path:String, val simple:String, val pkg:String, val params:List<Param>, val file:String)
fun classPath(c:KtClass):String { val outer=generateSequence(c.parent){it.parent}.filterIsInstance<KtClass>().firstOrNull(); return if(outer==null)(c.name?:"<anon>") else classPath(outer)+"."+(c.name?:"<anon>") }
fun callPath(call:KtCallExpression):String { val callee=call.calleeExpression?.text?:return ""; val p=call.parent; return if(p is KtDotQualifiedExpression && p.selectorExpression==call) p.receiverExpression.text+"."+callee else callee }
fun main(args:Array<String>){
 val root=File(args[0]); val files=root.walkTopDown().filter{it.isFile&&it.extension=="kt"}.toList().sortedBy{it.path}; val disp=Disposer.newDisposable()
 try{
  val cfg=CompilerConfiguration(); cfg.put(CLIConfigurationKeys.MESSAGE_COLLECTOR_KEY,MessageCollector.NONE); val env=KotlinCoreEnvironment.createForProduction(disp,cfg,EnvironmentConfigFiles.JVM_CONFIG_FILES); val fac=KtPsiFactory(env.project,false)
  val parsed=files.associateWith{fac.createFile(it.name,it.readText())}; val classes=mutableListOf<Klass>()
  for((f,psi) in parsed) for(c in PsiTreeUtil.collectElementsOfType(psi,KtClass::class.java)){ val n=c.name?:continue; if(c.isInterface()) continue; classes+=Klass(classPath(c),n,psi.packageFqName.asString(),c.primaryConstructorParameters.mapNotNull{p->p.name?.let{Param(it,p.hasDefaultValue(),p.isVarArg)}},f.relativeTo(root).path)}
  var checked=0; var failed=0
  for((f,psi) in parsed){ val pkg=psi.packageFqName.asString(); val imports=psi.importDirectives.mapNotNull{it.importPath?.pathStr}.toSet(); val doc=psi.viewProvider.document
   for(call in PsiTreeUtil.collectElementsOfType(psi,KtCallExpression::class.java)){
    if(call.lambdaArguments.isNotEmpty()) continue; val cp=callPath(call); val simple=call.calleeExpression?.text?:continue; val argsL=call.valueArguments; if(argsL.isEmpty())continue
    var candidates=classes.filter{k-> k.path==cp || k.path.endsWith(".$cp")}
    if(!cp.contains('.')) candidates=candidates.filter{k-> k.pkg==pkg || (k.pkg+"."+k.path) in imports || (k.pkg+"."+k.simple) in imports || (k.pkg+".*") in imports}
    if(candidates.isEmpty())continue
    val named=argsL.mapNotNull{it.getArgumentName()?.asName?.asString()}.toSet(); val viable=candidates.filter{k->
      val names=k.params.map{it.name}.toSet(); if(!names.containsAll(named)) return@filter false
      val positional=argsL.count{it.getArgumentName()==null}; if(positional>k.params.size && k.params.none{it.isVararg}) return@filter false
      val covered=k.params.take(positional).map{it.name}.toMutableSet(); covered+=named
      k.params.filter{!it.hasDefault&&!it.isVararg}.all{it.name in covered}
    }
    val unambiguous = cp.contains('.') || candidates.size==1; if(!unambiguous)continue; checked++
    if(viable.isEmpty()){failed++; val off=call.textRange.startOffset; val line=doc?.getLineNumber(off)?.plus(1)?:-1; println("FAIL | ${f.relativeTo(root).path}:$line | $cp | named=${named.sorted()} | candidates="+candidates.joinToString{it.pkg+"."+it.path+it.params.map{p->p.name}})}
   }
  }
  println("SUMMARY: ${checked-failed}/${checked} constructor/factory call-shapes PASS"); if(failed>0)kotlin.system.exitProcess(1)
 }finally{Disposer.dispose(disp)}
}
