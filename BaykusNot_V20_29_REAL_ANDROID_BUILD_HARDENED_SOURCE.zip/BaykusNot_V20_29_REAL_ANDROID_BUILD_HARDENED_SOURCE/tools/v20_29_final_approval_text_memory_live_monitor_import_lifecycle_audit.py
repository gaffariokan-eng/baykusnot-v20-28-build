from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]

def t(rel): return (ROOT/rel).read_text(encoding='utf-8')
checks=[]
def ck(name, cond):
    ok=bool(cond); checks.append(ok); print(('PASS' if ok else 'FAIL')+' | '+name)

vm=t('app/src/main/java/com/example/feature/workflow/AiEvaluationViewModel.kt')
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
dao=t('app/src/main/java/com/example/core/database/ExamEvaluationDao.kt')
src=t('app/src/main/java/com/example/core/data/ExamSourceDocumentRepository.kt')
upload=t('app/src/main/java/com/example/feature/workflow/UploadSourceRoute.kt')
uploadvm=t('app/src/main/java/com/example/feature/workflow/UploadSourceViewModel.kt')
selected=t('app/src/main/java/com/example/core/data/SelectedPdfSource.kt')
build=t('app/build.gradle.kts')
active=t('tools/ACTIVE_AUDITS.md')
governance=t('tools/model_benchmark/governance_fingerprint.py')

# Live monitor: durable Room model must not be fetched unconditionally every 500ms.
monitor=vm[vm.find('// Periodic monitor for in-memory progress'):vm.find('// Combine flows for realtime live monitoring')]
loop=monitor[monitor.find('while (true)'):]
ck('Locked model initialized outside hot loop', 'var lockedModel = evaluationRepository.getLockedEvaluationModel(examDraftId)' in monitor and monitor.find('var lockedModel') < monitor.find('while (true)'))
ck('Locked model refresh only on run transition', 'if (evaluating && !wasEvaluating)' in loop and 'lockedModel = evaluationRepository.getLockedEvaluationModel(examDraftId)' in loop)
ck('No unconditional locked-model val inside loop', 'val lockedModel = evaluationRepository.getLockedEvaluationModel(examDraftId)' not in loop)
ck('Idle monitor still uses in-memory progress state', all(x in loop for x in ['isEvaluating(examDraftId)','getProgress(examDraftId)','getCurrentEvaluatingPaperId(examDraftId)']))

# Final approval compare-and-commit.
confirm=repo[repo.find('suspend fun validateAndConfirmAllResults'):]
trans=dao[dao.find('suspend fun confirmAllStudentResultsIfSnapshotMatches'):dao.find('@Insert(onConflict = OnConflictStrategy.ABORT)', dao.find('suspend fun confirmAllStudentResultsIfSnapshotMatches'))]
ck('Approval loads exam-wide question snapshot once', 'getQuestionEvaluationsForExamOnce(examDraftId)' in confirm and 'groupBy { it.studentPaperId }' in confirm)
ck('Approval loop has no per-paper Room question query', 'getQuestionEvaluationsForPaperOnce(paper.id)' not in confirm)
ck('Approval uses snapshot transaction', 'confirmAllStudentResultsIfSnapshotMatches(' in confirm)
ck('Approval transaction stage-gated', 'getWorkflowStageForApproval(examDraftId) != "TEACHER_REVIEW"' in trans)
ck('Approval transaction rechecks open review requests', 'getReviewRequestsForExam(examDraftId).any { it.status == "OPEN" }' in trans)
ck('Approval transaction compares student snapshot', 'currentStudents != expectedStudentRows' in trans)
ck('Approval transaction compares question snapshot', 'currentQuestions != expectedQuestions' in trans)
ck('Approval transaction validates update identity set', 'updates.map { it.studentPaperId }.toSet()' in trans)
ck('Approval stale snapshot fails closed', 'if (!committed)' in confirm and 'eski snapshot onaylanmadı' in confirm)
ck('Legacy weak confirm transaction removed', 'confirmAllStudentResultsTransaction' not in dao and 'confirmAllStudentResultsTransaction' not in repo)

# Text memory bounds.
ck('Homework text source uses bounded reader', 'BoundedInputReader.readFile(file, BoundedInputReader.MAX_TEXT_BYTES' in src)
ck('Homework source repository has no whole-file readText', 'file.readText(' not in src)
ck('Text import declared-size cap is 2 MB', 'if (mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES.toLong() else MAX_SOURCE_SIZE_BYTES' in src)
ck('Text import stream enforces MIME-specific cap', 'actualSizeBytes > maxImportBytes' in src)
ck('Stored text usability cap is 2 MB', 'documentMaxBytes = if (document.mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES.toLong()' in src)
ck('Managed text bytes use 2 MB cap', 'if (document.mimeType == TEXT_MIME_TYPE) BoundedInputReader.MAX_TEXT_BYTES else BoundedInputReader.MAX_DOCUMENT_BYTES' in src)
ck('Import copy loop cooperates with cancellation', 'currentCoroutineContext().ensureActive()' in src)
ck('Import cancellation deletes temp and propagates', 'catch (e: CancellationException) {\n            tempFile.delete()\n            throw e' in src)
ck('Import checks cancellation before permanent move', src.find('currentCoroutineContext().ensureActive()', src.find('while (permFile.exists()')) < src.find('val moved = try', src.find('while (permFile.exists()')))
ck('Permanent move to DB ownership commit is NonCancellable', 'withContext(NonCancellable)' in src and src.find('withContext(NonCancellable)') > src.find('val moved = try'))
ck('Old file cleanup occurs only after new DB upsert', src.find('sourceDocumentDao.upsert(newDocument)') < src.find('Best-effort delete the superseded old file'))

# Multi-image / import lifecycle.
ck('Multi-image resolver is suspend', 'internal suspend fun handleSelectedUris(' in upload)
ck('Multi-image build checks coroutine cancellation', upload.count('coroutineContext.ensureActive()') >= 3)
ck('Temporary ZIP exposes explicit cleanup ownership', 'cleanup = { tempZip.delete() }' in upload and 'val cleanup: () -> Unit = {}' in selected)
ck('Temporary ZIP cancellation deletes file and rethrows', 'catch (e: CancellationException) {\n            tempZip.delete()\n            throw e' in upload)
ck('Multiple scenario files rejected instead of ZIP-as-text', 'pickingScenario && uris.size > 1' in upload and 'Senaryo için tek bir PDF veya görsel seçin.' in upload)
ck('Source import job is tracked', 'private var sourceImportJob: Job? = null' in uploadvm)
ck('Stage/dispose cancellation includes source import', 'sourceImportJob?.cancel()' in uploadvm)
ck('Import completion invokes temp cleanup hook', 'onFinished?.invoke()' in uploadvm and 'onFinished = selected.cleanup' in upload)
ck('Import CancellationException is rethrown', 'catch (e: CancellationException) {\n                throw e' in uploadvm)

# QA/version identity.
ck('V20.29 app version active', 'versionCode = 30' in build and 'versionName = "1.27-v20.29"' in build)
ck('V20.29 engine fingerprints active', all(x in build for x in ['BN-EVAL-ENGINE-V20.29','BN-FEEDBACK-ENGINE-V20.29','BN-AUTHOR-ENGINE-V20.29']))
ck('Benchmark fingerprint helper is V20.29-bound', all(x in governance for x in ['BN-EVAL-ENGINE-V20.29','BN-FEEDBACK-ENGINE-V20.29','BN-AUTHOR-ENGINE-V20.29']) and 'ENGINE-V20.27' not in governance)
ck('V20.29 marker exists', (ROOT/'BAYKUSNOT_SOURCE_V20_29_REAL_ANDROID_BUILD_HARDENED.marker').exists())
ck('V20.29 local build script exists', (ROOT/'BAYKUSNOT_BUILD_V20_29_LOCAL_TEST_ONLY.bat').exists())
ck('V20.29 release build script exists', (ROOT/'BAYKUSNOT_BUILD_V20_29_RELEASE_APK.bat').exists())
ck('Active audit manifest is V20.29', active.startswith('# V20.29 Active Audits') and 'tools/v20_29_*.py' in active)
ck('Active audit manifest retires V20.28', 'V20.28 ve daha eski' in active)

ok=sum(checks); total=len(checks)
print(f'\nSUMMARY: {ok}/{total} PASS')
if ok != total: sys.exit(1)
