import com.intellij.openapi.util.Disposer
import com.intellij.psi.PsiErrorElement
import com.intellij.psi.util.PsiTreeUtil
import org.jetbrains.kotlin.cli.common.CLIConfigurationKeys
import org.jetbrains.kotlin.cli.common.messages.MessageCollector
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment
import org.jetbrains.kotlin.config.CompilerConfiguration
import org.jetbrains.kotlin.psi.KtPsiFactory
import java.io.File

fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "root required" }
    val root = File(args[0])
    val files = root.walkTopDown().filter { it.isFile && it.extension == "kt" }.toList().sortedBy { it.path }
    val disposable = Disposer.newDisposable()
    try {
        val config = CompilerConfiguration()
        config.put(CLIConfigurationKeys.MESSAGE_COLLECTOR_KEY, MessageCollector.NONE)
        val env = KotlinCoreEnvironment.createForProduction(disposable, config, EnvironmentConfigFiles.JVM_CONFIG_FILES)
        val factory = KtPsiFactory(env.project, false)
        var failed = 0
        for (f in files) {
            val psi = factory.createFile(f.name, f.readText())
            val errors = PsiTreeUtil.collectElementsOfType(psi, PsiErrorElement::class.java)
            if (errors.isEmpty()) {
                println("PASS | ${f.relativeTo(root).path}")
            } else {
                failed++
                val details = errors.joinToString(" ; ") { e ->
                    val lc = psi.viewProvider.document?.let { d ->
                        val line = d.getLineNumber(e.textRange.startOffset) + 1
                        val col = e.textRange.startOffset - d.getLineStartOffset(line - 1) + 1
                        "$line:$col"
                    } ?: "?:?"
                    "$lc ${e.errorDescription}"
                }
                println("FAIL | ${f.relativeTo(root).path} | $details")
            }
        }
        println("SUMMARY: ${files.size - failed}/${files.size} PASS")
        if (failed > 0) kotlin.system.exitProcess(1)
    } finally {
        Disposer.dispose(disposable)
    }
}
