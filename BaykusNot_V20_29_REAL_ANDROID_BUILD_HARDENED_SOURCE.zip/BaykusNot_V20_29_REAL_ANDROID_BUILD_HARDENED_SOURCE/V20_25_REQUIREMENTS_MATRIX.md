# V20.25 Requirements Matrix

| Gereksinim | Durum | Kanıt |
|---|---|---|
| Uncertain submission sıcak döngü yapmaz | PASS_STATIC | SUBMISSION_UNCERTAIN + bounded backoff |
| Uncertain submission otomatik tekrar gönderilmez | PASS_STATIC | 10 dk fail-closed ERROR |
| AI Evaluation N+1 kaldırıldı | PASS_STATIC | bulk question-evaluation Flow |
| Polling rate-limit/pil dostu | PASS_STATIC | 15→30→60→120 sn |
| Workflow rewind remote Batch'i iptal eder | PASS_STATIC | pauseEvaluationAndCancelRemote boundary |
| Stale Batch sonucu stage değişince yazılmaz | PASS_STATIC | poll stage guard |
| Single-student retry stage guarded | PASS_STATIC | pre-call + pre-commit guards |
| Privacy startup blocker recovery | PASS_STATIC | retry/diagnostic/double-confirm reset |
| Room migration zinciri | PASS_STATIC | 21→30 validator |
| Kotlin parse/call shape | PASS | 322/322; 1571/1571 |
| Gerçek Android Gradle/KSP build | BLOCKED_ENV | services.gradle.org DNS |
