@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title BaykusNot V20.28 Production Release Build

echo ============================================================
echo   BAYKUSNOT V20.28 - FINAL APPROVAL / TEXT MEMORY / LIVE MONITOR / IMPORT LIFECYCLE HARDENED
echo ============================================================
if not exist "BAYKUSNOT_SOURCE_V20_28_FINAL_APPROVAL_TEXT_MEMORY_LIVE_MONITOR_IMPORT_LIFECYCLE_HARDENED.marker" goto :badsource
if not defined BAYKUS_AI_GATEWAY_URL goto :nogateway
if /I not "%BAYKUS_AI_GATEWAY_URL:~0,8%"=="https://" goto :badgateway
if not defined BAYKUS_PROVIDER_RETENTION_DAYS goto :noproviderpolicy
if not "%BAYKUS_PROVIDER_RETENTION_DAYS%"=="0" if not "%BAYKUS_PROVIDER_RETENTION_DAYS%"=="7" if not "%BAYKUS_PROVIDER_RETENTION_DAYS%"=="14" if not "%BAYKUS_PROVIDER_RETENTION_DAYS%"=="28" if not "%BAYKUS_PROVIDER_RETENTION_DAYS%"=="55" goto :noproviderpolicy
if not defined BAYKUS_PROVIDER_DATASET_SHARING_DISABLED goto :noproviderpolicy
if /I not "%BAYKUS_PROVIDER_DATASET_SHARING_DISABLED%"=="true" goto :noproviderpolicy
if not defined BAYKUS_PROVIDER_ACCESS_ROLES goto :noproviderpolicy
if not defined BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64 goto :nomodelapproval
if not defined BAYKUS_MODEL_APPROVAL_MANIFEST_B64 goto :nomodelapproval
if not defined KEYSTORE_PATH goto :nosigning
if not defined STORE_PASSWORD goto :nosigning
if not defined KEY_PASSWORD goto :nosigning
where java >nul 2>nul || goto :nojava
set "JAVA_VERSION="
for /f "tokens=3" %%v in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /C:"java.version ="') do if not defined JAVA_VERSION set "JAVA_VERSION=%%v"
if not defined JAVA_VERSION goto :nojava
for /f "tokens=1 delims=." %%m in ("%JAVA_VERSION%") do set "JAVA_MAJOR=%%m"
if not defined JAVA_MAJOR goto :nojava
set /a JAVA_MAJOR_NUM=%JAVA_MAJOR% >nul 2>nul
if %JAVA_MAJOR_NUM% LSS 17 goto :oldjava
set "SRC=%CD%"
set "SAFE=%LOCALAPPDATA%\BaykusNotBuildV20_28\BaykusNot"
set "OUTAPK=%SRC%\BaykusNot-V20_28-YAZEK-Release.apk"
set "SDK=%LOCALAPPDATA%\Android\Sdk"
if defined ANDROID_SDK_ROOT set "SDK=%ANDROID_SDK_ROOT%"
if defined ANDROID_HOME set "SDK=%ANDROID_HOME%"
set "ANDROID_SDK_ROOT=%SDK%"
set "ANDROID_HOME=%SDK%"
if not exist "%SAFE%" mkdir "%SAFE%" >nul 2>nul
robocopy "%SRC%" "%SAFE%" /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NP /XD ".gradle" "build" "app\build" /XF "local.properties" "BaykusNot-*.apk" "BaykusNot-*.sha256.txt" >nul
if !ERRORLEVEL! GTR 7 goto :copyfail
cd /d "%SAFE%"
set "SDKFWD=%SDK:\=/%"
>local.properties echo sdk.dir=%SDKFWD%
call gradlew.bat --no-daemon --no-configuration-cache --console=plain --stacktrace assembleRelease
if errorlevel 1 goto :buildfail
if not exist "app\build\outputs\apk\release\app-release.apk" goto :buildfail
copy /y "app\build\outputs\apk\release\app-release.apk" "%OUTAPK%" >nul
certutil -hashfile "%OUTAPK%" SHA256 > "%OUTAPK%.sha256.txt" 2>nul
echo SUCCESS: %OUTAPK%
goto :finish
:nogateway
echo HATA: BAYKUS_AI_GATEWAY_URL tanimli degil.
goto :failed
:badgateway
echo HATA: BAYKUS_AI_GATEWAY_URL HTTPS ile baslamalidir.
goto :failed
:noproviderpolicy
echo HATA: Provider veri koruma profili eksik/gecersiz.
goto :failed
:nomodelapproval
echo HATA: Imzali BNBENCH4 release model onayi eksik. Public key + manifest zorunludur.
goto :failed
:nosigning
echo HATA: KEYSTORE_PATH / STORE_PASSWORD / KEY_PASSWORD release imza degiskenleri eksik.
goto :failed
:nojava
echo HATA: Java bulunamadi veya surumu okunamadi. JDK 17+ gerekir.
goto :failed
:oldjava
echo HATA: Java %JAVA_VERSION% bulundu. JDK 17+ gerekir.
goto :failed
:badsource
echo HATA: V20.28 kaynak marker bulunamadi.
goto :failed
:copyfail
echo HATA: Kaynak guvenli build klasorune kopyalanamadi.
goto :failed
:buildfail
echo HATA: assembleRelease basarisiz.
goto :failed
:failed
echo DERLEME TAMAMLANAMADI.
:finish
pause
endlocal
