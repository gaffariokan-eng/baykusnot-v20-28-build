package com.example.core.security

import android.content.Context
import android.graphics.Bitmap
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class StudentImageKeyRecoveryRequiredException(
    message: String,
    cause: Throwable? = null
) : IllegalStateException(message, cause)

class StudentImageIntegrityException(
    message: String,
    cause: Throwable? = null
) : IllegalStateException(message, cause)

/**
 * Encrypts student answer/homework images at rest with an Android Keystore AES-256-GCM key.
 * V20.23: an existing encrypted corpus is never re-keyed silently. Evaluation uses the strict
 * decode path so one unreadable page blocks that student's AI evaluation instead of disappearing.
 */
object StudentImageCrypto {
    private const val KEY_ALIAS = "baykusnot_student_image_key_v1"
    private val MAGIC = byteArrayOf(0x42, 0x4E, 0x4B, 0x49, 0x4D, 0x47, 0x31) // BNKIMG1

    /** Startup health gate: encrypted answer images + missing/unusable Keystore key is recovery-required. */
    fun verifyExistingCorpusKey(context: Context) {
        val root = File(context.filesDir, "paper_uploads")
        if (!root.exists()) return
        val sample = root.walkTopDown().firstOrNull { it.isFile && isEncrypted(it) } ?: return
        // Do not create a replacement key. GCM authentication of one existing record proves the
        // current Keystore alias is at least cryptographically compatible with the stored corpus.
        try {
            val raw = BoundedInputReader.readFile(sample, BoundedInputReader.MAX_ENCRYPTED_IMAGE_BYTES, "Öğrenci görüntüsü")
            val plain = decrypt(raw)
            plain.fill(0)
        } catch (e: StudentImageKeyRecoveryRequiredException) {
            throw e
        } catch (e: Throwable) {
            throw StudentImageKeyRecoveryRequiredException(
                "Öğrenci cevap görüntülerinin şifreleme anahtarı mevcut kayıtları açamıyor. Görüntüler korunuyor; yeni anahtar üretilmedi.",
                e
            )
        }
    }

    fun writeBitmap(file: File, bitmap: Bitmap, quality: Int = 88) {
        val jpeg = ByteArrayOutputStream().use { out ->
            check(bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) { "Görüntü JPEG'e dönüştürülemedi." }
            out.toByteArray()
        }
        try {
            writeEncrypted(file, jpeg)
        } finally {
            jpeg.fill(0)
        }
    }

    /** Strict evaluation path. Missing/corrupt/undecryptable pages are explicit errors, never null. */
    fun decodeBitmapStrict(path: String): Bitmap {
        val file = File(path)
        if (!file.exists() || !file.isFile) {
            throw StudentImageIntegrityException("Öğrenci görüntü dosyası bulunamadı.")
        }
        val raw = try {
            BoundedInputReader.readFile(file, BoundedInputReader.MAX_ENCRYPTED_IMAGE_BYTES, "Öğrenci görüntüsü")
        } catch (e: Throwable) {
            throw StudentImageIntegrityException("Öğrenci görüntüsü güvenli biçimde okunamadı.", e)
        }
        return try {
            if (raw.startsWithMagic()) {
                val plain = try { decrypt(raw) } catch (e: StudentImageKeyRecoveryRequiredException) { throw e }
                try {
                    SafeBitmapDecoder.decodeByteArray(plain)
                        ?: throw StudentImageIntegrityException("Şifreli öğrenci görüntüsü çözüldü ancak görüntü biçimi okunamadı.")
                } finally {
                    plain.fill(0)
                }
            } else {
                val bitmap = SafeBitmapDecoder.decodeByteArray(raw)
                    ?: throw StudentImageIntegrityException("Öğrenci görüntüsü çözümlenemedi.")
                try {
                    writeEncrypted(file, raw)
                    check(isEncrypted(file)) { "Legacy öğrenci görüntüsü şifreli biçimde doğrulanamadı." }
                } catch (error: Throwable) {
                    bitmap.recycle()
                    when (error) {
                        is StudentImageKeyRecoveryRequiredException -> throw error
                        else -> throw StudentImageIntegrityException(
                            "Legacy plaintext öğrenci görüntüsü güvenli biçimde şifrelenemedi; kullanım durduruldu.",
                            error
                        )
                    }
                }
                bitmap
            }
        } finally {
            raw.fill(0)
        }
    }

    /** Lenient UI preview path. Evaluation must never use this function. */
    fun decodeBitmap(path: String): Bitmap? = runCatching { decodeBitmapStrict(path) }.getOrNull()

    /** Small decode path for list/grid thumbnails. */
    fun decodeThumbnail(path: String, maxDimension: Int = 512): Bitmap? {
        val file = File(path)
        if (!file.exists() || !file.isFile) return null
        return runCatching {
            val raw = BoundedInputReader.readFile(file, BoundedInputReader.MAX_ENCRYPTED_IMAGE_BYTES, "Öğrenci görüntüsü")
            try {
                val encoded = if (raw.startsWithMagic()) decrypt(raw) else raw
                try {
                    val bitmap = SafeBitmapDecoder.decodeByteArray(
                        encoded,
                        maxDecodePixels = 400_000L,
                        maxDecodeDimension = maxDimension.coerceIn(128, 768)
                    ) ?: return@runCatching null
                    if (!raw.startsWithMagic()) {
                        try {
                            writeEncrypted(file, raw)
                            check(isEncrypted(file)) { "Legacy öğrenci görüntüsü şifreli biçimde doğrulanamadı." }
                        } catch (error: Throwable) {
                            bitmap.recycle()
                            throw error
                        }
                    }
                    bitmap
                } finally {
                    if (encoded !== raw) encoded.fill(0)
                }
            } finally {
                raw.fill(0)
            }
        }.getOrNull()
    }

    fun encryptExistingPlainFileInPlace(file: File): Boolean {
        if (!file.exists()) return false
        return runCatching {
            val raw = BoundedInputReader.readFile(file, BoundedInputReader.MAX_ENCRYPTED_IMAGE_BYTES, "Öğrenci görüntüsü")
            try {
                if (raw.startsWithMagic()) {
                    // Encrypted does not mean readable. Never report success if its key is unavailable.
                    val plain = decrypt(raw)
                    plain.fill(0)
                    return@runCatching true
                }
                writeEncrypted(file, raw)
                isEncrypted(file)
            } finally {
                raw.fill(0)
            }
        }.getOrDefault(false)
    }

    fun isEncrypted(file: File): Boolean = runCatching {
        if (!file.exists() || file.length() < MAGIC.size) false
        else file.inputStream().use { input ->
            val prefix = ByteArray(MAGIC.size)
            input.read(prefix) == MAGIC.size && prefix.contentEquals(MAGIC)
        }
    }.getOrDefault(false)

    private fun writeEncrypted(file: File, plain: ByteArray) {
        file.parentFile?.mkdirs()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKeyForEncrypt(file))
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain)
        val atomic = AtomicFile(file)
        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomic.startWrite()
            stream.write(MAGIC)
            stream.write(iv.size)
            stream.write(iv)
            stream.write(encrypted)
            atomic.finishWrite(stream)
            stream = null
            check(isEncrypted(file)) { "Şifreli öğrenci görüntüsü yazma sonrası doğrulanamadı." }
        } catch (error: Throwable) {
            stream?.let { runCatching { atomic.failWrite(it) } }
            throw IllegalStateException("Öğrenci görüntüsü crash-safe biçimde şifrelenemedi.", error)
        } finally {
            encrypted.fill(0)
            iv.fill(0)
        }
    }

    private fun decrypt(raw: ByteArray): ByteArray {
        require(raw.startsWithMagic()) { "BaykuşNot şifreli görüntü başlığı bulunamadı." }
        val ivLenOffset = MAGIC.size
        val ivLen = raw[ivLenOffset].toInt() and 0xFF
        require(ivLen in 12..32 && raw.size > ivLenOffset + 1 + ivLen) { "Şifreli görüntü biçimi geçersiz." }
        val ivStart = ivLenOffset + 1
        val iv = raw.copyOfRange(ivStart, ivStart + ivLen)
        val encrypted = raw.copyOfRange(ivStart + ivLen, raw.size)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, existingKeyOrThrow(), GCMParameterSpec(128, iv))
            cipher.doFinal(encrypted)
        } catch (e: StudentImageKeyRecoveryRequiredException) {
            throw e
        } catch (e: Throwable) {
            throw StudentImageKeyRecoveryRequiredException(
                "Öğrenci görüntüsü şifreleme anahtarı kayıtlı görüntüyü açamadı. Yeni anahtar üretilmedi.",
                e
            )
        } finally {
            iv.fill(0)
            encrypted.fill(0)
        }
    }

    private fun existingKeyOrThrow(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            throw StudentImageKeyRecoveryRequiredException(
                "Öğrenci görüntüsü Keystore anahtarı bulunamıyor. Mevcut şifreli görüntüler korunuyor."
            )
        }
        return try {
            keyStore.getKey(KEY_ALIAS, null) as? SecretKey
                ?: throw StudentImageKeyRecoveryRequiredException("Öğrenci görüntüsü Keystore kaydı geçersiz.")
        } catch (e: StudentImageKeyRecoveryRequiredException) {
            throw e
        } catch (e: Throwable) {
            throw StudentImageKeyRecoveryRequiredException("Öğrenci görüntüsü Keystore anahtarı açılamadı.", e)
        }
    }

    private fun getOrCreateKeyForEncrypt(target: File): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (runCatching { keyStore.getKey(KEY_ALIAS, null) as? SecretKey }.getOrNull())?.let { return it }

        // If any sibling/ancestor paper_uploads corpus is already encrypted, missing key material
        // is a recovery event, not a first-install event. Never silently fork a second key epoch.
        val paperRoot = generateSequence(target.parentFile) { it.parentFile }
            .firstOrNull { it.name == "paper_uploads" }
        if (paperRoot != null && paperRoot.exists()) {
            val hasExistingEncrypted = paperRoot.walkTopDown().any { it.isFile && it != target && isEncrypted(it) }
            if (hasExistingEncrypted) {
                throw StudentImageKeyRecoveryRequiredException(
                    "Mevcut şifreli öğrenci görüntüleri varken görüntü anahtarı bulunamıyor; yeni anahtar üretilmedi."
                )
            }
        }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        keyGenerator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return keyGenerator.generateKey()
    }

    private fun ByteArray.startsWithMagic(): Boolean = size >= MAGIC.size && copyOfRange(0, MAGIC.size).contentEquals(MAGIC)
}
