package com.example.core.security

import com.example.BuildConfig
import java.security.MessageDigest

/** Build/deployment-bound external processor data policy used by the YAZEK fail-closed gate. */
data class ProviderDataProtectionProfile(
    val operator: String,
    val retentionDays: Int,
    val datasetSharingDisabled: Boolean,
    val accessRoles: String
) {
    fun validationProblems(): List<String> = buildList {
        if (operator.isBlank()) add("harici veri işleyen/sağlayıcı")
        if (retentionDays !in ALLOWED_RETENTION_DAYS) add("sağlayıcı log saklama süresi (0/7/14/28/55 gün)")
        if (!datasetSharingDisabled) add("model/dataset paylaşımı kapalı doğrulaması")
        if (accessRoles.isBlank()) add("veriye erişebilen yetkili roller")
    }

    fun requireReady() {
        val problems = validationProblems()
        require(problems.isEmpty()) {
            "Production veri koruma profili eksik: ${problems.joinToString(", ")}. Öğrenci verisi dış AI hizmetine gönderilemez."
        }
    }

    fun canonicalText(): String = listOf(
        operator.trim(), retentionDays.toString(), datasetSharingDisabled.toString(), accessRoles.trim()
    ).joinToString("|")

    fun signature(): String = MessageDigest.getInstance("SHA-256")
        .digest(canonicalText().toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    fun noticeText(): String = buildString {
        append("Harici veri işleyen/AI sağlayıcısı: ").append(operator).append(". ")
        append("Sağlayıcı/gateway log saklama profili: ").append(retentionDays).append(" gün. ")
        append("Model/dataset geliştirme amaçlı paylaşım: ").append(if (datasetSharingDisabled) "kapalı" else "DOĞRULANMADI").append(". ")
        append("Yetkili erişim rolleri: ").append(accessRoles.ifBlank { "DOĞRULANMADI" }).append(".")
    }

    companion object {
        private val ALLOWED_RETENTION_DAYS = setOf(0, 7, 14, 28, 55)
        fun current(): ProviderDataProtectionProfile = if (BuildConfig.ALLOW_DIRECT_GEMINI) {
            // Debug-only deterministic profile for developer/unit-test flows. Production release
            // never takes this branch and must supply explicit deployment policy fields.
            ProviderDataProtectionProfile(
                operator = "DEBUG developer Gemini transport — production için geçersiz",
                retentionDays = 0,
                datasetSharingDisabled = true,
                accessRoles = "Yalnız geliştirici test oturumu"
            )
        } else {
            ProviderDataProtectionProfile(
                operator = BuildConfig.PROVIDER_OPERATOR,
                retentionDays = BuildConfig.PROVIDER_RETENTION_DAYS,
                datasetSharingDisabled = BuildConfig.PROVIDER_DATASET_SHARING_DISABLED,
                accessRoles = BuildConfig.PROVIDER_ACCESS_ROLES
            )
        }
    }
}
