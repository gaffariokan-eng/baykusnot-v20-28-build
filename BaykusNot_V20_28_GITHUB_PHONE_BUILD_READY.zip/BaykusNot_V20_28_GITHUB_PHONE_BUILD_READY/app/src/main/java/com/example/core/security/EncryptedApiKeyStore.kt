package com.example.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class EncryptedApiKeyStore(context: Context) : SecureApiKeyStore {

    private val sharedPreferences = context.getSharedPreferences("secure_api_prefs", Context.MODE_PRIVATE)

    private val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply {
        load(null)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        return if (keyStore.containsAlias(KEY_ALIAS)) {
            (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
        } else {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(keyGenParameterSpec)
            keyGenerator.generateKey()
        }
    }

    override suspend fun saveApiKey(apiKey: String) = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        require(trimmedKey.isNotBlank()) { "API anahtarı boş olamaz." }
        val secretKey = getOrCreateSecretKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)

        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(trimmedKey.toByteArray(Charsets.UTF_8))

        val ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val encryptedBase64 = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)

        check(
            sharedPreferences.edit()
                .putString(KEY_IV, ivBase64)
                .putString(KEY_API_KEY_ENCRYPTED, encryptedBase64)
                .commit()
        ) { "API anahtarı cihazda güvenli biçimde kaydedilemedi." }
    }

    override suspend fun hasApiKey(): Boolean = withContext(Dispatchers.IO) {
        val encryptedBase64 = sharedPreferences.getString(KEY_API_KEY_ENCRYPTED, null)
        val ivBase64 = sharedPreferences.getString(KEY_IV, null)
        if (encryptedBase64.isNullOrBlank() || ivBase64.isNullOrBlank()) {
            return@withContext false
        }
        try {
            val iv = Base64.decode(ivBase64, Base64.DEFAULT)
            val encryptedBytes = Base64.decode(encryptedBase64, Base64.DEFAULT)
            if (iv.isEmpty() || encryptedBytes.isEmpty()) {
                return@withContext false
            }
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val gcmSpec = javax.crypto.spec.GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
            cipher.doFinal(encryptedBytes)
            true
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun deleteApiKey() = withContext(Dispatchers.IO) {
        check(
            sharedPreferences.edit()
                .remove(KEY_API_KEY_ENCRYPTED)
                .remove(KEY_IV)
                .commit()
        ) { "API anahtarı cihazdan güvenli biçimde silinemedi." }
    }

    override suspend fun <T> useApiKey(block: suspend (String) -> T): T? = withContext(Dispatchers.IO) {
        val encryptedBase64 = sharedPreferences.getString(KEY_API_KEY_ENCRYPTED, null)
        val ivBase64 = sharedPreferences.getString(KEY_IV, null)
        if (encryptedBase64.isNullOrBlank() || ivBase64.isNullOrBlank()) {
            return@withContext null
        }
        val apiKey = try {
            val iv = Base64.decode(ivBase64, Base64.DEFAULT)
            val encryptedBytes = Base64.decode(encryptedBase64, Base64.DEFAULT)
            if (iv.isEmpty() || encryptedBytes.isEmpty()) {
                return@withContext null
            }
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val gcmSpec = javax.crypto.spec.GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
            val decryptedBytes = cipher.doFinal(encryptedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }

        if (apiKey.isNullOrBlank()) {
            null
        } else {
            block(apiKey)
        }
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "gemini_api_key_alias"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val KEY_API_KEY_ENCRYPTED = "gemini_api_key_encrypted"
        private const val KEY_IV = "gemini_api_key_iv"
    }
}
