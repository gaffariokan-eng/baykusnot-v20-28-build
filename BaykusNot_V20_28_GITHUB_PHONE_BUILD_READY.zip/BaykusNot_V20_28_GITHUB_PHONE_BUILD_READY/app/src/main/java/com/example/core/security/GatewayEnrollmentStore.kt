package com.example.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Stores only the institution-issued gateway enrollment credential, never a Gemini credential.
 * The value is encrypted with Android Keystore and can be revoked by the institution gateway.
 */
class GatewayEnrollmentStore(context: Context) {
    private val prefs = context.getSharedPreferences("gateway_enrollment_v1", Context.MODE_PRIVATE)

    suspend fun save(value: String) = withContext(Dispatchers.IO) {
        val normalized = value.trim()
        require(normalized.length >= 16) { "Kurumsal gateway eşleştirme kodu geçersiz." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(normalized.toByteArray(Charsets.UTF_8))
        check(
            prefs.edit()
                .putString(KEY_IV, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString(KEY_VALUE, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .commit()
        ) { "Kurumsal gateway eşleştirmesi cihazda kalıcı ve güvenli biçimde kaydedilemedi." }
    }

    suspend fun read(): String? = withContext(Dispatchers.IO) {
        val iv = prefs.getString(KEY_IV, null) ?: return@withContext null
        val encrypted = prefs.getString(KEY_VALUE, null) ?: return@withContext null
        runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateKey(),
                GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP))
            )
            String(cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    suspend fun hasEnrollment(): Boolean = !read().isNullOrBlank()

    suspend fun clear() = withContext(Dispatchers.IO) {
        check(prefs.edit().remove(KEY_IV).remove(KEY_VALUE).commit()) {
            "Kurumsal gateway eşleştirme bilgisi cihazdan temizlenemedi."
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "baykusnot_gateway_enrollment_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val KEY_IV = "iv"
        private const val KEY_VALUE = "value"
    }
}
