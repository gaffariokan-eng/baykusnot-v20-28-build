package com.example.core.security

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/**
 * Memory-bounded bitmap decoder for user/student supplied raster images.
 * Reads dimensions first and samples large camera images before allocating pixel memory.
 */
object SafeBitmapDecoder {
    const val MAX_SOURCE_PIXELS: Long = 200_000_000L
    const val MAX_DECODE_PIXELS: Long = 6_000_000L
    const val MAX_DECODE_DIMENSION: Int = 3200

    fun decodeUri(
        context: Context,
        uri: Uri,
        maxDecodePixels: Long = MAX_DECODE_PIXELS,
        maxDecodeDimension: Int = MAX_DECODE_DIMENSION
    ): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: return null
        val options = decodeOptions(bounds, maxDecodePixels, maxDecodeDimension)
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
    }

    fun decodeFile(
        file: File,
        maxDecodePixels: Long = MAX_DECODE_PIXELS,
        maxDecodeDimension: Int = MAX_DECODE_DIMENSION
    ): Bitmap? {
        if (!file.exists() || !file.isFile) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        val options = decodeOptions(bounds, maxDecodePixels, maxDecodeDimension)
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    fun decodeByteArray(
        bytes: ByteArray,
        maxDecodePixels: Long = MAX_DECODE_PIXELS,
        maxDecodeDimension: Int = MAX_DECODE_DIMENSION
    ): Bitmap? {
        if (bytes.isEmpty()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val options = decodeOptions(bounds, maxDecodePixels, maxDecodeDimension)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }

    private fun decodeOptions(
        bounds: BitmapFactory.Options,
        maxDecodePixels: Long,
        maxDecodeDimension: Int
    ): BitmapFactory.Options {
        val width = bounds.outWidth
        val height = bounds.outHeight
        require(width > 0 && height > 0) { "Görsel boyutları okunamadı." }
        val sourcePixels = width.toLong() * height.toLong()
        require(sourcePixels <= MAX_SOURCE_PIXELS) {
            "Görsel güvenli piksel sınırını aşıyor; daha düşük çözünürlüklü bir kopya kullanın."
        }

        var sample = 1
        while (
            width / sample > maxDecodeDimension ||
            height / sample > maxDecodeDimension ||
            (width.toLong() / sample) * (height.toLong() / sample) > maxDecodePixels
        ) {
            sample *= 2
        }
        return BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
    }
}
