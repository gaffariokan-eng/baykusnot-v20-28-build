#!/usr/bin/env python3
"""V20.28 negative governance/scale oracle.
Uses an ephemeral P-256 key only in memory; no release private key is created or persisted.
"""
from pathlib import Path
import base64, time
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidSignature

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

store=text('app/src/main/java/com/example/core/network/GeminiModelProfileStore.kt')
registry=text('app/src/main/java/com/example/core/network/GeminiModelRegistry.kt')
repo=text('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
db=text('app/src/main/java/com/example/core/database/AppDatabase.kt')
build=text('app/build.gradle.kts')
settings=text('app/src/main/java/com/example/feature/settings/ApiKeySettingsScreen.kt')
signer=text('tools/model_benchmark/approval_signing.py')
release_bat=text('BAYKUSNOT_BUILD_V20_28_RELEASE_APK.bat')

# Actual cryptographic negative oracle: valid, tampered, and wrong-key behavior.
priv=ec.generate_private_key(ec.SECP256R1())
pub=priv.public_key(); other=ec.generate_private_key(ec.SECP256R1()).public_key()
now=int(time.time())
payload=(f'BNBENCH4|model=gemini-3.6-flash|role=EVALUATION|protocol=BN-EVAL-B|cases=20'
         f'|within=0.960000|sim=0.910000|recall=0.960000|mae=0.100000|dataset=REAL_ANONYMIZED|coverage=PASS'
         f'|highTokens=1120|highMedia=1|batch=1|cache=1|thinking=1|promptPolicySha256=abc|responseSchemaSha256=def|evaluationEngineRevision=BN-EVAL-ENGINE-V20.28|decision=ADOPT|ts={now}|expires={now+86400}')
sig=priv.sign(payload.encode(), ec.ECDSA(hashes.SHA256()))
def verifies(key,p,s):
    try: key.verify(s,p.encode(),ec.ECDSA(hashes.SHA256())); return True
    except InvalidSignature: return False
check('Ephemeral P-256 valid signature verifies', verifies(pub,payload,sig))
check('Tampered BNBENCH4 payload is rejected', not verifies(pub,payload.replace('within=0.960000','within=0.990000'),sig))
check('Wrong signing key is rejected', not verifies(other,payload,sig))
check('Signature is standard Base64 transportable', base64.b64decode(base64.b64encode(sig))==sig)

check('Runtime accepts only BNBENCH4', 'parts.firstOrNull() == "BNBENCH4"' in store)
check('Unsigned BNBENCH3 cannot grant approval', 'KEY_APPROVED_BENCHMARK_RECORDS_V3' in store and 'legacy unsigned; ignored' in store)
check('Runtime verifies SHA256withECDSA', 'Signature.getInstance("SHA256withECDSA")' in store)
check('Runtime enforces REAL_ANONYMIZED and role thresholds', 'DATASET_REAL_ANONYMIZED' in store and 'passesRoleThresholds(it)' in store)
check('Runtime approval snapshot carries expiry', 'Map<String, Long>' in registry and 'hasCurrentApproval' in registry and 'expiresAt' in registry)
check('Locked exam profile revalidates signed approvals', 'evaluationApproved' in repo and 'feedbackApproved' in repo and 'authoringApproved' in repo and 'imzalı üretim model onayı' in repo)
check('Release build requires signed manifest/public key', 'MODEL_APPROVAL_PUBLIC_KEY_B64' in build and 'MODEL_APPROVAL_MANIFEST_B64' in build and 'verifyReleaseModelApprovals' in build)
check('Release gate enforces role quality thresholds', all(x in build for x in ['within', 'consistency', 'extraction', 'coverage PASS']))
check('Release gate binds evaluation capability profile', all(x in build for x in ['highTokens', 'highMedia', 'batch', 'cache', 'thinking', '1120']))
check('Release gate binds prompt/schema fingerprints', all(x in build for x in ['promptPolicySha256','responseSchemaSha256','evaluationEngineRevision']))
check('Release BAT requires approval variables', 'BAYKUS_MODEL_APPROVAL_PUBLIC_KEY_B64' in release_bat and 'BAYKUS_MODEL_APPROVAL_MANIFEST_B64' in release_bat)
check('Private signing key is external-only', '--private-key' in text('tools/model_benchmark/sign_release_approvals.py') and 'private key' in signer.lower())
check('Teacher manual approval entry is debug-only', 'if (BuildConfig.DEBUG)' in settings)

check('Room version 30 contains Teacher Mode migration', 'version = 30' in db and 'MIGRATION_29_30' in db)
check('Teacher Mode migration canonicalizes hidden fields', all(x in db for x in ["`evaluationMode` = 'PAPER_BY_PAPER'", "`rubricAdherenceLevel` = 'BALANCED'", "`useBatchApi` = 0", "`usePromptCaching` = 1"]))
check('Durable evaluation run-state is persisted', 'ExamEvaluationRunStateEntity' in repo and 'persistEvaluationRunState' in repo)
check('Large classes auto-route to Batch at 50+', 'LARGE_EXAM_AUTO_BATCH_THRESHOLD = 50' in repo and 'largeExamAutoBatch' in repo)
check('Process-death RUNNING work resumes', 'resumeDurableEvaluationIfNeeded' in repo and 'state?.status != "RUNNING"' in repo)
check('PAUSED and ERROR never auto-resume even with remote Batch', 'if (state?.status != "RUNNING") return false' in repo)
check('Pause guard blocks crash-window auto-resume', 'evaluationPauseGuard?.isPaused(examDraftId) == true' in repo)
check('User stop uses durable remote-cancel pause boundary', 'pauseEvaluationAndCancelRemote' in repo and 'PAUSE_REMOTE_CANCEL_PENDING' in repo and 'manager.cleanupDraft(examDraftId, key)' in repo)

# No private PEM/PKCS8 material may be present in source package.
private_markers=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or any(x in p.parts for x in ('.gradle','build')): continue
    if p.suffix.lower() in {'.pem','.key','.p8','.pk8'}:
        private_markers.append(str(p.relative_to(ROOT)))
check('No private-key file is packaged', not private_markers)

failed=[n for n,ok in checks if not ok]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit('FAILED: '+', '.join(failed))
