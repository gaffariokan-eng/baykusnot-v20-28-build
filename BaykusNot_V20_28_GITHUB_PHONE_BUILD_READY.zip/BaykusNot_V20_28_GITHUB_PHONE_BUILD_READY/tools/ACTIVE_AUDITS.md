# V20.28 Active Audits

V20.28 için aktif sürüme özel denetimler `tools/v20_28_*.py` dosyalarıdır. Genel denetimler `static_audit.py`, `semantic_flow_audit.py`, `transactional_flow_audit.py`, `runtime_lifecycle_audit.py`, `validate_room_schema_migrations.py`, `kotlin_psi_audit.kt`, `kotlin_call_shape_audit.kt` ve `kotlin_explicit_unit_return_audit.kt` dosyalarıdır.

V20.27 ve daha eski scriptler `tools/historical/` altında tarihsel kanıttır; aktif sürüm PASS kararı için kullanılmaz.
