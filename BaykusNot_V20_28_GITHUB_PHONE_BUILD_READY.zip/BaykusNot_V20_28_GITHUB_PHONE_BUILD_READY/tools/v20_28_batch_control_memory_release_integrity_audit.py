#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def t(rel): return (ROOT/rel).read_text(encoding='utf-8',errors='ignore')
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
repo=t('app/src/main/java/com/example/core/data/ExamEvaluationRepository.kt')
vm=t('app/src/main/java/com/example/feature/workflow/AiEvaluationViewModel.kt')
reports=t('app/src/main/java/com/example/feature/workflow/ReportsScreen.kt')
build=t('app/build.gradle.kts')
store=t('app/src/main/java/com/example/core/network/GeminiModelProfileStore.kt')
score=t('tools/model_benchmark/score_results.py')
feedback=t('tools/model_benchmark/score_feedback_results.py')
author=t('tools/model_benchmark/score_authoring_results.py')
signer=t('tools/model_benchmark/sign_release_approvals.py')
fp=t('tools/model_benchmark/governance_fingerprint.py')
manager=t('app/src/main/java/com/example/core/network/GeminiBatchJobManager.kt')

check('User pause invokes remote cancellation cleanup', 'pauseEvaluationAndCancelRemote' in repo and 'manager.cleanupDraft(examDraftId, key)' in repo)
check('Pause pending remote cancellation is durable', 'PAUSE_REMOTE_CANCEL_PENDING' in repo and 'persistEvaluationRunState' in repo)
check('Cancellation handler preserves remote-pause state', 'current?.status !in setOf("PAUSE_REQUESTED", "PAUSE_REMOTE_CANCEL_PENDING")' in repo)
check('Crash-window PAUSE_REQUESTED is retried on screen return', 'state.status !in setOf("PAUSE_REQUESTED", "PAUSE_REMOTE_CANCEL_PENDING")' in repo)
check('New evaluation blocked while remote cancellation pending', 'Önceki uzak Batch iptali/temizliği tamamlanmadan yeni değerlendirme başlatılamaz.' in repo)
pause_retry=repo[repo.find('suspend fun retryPendingPauseRemoteCleanup'):repo.find('/** Compatibility entry point', repo.find('suspend fun retryPendingPauseRemoteCleanup'))]
check('Pause cleanup retry never resumes evaluation', 'retryPendingPauseRemoteCleanup' in pause_retry and 'startEvaluation(' not in pause_retry)
check('ViewModel uses remote-cancel pause API', 'pauseEvaluationAndCancelRemote(examDraftId)' in vm)
check('Provider cancel endpoint exists', ':cancel' in manager and 'remoteCancel' in manager)

batch_seg=repo[repo.find('// V20.26: true incremental Batch production'):repo.find('// 2. Poll all active/unprocessed batch jobs')]
check('Batch requests are produced incrementally', 'submitCurrentChunk()' in batch_seg and 'for (paper in eligiblePapers)' in batch_seg)
check('All-class request list removed', 'val requests = mutableListOf<Pair<Long, String>>()' not in batch_seg)
check('All-class chunks list removed', 'val chunks = mutableListOf' not in batch_seg)
check('Batch memory chunk bound is 15 MB', 'maxChunkSizeBytes = 15L * 1024 * 1024' in batch_seg)
check('Batch sizing uses UTF-8 bytes', 'reqBody.toByteArray(Charsets.UTF_8).size.toLong()' in batch_seg)
check('Oversized single request flushes immediately', 'reqBytes > 2L * 1024 * 1024' in batch_seg)

check('Class report UI paginates at 50 rows', 'classStudentPageSize = 50' in reports and 'visibleClassStudents' in reports)
check('Question report UI paginates at 50 rows', 'questionStudentPageSize = 50' in reports and 'visibleQuestionStudents' in reports)
check('Class full-list eager loop removed', 'sortedStudents.forEach { student ->' not in reports)
check('Question full-list eager loop removed', 'qReport.students.forEach { std ->' not in reports)

check('Gradle release deployment guard exists', 'verifyReleaseDeploymentConfig' in build)
check('Gradle release guard enforces HTTPS gateway', 'BAYKUS_AI_GATEWAY_URL' in build and 'startsWith("https://"' in build)
check('Gradle release guard enforces provider retention', 'BAYKUS_PROVIDER_RETENTION_DAYS' in build and 'setOf(0, 7, 14, 28, 55)' in build)
check('Gradle release guard enforces dataset sharing disabled', 'BAYKUS_PROVIDER_DATASET_SHARING_DISABLED' in build)
check('Gradle release guard enforces access roles and signing', 'BAYKUS_PROVIDER_ACCESS_ROLES' in build and 'KEYSTORE_PATH' in build and 'STORE_PASSWORD' in build and 'KEY_PASSWORD' in build)
check('preReleaseBuild depends on deployment and model guards', 'dependsOn(verifyReleaseDeploymentConfig)' in build and 'dependsOn(verifyReleaseModelApprovals)' in build)

for field in ('promptPolicySha256','responseSchemaSha256','evaluationEngineRevision'):
    check(f'BNBENCH4 runtime binds {field}', field in store)
    check(f'BNBENCH4 release gate binds {field}', field in build)
    check(f'Evaluation scorer emits {field}', field in score)
    check(f'Feedback scorer emits {field}', field in feedback)
    check(f'Authoring scorer emits {field}', field in author)
check('Signer rejects stale source fingerprints', 'candidate bu kaynak ağacının prompt/schema/engine fingerprintiyle eşleşmiyor' in signer)
check('Fingerprint helper covers all three roles', all(role in fp for role in ('EVALUATION','FEEDBACK','AUTHORING')))
check('Engine revision is V20.28-bound', all(x in build for x in ('BN-EVAL-ENGINE-V20.28','BN-FEEDBACK-ENGINE-V20.28','BN-AUTHOR-ENGINE-V20.28')))

check('V20.28 app version active', 'versionCode = 29' in build and 'versionName = "1.26-v20.28"' in build)
check('V20.28 marker exists', (ROOT/'BAYKUSNOT_SOURCE_V20_28_FINAL_APPROVAL_TEXT_MEMORY_LIVE_MONITOR_IMPORT_LIFECYCLE_HARDENED.marker').exists())

# Algorithm oracle: a one-byte source change must change the governance fingerprint.
def alg(label, items):
    h=hashlib.sha256(); h.update(label.encode()); h.update(b'\0')
    for path,data in sorted(items):
        h.update(path.encode()); h.update(b'\0'); h.update(data); h.update(b'\0')
    return h.hexdigest()
a=alg('EVALUATION_PROMPT',[('/app/x.kt',b'abc')])
b=alg('EVALUATION_PROMPT',[('/app/x.kt',b'abd')])
check('Fingerprint oracle changes on source mutation', a != b and len(a)==64 and len(b)==64)

failed=[n for n,ok in checks if not ok]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: print('FAILED: '+', '.join(failed))
sys.exit(1 if failed else 0)
