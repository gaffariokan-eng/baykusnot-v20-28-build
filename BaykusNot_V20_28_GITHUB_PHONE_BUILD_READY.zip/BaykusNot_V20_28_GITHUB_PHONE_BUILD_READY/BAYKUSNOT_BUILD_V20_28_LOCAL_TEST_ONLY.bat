@echo off
setlocal
cd /d "%~dp0"
title BaykusNot V20.28 Local Debug Build
if not exist "BAYKUSNOT_SOURCE_V20_28_FINAL_APPROVAL_TEXT_MEMORY_LIVE_MONITOR_IMPORT_LIFECYCLE_HARDENED.marker" goto :badsource
call gradlew.bat --no-daemon --no-configuration-cache --console=plain --stacktrace assembleDebug
if errorlevel 1 goto :failed
echo DEBUG BUILD SUCCESS. Production model approvals are not bypassed; AI remains fail-closed without a valid signed BNBENCH4 record.
goto :finish
:badsource
echo HATA: V20.28 kaynak marker bulunamadi.
goto :failed
:failed
echo DERLEME TAMAMLANAMADI.
:finish
pause
endlocal
